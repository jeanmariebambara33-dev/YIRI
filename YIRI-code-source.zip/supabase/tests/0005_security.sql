-- Tests de sécurité de la migration 0005 : faux utilisateurs, scénarios négatifs.
-- Exécutés sur une base LOCALE vide (voir run-local.sh). Les « auth.uid() » sont simulés.
\o /dev/null
create schema t;
create table t.results (id serial, label text, pass boolean, detail text);
grant usage on schema t to anon, authenticated;

-- enregistre un résultat (SECURITY DEFINER : les utilisateurs de test ne peuvent pas écrire dans t.results)
create function t.rec(label text, pass boolean, detail text default null) returns void
language plpgsql security definer as $$ begin insert into t.results(label, pass, detail) values (label, pass, detail); end $$;
grant execute on function t.rec(text, boolean, text) to anon, authenticated;

create function t.u(n int) returns uuid language sql immutable as $$ select ('00000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
create function t.p(n int) returns uuid language sql immutable as $$ select ('aaaaaaaa-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
create function t.b(n int) returns uuid language sql immutable as $$ select ('bbbbbbbb-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
grant execute on function t.u(int), t.p(int), t.b(int) to anon, authenticated;

-- change d'identité : 0 = visiteur non connecté, sinon utilisateur n°n (connecté)
create function t.as(n int) returns void language plpgsql as $$
begin
  perform set_config('app.uid', case when n = 0 then '' else t.u(n)::text end, false);
  execute case when n = 0 then 'set role anon' else 'set role authenticated' end;
end $$;

-- doit échouer (erreur de droits, contrainte, garde…)
create function t.must_fail(label text, q text) returns void language plpgsql as $$
begin
  begin execute q; perform t.rec(label, false, 'aurait dû être refusé');
  exception when others then perform t.rec(label, true, sqlerrm); end;
end $$;
-- doit réussir
create function t.ok(label text, q text) returns void language plpgsql as $$
begin
  begin execute q; perform t.rec(label, true);
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
-- nombre de lignes affectées (UPDATE/DELETE) attendu
create function t.rows(label text, q text, expected int) returns void language plpgsql as $$
declare n int;
begin
  begin execute q; get diagnostics n = row_count; perform t.rec(label, n = expected, 'lignes : ' || n);
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
-- nombre de lignes renvoyées par une requête
create function t.cnt(label text, q text, expected int) returns void language plpgsql as $$
declare n int;
begin
  begin execute 'select count(*) from (' || q || ') s' into n; perform t.rec(label, n = expected, 'lignes : ' || n);
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
-- une valeur attendue
create function t.eq(label text, q text, expected text) returns void language plpgsql as $$
declare v text;
begin
  begin execute q into v; perform t.rec(label, v is not distinct from expected, 'valeur : ' || coalesce(v, 'NULL'));
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
grant execute on function t.must_fail(text, text), t.ok(text, text), t.rows(text, text, int), t.cnt(text, text, int), t.eq(text, text, text) to anon, authenticated;

-- ====================== Données de test (en tant qu'administrateur de la base) ======================
-- Utilisateurs : 1=voyageur A, 2=voyageur B, 3=propriétaire O1, 4=propriétaire O2, 5=ADMIN,
-- 6=équipe « validation », 7=équipe « reservations », 8=équipe « paiements », 9=équipe « audit »,
-- 10=équipe « demandes », 11=équipe « partenariat »
insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 11) n;
-- un inscrit qui essaie de s'attribuer le rôle admin via ses métadonnées : doit rester simple voyageur
insert into auth.users (id, email, raw_user_meta_data) values (t.u(12), 'pirate@test.local', '{"full_name":"Pirate","role":"admin"}');

insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(4), 'proprietaire'), (t.u(5), 'admin'), (t.u(6), 'proprietaire');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'reservations', t.u(5)), (t.u(8), 'paiements', t.u(5)),
  (t.u(9), 'audit', t.u(5)), (t.u(10), 'demandes', t.u(5)), (t.u(11), 'partenariat', t.u(5));

insert into properties (id, owner_id, offer, title, description, city, district, private_address, capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo) values
 (t.p(1), t.u(3), 'annonce', 'Maison O1', 'desc', 'Banfora', 'Secteur 3', 'rue secrète 12', 4, 2, 2, 18000, 1, 'publiee', false),
 (t.p(2), t.u(4), 'annonce', 'Maison O2', 'desc', 'Dori', 'Centre', 'rue secrète 99', 3, 1, 2, 15000, 1, 'publiee', false),
 (t.p(3), t.u(3), 'gestion', 'Villa gérée', 'desc', 'Ouagadougou', 'Ouaga 2000', 'adresse gérée', 6, 3, 4, 50000, 1, 'publiee', false),
 (t.p(4), t.u(3), 'annonce', 'Brouillon O1', 'desc', 'Kaya', 'Centre', 'adresse 4', 2, 1, 1, 10000, 1, 'brouillon', false),
 (t.p(5), t.u(3), 'annonce', 'Soumise O1', 'desc', 'Kaya', 'Centre', 'adresse 5', 2, 1, 1, 10000, 1, 'soumise', false),
 (t.p(6), t.u(3), 'annonce', 'Publiée O1 (test majeur)', 'desc', 'Kaya', 'Centre', 'adresse 6', 2, 1, 1, 10000, 1, 'publiee', false),
 (t.p(7), t.u(3), 'annonce', 'Publiée O1 (test photos)', 'desc', 'Kaya', 'Centre', 'adresse 7', 2, 1, 1, 10000, 1, 'publiee', false),
 (t.p(8), t.u(3), 'annonce', 'Publiée O1 (test contact)', 'desc', 'Kaya', 'Centre', 'adresse 8', 2, 1, 1, 10000, 1, 'publiee', false),
 (t.p(9), t.u(6), 'annonce', 'Soumise par un membre équipe', 'desc', 'Kaya', 'Centre', 'adresse 9', 2, 1, 1, 10000, 1, 'soumise', false),
 (t.p(10), t.u(3), 'annonce', 'Soumise O1 (refus)', 'desc', 'Kaya', 'Centre', 'adresse 10', 2, 1, 1, 10000, 1, 'soumise', false),
 (t.p(11), t.u(3), 'annonce', 'Soumise O1 (correction)', 'desc', 'Kaya', 'Centre', 'adresse 11', 2, 1, 1, 10000, 1, 'soumise', false);
insert into subscriptions (owner_id, property_id, plan, amount_xof, status, starts_at, ends_at) values
 (t.u(3), t.p(1), 'mensuel', 5000, 'actif', current_date - 1, current_date + 30),
 (t.u(4), t.p(2), 'mensuel', 5000, 'actif', current_date - 1, current_date + 30);
insert into subscriptions (id, owner_id, property_id, plan, amount_xof, status) values
 ('cccccccc-0000-0000-0000-000000000001', t.u(3), t.p(5), 'mensuel', 5000, 'en_attente_paiement');
insert into management_agreements (property_id, contract_version, starts_on, signed, operational_check_done, expense_policy_version)
 values (t.p(3), 'v1', current_date, true, true, 'v1');
insert into property_contacts (property_id, contact_name, phone, whatsapp) values
 (t.p(1), 'Contact O1', '+226 70 00 00 01', true), (t.p(2), 'Contact O2', '+226 70 00 00 02', false), (t.p(8), 'Contact O1 bis', '+226 70 00 00 08', false);
insert into property_photos (property_id, storage_path, position, rights_checked) values
 (t.p(1), t.u(3) || '/' || t.p(1) || '/a.jpg', 0, true), (t.p(1), t.u(3) || '/' || t.p(1) || '/b.jpg', 1, false),
 (t.p(4), t.u(3) || '/' || t.p(4) || '/c.jpg', 0, false), (t.p(7), t.u(3) || '/' || t.p(7) || '/d.jpg', 0, true);
insert into storage.buckets (id, name) values ('property-photos', 'property-photos') on conflict do nothing;
insert into storage.objects (bucket_id, name) select 'property-photos', storage_path from property_photos;
insert into contact_views (property_id, viewer_id) values (t.p(1), t.u(1)), (t.p(1), t.u(2)), (t.p(1), null);

-- Réservations sur la villa gérée (p3) : confirmée, blocage en cours, blocage expiré
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values
 (t.b(1), t.p(3), t.u(1), daterange(current_date + 10, current_date + 13), 2, 50000, 150000, 150000, 'confirmee', null),
 (t.b(2), t.p(3), t.u(2), daterange(current_date + 20, current_date + 22), 2, 50000, 100000, 100000, 'en_attente_paiement', now() + interval '15 minutes'),
 (t.b(3), t.p(3), t.u(1), daterange(current_date + 30, current_date + 32), 2, 50000, 100000, 100000, 'en_attente_paiement', now() - interval '1 hour');
insert into payment_transactions (id, purpose, booking_id, idempotency_key, amount_xof, status) values
 ('dddddddd-0000-0000-0000-000000000001', 'booking', t.b(2), 'k-b2', 100000, 'en_attente');
insert into audit_logs (actor_id, action, entity_type, entity_id) values (t.u(5), 'test', 'x', '1');

-- ====================== 0. Inscription ======================
select t.cnt('inscription : un profil est créé pour chaque compte', 'select 1 from profiles', 12);
select t.cnt('inscription : chaque compte reçoit le rôle voyageur', $$select 1 from user_roles where role = 'voyageur'$$, 12);
select t.cnt('inscription : un rôle « admin » dans les métadonnées est ignoré', $$select 1 from user_roles where user_id = t.u(12) and role <> 'voyageur'$$, 0);

-- ====================== 1. Visiteur non connecté ======================
reset role; select t.as(0);
select t.cnt('visiteur : aucune annonce brute lisible', 'select 1 from properties', 0);
select t.cnt('visiteur : aucun contact propriétaire lisible', 'select 1 from property_contacts', 0);
select t.cnt('visiteur : aucune réservation lisible', 'select 1 from bookings', 0);
select t.cnt('visiteur : aucun profil lisible', 'select 1 from profiles', 0);
select t.cnt('visiteur : aucune demande propriétaire lisible', 'select 1 from owner_leads', 0);
select t.cnt('visiteur : aucun paiement lisible', 'select 1 from payment_transactions', 0);
select t.cnt('visiteur : aucun avis de paiement lisible', 'select 1 from payment_notices', 0);
select t.must_fail('visiteur : aucune consultation de contact lisible', 'select 1 from contact_views');
select t.cnt('visiteur : la vue publique ne montre que les 3 annonces publiables', 'select 1 from public_listings', 3);
select t.must_fail('visiteur : la vue publique n''expose pas l''adresse privée', 'select private_address from public_listings');
select t.cnt('visiteur : photos publiques = celles des annonces publiées (p1 : 2)', 'select 1 from public_listing_photos', 2);
select t.cnt('visiteur : dates indisponibles de la villa = 2 plages (confirmée + blocage en cours)', format('select * from public_booked_ranges(%L)', t.p(3)), 2);
select t.must_fail('visiteur : les dates indisponibles ne contiennent aucune donnée personnelle', format('select guest_id from public_booked_ranges(%L)', t.p(3)));
select t.cnt('visiteur : pas de dates pour une annonce non publiée', format('select * from public_booked_ranges(%L)', t.p(4)), 0);
select t.must_fail('visiteur : ne peut pas appeler le compteur d''abus', $$select enforce_rate_limit('x', 1, interval '1 hour')$$);

-- formulaires ouverts : valides, limités, et jamais avec un statut forgé
select t.ok('demande propriétaire valide (1/3)', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('visibilite','Villa','Dori',1,'autonomie','Test','70 11 22 33',true)$$);
select t.must_fail('demande propriétaire sans consentement refusée', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('visibilite','Villa','Dori',1,'autonomie','Test','70 99 99 99',false)$$);
select t.must_fail('demande propriétaire avec statut forgé refusée', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent, status) values ('visibilite','Villa','Dori',1,'autonomie','Test','70 99 99 98',true,'contactee')$$);
select t.must_fail('demande propriétaire avec téléphone invalide refusée', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('visibilite','Villa','Dori',1,'autonomie','Test','abc',true)$$);
select t.ok('demande propriétaire valide (2/3)', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('visibilite','Villa','Dori',1,'autonomie','Test','70 11 22 33',true)$$);
select t.ok('demande propriétaire valide (3/3)', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('visibilite','Villa','Dori',1,'autonomie','Test','70 11 22 33',true)$$);
select t.must_fail('limitation : 4e demande du même numéro en 1 h refusée', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('visibilite','Villa','Dori',1,'autonomie','Test','70 11 22 33',true)$$);
select t.ok('limitation : un autre numéro reste accepté', $$insert into owner_leads (pack, property_kind, city, property_count, level, name, phone, consent) values ('serenite','Villa','Kaya',2,'delegation','Autre','70 44 55 66',true)$$);
select t.cnt('visiteur : le compteur d''abus n''est pas lisible', 'select 1 from rate_events', 0);
select t.must_fail('candidature Partenariat avec statut forgé refusée', $$insert into partnership_applications (contact_name, contact_phone, city, district, property_kind, consent, status) values ('X','70 10 10 10','Dori','Centre','Villa',true,'acceptee')$$);
select t.ok('candidature Partenariat valide (1/3)', $$insert into partnership_applications (contact_name, contact_phone, city, district, property_kind, consent) values ('Awa','70 10 10 10','Dori','Centre','Villa',true)$$);
select t.ok('candidature Partenariat valide (2/3)', $$insert into partnership_applications (contact_name, contact_phone, city, district, property_kind, consent) values ('Awa','70 10 10 10','Dori','Centre','Villa',true)$$);
select t.ok('candidature Partenariat valide (3/3)', $$insert into partnership_applications (contact_name, contact_phone, city, district, property_kind, consent) values ('Awa','70 10 10 10','Dori','Centre','Villa',true)$$);
select t.must_fail('limitation : 4e candidature du même numéro en 1 jour refusée', $$insert into partnership_applications (contact_name, contact_phone, city, district, property_kind, consent) values ('Awa','70 10 10 10','Dori','Centre','Villa',true)$$);
select t.must_fail('candidature au nom d''un autre utilisateur refusée', format($$insert into partnership_applications (applicant_id, contact_name, contact_phone, city, district, property_kind, consent) values (%L,'Awa','70 20 20 20','Dori','Centre','Villa',true)$$, t.u(1)));
select t.must_fail('visiteur : avis de paiement refusé', format($$insert into payment_notices (user_id, object, booking_id, declared_amount_xof) values (%L,'reservation',%L,100000)$$, t.u(2), t.b(2)));

-- ====================== 2. Voyageur A (client de b1 et b3) ======================
reset role; select t.as(1);
select t.cnt('voyageur A : ne voit que ses 2 réservations', 'select 1 from bookings', 2);
select t.must_fail('voyageur A : ne peut pas créer une réservation directement', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof) values (%L,%L,daterange(current_date+50,current_date+52),1,50000,100000,100000)$$, t.p(3), t.u(1)));
select t.rows('voyageur A : ne peut pas modifier le statut d''une réservation', format($$update bookings set status = 'confirmee' where id = %L$$, t.b(3)), 0);
select t.rows('voyageur A : ne peut pas modifier la réservation d''un autre', format($$update bookings set guests = 1 where id = %L$$, t.b(2)), 0);
select t.cnt('voyageur A : ne voit aucune annonce brute', 'select 1 from properties', 0);
select t.cnt('voyageur A : ne voit aucun contact propriétaire', 'select 1 from property_contacts', 0);
select t.cnt('voyageur A : ne voit que son profil', 'select 1 from profiles', 1);
select t.must_fail('voyageur A : ne peut pas s''attribuer une permission d''équipe', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(1), t.u(1)));
select t.must_fail('voyageur A : ne peut pas s''attribuer le rôle admin', format($$insert into user_roles (user_id, role) values (%L,'admin')$$, t.u(1)));
select t.must_fail('voyageur A : ne peut pas devenir propriétaire par lui-même', format($$insert into user_roles (user_id, role) values (%L,'proprietaire')$$, t.u(1)));
select t.must_fail('voyageur A : ne peut pas créer une annonce (pas propriétaire)', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'annonce','Pirate','Dori','X',2,1000,'soumise')$$, t.u(1)));
select t.ok('voyageur A : avis de paiement sur SA réservation', format($$insert into payment_notices (object, booking_id, declared_amount_xof) values ('reservation',%L,100000)$$, t.b(3)));
select t.must_fail('voyageur A : avis de paiement sur la réservation d''un autre refusé', format($$insert into payment_notices (object, booking_id, declared_amount_xof) values ('reservation',%L,100000)$$, t.b(2)));
select t.must_fail('voyageur A : avis au nom d''un autre utilisateur refusé', format($$insert into payment_notices (user_id, object, booking_id, declared_amount_xof) values (%L,'reservation',%L,100000)$$, t.u(2), t.b(1)));
select t.must_fail('voyageur A : avis avec montant nul refusé', format($$insert into payment_notices (object, booking_id, declared_amount_xof) values ('reservation',%L,0)$$, t.b(1)));
select t.must_fail('voyageur A : avis incohérent (abonnement + réservation) refusé', format($$insert into payment_notices (object, booking_id, subscription_id, declared_amount_xof) values ('reservation',%L,'cccccccc-0000-0000-0000-000000000001',1000)$$, t.b(1)));
select t.rows('voyageur A : ne peut pas marquer son avis « traité »', $$update payment_notices set status = 'traite'$$, 0);
select t.cnt('voyageur A : voit son avis de paiement', 'select 1 from payment_notices', 1);
select t.cnt('voyageur A : ne voit pas les transactions des autres', 'select 1 from payment_transactions', 0);
select t.must_fail('voyageur A : ne peut pas lire qui a consulté un contact', 'select viewer_id from contact_views');

-- ====================== 3. Voyageur B ======================
reset role; select t.as(2);
select t.cnt('voyageur B : ne voit que sa réservation', 'select 1 from bookings', 1);
select t.cnt('voyageur B : ne voit pas l''avis de paiement de A', 'select 1 from payment_notices', 0);
select t.cnt('voyageur B : voit la transaction de sa propre réservation', 'select 1 from payment_transactions', 1);

-- ====================== 4. Propriétaire O1 ======================
reset role; select t.as(3);
select t.ok('O1 : crée une annonce soumise', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'annonce','Nouvelle','Dori','X',2,12000,'soumise')$$, t.u(3)));
select t.must_fail('O1 : ne peut pas créer une annonce déjà publiée', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'annonce','Directe','Dori','X',2,12000,'publiee')$$, t.u(3)));
select t.must_fail('O1 : ne peut pas créer une annonce « gérée »', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'gestion','Gérée','Dori','X',2,12000,'soumise')$$, t.u(3)));
select t.must_fail('O1 : ne peut pas créer une annonce pour un autre', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'annonce','Volée','Dori','X',2,12000,'soumise')$$, t.u(4)));
select t.must_fail('O1 : ne peut pas créer une annonce marquée démo', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status, is_demo) values (%L,'annonce','Démo','Dori','X',2,12000,'soumise',true)$$, t.u(3)));
select t.rows('O1 : ne peut pas modifier l''annonce de O2', format($$update properties set title = 'Piratée' where id = %L$$, t.p(2)), 0);
select t.must_fail('O1 : ne peut pas valider lui-même (soumise -> approuvée)', format($$update properties set status = 'approuvee' where id = %L$$, t.p(5)));
select t.must_fail('O1 : ne peut pas publier lui-même (brouillon -> publiée)', format($$update properties set status = 'publiee' where id = %L$$, t.p(4)));
select t.must_fail('O1 : ne peut pas se « re-publier » (publiée -> soumise à la main)', format($$update properties set status = 'soumise' where id = %L$$, t.p(1)));
select t.must_fail('O1 : ne peut pas écrire la note de l''équipe', format($$update properties set review_note = 'Validé !' where id = %L$$, t.p(5)));
select t.must_fail('O1 : ne peut pas changer l''offre', format($$update properties set offer = 'gestion' where id = %L$$, t.p(4)));
select t.must_fail('O1 : ne peut pas changer le propriétaire', format($$update properties set owner_id = %L where id = %L$$, t.u(4), t.p(4)));
select t.must_fail('O1 : ne peut pas se marquer « démo »', format($$update properties set is_demo = true where id = %L$$, t.p(4)));
select t.ok('O1 : dépose son brouillon (brouillon -> soumise)', format($$update properties set status = 'soumise' where id = %L$$, t.p(4)));
select t.rows('O1 : ne peut pas supprimer une annonce', format($$delete from properties where id = %L$$, t.p(4)), 0);
-- modification mineure : reste publiée
select t.ok('O1 : modifie la description d''une annonce publiée', format($$update properties set description = 'Nouvelle description plus longue', highlights = array['Calme','Cour'], arrival_instructions = 'Sonner deux fois', title = 'Maison O1 rénovée' where id = %L$$, t.p(1)));
select t.eq('O1 : modification MINEURE -> l''annonce reste publiée', format($$select status::text from properties where id = %L$$, t.p(1)), 'publiee');
-- modifications majeures : nouvelle validation
select t.ok('O1 : change le prix d''une annonce publiée', format($$update properties set nightly_price_xof = 25000 where id = %L$$, t.p(6)));
select t.eq('O1 : changement de PRIX -> repasse en validation', format($$select status::text from properties where id = %L$$, t.p(6)), 'soumise');
select t.eq('O1 : le motif de la nouvelle validation est tracé', format($$select review_note from properties where id = %L$$, t.p(6)), 'Modification à valider : prix');
-- photos
select t.must_fail('O1 : ne peut pas ajouter une photo « droits vérifiés »', format($$insert into property_photos (property_id, storage_path, rights_checked) values (%L, %L, true)$$, t.p(7), t.u(3) || '/' || t.p(7) || '/x.jpg'));
select t.must_fail('O1 : ne peut pas ajouter une photo dans le dossier d''un autre', format($$insert into property_photos (property_id, storage_path) values (%L, %L)$$, t.p(7), t.u(4) || '/' || t.p(7) || '/x.jpg'));
select t.must_fail('O1 : ne peut pas ajouter une photo sur l''annonce d''un autre', format($$insert into property_photos (property_id, storage_path) values (%L, %L)$$, t.p(2), t.u(3) || '/' || t.p(2) || '/x.jpg'));
select t.must_fail('O1 : chemin de photo avec « .. » refusé', format($$insert into property_photos (property_id, storage_path) values (%L, %L)$$, t.p(7), t.u(3) || '/' || t.p(7) || '/../x.jpg'));
select t.must_fail('O1 : ne peut pas cocher « droits vérifiés » sur une photo', format($$update property_photos set rights_checked = true where property_id = %L and storage_path like '%%b.jpg'$$, t.p(1)));
select t.ok('O1 : change l''ordre/le texte alternatif d''une photo (mineur)', format($$update property_photos set position = 5, alt_text = 'Salon' where property_id = %L and storage_path like '%%b.jpg'$$, t.p(1)));
select t.eq('O1 : réordonner les photos ne remet pas en validation', format($$select status::text from properties where id = %L$$, t.p(1)), 'publiee');
select t.ok('O1 : ajoute une photo à une annonce publiée', format($$insert into property_photos (property_id, storage_path) values (%L, %L)$$, t.p(7), t.u(3) || '/' || t.p(7) || '/new.jpg'));
select t.eq('O1 : AJOUT de photo -> repasse en validation', format($$select status::text from properties where id = %L$$, t.p(7)), 'soumise');
-- contact
select t.cnt('O1 : lit le contact de sa propre annonce', format('select 1 from property_contacts where property_id = %L', t.p(1)), 1);
select t.cnt('O1 : ne lit pas le contact de l''annonce de O2', format('select 1 from property_contacts where property_id = %L', t.p(2)), 0);
select t.rows('O1 : ne peut pas modifier le contact de O2', format($$update property_contacts set phone = '+226 70 66 66 66' where property_id = %L$$, t.p(2)), 0);
select t.must_fail('O1 : numéro de contact invalide refusé', format($$update property_contacts set phone = 'pas un numéro' where property_id = %L$$, t.p(8)));
select t.ok('O1 : change son numéro de contact', format($$update property_contacts set phone = '+226 70 77 77 77' where property_id = %L$$, t.p(8)));
select t.eq('O1 : changement de CONTACT -> repasse en validation', format($$select status::text from properties where id = %L$$, t.p(8)), 'soumise');
select t.cnt('O1 : voit le nombre de consultations de son contact (3)', format('select id from contact_views where property_id = %L', t.p(1)), 3);
select t.must_fail('O1 : ne peut pas voir QUI a consulté son contact', format('select viewer_id from contact_views where property_id = %L', t.p(1)));
select t.must_fail('O1 : ne peut pas fabriquer une consultation', format($$insert into contact_views (property_id) values (%L)$$, t.p(1)));
select t.cnt('O1 : voit les réservations de sa villa gérée (3)', 'select 1 from bookings', 3);
select t.cnt('O1 : ne voit pas les profils des autres', 'select 1 from profiles', 1);
select t.must_fail('O1 : ne peut pas s''attribuer une permission d''équipe', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'validation',%L)$$, t.u(3), t.u(3)));
select t.cnt('O1 : ne lit pas les demandes de propriétaires', 'select 1 from owner_leads', 0);
select t.cnt('O1 : voit son abonnement mais pas celui de O2', 'select 1 from subscriptions', 2);
-- dates bloquées par le propriétaire
select t.ok('O1 : bloque des dates sur son annonce', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date + 5, current_date + 8))$$, t.p(1)));
select t.must_fail('O1 : ne bloque pas des dates sur la villa gérée', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date + 40, current_date + 42))$$, t.p(3)));
select t.must_fail('O1 : ne bloque pas des dates chez O2', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date + 5, current_date + 8))$$, t.p(2)));
select t.must_fail('O1 : deux blocages qui se chevauchent refusés', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date + 6, current_date + 9))$$, t.p(1)));
select t.cnt('O1 : ne voit pas les blocages de O2', 'select 1 from availability_blocks', 1);

-- ====================== 5. Propriétaire O2 ======================
reset role; select t.as(4);
select t.cnt('O2 : ne voit que ses propres annonces (1)', 'select 1 from properties', 1);
select t.cnt('O2 : ne voit pas les réservations de O1', 'select 1 from bookings', 0);
select t.cnt('O2 : voit son contact seulement', 'select 1 from property_contacts', 1);

-- ====================== 6. Membres d'équipe : seules les cases cochées comptent ======================
reset role; select t.as(6);
select t.cnt('équipe « validation » : voit les annonces à valider', $$select 1 from properties where status = 'soumise'$$, 9);
select t.ok('validation : approuve une annonce d''un autre propriétaire', format($$update properties set status = 'approuvee' where id = %L$$, t.p(5)));
select t.must_fail('validation : refuse sans motif', format($$update properties set status = 'refusee' where id = %L$$, t.p(10)));
select t.ok('validation : refuse avec motif', format($$update properties set status = 'refusee', review_note = 'Photos floues' where id = %L$$, t.p(10)));
select t.ok('validation : demande une correction avec motif', format($$update properties set status = 'a_corriger', review_note = 'Description trop courte' where id = %L$$, t.p(11)));
select t.must_fail('validation : ne modifie pas le contenu d''une annonce', format($$update properties set title = 'Titre imposé' where id = %L$$, t.p(4)));
select t.must_fail('validation : transition interdite (soumise -> publiée)', format($$update properties set status = 'publiee' where id = %L$$, t.p(4)));
select t.must_fail('validation : AUCUNE auto-validation de sa propre annonce', format($$update properties set status = 'approuvee' where id = %L$$, t.p(9)));
select t.must_fail('validation : ne peut pas s''octroyer une permission', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(6), t.u(6)));
select t.cnt('validation : ne lit pas les paiements (case non cochée)', 'select 1 from payment_transactions', 0);
select t.cnt('validation : ne lit pas les demandes (case non cochée)', 'select 1 from owner_leads', 0);
select t.cnt('validation : ne lit pas le journal d''audit', 'select 1 from audit_logs', 0);
select t.cnt('validation : ne lit pas les réservations (case non cochée)', 'select 1 from bookings', 0);
select t.cnt('validation : lit les contacts des annonces (pour valider)', 'select 1 from property_contacts', 3);
select t.ok('validation : marque les droits d''une photo vérifiés', format($$update property_photos set rights_checked = true where property_id = %L and storage_path like '%%b.jpg'$$, t.p(1)));

reset role; select t.as(7);
select t.cnt('équipe « reservations » : voit toutes les réservations (3)', 'select 1 from bookings', 3);
select t.rows('reservations : ne valide pas les annonces', format($$update properties set status = 'approuvee' where id = %L$$, t.p(4)), 0);
select t.cnt('reservations : ne lit pas les paiements', 'select 1 from payment_transactions', 0);
select t.cnt('reservations : ne lit pas les contacts propriétaires', 'select 1 from property_contacts', 0);
select t.ok('reservations : bloque des dates sur la villa gérée', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date + 60, current_date + 62))$$, t.p(3)));

reset role; select t.as(8);
select t.cnt('équipe « paiements » : voit les transactions', 'select 1 from payment_transactions', 1);
select t.cnt('paiements : voit les avis « J''ai payé »', 'select 1 from payment_notices', 1);
select t.must_fail('paiements : ne peut pas modifier le montant déclaré', $$update payment_notices set declared_amount_xof = 1$$);
select t.must_fail('paiements : ne peut pas réattribuer un avis', format($$update payment_notices set user_id = %L$$, t.u(2)));
select t.rows('paiements : marque l''avis « traité »', $$update payment_notices set status = 'traite'$$, 1);
select t.eq('paiements : l''équipier qui traite est enregistré', 'select handled_by::text from payment_notices', t.u(8)::text);
select t.must_fail('paiements : un avis traité ne repasse pas en « nouveau »', $$update payment_notices set status = 'nouveau'$$);
select t.cnt('paiements : ne lit pas les demandes de propriétaires', 'select 1 from owner_leads', 0);
select t.rows('paiements : ne peut pas modifier une transaction depuis le navigateur', $$update payment_transactions set status = 'reussi', received_amount_xof = 100000$$, 0);
select t.must_fail('paiements : ne peut pas créer une transaction', format($$insert into payment_transactions (purpose, booking_id, idempotency_key, amount_xof, status, received_amount_xof) values ('booking',%L,'faux',1000,'reussi',1000)$$, t.b(1)));

reset role; select t.as(9);
select t.cnt('équipe « audit » : lit le journal (≥ 1)', 'select 1 from audit_logs where action = ''test''', 1);
select t.cnt('audit : ne lit ni réservations, ni paiements, ni annonces, ni profils des autres', 'select 1 from bookings union all select 1 from payment_transactions union all select 1 from properties', 0);

reset role; select t.as(10);
select t.cnt('équipe « demandes » : lit les demandes de propriétaires (4)', 'select 1 from owner_leads', 4);
select t.rows('demandes : marque une demande « contactée »', $$update owner_leads set status = 'contactee' where name = 'Autre'$$, 1);
select t.must_fail('demandes : ne peut pas modifier le contenu d''une demande', $$update owner_leads set name = 'Falsifié'$$);
select t.cnt('demandes : ne lit pas les candidatures Partenariat', 'select 1 from partnership_applications', 0);

reset role; select t.as(11);
select t.cnt('équipe « partenariat » : lit les candidatures (3)', 'select 1 from partnership_applications', 3);
select t.rows('partenariat : change le statut d''une candidature', $$update partnership_applications set status = 'preselectionnee' where id = (select id from partnership_applications limit 1)$$, 1);
select t.must_fail('partenariat : ne peut pas modifier le consentement/contact', $$update partnership_applications set contact_phone = '00000000'$$);
select t.cnt('partenariat : ne lit pas les demandes de propriétaires', 'select 1 from owner_leads', 0);

-- ====================== 7. Permissions déléguées : octroi et retrait réellement appliqués ======================
reset role; select t.as(5);
select t.must_fail('admin : ne peut pas s''octroyer une permission à lui-même', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'audit',%L)$$, t.u(5), t.u(5)));
select t.must_fail('admin : ne peut pas fausser « granted_by »', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'audit',%L)$$, t.u(1), t.u(2)));
select t.must_fail('admin : ne peut pas attribuer des rôles depuis le navigateur', format($$insert into user_roles (user_id, role) values (%L,'admin')$$, t.u(1)));
select t.ok('admin : donne « paiements » à l''équipier 9', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(9), t.u(5)));
select t.cnt('admin : voit tout (11 annonces + 1 nouvelle de O1)', 'select 1 from properties', 12);
select t.ok('admin : valide l''annonce soumise par un membre d''équipe (autre personne)', format($$update properties set status = 'approuvee' where id = %L$$, t.p(9)));
reset role; select t.as(9);
select t.cnt('permission accordée : l''équipier 9 lit maintenant les transactions', 'select 1 from payment_transactions', 1);
reset role; select t.as(5);
select t.ok('admin : retire « paiements » à l''équipier 9', format($$delete from team_permissions where user_id = %L and perm = 'paiements'$$, t.u(9)));
reset role; select t.as(9);
select t.cnt('permission retirée : l''équipier 9 ne lit plus les transactions', 'select 1 from payment_transactions', 0);

-- ====================== 8. Dates : aucun chevauchement (tests au niveau serveur) ======================
reset role;
select t.must_fail('serveur : deux réservations qui se chevauchent refusées', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values (%L,%L,daterange(current_date+11,current_date+14),1,50000,150000,150000,'en_attente_paiement', now()+interval '15 minutes')$$, t.p(3), t.u(2)));
select t.must_fail('serveur : blocage propriétaire sur une réservation confirmée refusé', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date+11, current_date+12))$$, t.p(3)));
select t.must_fail('serveur : blocage propriétaire sur un paiement en attente (blocage valide) refusé', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date+20, current_date+21))$$, t.p(3)));
select t.ok('serveur : blocage sur un paiement EXPIRÉ accepté (dates libérées)', format($$insert into availability_blocks (property_id, stay) values (%L, daterange(current_date+30, current_date+31))$$, t.p(3)));
select t.eq('serveur : la réservation expirée est passée en « expirée »', format($$select status::text from bookings where id = %L$$, t.b(3)), 'expiree');
select t.must_fail('serveur : réservation sur des dates bloquées par le propriétaire refusée', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values (%L,%L,daterange(current_date+6,current_date+7),1,18000,18000,18000,'en_attente_paiement', now()+interval '15 minutes')$$, t.p(1), t.u(2)));
select t.ok('serveur : réservation sur des dates libres acceptée', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values (%L,%L,daterange(current_date+8,current_date+9),1,18000,18000,18000,'en_attente_paiement', now()+interval '15 minutes')$$, t.p(1), t.u(2)));
select t.ok('serveur : une réservation expirée libère les dates pour une nouvelle', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values (%L,%L,daterange(current_date+31,current_date+32),1,50000,50000,50000,'en_attente_paiement', now()+interval '15 minutes')$$, t.p(3), t.u(2)));
select t.cnt('visiteur-API : les plages publiques excluent les blocages expirés', format('select * from public_booked_ranges(%L)', t.p(3)), 5);

-- ====================== 9. Non-régression : confirmation de paiement manuelle (0004) ======================
select t.must_fail('paiement « réussi » avec montant reçu différent : refusé par la base', format($$insert into payment_transactions (purpose, booking_id, idempotency_key, amount_xof, status, received_amount_xof) values ('booking',%L,'m1',100000,'reussi',90000)$$, t.b(2)));
select t.ok('paiement « réussi » avec le bon montant : accepté (confirmation faite par le serveur)', format($$insert into payment_transactions (purpose, booking_id, idempotency_key, amount_xof, status, received_amount_xof) values ('booking',%L,'m2',100000,'reussi',100000)$$, t.b(1)));
select t.must_fail('transaction sans cible cohérente refusée', format($$insert into payment_transactions (purpose, idempotency_key, amount_xof) values ('booking','m3',1000)$$));

-- ====================== 10. Stockage des photos (faux schéma storage) ======================
reset role; select t.as(0);
select t.cnt('stockage : visiteur lit les photos d''une annonce publiée', $$select 1 from storage.objects where name like '%/a.jpg'$$, 1);
select t.cnt('stockage : visiteur ne lit PAS les photos d''un brouillon', $$select 1 from storage.objects where name like '%/c.jpg'$$, 0);
select t.must_fail('stockage : visiteur ne peut pas téléverser', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(3) || '/' || t.p(1) || '/v.jpg'));
reset role; select t.as(3);
select t.cnt('stockage : O1 lit ses photos non publiées', $$select 1 from storage.objects where name like '%/c.jpg'$$, 1);
select t.ok('stockage : O1 téléverse dans son dossier et son logement', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(3) || '/' || t.p(1) || '/ok.jpg'));
select t.must_fail('stockage : O1 ne téléverse pas dans le dossier de O2', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(4) || '/' || t.p(2) || '/x.jpg'));
select t.must_fail('stockage : O1 ne téléverse pas sur un logement qui n''est pas le sien', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(3) || '/' || t.p(2) || '/x.jpg'));
select t.must_fail('stockage : O1 ne téléverse pas dans un autre bucket', format($$insert into storage.objects (bucket_id, name) values ('autre', %L)$$, t.u(3) || '/' || t.p(1) || '/x.jpg'));
reset role; select t.as(4);
select t.cnt('stockage : O2 ne lit pas le brouillon de O1', $$select 1 from storage.objects where name like '%/c.jpg'$$, 0);
reset role; select t.as(1);
select t.must_fail('stockage : un voyageur ne peut pas téléverser', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(1) || '/' || t.p(1) || '/x.jpg'));
reset role; select t.as(6);
select t.cnt('stockage : la validation lit le brouillon pour le contrôler', $$select 1 from storage.objects where name like '%/c.jpg'$$, 1);

-- ====================== 11. Cohérence des règles ======================
reset role;
select t.cnt('aucune règle n''utilise encore les anciens contrôles par rôle (is_staff / gestionnaire / finance)',
  $$select 1 from pg_policies where schemaname in ('public','storage') and (coalesce(qual,'') || coalesce(with_check,'')) ~ 'is_staff|has_role\(''(gestionnaire|finance)''\)'$$, 0);
select t.cnt('toutes les tables du schéma public ont la sécurité par ligne activée',
  $$select 1 from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity$$, 0);

\o
do $$ begin
  if exists (select 1 from t.results where not pass) then
    raise exception 'ÉCHECS : %', (select string_agg(label || ' [' || coalesce(detail,'') || ']', E'\n  ') from t.results where not pass);
  end if;
end $$;
select count(*) || ' tests de sécurité réussis, 0 échec' from t.results;
