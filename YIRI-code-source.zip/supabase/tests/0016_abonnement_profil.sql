-- Tests de la migration 0016 (abonnement par profil) — les 15 cas demandés par la spécification.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values
  (t.u(3), 'proprietaire'), (t.u(4), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'paiements', t.u(5));

-- Propriétaire 3 : TROIS logements YIRI Annonce. Propriétaire 4 : un logement (cloisonnement).
-- Logement 9 : YIRI Sérénité, pour vérifier qu'il n'est pas touché.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'annonce', 'Annonce A', 'd', 'Ouagadougou', 'Gounghin', 'a', 2,1,1, 15000,1, 'approuvee', false),
       (t.p(2), t.u(3), 'annonce', 'Annonce B', 'd', 'Ouagadougou', 'Zogona',   'a', 2,1,1, 16000,1, 'approuvee', false),
       (t.p(3), t.u(3), 'annonce', 'Annonce C', 'd', 'Bobo-Dioulasso', 'Accart','a', 2,1,1, 17000,1, 'soumise', false),
       (t.p(4), t.u(4), 'annonce', 'Annonce D', 'd', 'Ouagadougou', 'Tanghin',  'a', 2,1,1, 18000,1, 'approuvee', false),
       (t.p(9), t.u(3), 'gestion', 'Serenite',  'd', 'Ouagadougou', 'Koulouba', 'a', 4,2,2, 30000,1, 'approuvee', false);
insert into property_photos (property_id, storage_path, position, rights_checked)
select p, 'x/' || p || '.jpg', 0, true from unnest(array[t.p(1), t.p(2), t.p(3), t.p(4), t.p(9)]) p;
insert into property_contacts (property_id, contact_name, phone, whatsapp)
select p, 'Contact', '70000000', true from unnest(array[t.p(1), t.p(2), t.p(3), t.p(4)]) p;
insert into management_agreements (property_id, contract_version, starts_on, signed, operational_check_done, expense_policy_version)
values (t.p(9), 'v1', current_date, true, true, 'v1');

-- ============ Cas 4 : les tarifs ============
reset role; select t.as(3);
select t.eq('forfait mensuel : 5 000', $$select amount_xof::text from subscribe_owner('mensuel')$$, '5000');
reset role; delete from subscriptions; reset role; select t.as(3);
select t.eq('forfait annuel : 30 000', $$select amount_xof::text from subscribe_owner('annuel')$$, '30000');
reset role; delete from subscriptions; reset role; select t.as(3);

-- ============ Cas 2 : aucune offre en double ============
reset role;
select t.eq('subscribe_property n''existe plus',
  $$select (to_regprocedure('public.subscribe_property(uuid,subscription_plan)') is null)::text$$, 'true');
select t.eq('grant_subscription non plus',
  $$select (to_regprocedure('public.grant_subscription(uuid,int,text)') is null)::text$$, 'true');
select t.eq('les trois offres commerciales restent définies',
  $$select count(*)::text from pg_enum where enumtypid = 'offer_type'::regtype$$, '3');

-- ============ Cas 3 : un abonnement, plusieurs logements ============
reset role; select t.as(3);
select t.ok('le propriétaire s''abonne une fois', $$select * from subscribe_owner('mensuel')$$);
select t.eq('appelé deux fois, pas de doublon',
  $$select count(*)::text from (select subscribe_owner('mensuel')) s$$, '1');
reset role;
select t.eq('une seule ligne d''abonnement', $$select count(*)::text from subscriptions$$, '1');
select t.eq('et elle n''est rattachée à aucun logement',
  $$select (property_id is null)::text from subscriptions$$, 'true');

-- ============ Cas 12 : un paiement non confirmé ne publie rien ============
reset role; select t.as(6);
select t.must_fail('tant que l''abonnement n''est pas payé, rien ne se publie',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(1)));
reset role;
select t.eq('et la vitrine est vide', $$select count(*)::text from public_listings where offer = 'annonce'$$, '0');

-- ============ Le paiement active, et publie les annonces DÉJÀ validées ============
reset role; select t.as(7);
select t.ok('l''équipe confirme le paiement',
  $$select confirm_payment('abonnement', (select id from subscriptions), 5000)$$);
reset role;
select t.eq('les deux annonces approuvées sont publiées d''un coup',
  format($$select count(*)::text from properties where id in (%L, %L) and status = 'publiee'$$, t.p(1), t.p(2)), '2');

-- ============ Cas 11 : une annonce en attente n'est jamais publiée par un paiement ============
select t.eq('l''annonce encore en validation reste en validation',
  format($$select status::text from properties where id = %L$$, t.p(3)), 'soumise');

-- ============ Cas 5 : visible tant que l'abonnement est actif ============
select t.eq('les deux annonces sont dans la vitrine',
  format($$select count(*)::text from public_listings where id in (%L, %L)$$, t.p(1), t.p(2)), '2');

-- ============ Cas 3 (suite) : un TROISIÈME logement sans repayer ============
reset role; select t.as(6);
select t.ok('l''équipe approuve le troisième', format($$select set_listing_status(%L, 'approuvee')$$, t.p(3)));
select t.ok('et le publie, sans nouvel abonnement', format($$select set_listing_status(%L, 'publiee')$$, t.p(3)));
reset role;
select t.eq('les trois logements sont visibles',
  format($$select count(*)::text from public_listings where id in (%L, %L, %L)$$, t.p(1), t.p(2), t.p(3)), '3');
select t.eq('et toujours un seul abonnement payé',
  $$select count(*)::text from payment_transactions where purpose = 'subscription' and status = 'reussi'$$, '1');

-- ============ Cas 14 : cloisonnement entre propriétaires ============
reset role; select t.as(6);
select t.must_fail('l''abonnement du 3 ne publie pas l''annonce du 4',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(4)));
reset role; select t.as(4);
select t.cnt('le propriétaire 4 ne voit pas l''abonnement du 3', $$select * from my_subscription()$$, 0);
select t.eq('et ses compteurs ne comptent que ses logements',
  $$select soumis::text from my_listing_counts()$$, '1');
reset role; select t.as(3);
select t.eq('le propriétaire 3 compte bien ses quatre logements',
  $$select soumis::text from my_listing_counts()$$, '4');
select t.eq('dont trois publiés', $$select publies::text from my_listing_counts()$$, '3');

-- ============ Cas 6 et 7 : à l'expiration, TOUT est masqué ============
reset role;
update subscriptions set starts_at = current_date - 40, ends_at = current_date;
select t.eq('les trois annonces sortent de la vitrine le jour même',
  format($$select count(*)::text from public_listings where id in (%L, %L, %L)$$, t.p(1), t.p(2), t.p(3)), '0');
-- Cas 7 : la fiche publique lit la même vue, donc le lien direct ne donne rien non plus.
reset role; select t.as(0);
select t.eq('un visiteur ne peut pas ouvrir la fiche par son lien direct',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(1)), '0');
select t.eq('ni voir ses photos',
  format($$select count(*)::text from public_listing_photos where property_id = %L$$, t.p(1)), '0');
reset role; select t.as(2);
select t.must_fail('et le contact du propriétaire reste fermé', format($$select reveal_contact(%L)$$, t.p(1)));

reset role;
select t.eq('la tâche de nuit masque les trois annonces',
  $$select annonces_retirees::text from expire_subscriptions()$$, '3');
select t.eq('elles sont en « expirée »',
  format($$select count(*)::text from properties where id in (%L, %L, %L) and status = 'expiree'$$, t.p(1), t.p(2), t.p(3)), '3');

-- ============ Cas 8 et 9 : rien n'est perdu, le propriétaire garde son accès ============
select t.eq('les logements sont toujours en base',
  format($$select count(*)::text from properties where owner_id = %L$$, t.u(3)), '4');
select t.eq('les photos aussi',
  format($$select count(*)::text from property_photos ph join properties p on p.id = ph.property_id where p.owner_id = %L$$, t.u(3)), '4');
reset role; select t.as(3);
select t.ok('le propriétaire lit toujours son tableau de bord', $$select * from my_listing_counts()$$);
select t.eq('son abonnement est marqué expiré', $$select status::text from my_subscription()$$, 'expire');
select t.eq('et il sait qu''il ne peut plus publier', $$select actif::text from my_subscription()$$, 'false');

-- ============ Cas 15 : YIRI Sérénité n'est pas touché ============
reset role; select t.as(6);
select t.ok('le logement Sérénité se publie malgré l''abonnement expiré',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(9)));
reset role;
select t.eq('et il est visible dans la vitrine',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(9)), '1');
select t.eq('la tâche de nuit ne le retire pas',
  $$select annonces_retirees::text from expire_subscriptions()$$, '0');

-- ============ Cas 10 : le renouvellement ne réactive que ce qui est éligible ============
-- On suspend une annonce et on en refuse une autre : elles ne doivent PAS revenir.
reset role; select t.as(6);
select t.ok('l''équipe suspend une annonce', format($$select set_listing_status(%L, 'suspendue', 'Photos a refaire')$$, t.p(2)));
reset role;
update properties set status = 'refusee' where id = t.p(3);

reset role; select t.as(3);
select t.ok('le propriétaire renouvelle', $$select * from subscribe_owner('mensuel')$$);
reset role; select t.as(7);
select t.ok('le paiement est confirmé',
  $$select confirm_payment('abonnement', (select id from subscriptions where status = 'en_attente_paiement'), 5000)$$);
reset role;
select t.eq('l''annonce qui était publiée revient en ligne',
  format($$select status::text from properties where id = %L$$, t.p(1)), 'publiee');
select t.eq('l''annonce suspendue NE revient PAS',
  format($$select status::text from properties where id = %L$$, t.p(2)), 'suspendue');
select t.eq('l''annonce refusée NON PLUS',
  format($$select status::text from properties where id = %L$$, t.p(3)), 'refusee');
select t.eq('une seule annonce est donc visible',
  format($$select count(*)::text from public_listings where id in (%L, %L, %L)$$, t.p(1), t.p(2), t.p(3)), '1');
-- Deux traces : la première activation en a publié deux, le renouvellement une seule.
select t.eq('la remise en ligne est tracée à chaque fois',
  $$select count(*)::text from audit_logs where action = 'listing.republished'$$, '2');
select t.eq('et la dernière trace ne compte qu''UNE annonce remise en ligne',
  $$select (after ->> 'annonces') from audit_logs
     where action = 'listing.republished' order by created_at desc, id desc limit 1$$, '1');

-- ============ Le renouvellement AVANT l'échéance s'ajoute à la suite ============
-- Le cas précédent partait d'un abonnement déjà expiré : la date de reprise était donc
-- forcément aujourd'hui, et le test ne prouvait rien sur le cumul. Ici le propriétaire 4
-- renouvelle alors qu'il lui reste 20 jours : il ne doit en perdre aucun.
reset role; select t.as(4);
select t.ok('le propriétaire 4 s''abonne', $$select * from subscribe_owner('mensuel')$$);
reset role; select t.as(7);
select t.ok('son paiement est confirmé',
  format($$select confirm_payment('abonnement', (select id from subscriptions where owner_id = %L), 5000)$$, t.u(4)));
reset role;
update subscriptions set starts_at = current_date - 10, ends_at = current_date + 20
 where owner_id = t.u(4) and status = 'actif';
reset role; select t.as(4);
select t.ok('il renouvelle avant l''échéance', $$select * from subscribe_owner('annuel')$$);
reset role; select t.as(7);
select t.ok('le renouvellement est confirmé',
  format($$select confirm_payment('abonnement', (select id from subscriptions where owner_id = %L and status = 'en_attente_paiement'), 30000)$$, t.u(4)));
reset role;
select t.eq('le nouvel abonnement DÉMARRE à la fin de l''ancien, pas aujourd''hui',
  format($$select (starts_at = current_date + 20)::text from subscriptions
            where owner_id = %L and plan = 'annuel' and status = 'actif'$$, t.u(4)), 'true');
select t.eq('et se termine un an plus tard : aucune journée perdue',
  format($$select (ends_at = current_date + 20 + interval '1 year')::text from subscriptions
            where owner_id = %L and plan = 'annuel' and status = 'actif'$$, t.u(4)), 'true');

-- ============ Cas 13 : pas de double renouvellement ============
reset role; select t.as(7);
select t.must_fail('confirmer deux fois le même abonnement est refusé',
  $$select confirm_payment('abonnement', (select id from subscriptions where status = 'actif' order by created_at desc limit 1), 5000)$$);
reset role;
-- Formulé sans nombre fixe : ce qui compte est qu'AUCUN abonnement n'ait deux encaissements,
-- quel que soit le nombre d'abonnements créés par les tests qui précèdent.
select t.eq('aucun abonnement n''a deux encaissements réussis',
  $$select count(*)::text from (
      select subscription_id from payment_transactions
       where purpose = 'subscription' and status = 'reussi'
       group by subscription_id having count(*) > 1) x$$, '0');
select t.eq('une écriture au registre par encaissement, ni plus ni moins',
  $$select ((select count(*) from financial_ledger where entry_type = 'abonnement')
          = (select count(*) from payment_transactions where purpose = 'subscription' and status = 'reussi'))::text$$, 'true');

-- Un montant faux n'active rien.
reset role; select t.as(3);
select t.ok('nouvelle demande d''abonnement', $$select * from subscribe_owner('mensuel')$$);
reset role; select t.as(7);
select t.must_fail('un montant inférieur au tarif est refusé',
  $$select confirm_payment('abonnement', (select id from subscriptions where status = 'en_attente_paiement'), 100)$$);
reset role;
select t.eq('et l''abonnement reste en attente',
  $$select count(*)::text from subscriptions where status = 'en_attente_paiement'$$, '1');

-- ============ Sécurité : on ne s'accorde pas un abonnement soi-même ============
reset role; select t.as(3);
-- Sans règle d'écriture, PostgreSQL ne lève pas d'erreur : la mise à jour ne touche
-- simplement AUCUNE ligne. C'est ça qu'il faut vérifier, pas une exception.
select t.rows('un propriétaire ne modifie aucune ligne de la table des abonnements',
  $$update subscriptions set status = 'actif', starts_at = current_date, ends_at = current_date + 365$$, 0);
select t.must_fail('ni ne confirme son propre paiement',
  $$select confirm_payment('abonnement', (select id from subscriptions where status = 'en_attente_paiement'), 5000)$$);
select t.must_fail('ni ne lit la file de l''équipe', $$select * from subscriptions_queue()$$);
reset role; select t.as(0);
select t.must_fail('un visiteur ne s''abonne pas', $$select * from subscribe_owner('mensuel')$$);

-- ============ La file de l'équipe ============
reset role; select t.as(6);
select t.ok('l''équipe « validation » lit la file', $$select * from subscriptions_queue()$$);
select t.eq('elle voit le nombre d''annonces du propriétaire',
  format($$select max(annonces)::text from subscriptions_queue() where owner_id = %L$$, t.u(3)), '3');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0016 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
