import * as React from "react";
import { PropertyArt, cx } from "./ui";
import type { VisuelLogement } from "./lib/domain";

import { MAX_PHOTOS, MIN_PHOTOS } from "./lib/rules";
export { MAX_PHOTOS, MIN_PHOTOS };

/** Réduit une photo (1 400 px max, JPEG) pour qu'elle reste légère. En production : envoi vers Supabase Storage. */
async function compress(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = () => reject(new Error("illisible"));
      i.src = url;
    });
    const k = Math.min(1, 1400 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(img.naturalWidth * k));
    c.height = Math.max(1, Math.round(img.naturalHeight * k));
    c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.78);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function PhotoUploader({ id, photos, onChange }: { id: string; photos: string[]; onChange: (p: string[]) => void }) {
  const [busy, setBusy] = React.useState("");
  const [notice, setNotice] = React.useState("");
  const [drag, setDrag] = React.useState(false);

  async function addFiles(list: FileList | File[]) {
    const files = Array.from(list).filter((f) => f.type.startsWith("image/"));
    const skippedType = list.length - files.length;
    const room = MAX_PHOTOS - photos.length;
    const take = files.slice(0, Math.max(0, room));
    const done: string[] = [];
    let failed = 0;
    for (let i = 0; i < take.length; i++) {
      setBusy(`Préparation de la photo ${i + 1} sur ${take.length}…`);
      try { done.push(await compress(take[i])); } catch { failed++; }
    }
    setBusy("");
    if (done.length) onChange([...photos, ...done]);
    const parts: string[] = [];
    if (files.length > room) parts.push(`${files.length - room} photo(s) ignorée(s) : maximum ${MAX_PHOTOS} photos.`);
    if (skippedType) parts.push(`${skippedType} fichier(s) ignoré(s) : seules les images sont acceptées.`);
    if (failed) parts.push(`${failed} photo(s) illisible(s). Les photos HEIC doivent être converties en JPEG.`);
    setNotice(parts.join(" "));
  }

  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= photos.length) return;
    const next = [...photos];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  const cover = (i: number) => onChange([photos[i], ...photos.filter((_, k) => k !== i)]);
  const remove = (i: number) => onChange(photos.filter((_, k) => k !== i));

  const enough = photos.length >= MIN_PHOTOS;
  return (
    <div className="flex flex-col gap-3">
      <label
        htmlFor={id}
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); if (e.dataTransfer.files.length) void addFiles(e.dataTransfer.files); }}
        className={cx(
          "flex cursor-pointer flex-col items-center gap-2 rounded-2xl border-2 border-dashed px-4 py-8 text-center transition-colors focus-within:outline-2 focus-within:outline-offset-2 focus-within:outline-accent",
          drag ? "border-brand bg-brand/5" : "border-line-strong bg-surface hover:border-ink"
        )}
      >
        <span className="font-display text-lg font-bold text-ink">Ajoutez vos photos</span>
        <span className="max-w-[44ch] text-sm text-muted">Choisissez plusieurs photos à la fois, ou glissez-les ici.</span>
        <span className="mt-1 inline-flex rounded-full bg-brand px-5 py-2 text-sm font-semibold text-on-brand">Choisir des photos</span>
        <input
          id={id} type="file" accept="image/*" multiple className="sr-only"
          onChange={(e) => { if (e.target.files?.length) void addFiles(e.target.files); e.target.value = ""; }}
        />
      </label>

      <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
        <p className={cx("font-semibold", enough ? "text-good" : "text-ink")}>
          {photos.length} / {MAX_PHOTOS} photos {enough ? "· c'est suffisant, vous pouvez en ajouter d'autres" : `· il en faut au moins ${MIN_PHOTOS}`}
        </p>
        <p className="text-muted">Salon, chambres, cuisine, salle d'eau, extérieur. Photos horizontales et lumineuses.</p>
      </div>
      {busy && <p role="status" className="text-sm font-medium text-accent-ink">{busy}</p>}
      {notice && <p role="alert" className="text-sm font-medium text-danger">{notice}</p>}

      {photos.length > 0 && (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {photos.map((src, i) => (
            <li key={src.slice(-40) + i} className="relative overflow-hidden rounded-xl bg-sunk">
              <img src={src} alt={`Photo ${i + 1}`} className="aspect-[4/3] w-full object-cover" />
              {i === 0 && <span className="absolute left-2 top-2 rounded-full bg-ink px-2 py-0.5 text-[11px] font-bold text-bg">Couverture</span>}
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-1 bg-black/60 p-1.5 text-white">
                <div className="flex gap-1">
                  <IconBtn label={`Déplacer la photo ${i + 1} vers la gauche`} disabled={i === 0} onClick={() => move(i, -1)}>←</IconBtn>
                  <IconBtn label={`Déplacer la photo ${i + 1} vers la droite`} disabled={i === photos.length - 1} onClick={() => move(i, 1)}>→</IconBtn>
                  {i !== 0 && <IconBtn label={`Choisir la photo ${i + 1} comme couverture`} onClick={() => cover(i)}>★</IconBtn>}
                </div>
                <IconBtn label={`Supprimer la photo ${i + 1}`} onClick={() => remove(i)}>✕</IconBtn>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function IconBtn({ label, children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button type="button" aria-label={label} title={label} {...p}
      className="grid size-8 place-items-center rounded-md text-sm font-bold hover:bg-white/20 disabled:opacity-30 cursor-pointer focus-visible:outline-2 focus-visible:outline-white">
      {children}
    </button>
  );
}

/** Galerie de la fiche logement : grande photo + vignettes. Sans photo, retombe sur l'illustration. */
export function Gallery({ p }: { p: VisuelLogement & { photos?: string[] } }) {
  const [i, setI] = React.useState(0);
  const photos = p.photos ?? [];
  if (!photos.length) return <PropertyArt p={p} tall className="aspect-[21/9] max-h-[420px] w-full rounded-3xl" />;
  const cur = Math.min(i, photos.length - 1);
  return (
    <div className="flex flex-col gap-3">
      <div className="relative">
        <img src={photos[cur]} alt={`Photo ${cur + 1} sur ${photos.length}`} className="aspect-[16/9] max-h-[520px] w-full rounded-3xl bg-sunk object-cover" />
        <span className="absolute bottom-3 right-3 rounded-full bg-black/60 px-3 py-1 text-xs font-semibold text-white">{cur + 1} / {photos.length}</span>
      </div>
      {photos.length > 1 && (
        <ul className="flex gap-2 overflow-x-auto pb-1">
          {photos.map((src, k) => (
            <li key={k} className="shrink-0">
              <button onClick={() => setI(k)} aria-label={`Voir la photo ${k + 1}`} aria-current={k === cur}
                className={cx("block overflow-hidden rounded-xl border-2 cursor-pointer", k === cur ? "border-brand" : "border-transparent opacity-80 hover:opacity-100")}>
                <img src={src} alt="" className="h-16 w-24 object-cover" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
