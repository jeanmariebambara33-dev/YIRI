-- Réservation Sérénité : paiement immédiat, sans étape de confirmation préalable.
-- Une réservation est créée directement « en attente de paiement » avec un blocage des dates limité dans le temps.
alter table bookings alter column status set default 'en_attente_paiement';

-- Libère les dates dont le blocage est expiré. À exécuter chaque minute (pg_cron ou tâche planifiée Supabase),
-- sinon une réservation non payée bloquerait le logement indéfiniment (la contrainte d'exclusion ne regarde que le statut).
create or replace function expire_booking_holds() returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update bookings set status = 'expiree'
   where status = 'en_attente_paiement' and hold_expires_at is not null and hold_expires_at < now();
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function expire_booking_holds() from public, anon, authenticated;

-- Prestataire de paiement : Chariow (lien à montant libre). Confirmation manuelle par l'équipe, avec contrôle du montant.
alter table payment_transactions alter column provider set default 'chariow';
alter table payment_transactions
  add column if not exists received_amount_xof int,
  add column if not exists confirmed_by uuid references profiles(id),
  add column if not exists confirmed_at timestamptz;

-- Une transaction vise exactement une cible, cohérente avec son objet.
alter table payment_transactions add constraint payment_target_chk check (
  (purpose = 'booking'      and booking_id is not null and subscription_id is null) or
  (purpose = 'subscription' and subscription_id is not null and booking_id is null) or
  (purpose in ('refund','payout'))
);
-- Un paiement ne peut être « réussi » que si le montant réellement reçu égale le montant attendu.
alter table payment_transactions add constraint payment_success_amount_chk check (
  status <> 'reussi' or (purpose in ('refund','payout')) or received_amount_xof = amount_xof
);
