// Tests de bout en bout du parcours voyageur (catalogue public, fiche, réservation, « J'ai payé »).
// Le serveur est REMPLACÉ par une imitation qui applique les mêmes refus que la base (0005, 0006) :
//   * le catalogue public ne montre que les annonces publiées et payées ;
//   * le PRIX est calculé par le serveur, jamais envoyé par le navigateur ;
//   * dates déjà prises, séjour minimum, capacité, propre logement : refusés ;
//   * réserver, voir un contact ou déclarer un paiement exigent une connexion ;
//   * une déclaration « J'ai payé » ne confirme jamais rien.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const DB = {
  listings: [
    { id: "p-1", offer: "gestion", title: "Villa Koulouba", description: "Villa avec jardin", city: "Ouagadougou", district: "Koulouba", capacity: 4, bedrooms: 2, beds: 3, nightly_price_xof: 30000, min_nights: 2, house_rules: "Non fumeur", cancellation_policy: "Gratuite 48h avant" },
    { id: "p-2", offer: "annonce", title: "Studio Gounghin", description: "Studio proche du marché", city: "Ouagadougou", district: "Gounghin", capacity: 2, bedrooms: 1, beds: 1, nightly_price_xof: 12000, min_nights: 1, house_rules: null, cancellation_policy: null },
  ],
  photos: { "p-1": ["o-1/p-1/a.jpg", "o-1/p-1/b.jpg"], "p-2": ["o-2/p-2/a.jpg"] },
  pris: [{ start_date: "2026-12-24", end_date: "2026-12-27" }],
  bookings: [],
  notices: [],
  vues: [],
  connecte: false,
  seq: 1,
};
window.__db = DB;
const UID = "v-1";
const err = (code, message) => ({ data: null, error: { code, message } });
const okRes = (data) => ({ data, error: null });
const exigeConnexion = () => err("28000", "Connexion requise.");

function run(table, op, payload, filters) {
  const by = (r) => filters.every(([c, v]) => r[c] === v);
  if (table === "public_listings") return okRes(DB.listings.slice());
  if (table === "public_listing_photos") {
    const id = (filters.find(([c]) => c === "property_id") || [])[1];
    return okRes((DB.photos[id] || []).map((p, i) => ({ storage_path: p, position: i })));
  }
  if (table === "bookings") {
    if (!DB.connecte) return okRes([]);           // RLS : rien pour un visiteur
    return okRes(DB.bookings.filter((b) => b.guest_id === UID));
  }
  if (table === "profiles") return okRes([{ full_name: "Issa Traore", phone: null }]);
  if (table === "user_roles") return okRes([{ user_id: UID, role: "voyageur" }]);
  if (table === "team_permissions") return okRes([]);
  return okRes([]);
}
function builder(table) {
  let op = "select", payload = null; const filters = [];
  const exec = () => Promise.resolve(run(table, op, payload, filters));
  const self = {
    select() { return self; }, insert(p) { op = "insert"; payload = p; return self; },
    upsert(p) { op = "upsert"; payload = p; return self; }, update(p) { op = "update"; payload = p; return self; },
    delete() { op = "delete"; return self; }, eq(c, v) { filters.push([c, v]); return self; },
    order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}
const SESSION = { access_token: "jeton", user: { id: UID, email: "issa@test.local" } };
const listeners = [];
const chevauche = (a1, a2, b1, b2) => a1 < b2 && b1 < a2;

window.supabase = { createClient() { return {
  auth: {
    async getSession() { DB.connecte = !!localStorage.getItem("fs"); return okRes({ session: DB.connecte ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); DB.connecte = true; listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); DB.connecte = false; listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    if (fn === "public_booked_ranges") return Promise.resolve(okRes(DB.pris.slice()));
    if (fn === "create_booking") {
      if (!DB.connecte) return Promise.resolve(exigeConnexion());
      const l = DB.listings.find((x) => x.id === a.p_property);
      if (!l) return Promise.resolve(err("P0001", "Logement indisponible."));
      if (l.offer === "annonce") return Promise.resolve(err("P0001", "Ce logement ne se réserve pas en ligne."));
      // Même règle que create_booking en base (0012) : le téléphone est obligatoire.
      // Écrit SANS antislash : ce code vit dans un littéral gabarit, qui mangerait les échappements.
      const tel = String(a.p_phone || "").replace(/[^0-9+]/g, "");
      const telValide = tel.length >= 8 && tel.length <= 16 && /^[+]?[0-9]+$/.test(tel);
      if (!telValide) {
        return Promise.resolve(err("P0001", "Indiquez un numéro de téléphone valide : c'est par là que nous vous joindrons pour la remise des clés."));
      }
      const n = Math.round((Date.parse(a.p_end) - Date.parse(a.p_start)) / 86400000);
      if (n <= 0) return Promise.resolve(err("P0001", "Les dates ne sont pas valides."));
      if (n < l.min_nights) return Promise.resolve(err("P0001", "Le séjour minimum est de " + l.min_nights + " nuits."));
      if (a.p_guests > l.capacity) return Promise.resolve(err("P0001", "Ce logement accueille " + l.capacity + " voyageurs au maximum."));
      if (DB.pris.some((r) => chevauche(a.p_start, a.p_end, r.start_date, r.end_date)))
        return Promise.resolve(err("P0001", "Ces dates ne sont plus disponibles."));
      // PRIX CALCULÉ PAR LE SERVEUR
      const total = n * l.nightly_price_xof;
      const b = { id: "b-" + DB.seq++, property_id: l.id, guest_id: UID, stay: "[" + a.p_start + "," + a.p_end + ")",
                  guests: a.p_guests, nightly_price_xof: l.nightly_price_xof, accommodation_xof: total, total_xof: total,
                  status: "en_attente_paiement", hold_expires_at: new Date(Date.now() + 15 * 60000).toISOString(),
                  created_at: new Date().toISOString(), guest_phone: tel };
      DB.bookings.push(b); DB.pris.push({ start_date: a.p_start, end_date: a.p_end });
      return Promise.resolve(okRes(b));
    }
    if (fn === "reveal_contact") {
      if (!DB.connecte) return Promise.resolve(exigeConnexion());
      const l = DB.listings.find((x) => x.id === a.p_property);
      if (!l || l.offer !== "annonce") return Promise.resolve(err("P0001", "Contact indisponible."));
      DB.vues.push({ property_id: a.p_property, at: Date.now() });
      return Promise.resolve(okRes({ contact_name: "Salif Kabore", phone: "+226 70 55 44 33", whatsapp: true }));
    }
    if (fn === "declare_payment") {
      if (!DB.connecte) return Promise.resolve(exigeConnexion());
      const b = DB.bookings.find((x) => x.id === a.p_id);
      if (!b) return Promise.resolve(err("P0001", "Réservation introuvable."));
      if (a.p_amount <= 0) return Promise.resolve(err("P0001", "Montant invalide."));
      DB.notices.push({ id: "n-" + DB.seq++, booking_id: a.p_id, declared_amount_xof: a.p_amount, reference: a.p_reference, message: a.p_message, status: "nouveau" });
      return Promise.resolve(okRes({}));   // la réservation N'EST PAS confirmée
    }
    return Promise.resolve(okRes(null));
  },
  storage: { from() { return {
    async createSignedUrl() { return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ viewport: { width: 1280, height: 1100 } });
await ctx.route("**cdn.jsdelivr.net/**", (r) => r.abort());
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
let body;

// --- catalogue public, sans compte ---
await p.goto(URL + "#sejours"); await p.waitForSelector("h1");
await p.waitForTimeout(500);
body = await p.locator("body").innerText();
ok("le catalogue est consultable sans compte", /Villa Koulouba/.test(body) && /Studio Gounghin/.test(body));
ok("le prix par nuit est affiché", /30 000/.test(body.replace(/ | /g, " ")));
ok("la recherche filtre les logements", true);
await p.fill("#v-q", "gounghin");
await p.waitForTimeout(300);
body = await p.locator("body").innerText();
ok("recherche : seul le logement correspondant reste", /Studio Gounghin/.test(body) && !/Villa Koulouba/.test(body));
await p.fill("#v-q", "");
await p.waitForTimeout(300);

// --- fiche d'un logement réservable ---
await p.getByText("Villa Koulouba").first().click();
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("fiche : description et règles affichées", /Villa avec jardin/.test(body) && /Non fumeur/.test(body));
ok("fiche : dates déjà prises affichées", /2026-12-24/.test(body));
ok("fiche : sans compte, invitation à se connecter", await p.getByRole("button", { name: "Se connecter pour réserver" }).count() === 1);
ok("fiche : aucune réservation possible sans compte", await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).count() === 0);

// --- connexion ---
await p.getByRole("button", { name: "Se connecter pour réserver" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "issa@test.local"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(600);
await p.evaluate(() => { location.hash = "offre-p-1"; });
await p.waitForTimeout(700);
ok("connecté : le bouton de réservation apparaît", await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).count() === 1);

// --- le téléphone est obligatoire (migration 0012) ---
ok("sans numéro, le bouton « Réserver » est inactif",
  await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).isDisabled());
ok("et l'écran dit pourquoi", /Indiquez votre téléphone pour pouvoir réserver/.test(await p.locator("body").innerText()));
ok("la raison du numéro est expliquée, pas seulement exigée",
  /joint pour la remise des clés/.test(await p.locator("body").innerText()));
await p.fill("#v-tel", "pas un numero");
await p.waitForTimeout(200);
ok("un numéro illisible laisse le bouton inactif",
  await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).isDisabled());
ok("et le signale", /ne ressemble pas à un numéro/.test(await p.locator("body").innerText()));
await p.fill("#v-tel", "70 00 00 42");
await p.waitForTimeout(200);
ok("avec un numéro valide, le bouton s'active",
  await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).isEnabled());

// --- refus du serveur : séjour trop court ---
await p.fill("#v-in", "2027-03-10"); await p.fill("#v-out", "2027-03-11");
await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).click();
await p.waitForTimeout(500);
ok("séjour plus court que le minimum : refusé", /séjour minimum est de 2 nuits/.test(await p.locator("[role=alert]").first().innerText()));
ok("aucune réservation créée", await p.evaluate(() => window.__db.bookings.length === 0));

// --- refus : trop de voyageurs ---
await p.fill("#v-in", "2027-03-10"); await p.fill("#v-out", "2027-03-13"); await p.fill("#v-pax", "9");
await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).click();
await p.waitForTimeout(500);
ok("trop de voyageurs : refusé", /4 voyageurs au maximum/.test(await p.locator("[role=alert]").first().innerText()));

// --- refus : dates déjà prises ---
await p.fill("#v-pax", "2");
await p.fill("#v-in", "2026-12-25"); await p.fill("#v-out", "2026-12-28");
await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).click();
await p.waitForTimeout(500);
ok("dates déjà prises : refusées", /ne sont plus disponibles/.test(await p.locator("[role=alert]").first().innerText()));
ok("toujours aucune réservation créée", await p.evaluate(() => window.__db.bookings.length === 0));

// --- réservation acceptée : le PRIX vient du serveur ---
await p.fill("#v-in", "2027-03-10"); await p.fill("#v-out", "2027-03-13");
await p.locator("main").getByRole("button", { name: "Réserver", exact: true }).click();
await p.waitForTimeout(700);
body = await p.locator("body").innerText();
ok("réservation enregistrée", /Réservation enregistrée/.test(body));
const bk = await p.evaluate(() => window.__db.bookings[0]);
ok("le total est calculé par le serveur (3 × 30 000)", bk && bk.total_xof === 90000);
ok("le navigateur n'a envoyé aucun prix", await p.evaluate(() => !("p_price" in (window.__db.bookings[0] || {}))));
ok("statut initial : en attente de paiement", bk && bk.status === "en_attente_paiement");
ok("les dates sont retenues 15 minutes", /retenues 15 minutes/.test(body));

// --- mes séjours + « J'ai payé » ---
await p.getByRole("button", { name: "Payer et suivre ma réservation" }).click();
await p.waitForTimeout(700);
body = await p.locator("body").innerText();
ok("mes séjours : la réservation apparaît", /2027-03-10/.test(body));
ok("mes séjours : état « En attente de paiement »", /En attente de paiement/.test(body));
ok("mes séjours : le délai restant est indiqué", /retenues encore \d+ minute/.test(body));
ok("mes séjours : le paiement en ligne est proposé en premier", /en ligne/.test(body));
// Le paiement hors ligne est désormais replié sous « Ou payer hors ligne » : on l'ouvre.
ok("mes séjours : le paiement hors ligne reste accessible", /Ou payer hors ligne/.test(body));
await p.getByText("Ou payer hors ligne").click();
await p.waitForTimeout(400);
body = await p.locator("body").innerText();
ok("rappel : une déclaration n'est pas une preuve", /n'est pas une preuve de paiement/.test(body));
await p.fill("input[id^='d-a-']", "0");
await p.getByRole("button", { name: "J'ai payé" }).click();
await p.waitForTimeout(300);
ok("montant vide ou nul : refusé", /Indiquez le montant payé/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("input[id^='d-a-']", "90000");
await p.fill("input[id^='d-r-']", "CH-2026-77");
await p.getByRole("button", { name: "J'ai payé" }).click();
await p.waitForTimeout(700);
ok("déclaration envoyée", await p.evaluate(() => window.__db.notices.length === 1));
ok("la référence est transmise", await p.evaluate(() => window.__db.notices[0].reference === "CH-2026-77"));
ok("la déclaration ne confirme PAS la réservation", await p.evaluate(() => window.__db.bookings[0].status === "en_attente_paiement"));
ok("message : l'équipe doit vérifier", /vérifie la réception/.test(await p.locator("body").innerText()));

// --- offre YIRI Annonce : pas de réservation, contact sur demande ---
await p.evaluate(() => { location.hash = "offre-p-2"; });
await p.waitForTimeout(700);
body = await p.locator("body").innerText();
ok("offre YIRI Annonce : aucune réservation en ligne", /se fait directement avec le propriétaire/.test(body));
ok("offre YIRI Annonce : le contact n'est pas affiché d'emblée", !/70 55 44 33/.test(body));

// L'avertissement anti-arnaque. Sur ces logements YIRI n'encaisse rien et ne peut rien
// récupérer : la seule protection du voyageur est ce message, et il doit être lu AVANT
// d'obtenir le numéro, pas seulement après.
ok("avertissement visible AVANT d'afficher le contact", /Ne versez aucun argent à l'avance/.test(body));
ok("il dit quand payer", /au moment où le propriétaire vous remet les clés/.test(body));
ok("il nomme les pièges : acompte, frais, transfert pour bloquer les dates",
  /acompte/.test(body) && /frais de réservation/.test(body) && /bloquer les dates/.test(body));
ok("il dit franchement que YIRI ne pourra pas récupérer l'argent",
  /ne pourrons\s+pas récupérer|pas récupérer une somme/.test(body));

await p.getByRole("button", { name: "Afficher le contact" }).click();
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("contact révélé après demande", /Salif Kabore/.test(body) && /70 55 44 33/.test(body));
ok("la consultation est comptée côté serveur", await p.evaluate(() => window.__db.vues.length === 1));
ok("mention : une consultation par 24 heures", /24 heures/.test(body));
ok("l'avertissement est RÉPÉTÉ à côté du numéro",
  (body.match(/Ne versez aucun argent à l'avance/g) || []).length === 2);

// --- déconnexion : plus rien de personnel ---
await p.evaluate(() => { location.hash = "compte"; });
await p.waitForTimeout(400);
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForTimeout(400);
await p.evaluate(() => { location.hash = "mes-sejours"; });
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("déconnecté : les réservations ne sont plus visibles", !/2027-03-10/.test(body));
ok("déconnecté : invitation à se connecter", /Connectez-vous pour retrouver/.test(body));
await p.evaluate(() => { location.hash = "sejours"; });
await p.waitForTimeout(600);
ok("déconnecté : le catalogue public reste consultable", /Villa Koulouba/.test(await p.locator("body").innerText()));

ok("aucune erreur JavaScript pendant les tests", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 3).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DU PARCOURS VOYAGEUR SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
