import { assertXOF, percentOf, type XOF } from "./money";
import { nightsBetween, rangesOverlap, type ISODate } from "./dates";

// ---------- Devis de réservation (calculé côté serveur en production) ----------

export interface PricedProperty {
  nightlyPrice: XOF;
  capacity: number;
  minNights: number;
}

export interface BlockingRange {
  start: ISODate;
  end: ISODate; // exclu
}

export type QuoteError =
  | "DATES_INVALIDES"
  | "SEJOUR_TROP_COURT"
  | "CAPACITE_DEPASSEE"
  | "VOYAGEURS_INVALIDES"
  | "DATES_INDISPONIBLES";

export interface Quote {
  nights: number;
  nightlyPrice: XOF;
  accommodation: XOF; // hébergement = base des RLP
  total: XOF;
}

export function quoteBooking(
  p: PricedProperty,
  checkIn: ISODate,
  checkOut: ISODate,
  guests: number,
  blocking: BlockingRange[] = []
): { ok: true; quote: Quote } | { ok: false; error: QuoteError } {
  let nights: number;
  try {
    nights = nightsBetween(checkIn, checkOut);
  } catch {
    return { ok: false, error: "DATES_INVALIDES" };
  }
  if (nights <= 0) return { ok: false, error: "DATES_INVALIDES" };
  if (!Number.isInteger(guests) || guests < 1) return { ok: false, error: "VOYAGEURS_INVALIDES" };
  if (guests > p.capacity) return { ok: false, error: "CAPACITE_DEPASSEE" };
  if (nights < p.minNights) return { ok: false, error: "SEJOUR_TROP_COURT" };
  if (blocking.some((b) => rangesOverlap(checkIn, checkOut, b.start, b.end))) {
    return { ok: false, error: "DATES_INDISPONIBLES" };
  }
  const accommodation = assertXOF(p.nightlyPrice * nights, "hébergement");
  return {
    ok: true,
    quote: { nights, nightlyPrice: p.nightlyPrice, accommodation, total: accommodation },
  };
}

export const QUOTE_ERROR_FR: Record<QuoteError, string> = {
  DATES_INVALIDES: "La date de départ doit être après la date d'arrivée.",
  SEJOUR_TROP_COURT: "La durée minimale de séjour n'est pas atteinte.",
  CAPACITE_DEPASSEE: "Le nombre de voyageurs dépasse la capacité du logement.",
  VOYAGEURS_INVALIDES: "Indiquez au moins un voyageur.",
  DATES_INDISPONIBLES: "Ces dates ne sont pas disponibles.",
};

// ---------- YIRI Gestion : revenus locatifs partageables (RLP) et partage ----------

export interface RLPInput {
  accommodationCollected: XOF; // hébergement réellement encaissé
  discounts?: XOF;
  refunds?: XOF;
  thirdPartyTaxes?: XOF; // taxes collectées pour un tiers
  paymentFees?: XOF;
  deductPaymentFees: boolean; // seulement si le contrat le prévoit
}

/** §8 : RLP = hébergement encaissé − remises − remboursements − taxes tiers − (frais de paiement si contrat). Plancher à 0. */
export function computeRLP(i: RLPInput): XOF {
  const deductions =
    (i.discounts ?? 0) + (i.refunds ?? 0) + (i.thirdPartyTaxes ?? 0) + (i.deductPaymentFees ? i.paymentFees ?? 0 : 0);
  for (const [k, v] of Object.entries(i)) if (typeof v === "number") assertXOF(v, k);
  return Math.max(0, i.accommodationCollected - deductions);
}

export interface Split {
  rlp: XOF;
  ownerShare: XOF;
  yiriCommission: XOF;
}

/** Partage propriétaire/YIRI. Le propriétaire reçoit sa part arrondie ; YIRI reçoit le reste, la somme est toujours exacte. */
export function splitRevenue(rlp: XOF, ownerPercent = 60): Split {
  assertXOF(rlp, "RLP");
  const ownerShare = percentOf(rlp, ownerPercent);
  return { rlp, ownerShare, yiriCommission: rlp - ownerShare };
}

export interface StatementInput extends RLPInput {
  ownerExpenses?: XOF; // eau, électricité, Wi-Fi, réparations… justifiées
  yiriVariableCosts?: XOF; // ménage, consommables, déplacements, frais imputés à YIRI
  ownerPercent?: number;
}

export interface Statement extends Split {
  ownerExpenses: XOF;
  ownerNet: number; // peut être négatif : montant à régulariser, jamais masqué
  yiriVariableCosts: XOF;
  yiriContribution: number; // avant coûts fixes et impôts — pas un bénéfice net
}

export function buildStatement(i: StatementInput): Statement {
  const split = splitRevenue(computeRLP(i), i.ownerPercent ?? 60);
  const ownerExpenses = assertXOF(i.ownerExpenses ?? 0, "dépenses propriétaire");
  const yiriVariableCosts = assertXOF(i.yiriVariableCosts ?? 0, "coûts YIRI");
  return {
    ...split,
    ownerExpenses,
    ownerNet: split.ownerShare - ownerExpenses,
    yiriVariableCosts,
    yiriContribution: split.yiriCommission - yiriVariableCosts,
  };
}

// ---------- YIRI Annonce : abonnements ----------

export const PLANS = {
  mensuel: { label: "Mensuel", price: 5_000, months: 1 },
  annuel: { label: "Annuel", price: 30_000, months: 12 },
} as const;
export type PlanId = keyof typeof PLANS;
