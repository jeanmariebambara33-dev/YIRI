// YIRI — réception des messages du prestataire de paiement.
//
// Cette fonction est le SEUL point par lequel un paiement peut être confirmé automatiquement.
// Elle est publique (le prestataire ne possède pas de JWT), donc elle se protège elle-même :
//
//   1. signature vérifiée avant toute lecture du contenu ;
//   2. le prestataire est RÉINTERROGÉ pour connaître le vrai statut : on ne croit pas le message
//      sur parole, même signé, car un message signé ancien peut décrire un état dépassé ;
//   3. la base refuse de toute façon un montant différent de celui qu'elle a calculé elle-même ;
//   4. le même message reçu cinq fois (le prestataire réessaie jusqu'à 5 fois) n'encaisse qu'une fois.
//
// Fichier AUTONOME : rien à importer, pour pouvoir être collé tel quel dans le tableau de bord
// Supabase. À déployer SANS vérification de JWT.
//
// Variables d'environnement attendues (Edge Functions → Secrets) :
//   SASPAY_SECRET_KEY, SASPAY_WEBHOOK_SECRET
//   SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont fournies automatiquement par Supabase.

const SASPAY_BASE = "https://api.saspay.me/api/v1";

/** Variable d'environnement obligatoire. On échoue bruyamment plutôt que de deviner. */
export function requis(nom: string): string {
  const v = Deno.env.get(nom);
  if (!v || v.trim() === "") throw new Error(`Variable d'environnement manquante : ${nom}`);
  return v.trim();
}

/** Appel d'une fonction de la base avec la clé de service. */
export async function rpc<T>(fn: string, args: Record<string, unknown>, cle: string): Promise<T> {
  const r = await fetch(`${requis("SUPABASE_URL")}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { "apikey": cle, "Authorization": `Bearer ${cle}`, "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  const texte = await r.text();
  if (!r.ok) throw new Error(`${fn} a échoué (${r.status}) : ${texte.slice(0, 300)}`);
  return (texte ? JSON.parse(texte) : null) as T;
}

/** Hexadécimal minuscule du HMAC-SHA256. */
export async function hmacHex(secret: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const cle = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", cle, enc.encode(message));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Comparaison à durée constante : comparer avec « === » laisse fuir, octet par octet,
 *  où la signature diverge, ce qui permet de la reconstituer essai après essai. */
export function egalConstant(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** Vérifie un message reçu du prestataire.
 *  Le texte signé est « horodatage + point + corps brut », jamais le corps seul :
 *  sans l'horodatage dans la signature, un message authentique capté une fois pourrait être
 *  rejoué indéfiniment. Le corps doit être le texte EXACT reçu, jamais un JSON re-sérialisé,
 *  car le moindre espace change la signature. */
export async function signatureValide(
  corpsBrut: string,
  signatureRecue: string | null,
  horodatage: string | null,
  secret: string,
  toleranceSecondes = 300,
): Promise<{ ok: true } | { ok: false; raison: string }> {
  if (!signatureRecue) return { ok: false, raison: "signature absente" };
  if (!horodatage) return { ok: false, raison: "horodatage absent" };

  const ts = Number(horodatage);
  if (!Number.isFinite(ts)) return { ok: false, raison: "horodatage illisible" };
  const ecart = Math.abs(Math.floor(Date.now() / 1000) - ts);
  if (ecart > toleranceSecondes) return { ok: false, raison: `horodatage trop ancien (${ecart} s)` };

  const attendue = await hmacHex(secret, `${horodatage}.${corpsBrut}`);
  if (!egalConstant(attendue, signatureRecue.trim().toLowerCase())) {
    return { ok: false, raison: "signature invalide" };
  }
  return { ok: true };
}

export function json(donnees: unknown, status = 200): Response {
  return new Response(JSON.stringify(donnees), { status, headers: { "Content-Type": "application/json" } });
}

type Transaction = {
  id?: string;
  reference?: string;
  status?: string;
  amount?: number | string;
  fee?: number | string;
  net_amount?: number | string;
  charged?: number | string;
  fee_charge_mode?: string;
  currency?: string;
  msisdn?: string;
  network?: string;
};

function entier(v: unknown): number | null {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? n : null;
}

export async function traiter(req: Request): Promise<Response> {
  if (req.method !== "POST") return json({ erreur: "méthode non autorisée" }, 405);

  // Le corps BRUT, tel que reçu. Toute réécriture invaliderait la signature.
  const corpsBrut = await req.text();

  const verdict = await signatureValide(
    corpsBrut,
    req.headers.get("X-Webhook-Signature"),
    req.headers.get("X-Webhook-Timestamp"),
    requis("SASPAY_WEBHOOK_SECRET"),
  );
  if (!verdict.ok) {
    // On ne dit pas au demandeur ce qui a échoué : ce serait l'aider à réessayer utilement.
    console.error("message refusé :", verdict.raison);
    return json({ erreur: "refusé" }, 403);
  }

  let message: { event?: string; data?: Transaction };
  try {
    message = JSON.parse(corpsBrut);
  } catch {
    return json({ erreur: "corps illisible" }, 400);
  }

  const evenement = message.event ?? "";
  const d = message.data ?? {};

  // Message de test envoyé depuis le tableau de bord : signature vérifiée, rien à faire.
  if (evenement === "webhook.test") return json({ ok: true, resultat: "test_recu" });

  const service = requis("SUPABASE_SERVICE_ROLE_KEY");
  const appel = <T>(fn: string, args: Record<string, unknown>) => rpc<T>(fn, args, service);

  if (!d.id) return json({ ok: true, resultat: "sans_identifiant" });

  // Retrouver NOTRE référence. Repli sur le champ « reference » si le prestataire la renvoie.
  let reference = await appel<string | null>("payment_reference_of", { p_provider_id: d.id });
  if (!reference && typeof d.reference === "string" && d.reference.startsWith("YIRI")) {
    reference = d.reference;
  }
  if (!reference) {
    // Paiement qui ne vient pas de YIRI, ou tentative jamais enregistrée.
    // On répond 200 : sinon le prestataire réessaierait cinq fois pour rien.
    console.warn("message signé mais référence inconnue :", d.id);
    return json({ ok: true, resultat: "reference_inconnue" });
  }

  try {
    if (evenement === "transaction.success") {
      // ---- Étape 2 : on redemande au prestataire, c'est lui la source de vérité ----
      const r = await fetch(`${SASPAY_BASE}/payments/${encodeURIComponent(d.id)}/verify/`, {
        headers: { "Authorization": `Bearer ${requis("SASPAY_SECRET_KEY")}` },
      });
      if (!r.ok) {
        // Échec temporaire de notre côté : on renvoie 500 pour que le prestataire réessaie.
        console.error("vérification impossible :", r.status, (await r.text()).slice(0, 200));
        return json({ erreur: "vérification impossible" }, 500);
      }
      const verif = await r.json();
      const vd = (verif?.data ?? {}) as Transaction;
      const statut = String(vd.status ?? "").toUpperCase();
      if (statut !== "SUCCESS") {
        console.warn(`le prestataire annonce « success » mais répond « ${statut} » : rien n'est encaissé`);
        return json({ ok: true, resultat: "statut_non_confirme", statut });
      }

      const devise = String(vd.currency ?? d.currency ?? "").toUpperCase();
      if (devise && devise !== "XOF") {
        console.error("devise inattendue :", devise);
        return json({ ok: true, resultat: "devise_refusee", devise });
      }

      const montant = entier(vd.amount ?? d.amount);
      if (montant === null || montant <= 0) {
        console.error("montant illisible");
        return json({ ok: true, resultat: "montant_illisible" });
      }

      // Les frais d'abord : ils entrent dans le calcul d'un éventuel remboursement.
      const frais = entier(vd.fee ?? d.fee) ?? 0;
      await appel("record_payment_fee", {
        p_reference: reference,
        p_fee_xof: frais,
        p_mode: String(vd.fee_charge_mode ?? d.fee_charge_mode ?? ""),
      });

      // Le compte du payeur : seule destination autorisée pour un remboursement.
      const payeur = String(vd.msisdn ?? d.msisdn ?? "").trim();
      if (payeur) await appel("set_payment_payer", { p_reference: reference, p_account: payeur });

      // La base recalcule et refuse tout écart. Elle seule décide.
      const resultat = await appel<string>("confirm_payment_online", {
        p_reference: reference,
        p_received_amount_xof: montant,
        p_method: String(vd.network ?? d.network ?? "").slice(0, 40) || null,
      });
      return json({ ok: true, resultat });
    }

    if (evenement === "transaction.failed" || evenement === "transaction.cancelled") {
      await appel("fail_online_payment", { p_reference: reference, p_reason: evenement });
      return json({ ok: true, resultat: "echec_enregistre" });
    }

    // transaction.created, settlement.*, wallet_transfer.* : rien à faire côté réservations.
    return json({ ok: true, resultat: "ignore", evenement });
  } catch (e) {
    // Erreur de notre côté : 500 pour que le prestataire réessaie (immédiat, 30 s, 5 min, 30 min, 2 h).
    console.error("traitement en échec :", e instanceof Error ? e.message : String(e));
    return json({ erreur: "traitement en échec" }, 500);
  }
}

Deno.serve(traiter);
