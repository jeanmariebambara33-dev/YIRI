// Tentative de falsification depuis le navigateur.
//
// Ce script datait de la maquette : il CONSTATAIT qu'on pouvait se fabriquer un accès
// administrateur en écrivant dans le stockage du navigateur, parce que les droits vivaient
// dans la page. Ce n'est plus vrai : les rôles et les autorisations sont lus dans la base, et
// la base les vérifie à chaque requête. Le script devient donc un garde-fou : il échoue si un
// accès forgé redevient possible un jour.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1200 } });
// Aucune requête ne sort : la page ne parlera donc à aucun serveur. Un accès accordé ici
// serait un accès accordé par la page elle-même, c'est-à-dire exactement ce qu'on interdit.
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
const p = await ctx.newPage();
const texte = () => p.locator("body").innerText();

await p.goto(URL);
await p.waitForSelector("h1");

// 1. Les anciennes clés de la maquette : plus personne ne les lit.
await p.evaluate(() => {
  localStorage.setItem("yiri-team-v1", JSON.stringify([{
    id: "x", name: "Intrus", email: "i@x", hash: "0", isOwner: true,
    perms: ["validation", "reservations", "partenariat", "demandes", "paiements", "audit", "equipe"],
    createdAt: new Date().toISOString(),
  }]));
  sessionStorage.setItem("yiri-session-v1", "x");
});
await p.goto(URL + "#equipe");
await p.waitForSelector("h1");
let t = await texte();
ok("un accès équipe forgé dans le stockage n'ouvre rien", !/Pièces d'identité|Paiements|Journal/.test(t));
ok("et l'intrus n'apparaît nulle part", !/Intrus/.test(t));

// 2. Une session et des rôles inventés de toutes pièces, aux noms utilisés aujourd'hui.
await p.evaluate(() => {
  const faux = { access_token: "forge", user: { id: "intrus", email: "i@x" } };
  for (const cle of Object.keys(localStorage)) if (cle.startsWith("sb-")) localStorage.removeItem(cle);
  localStorage.setItem("sb-kzzrowymwwxoydklnkfb-auth-token", JSON.stringify(faux));
  localStorage.setItem("yiri-roles", JSON.stringify(["admin"]));
  localStorage.setItem("yiri-perms", JSON.stringify(["validation", "paiements", "audit"]));
});
await p.goto(URL + "#equipe");
await p.waitForSelector("h1");
t = await texte();
ok("un jeton inventé n'ouvre pas l'espace équipe", !/Pièces d'identité en attente|Journal/.test(t));

await p.goto(URL + "#espace");
await p.waitForSelector("h1");
t = await texte();
ok("ni l'espace propriétaire", !/Mes annonces|Mon abonnement/.test(t));

// 3. Le rôle n'est plus choisissable depuis la page : aucun bouton de démonstration ne subsiste.
for (const h of ["", "#logements", "#espace", "#equipe", "#compte"]) {
  await p.goto(URL + h);
  await p.waitForSelector("h1");
  const n = await p.getByRole("button", { name: /Je suis propriétaire|Mode admin|Devenir propriétaire|Réinitialiser la démo/ }).count();
  ok(`aucun bouton de démonstration ne change les droits (${h || "accueil"})`, n === 0);
}

// 4. Aucune authentification locale ne doit revenir dans le dépôt.
//    src/auth.tsx portait comptes et autorisations dans localStorage. Il n'était plus importé
//    nulle part, mais un fichier mort qui distribue des droits est exactement ce que ce script
//    existe pour interdire. Ce contrôle empêche qu'il revienne par mégarde.
{
  const fs = await import("node:fs");
  ok("aucun fichier d'authentification locale dans les sources",
    !fs.existsSync("/home/claude/yiri/src/auth.tsx"));
  const sources = fs.readdirSync("/home/claude/yiri/src", { recursive: true })
    .filter((f) => typeof f === "string" && /[.]tsx?$/.test(f) && !f.includes("test"));
  const coupables = sources.filter((f) => {
    const t = fs.readFileSync("/home/claude/yiri/src/" + f, "utf8");
    // Un écran qui lit un rôle ou une autorisation dans le stockage du navigateur.
    return /localStorage[^;]{0,80}(perms?|role|session-|team|admin)/i.test(t);
  });
  ok("aucune source ne lit un rôle ou une autorisation dans le stockage du navigateur",
    coupables.length === 0, coupables.join(", "));
}

await b.close();
console.log(fails === 0 ? "\nAUCUN ACCES FORGE N'ABOUTIT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
