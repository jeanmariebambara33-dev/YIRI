import * as React from "react";
import { StoreProvider, useStore } from "./store";
import { Button } from "./ui";
import { Home } from "./pages/public";
import { OfferAnnonce, OfferGestion, OfferPartenariat } from "./pages/offers";
import { ProprietairesPage, SolutionsPage, DemandePage } from "./pages/owners";
import { SessionProvider, useSession } from "./session";
import { ComptePage, MonCompte, type CompteMode } from "./pages/compte";
import { EspacePro } from "./pages/espace";
import { EquipeYiri } from "./pages/equipe";
import { CatalogueReel, FicheReelle, MesReservations } from "./pages/voyage";
import { LegalRoute } from "./pages/legal";
import { SOCIETE, ANNEE } from "./data/legal";
import { InstallBanner } from "./install";
import { Intro } from "./intro";
import * as api from "./lib/api";


function Header() {
  const { go } = useStore();
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-2 px-4 py-3 sm:px-6">
        <button onClick={() => go({ name: "accueil" })} className="flex items-baseline gap-2 cursor-pointer" aria-label="YIRI, accueil">
          <span className="font-display text-2xl font-extrabold tracking-tight text-ink">YIRI</span>
          <span className="hidden text-xs text-muted sm:inline">location meublée · Burkina Faso</span>
        </button>
        <nav className="flex flex-wrap items-center gap-1 text-sm font-semibold" aria-label="Navigation principale">
          <Button variant="ghost" size="sm" onClick={() => go({ name: "sejours" })}>Logements</Button>
          <Button variant="ghost" size="sm" onClick={() => go({ name: "proprietaires" })}>Propriétaires</Button>
          <Button variant="ghost" size="sm" onClick={() => go({ name: "mes-sejours" })}>Mes séjours</Button>
          <Button size="sm" className="ml-1" onClick={() => go({ name: "espace" })}>Publier mon logement</Button>
          <NotificationsButton />
          <EquipeButton />
          <EspaceButton />
          <CompteButton />
        </nav>
      </div>
    </header>
  );
}

function Router() {
  const { route } = useStore();
  // L'accueil gère sa propre largeur (fond pleine largeur) ; les autres pages restent centrées.
  if (route.name === "accueil") return <Home />;
  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6">
      <BackButton />
      <Page />
    </div>
  );
}

function ArrowLeft() {
  return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6" /></svg>;
}

function BackButton() {
  const { back, canBack } = useStore();
  return (
    <>
      <button onClick={back} className="mt-4 inline-flex items-center gap-2 rounded-full border border-line-strong bg-surface px-3 py-1.5 text-sm font-semibold text-ink cursor-pointer hover:border-ink">
        <ArrowLeft /> {canBack ? "Retour" : "Accueil"}
      </button>
      <button onClick={back} aria-label="Retour" className="fixed bottom-4 left-4 z-30 grid size-12 place-items-center rounded-full bg-ink text-bg shadow-lg cursor-pointer sm:hidden">
        <ArrowLeft />
      </button>
    </>
  );
}

function Page() {
  const { route, go: goTo } = useStore();
  const login = () => goTo({ name: "compte", mode: "connexion" });
  switch (route.name) {
    case "accueil": return <Home />;
    // Pages de présentation (aucune donnée fictive)
    case "offre-annonce": return <OfferAnnonce />;
    case "offre-gestion": return <OfferGestion />;
    case "offre-partenariat": return <OfferPartenariat />;
    case "proprietaires": return route.at === "solutions" ? <SolutionsPage /> : <ProprietairesPage key={(route.need ?? "") + (route.at ?? "")} need={route.need} at={route.at} />;
    case "demande": return <DemandePage key={route.pack ?? "x"} pack={route.pack} />;
    // Parcours voyageur (données réelles)
    case "sejours": case "catalogue": return <CatalogueReel onOpen={(id) => goTo({ name: "offre", id })} />;
    case "offre": return <FicheReelle id={route.id} onBack={() => goTo({ name: "sejours" })} onLogin={login} onBookings={() => goTo({ name: "mes-sejours" })} />;
    case "logement": return <FicheReelle id={route.id} onBack={() => goTo({ name: "sejours" })} onLogin={login} onBookings={() => goTo({ name: "mes-sejours" })} />;
    case "mes-sejours": case "mes-reservations": case "paiement": case "merci":
      return <MesReservations onLogin={login} onCatalogue={() => goTo({ name: "sejours" })} />;
    // Espace propriétaire et espace équipe (données réelles)
    case "espace": case "proprietaire": case "nouvelle-annonce": return <EspaceRoute />;
    case "equipe": case "admin": case "connexion": return <EquipeRoute />;
    case "compte": return <CompteRoute mode={route.mode} />;
    case "legal": return <LegalRoute page={route.page} />;
  }
}

function CompteRoute({ mode }: { mode?: CompteMode }) {
  const { go } = useStore();
  const s = useSession();
  const setMode = React.useCallback((m: CompteMode) => go({ name: "compte", mode: m }), [go]);
  if (!s.ready) return <p className="py-16 text-center text-muted">Chargement…</p>;
  if (s.account && !s.recovery && mode !== "nouveau") return <MonCompte onLogin={() => setMode("connexion")} />;
  return <ComptePage mode={mode ?? "connexion"} onMode={setMode} onDone={() => go({ name: "compte" })} />;
}

function EspaceRoute() {
  const { go } = useStore();
  return <EspacePro onLogin={() => go({ name: "compte", mode: "connexion" })} />;
}

function EquipeRoute() {
  const { go } = useStore();
  return <EquipeYiri onLogin={() => go({ name: "compte", mode: "connexion" })} />;
}

/** Bouton de compte dans l'en-tête : état réel de la session, jamais une supposition du navigateur. */
function EspaceButton() {
  const { go } = useStore();
  const s = useSession();
  if (!s.ready || !s.account) return null;
  return <Button variant="ghost" size="sm" onClick={() => go({ name: "espace" })}>Mes annonces</Button>;
}

/** Cloche de notifications.
 *
 *  Les migrations 0011 et 0014 écrivent déjà les bons messages en base — réservation payée,
 *  abonnement qui expire dans sept jours, remboursement parti. Mais AUCUN écran ne les lisait :
 *  tout ce travail d'automatisation ne produisait aucun effet visible. C'est ici que ça change.
 *
 *  Pas de rafraîchissement automatique : une relance d'abonnement n'est pas une alerte à la
 *  seconde, et interroger le serveur en boucle coûterait plus que ça ne rapporte.
 */
function NotificationsButton() {
  const s = useSession();
  const [items, setItems] = React.useState<api.AppNotification[] | null>(null);
  const [ouvert, setOuvert] = React.useState(false);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    if (!s.account) { setItems(null); return; }
    let alive = true;
    api.myNotifications().then((r) => { if (alive) setItems(r); }).catch(() => { if (alive) setItems([]); });
    return () => { alive = false; };
  }, [s.account, tick]);

  if (!s.ready || !s.account || items === null) return null;
  const nonLues = items.filter((n) => !n.read_at).length;

  const ouvrir = () => void (async () => {
    const etait = ouvert;
    setOuvert(!etait);
    if (!etait && nonLues > 0) {
      try { await api.markNotificationsRead(); setTick((t) => t + 1); } catch { /* sans effet sur la lecture */ }
    }
  })();

  return (
    <div className="relative">
      <Button variant="ghost" size="sm" onClick={ouvrir}
              aria-label={nonLues > 0 ? `Notifications, ${nonLues} non lue(s)` : "Notifications"}>
        Alertes{nonLues > 0 && (
          <span className="ml-1 rounded-full bg-danger px-1.5 py-0.5 text-xs font-bold text-white">{nonLues}</span>
        )}
      </Button>
      {ouvert && (
        <div className="absolute right-0 z-50 mt-2 w-80 max-h-96 overflow-auto rounded-2xl border border-line bg-surface p-3 shadow-lg">
          {items.length === 0 ? (
            <p className="px-1 py-2 text-sm text-muted">Aucune alerte pour le moment.</p>
          ) : items.slice(0, 20).map((n) => (
            <div key={n.id} className="border-b border-line px-1 py-2.5 last:border-0">
              <p className="text-sm font-semibold text-ink">{api.notificationLabel(n)}</p>
              <p className="mt-0.5 text-xs text-muted">{new Date(n.created_at).toLocaleString("fr-FR")}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EquipeButton() {
  const { go } = useStore();
  const s = useSession();
  if (!s.ready || !s.account) return null;
  if (!s.account.roles.includes("admin") && s.account.perms.length === 0) return null;
  return <Button variant="ghost" size="sm" onClick={() => go({ name: "equipe" })}>Équipe</Button>;
}

function CompteButton() {
  const { go } = useStore();
  const s = useSession();
  if (!s.ready) return null;
  return (
    <Button variant={s.account ? "ghost" : "secondary"} size="sm" onClick={() => go({ name: "compte" })}>
      {s.account ? (s.account.fullName.split(" ")[0] || "Mon compte") : "Connexion"}
    </Button>
  );
}

function Footer() {
  const { go } = useStore();
  const s = useSession();
  const team = !!s.account && (s.account.roles.includes("admin") || s.account.perms.length > 0);
  const lien = "text-muted underline-offset-4 hover:text-ink hover:underline cursor-pointer";
  return (
    <footer className="mt-20 border-t border-line bg-sunk">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
        <div className="flex flex-col gap-2">
          <span className="font-display text-xl font-extrabold tracking-tight text-ink">{SOCIETE.nomCommercial}</span>
          <p className="text-sm text-muted">Location meublée de courte durée au Burkina Faso.</p>
          {SOCIETE.email && (
            <a href={`mailto:${SOCIETE.email}`} className="text-sm text-muted underline-offset-4 hover:text-ink hover:underline">{SOCIETE.email}</a>
          )}
          {SOCIETE.whatsapp && (
            <a href={`https://wa.me/${SOCIETE.whatsappLien}`} target="_blank" rel="noopener noreferrer"
               className="inline-flex items-center gap-1.5 self-start text-sm font-semibold text-ink underline-offset-4 hover:underline">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.97L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.16 8.16 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23 2.2 0 4.27.86 5.83 2.41a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.23-8.24 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.24-.64.8-.78.97-.14.16-.29.18-.54.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.24-1.47-1.38-1.72-.15-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.15.16-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.86.85-.86 2.07 0 1.21.88 2.39 1.01 2.55.12.17 1.74 2.65 4.21 3.72.59.25 1.05.4 1.4.52.59.19 1.13.16 1.55.1.47-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.1-.23-.16-.48-.29Z" />
              </svg>
              WhatsApp {SOCIETE.whatsapp}
            </a>
          )}
        </div>

        <nav className="flex flex-col gap-2 text-sm" aria-label="Voyageurs">
          <h2 className="font-semibold text-ink">Voyageurs</h2>
          <button className={lien + " text-left"} onClick={() => go({ name: "sejours" })}>Trouver un logement</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "mes-sejours" })}>Mes séjours</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "compte" })}>Mon compte</button>
        </nav>

        <nav className="flex flex-col gap-2 text-sm" aria-label="Propriétaires">
          <h2 className="font-semibold text-ink">Propriétaires</h2>
          <button className={lien + " text-left"} onClick={() => go({ name: "espace" })}>Publier un logement</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "proprietaires" })}>Nos solutions</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "demande" })}>Être rappelé</button>
        </nav>

        <nav className="flex flex-col gap-2 text-sm" aria-label="Informations légales">
          <h2 className="font-semibold text-ink">Informations</h2>
          <button className={lien + " text-left"} onClick={() => go({ name: "legal", page: "cgu" })}>Conditions générales</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "legal", page: "confidentialite" })}>Confidentialité</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "legal", page: "cookies" })}>Cookies</button>
          <button className={lien + " text-left"} onClick={() => go({ name: "legal", page: "mentions" })}>Mentions légales</button>
        </nav>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-5 text-xs text-muted sm:px-6">
          <span>© {ANNEE} {SOCIETE.nomCommercial}. Tous droits réservés.</span>
          {team && (
            <button onClick={() => go({ name: "equipe" })} className="font-semibold text-muted underline underline-offset-4 cursor-pointer hover:text-ink">
              Espace équipe
            </button>
          )}
        </div>
      </div>
    </footer>
  );
}

export function App() {
  return (
    <SessionProvider>
    <StoreProvider>
      <Header />
      <main><Router /></main>
      <Footer />
      <InstallBanner />
      <Intro />
    </StoreProvider>
    </SessionProvider>
  );
}
