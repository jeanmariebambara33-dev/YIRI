-- Tests de la migration 0021 : les deux droits oubliés sont bien retirés.
--
-- Le test important n'est pas « le revoke a été écrit » mais « un visiteur ne lit rien, MÊME si
-- une politique permissive apparaissait un jour ». C'est ce second cas qui justifie la migration.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
values (t.u(1), 'u1@test.local', '{"full_name": "Un"}');

-- De quoi lire : des lignes réelles dans les deux tables.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(1), 'gestion', 'V', 'd', 'Ouagadougou', 'K', 'a', 2,1,1, 20000,1, 'publiee', false);
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status)
values (t.b(1), t.p(1), t.u(1), daterange(current_date + 30, current_date + 32), 1, 20000, 40000, 40000, 'confirmee');
insert into payment_transactions (id, purpose, booking_id, amount_xof, status, provider, provider_reference, idempotency_key)
values (t.b(9), 'booking', t.b(1), 40000, 'reussi', 'saspay', 'ref-x', 'idem-x');
insert into payment_events (transaction_id, provider_event_id, payload)
values (t.b(9), 'evt-1', '{"donnee_sensible": "ne doit jamais sortir"}');
insert into rate_events (key) values ('reveal:empreinte');

reset role;
select t.eq('les deux tables contiennent bien quelque chose',
  $$select (select count(*) from payment_events)::text || '/' || (select count(*) from rate_events)::text$$, '1/1');

-- ============ Le droit lui-même ============
select t.eq('« anon » n''a plus le droit de lire les messages du prestataire',
  $$select has_table_privilege('anon', 'public.payment_events', 'select')::text$$, 'false');
select t.eq('ni « authenticated »',
  $$select has_table_privilege('authenticated', 'public.payment_events', 'select')::text$$, 'false');
select t.eq('idem pour les compteurs de limitation',
  $$select has_table_privilege('anon', 'public.rate_events', 'select')::text$$, 'false');
select t.eq('et pour un utilisateur connecté',
  $$select has_table_privilege('authenticated', 'public.rate_events', 'select')::text$$, 'false');
select t.eq('aucun droit d''écriture non plus',
  $$select (has_table_privilege('authenticated', 'public.payment_events', 'insert')
         or has_table_privilege('authenticated', 'public.payment_events', 'update')
         or has_table_privilege('authenticated', 'public.payment_events', 'delete'))::text$$, 'false');

-- ============ L'effet réel ============
select t.as(0);
select t.must_fail('un visiteur ne peut pas lire les messages du prestataire', $$select * from payment_events$$);
select t.must_fail('ni les compteurs de limitation', $$select * from rate_events$$);
reset role; select t.as(1);
select t.must_fail('un utilisateur connecté non plus', $$select * from payment_events$$);

-- ============ LE cas qui justifie la migration ============
-- Avant 0021, une politique permissive ajoutée un jour aurait rendu la table lisible, parce que
-- le droit était resté. Maintenant, même avec une telle politique, le droit manque.
reset role;
create policy tmp_lecture_large on payment_events for select using (true);
select t.as(0);
select t.must_fail('MÊME avec une politique permissive, un visiteur ne lit rien : les deux barrières sont fermées',
  $$select * from payment_events$$);
reset role; select t.as(1);
select t.must_fail('et un utilisateur connecté non plus', $$select * from payment_events$$);
reset role;
drop policy tmp_lecture_large on payment_events;

-- ============ Les cinq autres tables de la même famille restent fermées ============
select t.eq('les sept tables sans politique sont toutes fermées au navigateur',
  $$select count(*)::text from pg_class c join pg_namespace n on n.oid = c.relnamespace
     where n.nspname = 'public' and c.relkind = 'r' and c.relrowsecurity
       and not exists (select 1 from pg_policies p where p.schemaname = 'public' and p.tablename = c.relname)
       and (has_table_privilege('anon', c.oid, 'select')
            or has_table_privilege('authenticated', c.oid, 'select'))$$, '0');

-- ============ Rien d'autre n'a bougé ============
select t.eq('aucune donnée n''a été touchée',
  $$select (select count(*) from payment_events)::text || '/' || (select count(*) from rate_events)::text$$, '1/1');
select t.eq('les politiques du reste de la base sont intactes',
  $$select (count(*) >= 55)::text from pg_policies where schemaname = 'public'$$, 'true');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0021 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
