// Tests de bout en bout des alertes sur l'appareil.
//
// Le service de notification d'un vrai téléphone (Google, Apple) ne peut pas être joint depuis
// ici : ce qui est imité, c'est LUI — exactement comme le prestataire de paiement est imité dans
// paiement-e2e.mjs. Tout le reste est le vrai code : le vrai écran, la vraie fonction
// activerPush(), les vrais appels à la base. Le chiffrement, lui, est éprouvé séparément en
// déchiffrant le message (supabase/functions/tests/push.test.mjs).
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

// La clé publique VAPID d'un vrai navigateur : 65 octets, premier octet 0x04.
const CLE = "BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM";

const FAKE = `
const DB = {
  clePublique: null,
  appareils: [],
  enregistres: [],
  retires: [],
  permission: 'default',
  demandes: 0,
  abonnement: null,
  desabonnements: 0,
  ordre: [],
  ios: false,
  installee: false,
  roles: [{ role: 'proprietaire' }],
  perms: [],
};
window.__db = DB;
const UID = 'moi';
const okRes = (data) => ({ data, error: null });
const err = (code, message) => ({ data: null, error: { code, message } });

// ---- Le service de notification du navigateur, imité ----
window.PushManager = function PushManager() {};
const b64 = (o) => { let s = ''; for (let i = 0; i < o.length; i++) s += String.fromCharCode(o[i]); return btoa(s).replace(/[+]/g, '-').replace(/[/]/g, '_').replace(/=+$/, ''); };

window.Notification = function Notification() {};
Object.defineProperty(window.Notification, 'permission', { get: () => DB.permission });
window.Notification.requestPermission = async () => {
  DB.demandes++;
  DB.ordre.push('demande-autorisation');
  if (DB.permission === 'default') DB.permission = DB.reponseAutorisation || 'granted';
  return DB.permission;
};

const faireAbonnement = (cleOctets) => ({
  endpoint: 'https://push.test.local/abc' + (DB.enregistres.length + 1),
  options: { applicationServerKey: cleOctets.buffer.slice(cleOctets.byteOffset, cleOctets.byteOffset + cleOctets.byteLength) },
  getKey(nom) {
    const n = nom === 'auth' ? 16 : 65;
    const o = new Uint8Array(n);
    for (let i = 0; i < n; i++) o[i] = (i + (nom === 'auth' ? 7 : 1)) % 251;
    if (nom !== 'auth') o[0] = 4;
    return o.buffer;
  },
  async unsubscribe() { DB.desabonnements++; DB.ordre.push('desabonnement'); DB.abonnement = null; return true; },
});

const registration = {
  pushManager: {
    async getSubscription() { return DB.abonnement; },
    async subscribe(opts) {
      if (DB.permission !== 'granted') throw new Error('autorisation refusee');
      DB.ordre.push('abonnement');
      DB.cleUtilisee = b64(new Uint8Array(opts.applicationServerKey));
      DB.userVisibleOnly = opts.userVisibleOnly;
      DB.abonnement = faireAbonnement(new Uint8Array(opts.applicationServerKey));
      return DB.abonnement;
    },
  },
  showNotification: async () => {},
};
Object.defineProperty(navigator, 'serviceWorker', {
  configurable: true,
  get: () => ({ ready: Promise.resolve(registration), register: async () => registration,
                addEventListener() {}, removeEventListener() {} }),
});

// iPhone non installé : Safari n'expose pas le push. On imite l'absence, pas seulement l'agent.
const vraiMatch = window.matchMedia.bind(window);
window.matchMedia = (q) => (q === '(display-mode: standalone)'
  ? { matches: DB.installee, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }
  : vraiMatch(q));
Object.defineProperty(navigator, 'userAgent', {
  configurable: true,
  get: () => (DB.ios
    ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 Safari/604.1'
    : 'Mozilla/5.0 (Linux; Android 13; SM-A135F Build/TP1A) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'),
});

function builder(table) {
  const run = () => {
    if (table === 'user_roles') return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    if (table === 'team_permissions') return okRes(DB.perms.map((x) => ({ user_id: UID, perm: x.perm })));
    if (table === 'profiles') return okRes([{ id: UID, full_name: 'Moussa Compaore', phone: null }]);
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; }, insert() { return self; }, update() { return self; }, upsert() { return self; },
    delete() { return self; }, eq() { return self; }, in() { return self; }, order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => (r.error ? r : { data: (r.data || [])[0] ?? null, error: null })); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: 'jeton', user: { id: UID, email: 'moussa@test.local' } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem('fs') ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem('fs', '1'); listeners.forEach((f) => f('SIGNED_IN', SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem('fs'); listeners.forEach((f) => f('SIGNED_OUT', null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, args) {
    if (fn === 'push_public_key') return Promise.resolve(okRes(DB.clePublique));
    if (fn === 'register_push') {
      DB.ordre.push('enregistrement-en-base');
      if (DB.refuserEnregistrement) return Promise.resolve(err('42501', 'refus de la base'));
      DB.enregistres.push(args);
      DB.appareils = [{ id: 'd1', user_agent: args.p_user_agent, created_at: new Date().toISOString(),
                        last_ok_at: null, endpoint_court: args.p_endpoint.slice(-12) }];
      return Promise.resolve(okRes('d1'));
    }
    if (fn === 'unregister_push') {
      DB.ordre.push('retrait-en-base');
      DB.retires.push(args.p_endpoint);
      DB.appareils = [];
      return Promise.resolve(okRes(1));
    }
    if (fn === 'my_push_devices') return Promise.resolve(okRes(DB.appareils.slice()));
    if (fn === 'my_notifications') return Promise.resolve(okRes([]));
    if (fn === 'my_owner_identity') return Promise.resolve(okRes([{ state: 'verifie', id_type: 'cnib', id_number_masked: '****1', files_sent: 0, decision_note: null, files_deleted: true }]));
    if (fn === 'my_subscription' || fn === 'my_listing_counts') return Promise.resolve(okRes([]));
    return Promise.resolve(okRes([]));
  },
  storage: { from() { return { async createSignedUrl() { return okRes({ signedUrl: '' }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); } }; } },
}; } };
`;

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1400 } });
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
const aller = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(700); };

const connexion = async () => {
  await aller("#compte");
  const sortie = p.getByRole("button", { name: "Se déconnecter" });
  if (await sortie.count()) { await sortie.click(); await p.waitForTimeout(400); }
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "moussa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(800);
};

// =====================================================================
// 1. Sans clé publique posée, on ne propose rien
// =====================================================================
await p.goto(URL + "#compte");
await p.waitForSelector("h1");
await connexion();
await aller("#compte");
ok("tant que la clé publique n'est pas posée, rien n'est proposé",
  !/Alertes sur cet appareil/.test(await texte()));
ok("et aucune erreur n'est montrée pour autant",
  !/erreur|échou/i.test(await texte()));

// =====================================================================
// 2. La clé est posée : la proposition apparaît
// =====================================================================
await p.evaluate((c) => { window.__db.clePublique = c; }, CLE);
await aller("#espace");
await aller("#compte");
let t = await texte();
ok("la clé posée, l'activation est proposée", /Alertes sur cet appareil/.test(t));
ok("le bouton invite à activer", /Activer les alertes/.test(t));
ok("et explique à quoi ça sert", /sans avoir à ouvrir le site/.test(t));
ok("il est dit que seul ce qui concerne la personne est envoyé", /vérifie vos autorisations/.test(t));
ok("et que le contenu est chiffré", /chiffré de bout en bout/.test(t));
ok("rien n'est activé avant le clic",
  await p.evaluate(() => window.__db.demandes === 0 && window.__db.enregistres.length === 0));

// =====================================================================
// 3. Le clic : autorisation, abonnement, enregistrement
// =====================================================================
await p.getByRole("button", { name: "Activer les alertes" }).click();
await p.waitForTimeout(900);
t = await texte();
ok("l'autorisation est demandée une seule fois",
  await p.evaluate(() => window.__db.demandes === 1));
ok("l'abonnement est pris avec la clé publique de la base",
  await p.evaluate((c) => window.__db.cleUtilisee === c, CLE));
ok("en mode « toujours visible », comme l'exigent les navigateurs",
  await p.evaluate(() => window.__db.userVisibleOnly === true));
ok("l'appareil est enregistré en base", await p.evaluate(() => window.__db.enregistres.length === 1));
const envoye = await p.evaluate(() => window.__db.enregistres[0]);
ok("avec son adresse", envoye && /^https:\/\/push\.test\.local\//.test(envoye.p_endpoint));
ok("ses deux clés de chiffrement", envoye && envoye.p_p256dh.length > 40 && envoye.p_auth.length > 10);
ok("et de quoi le reconnaître à l'écran", envoye && /SM-A135F/.test(envoye.p_user_agent));
ok("l'ordre est respecté : autorisation, puis abonnement, puis base",
  await p.evaluate(() => JSON.stringify(window.__db.ordre.slice(0, 3)) ===
    JSON.stringify(["demande-autorisation", "abonnement", "enregistrement-en-base"])));
ok("l'écran confirme que l'appareil reçoit", /Cet appareil reçoit les alertes/.test(t));
ok("et propose d'arrêter", /Ne plus recevoir ici/.test(t));

// L'appareil enregistré est montré sous un nom lisible, pas une ligne technique.
await p.getByText(/Appareils enregistrés/).click();
await p.waitForTimeout(300);
t = await texte();
ok("l'appareil est nommé lisiblement", /Android — SM-A135F/.test(t));
ok("et la ligne technique du navigateur n'est pas affichée", !/Mozilla\/5\.0/.test(t));
ok("l'adresse complète de l'appareil n'apparaît nulle part", !/push\.test\.local\/abc/.test(t));
ok("il est dit que personne d'autre ne voit cette liste", /pas même un administrateur/.test(t));

// =====================================================================
// 4. Arrêter de recevoir : la base d'abord, le navigateur ensuite
// =====================================================================
await p.evaluate(() => { window.__db.ordre = []; });
await p.getByRole("button", { name: "Ne plus recevoir ici" }).click();
await p.waitForTimeout(900);
ok("l'appareil est retiré de la base", await p.evaluate(() => window.__db.retires.length === 1));
ok("et désabonné du navigateur", await p.evaluate(() => window.__db.desabonnements === 1));
ok("dans cet ordre : si la base refusait, l'appareil resterait joignable",
  await p.evaluate(() => JSON.stringify(window.__db.ordre) ===
    JSON.stringify(["retrait-en-base", "desabonnement"])));
ok("l'écran repropose d'activer", /Activer les alertes/.test(await texte()));

// =====================================================================
// 5. Rotation de clé : un abonnement pris avec une ancienne clé est refait
// =====================================================================
// Sans cela, les messages partiraient chiffrés avec une clé que l'appareil ne reconnaît plus,
// et l'appareil cesserait de recevoir sans que personne ne comprenne pourquoi.
await p.evaluate(() => {
  const vieille = new Uint8Array(65); vieille[0] = 4; vieille[1] = 9;
  window.__db.abonnement = {
    endpoint: "https://push.test.local/ancien",
    options: { applicationServerKey: vieille.buffer },
    getKey(nom) { const n = nom === "auth" ? 16 : 65; const o = new Uint8Array(n); if (nom !== "auth") o[0] = 4; return o.buffer; },
    async unsubscribe() { window.__db.desabonnements++; window.__db.ordre.push("desabonnement"); window.__db.abonnement = null; return true; },
  };
  window.__db.ordre = []; window.__db.retires = []; window.__db.desabonnements = 0; window.__db.enregistres = [];
});
await p.getByRole("button", { name: "Activer les alertes" }).click();
await p.waitForTimeout(900);
ok("l'ancien abonnement est retiré de la base", await p.evaluate(() => window.__db.retires[0] === "https://push.test.local/ancien"));
ok("puis désabonné", await p.evaluate(() => window.__db.desabonnements === 1));
ok("et un nouvel abonnement est pris avec la clé à jour",
  await p.evaluate((c) => window.__db.cleUtilisee === c, CLE));
ok("l'appareil est réenregistré", await p.evaluate(() => window.__db.enregistres.length === 1));

// =====================================================================
// 6. Autorisation refusée : on explique, on n'insiste pas
// =====================================================================
await p.evaluate(() => { window.__db.permission = "denied"; window.__db.abonnement = null; });
await aller("#espace");
await aller("#compte");
t = await texte();
ok("un refus est expliqué", /Alertes bloquées par le navigateur/.test(t));
ok("avec le geste à faire pour revenir en arrière", /réglages du navigateur/.test(t));
ok("et aucun bouton n'insiste", await p.getByRole("button", { name: /Activer les alertes/ }).count() === 0);
const avant = await p.evaluate(() => window.__db.demandes);
await aller("#espace");
await aller("#compte");
ok("le site ne redemande jamais l'autorisation de lui-même",
  await p.evaluate((n) => window.__db.demandes === n, avant));

// =====================================================================
// 7. Une personne qui refuse à la demande
// =====================================================================
await p.evaluate(() => { window.__db.permission = "default"; window.__db.reponseAutorisation = "denied"; window.__db.enregistres = []; });
await aller("#espace");
await aller("#compte");
await p.getByRole("button", { name: "Activer les alertes" }).click();
await p.waitForTimeout(900);
ok("un refus à la demande ne fait rien enregistrer",
  await p.evaluate(() => window.__db.enregistres.length === 0));
ok("et l'écran l'explique", /Alertes bloquées par le navigateur/.test(await texte()));

// =====================================================================
// 8. iPhone : le push n'existe pas avant l'ajout à l'écran d'accueil
// =====================================================================
await p.evaluate(() => {
  window.__db.permission = "default"; window.__db.reponseAutorisation = "granted";
  window.__db.ios = true; window.__db.installee = false;
});
await aller("#espace");
await aller("#compte");
t = await texte();
ok("sur iPhone non installé, le geste est expliqué", /Recevoir les alertes sur cet iPhone/.test(t));
ok("avec les mots de Safari", /Sur l'écran d'accueil/.test(t));
ok("et aucun bouton qui échouerait", await p.getByRole("button", { name: /Activer les alertes/ }).count() === 0);

await p.evaluate(() => { window.__db.installee = true; });
await aller("#espace");
await aller("#compte");
ok("une fois installée, l'activation est proposée sur iPhone",
  /Activer les alertes/.test(await texte()));

// =====================================================================
// 9. Un refus de la base est montré, pas avalé
// =====================================================================
await p.evaluate(() => { window.__db.ios = false; window.__db.refuserEnregistrement = true; window.__db.abonnement = null; });
await aller("#espace");
await aller("#compte");
await p.getByRole("button", { name: "Activer les alertes" }).click();
await p.waitForTimeout(900);
// Le message est celui que la base a produit, traduit en français par frMessage() :
// « Action non autorisée. » pour un refus de droits. Ce qui compte est qu'il SOIT montré.
const alerte = p.locator('[role="alert"]');
ok("un refus de la base s'affiche au lieu d'être avalé", await alerte.count() > 0);
ok("et il est écrit en français, pas en code",
  /Action non autorisée|impossible|refus/i.test((await alerte.first().innerText().catch(() => "")) || ""));
ok("l'écran ne prétend pas que l'appareil reçoit", !/Cet appareil reçoit les alertes/.test(await texte()));

// =====================================================================
// 10. L'équipe et l'espace propriétaire proposent aussi l'activation
// =====================================================================
await p.evaluate(() => { window.__db.refuserEnregistrement = false; window.__db.perms = [{ perm: "reservations" }]; });
await connexion();
await aller("#equipe");
await p.waitForSelector("h1");
ok("l'espace équipe propose les alertes", /Alertes sur cet appareil|Cet appareil reçoit/.test(await texte()));
await aller("#espace");
await p.waitForTimeout(600);
ok("l'espace propriétaire aussi", /Alertes sur cet appareil|Cet appareil reçoit/.test(await texte()));

// Déconnecté, rien n'est proposé : un appareil s'enregistre pour QUELQU'UN.
await aller("#compte");
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForTimeout(800);
ok("déconnecté, aucune activation n'est proposée", !/Alertes sur cet appareil/.test(await texte()));

ok("aucune erreur JavaScript pendant tout le parcours", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DES ALERTES PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
