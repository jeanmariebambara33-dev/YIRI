-- YIRI — 0016 : l'abonnement est rattaché au PROFIL, plus au logement.
--
-- Règle commerciale demandée : un propriétaire paie UN abonnement et publie autant de logements
-- qu'il veut. Aujourd'hui l'abonnement porte sur une annonce précise (subscriptions.property_id
-- est obligatoire), donc trois logements coûtent trois abonnements.
--
-- Ce fichier déplace la règle du logement vers le compte, partout où elle est lue :
--   * la vitrine publique et la garde de publication ;
--   * le calcul de la date de fin au paiement (un renouvellement s'ajoute à la suite) ;
--   * la tâche de nuit ;
--   * la remise en ligne après renouvellement.
--
-- Les abonnements DÉJÀ enregistrés ne sont ni modifiés ni migrés : la colonne property_id est
-- conservée telle quelle, elle devient simplement facultative. Comme la nouvelle règle lit
-- « cet owner_id a-t-il un abonnement actif », un abonnement existant souscrit pour un logement
-- couvre désormais tous les logements de son propriétaire. C'est exactement la règle voulue,
-- appliquée aux clients existants sans toucher à une seule ligne de données.
--
-- Ce qui N'EST PAS touché : YIRI Sérénité et YIRI Partenariat, qui dépendent d'un contrat de
-- gestion et non d'un abonnement ; les réservations ; les montants (5 000 / 30 000), toujours
-- recalculés par le serveur ; la validation individuelle de chaque annonce.

-- =====================================================================
-- 0. Garde : 0016 s'appuie sur 0015
-- =====================================================================
do $$
begin
  if to_regclass('public.owner_free_pass') is null then
    raise exception 'La migration 0015 n''est pas appliquée. Appliquez 0014 puis 0015 d''abord. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. L'abonnement n'a plus besoin d'un logement
-- =====================================================================
alter table subscriptions alter column property_id drop not null;
create index if not exists subscriptions_owner_actif_idx on subscriptions (owner_id, status, ends_at);

/* « Ce propriétaire a-t-il le droit de publier aujourd'hui ? »
   Une seule définition, lue par la vitrine publique, par la garde de publication et par la
   tâche de nuit. Écrite trois fois, elle aurait fini par diverger — et une divergence ici
   signifie soit une annonce payée invisible, soit une annonce impayée visible. */
create or replace function owner_can_publish(p_owner uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (
    select 1 from subscriptions s
     where s.owner_id = p_owner and s.status = 'actif'
       and s.starts_at <= current_date and s.ends_at > current_date
  ) or owner_has_free_pass(p_owner);
$$;
revoke all on function owner_can_publish(uuid) from public;
grant execute on function owner_can_publish(uuid) to anon, authenticated;

-- =====================================================================
-- 2. S'abonner, pour son profil
-- =====================================================================
/* Remplace subscribe_property : on ne choisit plus un logement, on s'abonne. Le montant vient
   du forfait, jamais du navigateur. Appelée deux fois, elle renvoie la demande déjà en attente
   au lieu d'en créer une seconde — sinon deux paiements seraient possibles pour un seul service. */
create or replace function subscribe_owner(p_plan subscription_plan)
returns subscriptions
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  s subscriptions%rowtype;
  montant int;
begin
  if p_plan is null then
    raise exception 'Choisissez un forfait : mensuel ou annuel.';
  end if;
  perform enforce_rate_limit('sub:' || uid::text, 10, interval '1 hour');

  select * into s from subscriptions
   where owner_id = uid and status = 'en_attente_paiement'
   order by created_at desc limit 1;
  if found then
    return s;
  end if;

  montant := case p_plan when 'mensuel' then 5000 else 30000 end;

  insert into subscriptions (owner_id, property_id, plan, amount_xof, status)
  values (uid, null, p_plan, montant, 'en_attente_paiement')
  returning * into s;

  return s;
end $$;
revoke all on function subscribe_owner(subscription_plan) from public, anon;
grant execute on function subscribe_owner(subscription_plan) to authenticated;

-- subscribe_property (0014) n'a plus de sens : on ne s'abonne plus logement par logement.
-- grant_subscription (0014) non plus : un accès offert se donne au compte, par grant_owner_pass.
drop function if exists subscribe_property(uuid, subscription_plan);
drop function if exists grant_subscription(uuid, int, text);

-- =====================================================================
-- 3. La vitrine publique lit le compte, plus le logement
-- =====================================================================
-- Colonnes identiques à celles de 0005 et 0015 : rien de ce qui lit cette vue n'est à modifier.
-- C'est elle qui garantit qu'une annonce dont l'abonnement a expiré n'est accessible NI par la
-- recherche, NI par son lien direct : la fiche publique lit la même vue.
create or replace view public_listings with (security_invoker = false) as
select p.id, p.offer, p.title, p.description, p.city, p.district, p.capacity, p.bedrooms, p.beds,
       p.nightly_price_xof, p.min_nights, p.house_rules, p.cancellation_policy,
       p.neighborhood, p.highlights
from properties p
where p.status = 'publiee'
  and p.is_demo = false
  and (
    (p.offer = 'annonce' and owner_can_publish(p.owner_id))
    or (p.offer in ('gestion','partenariat') and exists (
      select 1 from management_agreements m
      where m.property_id = p.id and m.signed and m.operational_check_done))
  );
grant select on public_listings to anon, authenticated;

-- =====================================================================
-- 4. La garde de publication aussi
-- =====================================================================
create or replace function _listing_publish_problem(p_property uuid) returns text
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare p properties%rowtype;
begin
  select * into p from properties where id = p_property;
  if not found then return 'Annonce introuvable.'; end if;
  if p.is_demo then return 'Une annonce de démonstration ne se publie pas.'; end if;
  if p.offer = 'annonce' then
    if not owner_can_publish(p.owner_id) then
      return 'Un abonnement actif (paiement confirmé) est requis.';
    end if;
    if not exists (select 1 from property_contacts c where c.property_id = p.id) then
      return 'Le contact du propriétaire est manquant.';
    end if;
  else
    if not exists (select 1 from management_agreements m
                    where m.property_id = p.id and m.signed and m.operational_check_done) then
      return 'Un contrat signé et la vérification opérationnelle sont requis.';
    end if;
  end if;
  if not exists (select 1 from property_photos ph where ph.property_id = p.id and ph.rights_checked) then
    return 'Au moins une photo aux droits vérifiés est requise.';
  end if;
  return null;
end $$;
revoke all on function _listing_publish_problem(uuid) from public, anon, authenticated;

-- =====================================================================
-- 5. Le paiement calcule la date de fin au niveau du compte
-- =====================================================================
-- Redéfinition de _apply_payment (0009). Seule la branche « abonnement » change :
--   * le verrou porte sur le PROFIL et non sur un logement, puisqu'il peut ne plus y en avoir ;
--   * la date de reprise vient du dernier abonnement actif DU PROPRIÉTAIRE ;
--   * la remise en ligne des annonces n'est plus faite ici : le déclencheur de la section 6
--     s'en charge pour TOUTES les annonces éligibles du compte, et une seule fois.
-- La branche « réservation » est reprise à l'identique : rien n'y change.
create or replace function _apply_payment(
  p_object text, p_id uuid, p_received_amount_xof int,
  p_actor uuid, p_provider text, p_reference text, p_auto boolean
) returns payment_transactions
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  bk bookings%rowtype;
  sb subscriptions%rowtype;
  tx payment_transactions%rowtype;
  prop_id uuid;
  expected int;
  base date; st date; en date;
  before_status text;
  origine text := case when p_auto then 'confirmé automatiquement par le prestataire' else 'confirmé manuellement par l''équipe' end;
  action text := case when p_auto then 'payment.confirmed_online' else 'payment.confirmed' end;
begin
  if p_object not in ('reservation', 'abonnement') or p_id is null then
    raise exception 'Objet de paiement invalide.';
  end if;
  if p_received_amount_xof is null or p_received_amount_xof <= 0 then
    raise exception 'Indiquez le montant réellement reçu.';
  end if;

  if p_object = 'reservation' then
    select property_id into prop_id from bookings where id = p_id;
    if not found then raise exception 'Réservation introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;
    select * into bk from bookings where id = p_id for update;
    if p_actor is not null and bk.guest_id = p_actor then
      raise exception 'Vous ne pouvez pas confirmer votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where booking_id = bk.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé.' using errcode = '23505';
    end if;
    if bk.status not in ('en_attente_paiement', 'expiree') then
      raise exception 'Cette réservation ne peut plus être confirmée (statut : %).', bk.status;
    end if;
    expected := bk.total_xof;
    if p_received_amount_xof <> expected then
      raise exception 'Montant reçu (%) différent du montant attendu (%). Rien n''a été confirmé.', p_received_amount_xof, expected;
    end if;
    before_status := bk.status::text;
    begin
      update bookings set status = 'confirmee', hold_expires_at = null where id = bk.id;
    exception when exclusion_violation then
      raise exception 'Les dates ont été reprises depuis l''expiration du blocage : confirmation impossible. Un remboursement éventuel doit être organisé hors plateforme.'
        using errcode = '23P01';
    end;
    select * into tx from payment_transactions
     where booking_id = bk.id and purpose = 'booking' and status in ('cree', 'en_attente')
     order by created_at desc limit 1 for update;
    if found then
      update payment_transactions
         set status = 'reussi', amount_xof = expected, received_amount_xof = p_received_amount_xof,
             provider = coalesce(p_provider, provider),
             provider_reference = coalesce(p_reference, provider_reference),
             confirmed_by = p_actor, confirmed_at = now(), updated_at = now()
       where id = tx.id returning * into tx;
    else
      insert into payment_transactions (purpose, booking_id, provider, provider_reference, idempotency_key,
                                        amount_xof, status, received_amount_xof, confirmed_by, confirmed_at)
      values ('booking', bk.id, coalesce(p_provider, 'chariow'), p_reference,
              coalesce(p_reference, 'manual:booking:' || bk.id::text), expected, 'reussi',
              p_received_amount_xof, p_actor, now())
      returning * into tx;
    end if;
    insert into financial_ledger (transaction_id, entry_type, credit_xof, description)
    values (tx.id, 'reservation', expected, 'Réservation payée, ' || origine);
    update payment_notices set status = 'traite', handled_by = p_actor, handled_at = now()
     where booking_id = bk.id and status = 'nouveau';
    insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
    values (p_actor, action, 'booking', bk.id::text,
            jsonb_build_object('status', before_status),
            jsonb_build_object('status', 'confirmee', 'expected_xof', expected, 'received_xof', p_received_amount_xof,
                               'transaction_id', tx.id, 'provider', tx.provider, 'reference', tx.provider_reference));
  else
    select * into sb from subscriptions where id = p_id;
    if not found then raise exception 'Abonnement introuvable.'; end if;
    -- Le verrou porte sur le profil : deux confirmations simultanées pour le même propriétaire
    -- ne doivent pas calculer la même date de reprise et se recouvrir.
    perform 1 from profiles where id = sb.owner_id for update;
    select * into sb from subscriptions where id = p_id for update;
    if p_actor is not null and sb.owner_id = p_actor then
      raise exception 'Vous ne pouvez pas confirmer votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where subscription_id = sb.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé.' using errcode = '23505';
    end if;
    if sb.status <> 'en_attente_paiement' then
      raise exception 'Cet abonnement ne peut plus être activé (statut : %).', sb.status;
    end if;
    expected := case sb.plan when 'mensuel' then 5000 else 30000 end;   -- tarif recalculé, jamais lu du navigateur
    if sb.amount_xof <> expected or p_received_amount_xof <> expected then
      raise exception 'Montant reçu (%) différent du montant attendu (%). Rien n''a été confirmé.', p_received_amount_xof, expected;
    end if;
    -- Un renouvellement commence à la fin de l'abonnement en cours DU PROPRIÉTAIRE : aucune
    -- journée perdue, et le nombre de logements n'entre pas dans le calcul.
    select coalesce(max(ends_at), current_date) into base
      from subscriptions where owner_id = sb.owner_id and status = 'actif' and ends_at > current_date;
    st := greatest(current_date, base);
    en := (st + case sb.plan when 'mensuel' then interval '1 month' else interval '1 year' end)::date;
    update subscriptions set status = 'actif', starts_at = st, ends_at = en where id = sb.id;
    select * into tx from payment_transactions
     where subscription_id = sb.id and purpose = 'subscription' and status in ('cree', 'en_attente')
     order by created_at desc limit 1 for update;
    if found then
      update payment_transactions
         set status = 'reussi', amount_xof = expected, received_amount_xof = p_received_amount_xof,
             provider = coalesce(p_provider, provider),
             provider_reference = coalesce(p_reference, provider_reference),
             confirmed_by = p_actor, confirmed_at = now(), updated_at = now()
       where id = tx.id returning * into tx;
    else
      insert into payment_transactions (purpose, subscription_id, provider, provider_reference, idempotency_key,
                                        amount_xof, status, received_amount_xof, confirmed_by, confirmed_at)
      values ('subscription', sb.id, coalesce(p_provider, 'chariow'), p_reference,
              coalesce(p_reference, 'manual:subscription:' || sb.id::text), expected, 'reussi',
              p_received_amount_xof, p_actor, now())
      returning * into tx;
    end if;
    insert into financial_ledger (transaction_id, entry_type, credit_xof, description)
    values (tx.id, 'abonnement', expected, 'Abonnement payé, ' || origine);
    update payment_notices set status = 'traite', handled_by = p_actor, handled_at = now()
     where subscription_id = sb.id and status = 'nouveau';
    insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
    values (p_actor, action, 'subscription', sb.id::text,
            jsonb_build_object('status', 'en_attente_paiement'),
            jsonb_build_object('status', 'actif', 'starts_at', st, 'ends_at', en, 'expected_xof', expected,
                               'received_xof', p_received_amount_xof, 'transaction_id', tx.id,
                               'provider', tx.provider, 'reference', tx.provider_reference));
  end if;
  return tx;
end $$;
revoke all on function _apply_payment(text, uuid, int, uuid, text, text, boolean) from public, anon, authenticated;

-- =====================================================================
-- 6. Après paiement, les annonces ÉLIGIBLES reviennent en ligne
-- =====================================================================
-- Redéfinition du déclencheur de 0015, qui ne regardait qu'un logement — impossible désormais,
-- puisque l'abonnement n'en désigne plus aucun.
--
-- Ne reviennent en ligne que les annonces « expirée » (elles étaient publiées avant) et
-- « approuvée » (l'équipe a déjà décidé, seul l'abonnement manquait). Une annonce en attente,
-- refusée ou suspendue n'est JAMAIS publiée par un paiement : payer n'est pas être validé.
create or replace function subscription_reactivate_listing()
returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  if new.status = 'actif' and (tg_op = 'INSERT' or old.status is distinct from 'actif') then
    update properties p set status = 'publiee', review_note = null
     where p.owner_id = new.owner_id
       and p.offer = 'annonce'
       and p.status in ('expiree', 'approuvee')
       and _listing_publish_problem(p.id) is null;
    get diagnostics n = row_count;

    if n > 0 then
      insert into audit_logs (actor_id, action, entity_type, entity_id, after)
      values (null, 'listing.republished', 'profile', new.owner_id::text,
              jsonb_build_object('abonnement', new.id, 'annonces', n));
    end if;

    -- Les relances repartent à zéro : le prochain cycle doit pouvoir prévenir à nouveau.
    delete from subscription_reminders where subscription_id = new.id;
  end if;
  return new;
end $$;
revoke all on function subscription_reactivate_listing() from public, anon, authenticated;

-- =====================================================================
-- 7. La tâche de nuit masque TOUTES les annonces du profil
-- =====================================================================
create or replace function expire_subscriptions()
returns table (relances_j7 int, relances_j1 int, expires int, annonces_retirees int)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  n7 int := 0; n1 int := 0; ne int := 0; na int := 0;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Fonction réservée au serveur.' using errcode = '42501';
  end if;

  with cibles as (
    select s.id, s.owner_id, s.ends_at
      from subscriptions s
     where s.status = 'actif' and s.ends_at > current_date and s.ends_at <= current_date + 7
       and not exists (select 1 from subscription_reminders r where r.subscription_id = s.id and r.kind = 'j7')
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'j7' from cibles returning 1
  )
  insert into notifications (user_id, type, payload)
  select c.owner_id, 'subscription.bientot_expiree',
         jsonb_build_object('abonnement', c.id, 'jusqu_au', c.ends_at, 'jours', c.ends_at - current_date)
    from cibles c;
  get diagnostics n7 = row_count;

  with cibles as (
    select s.id, s.owner_id, s.ends_at
      from subscriptions s
     where s.status = 'actif' and s.ends_at > current_date and s.ends_at <= current_date + 1
       and not exists (select 1 from subscription_reminders r where r.subscription_id = s.id and r.kind = 'j1')
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'j1' from cibles returning 1
  )
  insert into notifications (user_id, type, payload)
  select c.owner_id, 'subscription.expire_demain',
         jsonb_build_object('abonnement', c.id, 'jusqu_au', c.ends_at)
    from cibles c;
  get diagnostics n1 = row_count;

  -- « get diagnostics » ne verrait que la DERNIÈRE écriture, c'est-à-dire le nombre de membres
  -- d'équipe prévenus — pas le nombre d'abonnements expirés. On compte donc explicitement.
  with echus as (
    update subscriptions s set status = 'expire'
     where s.status = 'actif' and s.ends_at <= current_date
    returning s.id, s.owner_id, s.ends_at
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'expire' from echus
    on conflict do nothing returning 1
  ), au_proprietaire as (
    insert into notifications (user_id, type, payload)
    select e.owner_id, 'subscription.expiree',
           jsonb_build_object('abonnement', e.id, 'expire_le', e.ends_at)
      from echus e
    returning 1
  ), a_equipe as (
    insert into notifications (user_id, type, payload)
    select distinct x.user_id, 'subscription.expiree.equipe',
           jsonb_build_object('abonnement', e.id, 'proprietaire', e.owner_id, 'expire_le', e.ends_at)
      from echus e
      cross join (
        select tp.user_id from team_permissions tp where tp.perm in ('validation', 'paiements')
        union
        select ur.user_id from user_roles ur where ur.role = 'admin'
      ) x
     where x.user_id <> e.owner_id
    returning 1
  )
  select count(*) into ne from echus;

  -- TOUTES les annonces du profil, et non plus logement par logement.
  update properties p set status = 'expiree'
   where p.offer = 'annonce' and p.status = 'publiee'
     and not owner_can_publish(p.owner_id);
  get diagnostics na = row_count;

  insert into notifications (user_id, type, payload)
  select f.owner_id, 'free_pass.bientot_fini',
         jsonb_build_object('jusqu_au', f.ends_on, 'jours', f.ends_on - current_date)
    from owner_free_pass f
   where f.revoked_at is null and f.ends_on = current_date + 7;

  return query select n7, n1, ne, na;
end $$;
revoke all on function expire_subscriptions() from public, anon, authenticated;

-- =====================================================================
-- 8. Ce que le propriétaire voit de son abonnement et de ses annonces
-- =====================================================================
create or replace function my_subscription()
returns table (id uuid, plan subscription_plan, amount_xof int, status subscription_status,
               starts_at date, ends_at date, jours_restants int,
               actif boolean, acces_offert boolean, offert_jusqu_au date)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select s.id, s.plan, s.amount_xof, s.status, s.starts_at, s.ends_at,
           case when s.ends_at is null then null else (s.ends_at - current_date) end,
           owner_can_publish(uid),
           owner_has_free_pass(uid),
           (select max(f.ends_on) from owner_free_pass f
             where f.owner_id = uid and f.revoked_at is null and f.ends_on > current_date)
      from subscriptions s
     where s.owner_id = uid
     order by (s.status = 'actif') desc, s.ends_at desc nulls last, s.created_at desc
     limit 1;
end $$;
revoke all on function my_subscription() from public, anon;
grant execute on function my_subscription() to authenticated;

/* Les compteurs du tableau de bord. Une seule lecture plutôt que cinq, et surtout un seul
   endroit où la définition de « publié » est écrite. */
create or replace function my_listing_counts()
returns table (soumis int, publies int, en_attente int, refuses int, suspendus int, expirees int)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select count(*)::int,
           count(*) filter (where status = 'publiee')::int,
           count(*) filter (where status in ('brouillon', 'soumise', 'a_corriger', 'approuvee'))::int,
           count(*) filter (where status = 'refusee')::int,
           count(*) filter (where status = 'suspendue')::int,
           count(*) filter (where status = 'expiree')::int
      from properties where owner_id = uid and not is_demo;
end $$;
revoke all on function my_listing_counts() from public, anon;
grant execute on function my_listing_counts() to authenticated;

-- =====================================================================
-- 9. La file de l'équipe, par propriétaire
-- =====================================================================
-- Le type de retour change (une ligne par PROPRIÉTAIRE, plus par logement) : PostgreSQL
-- refuse un « create or replace » dans ce cas, il faut retirer l'ancienne d'abord.
drop function if exists subscriptions_queue(int);
create or replace function subscriptions_queue(p_limit int default 100)
returns table (id uuid, owner_id uuid, proprietaire text, email text,
               plan subscription_plan, amount_xof int, status subscription_status,
               starts_at date, ends_at date, jours_restants int,
               peut_publier boolean, acces_offert boolean, annonces int, publiees int)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_any_perm('validation', 'paiements') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  return query
    select s.id, s.owner_id, pr.full_name, coalesce(pr.email, u.email::text),
           s.plan, s.amount_xof, s.status, s.starts_at, s.ends_at,
           case when s.ends_at is null then null else (s.ends_at - current_date) end,
           owner_can_publish(s.owner_id), owner_has_free_pass(s.owner_id),
           (select count(*)::int from properties p where p.owner_id = s.owner_id and p.offer = 'annonce' and not p.is_demo),
           (select count(*)::int from properties p where p.owner_id = s.owner_id and p.offer = 'annonce' and p.status = 'publiee')
      from subscriptions s
      join profiles pr on pr.id = s.owner_id
      left join auth.users u on u.id = s.owner_id
     order by
       (case when s.status = 'actif' then 0 when s.status = 'en_attente_paiement' then 1 else 2 end),
       s.ends_at asc nulls first,
       s.created_at desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function subscriptions_queue(int) from public, anon;
grant execute on function subscriptions_queue(int) to authenticated;

-- my_subscriptions() de 0014 renvoyait une ligne par logement : sans objet désormais.
drop function if exists my_subscriptions();

-- =====================================================================
-- 10. Une annonce expirée doit rester suspendable
-- =====================================================================
-- Trou trouvé en écrivant les tests : les transitions de 0005 ne permettent pas de suspendre
-- une annonce « expirée ». Or la suspension est la seule mesure contre une annonce abusive, et
-- une annonce expirée non suspendue revient EN LIGNE toute seule au renouvellement. On ajoute
-- donc la transition « expiree » vers « suspendue ». Rien d'autre ne change dans la table.
create or replace function listing_transition_ok(a listing_status, b listing_status) returns boolean
language sql immutable as $$
  select (a, b) in (
    ('brouillon','soumise'), ('brouillon','archivee'),
    ('soumise','a_corriger'), ('soumise','approuvee'), ('soumise','refusee'),
    ('a_corriger','soumise'), ('a_corriger','archivee'),
    ('approuvee','publiee'), ('approuvee','suspendue'), ('approuvee','archivee'),
    ('refusee','archivee'),
    ('publiee','suspendue'), ('publiee','expiree'), ('publiee','archivee'),
    ('suspendue','publiee'), ('suspendue','archivee'),
    ('expiree','publiee'), ('expiree','suspendue'), ('expiree','archivee')
  );
$$;

-- =====================================================================
-- 11. Le dernier message qui disait encore « Visibilité »
-- =====================================================================
-- set_management_agreement (0014) refuse un contrat sur une annonce de l'autre offre, et son
-- message nomme l'ancienne appellation commerciale. C'est le SEUL texte vu par un utilisateur
-- qui restait à renommer côté base. La fonction est reprise à l'identique pour le reste.
create or replace function set_management_agreement(
  p_property uuid, p_signed boolean, p_check_done boolean, p_version text default 'v1')
returns management_agreements
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  p properties%rowtype;
  m management_agreements%rowtype;
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;

  select * into p from properties where id = p_property for update;
  if not found then raise exception 'Annonce introuvable.'; end if;
  if p.offer not in ('gestion', 'partenariat') then
    raise exception 'Cette annonce relève de l''offre YIRI Annonce : elle fonctionne par abonnement.';
  end if;

  select * into m from management_agreements where property_id = p.id;
  if found then
    update management_agreements
       set signed = coalesce(p_signed, signed),
           operational_check_done = coalesce(p_check_done, operational_check_done),
           contract_version = coalesce(p_version, contract_version)
     where property_id = p.id
    returning * into m;
  else
    insert into management_agreements (property_id, contract_version, starts_on, signed,
                                       operational_check_done, expense_policy_version)
    values (p.id, coalesce(p_version, 'v1'), current_date,
            coalesce(p_signed, false), coalesce(p_check_done, false), 'v1')
    returning * into m;
  end if;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'agreement.set', 'property', p.id::text,
          jsonb_build_object('signe', m.signed, 'visite_faite', m.operational_check_done));

  return m;
end $$;
revoke all on function set_management_agreement(uuid, boolean, boolean, text) from public, anon;
grant execute on function set_management_agreement(uuid, boolean, boolean, text) to authenticated;
