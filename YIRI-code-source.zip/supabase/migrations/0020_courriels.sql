-- YIRI — 0020 : les notifications qui manquaient, et le départ des courriels.
--
-- Deux trous constatés en inspectant l'existant, avant d'écrire une ligne :
--
--   1. LE VOYAGEUR N'EST PRÉVENU DE RIEN. Le déclencheur de la 0011 prévient le propriétaire et
--      l'équipe quand une réservation est payée ou annulée — jamais la personne qui a payé.
--      Elle doit ouvrir le site pour savoir si son séjour est confirmé.
--   2. UNE ANNONCE VALIDÉE OU REFUSÉE NE PRÉVIENT PERSONNE. set_listing_status écrit au journal
--      et s'arrête là. Le propriétaire doit deviner, en revenant regarder.
--
-- Ces deux trous existaient avant les courriels et touchaient déjà les notifications du
-- téléphone. Les combler profite donc aux deux canaux à la fois.
--
-- Le courriel suit exactement le chemin du push (0017) : une colonne sur la notification, une
-- file fermée au navigateur, une fonction serveur qui envoie. Les mêmes autorisations sont
-- relues au moment de l'envoi, par la MÊME fonction — un propriétaire ne recevra jamais le
-- courriel d'un autre, et un membre d'équipe sans l'autorisation voulue ne recevra rien.
--
-- Ce que cette migration ne touche pas : les tarifs, les offres, les barèmes, les règles de
-- réservation, les conditions de paiement. Aucune donnée n'est supprimée.

-- =====================================================================
-- 0. Garde
-- =====================================================================
do $$
begin
  if to_regprocedure('public.push_pending(integer)') is null then
    raise exception 'La migration 0017 n''est pas appliquée. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Le voyageur apprend enfin ce qui arrive à SA réservation
-- =====================================================================
-- notify_booking_change() est redéfinie plutôt que doublée par un second déclencheur : deux
-- déclencheurs écrivant des notifications voisines finiraient par diverger. Tout le reste de la
-- fonction est conservé à l'identique — seul le bloc « voyageur » est nouveau.
create or replace function notify_booking_change()
returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  prop record;
  genre text;
  charge boolean;
begin
  if new.status = 'confirmee' and (tg_op = 'INSERT' or old.status is distinct from 'confirmee') then
    genre := 'booking.confirmee';
  elsif new.status = 'annulee' and (tg_op = 'INSERT' or old.status is distinct from 'annulee') then
    genre := 'booking.annulee';
  else
    return new;
  end if;

  select p.id, p.owner_id, p.title, p.city, p.district, p.offer into prop
    from properties p where p.id = new.property_id;
  if not found then return new; end if;

  charge := prop.offer in ('gestion', 'partenariat');

  -- NOUVEAU : le voyageur. C'est lui qui a payé ; il devrait être le premier informé.
  -- Son message porte un type distinct, pour que le texte lui parle de SON séjour et non d'un
  -- séjour à préparer.
  insert into notifications (user_id, type, payload)
  values (new.guest_id, genre || '.voyageur',
          jsonb_build_object('reservation', new.id, 'logement', prop.title,
                             'ville', prop.city, 'arrivee', lower(new.stay),
                             'depart', upper(new.stay), 'total_xof', new.total_xof,
                             'sous_gestion', charge));

  -- Le propriétaire du logement. Inchangé.
  insert into notifications (user_id, type, payload)
  select prop.owner_id, genre,
         jsonb_build_object('reservation', new.id, 'logement', prop.title,
                            'ville', prop.city, 'arrivee', lower(new.stay),
                            'depart', upper(new.stay), 'total_xof', new.total_xof,
                            'sous_gestion', charge)
   where prop.owner_id <> new.guest_id;   -- un propriétaire qui réserve chez lui n'est prévenu qu'une fois

  -- L'équipe habilitée, plus les administrateurs. Inchangé.
  insert into notifications (user_id, type, payload)
  select distinct x.user_id, genre || '.equipe',
         jsonb_build_object('reservation', new.id, 'logement', prop.title,
                            'ville', prop.city, 'arrivee', lower(new.stay),
                            'depart', upper(new.stay), 'total_xof', new.total_xof,
                            'sous_gestion', charge, 'a_traiter', charge)
    from (
      select tp.user_id from team_permissions tp where tp.perm in ('reservations', 'paiements')
      union
      select ur.user_id from user_roles ur where ur.role = 'admin'
    ) x
   where x.user_id <> prop.owner_id and x.user_id <> new.guest_id;

  return new;
end $$;

-- =====================================================================
-- 2. L'annonce validée : RIEN à ajouter, c'était déjà là
-- =====================================================================
-- J'avais d'abord écrit un déclencheur pour prévenir le propriétaire d'un changement de statut
-- de son annonce, en croyant ce canal absent. Il ne l'est pas : set_listing_status écrit déjà la
-- notification « listing.<statut> » au propriétaire, depuis la migration 0015. Mon déclencheur
-- faisait doublon — le propriétaire recevait deux fois le même message, et aurait reçu deux
-- courriels. Il a été retiré avant d'aller plus loin.
--
-- Ce qui reste à faire pour cette partie n'est donc pas d'écrire une notification, mais de la
-- faire PARTIR par courriel : c'est le rôle de _email_eligible() ci-dessous. La charge utile de
-- ces notifications porte les clés « titre » et « note » (et non « logement » et « motif ») :
-- la fonction d'envoi lit donc ces noms-là.
--
-- Par sécurité, si une version antérieure de cette migration a été appliquée, on retire le
-- déclencheur qu'elle posait.
drop trigger if exists properties_notify_status on properties;
drop function if exists notify_listing_status();

-- =====================================================================
-- 3. La trace de ce qui est parti par courriel
-- =====================================================================
-- Même forme que pour le téléphone : la notification porte sa propre trace. La clé primaire de
-- la notification suffit donc à interdire tout doublon, sans table ni verrou supplémentaire.
alter table notifications add column if not exists emailed_at timestamptz;
alter table notifications add column if not exists email_attempts int not null default 0;
alter table notifications add column if not exists email_error text;
create index if not exists notifications_a_envoyer_idx
  on notifications (created_at) where emailed_at is null;

-- =====================================================================
-- 4. Quels événements méritent un courriel
-- =====================================================================
-- Le téléphone peut tout recevoir : une notification poussée coûte un regard. Un courriel coûte
-- une place dans une boîte de réception, et une boîte inondée finit en indésirables — ce qui fait
-- perdre AUSSI les courriels importants. Cette liste est donc volontairement courte.
create or replace function _email_eligible(p_type text)
returns boolean
language sql immutable set search_path = public, pg_temp as $$
  select p_type in (
    -- Le voyageur : son séjour.
    'booking.confirmee.voyageur', 'booking.annulee.voyageur', 'refund.enregistre',
    -- Le propriétaire : ses réservations, ses annonces, son abonnement.
    'booking.confirmee', 'booking.annulee',
    'listing.approuvee', 'listing.publiee', 'listing.a_corriger', 'listing.refusee', 'listing.suspendue',
    'subscription.bientot_expiree', 'subscription.expire_demain', 'subscription.expiree',
    'subscription.offerte', 'free_pass.offert', 'free_pass.retire',
    -- L'équipe : seulement ce qui demande une intervention. Le reste reste sur le téléphone.
    'booking.confirmee.equipe', 'refund.a_examiner.equipe'
  );
$$;
revoke all on function _email_eligible(text) from public, anon, authenticated;

-- =====================================================================
-- 5. La file d'envoi, fermée au navigateur
-- =====================================================================
/* Appelée UNIQUEMENT par la fonction serveur d'envoi. Elle rend l'adresse du destinataire :
   ces adresses sont des données personnelles, un navigateur n'a rien à faire ici. */
create or replace function email_pending(p_limit int default 30)
returns table (notification_id uuid, user_id uuid, destinataire text, nom text,
               type text, payload jsonb, created_at timestamptz)
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;

  return query
    select n.id, n.user_id, coalesce(nullif(btrim(pr.email), ''), u.email::text), pr.full_name,
           n.type, n.payload, n.created_at
      from notifications n
      join profiles pr on pr.id = n.user_id
      left join auth.users u on u.id = n.user_id
     where n.emailed_at is null
       and n.email_attempts < 3
       -- Comme pour le téléphone : une alerte de la semaine dernière n'a plus d'intérêt et
       -- inquiète plus qu'elle n'informe.
       and n.created_at > now() - interval '2 days'
       and _email_eligible(n.type)
       -- LA MÊME règle d'autorisation que le téléphone, relue à l'envoi : un membre d'équipe qui
       -- a perdu son autorisation cesse de recevoir, sans que personne ne le désinscrive.
       and _push_destinataire_legitime(n.user_id, n.type)
       and coalesce(nullif(btrim(pr.email), ''), u.email::text) is not null
     order by n.created_at
     limit greatest(1, least(coalesce(p_limit, 30), 100));
end $$;
revoke all on function email_pending(int) from public, anon, authenticated;

/* Rapport d'envoi. Un courriel n'est marqué parti QUE si le service l'a confirmé : c'est la
   fonction serveur qui décide, sur la réponse du service, et jamais sur une supposition. */
create or replace function email_mark_sent(p_notifications uuid[])
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  update notifications
     set emailed_at = now(), email_attempts = email_attempts + 1, email_error = null
   where id = any(coalesce(p_notifications, '{}')) and emailed_at is null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function email_mark_sent(uuid[]) from public, anon, authenticated;

create or replace function email_mark_failed(p_notifications uuid[], p_erreur text default null)
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  update notifications
     set email_attempts = email_attempts + 1, email_error = left(coalesce(p_erreur, 'échec'), 300)
   where id = any(coalesce(p_notifications, '{}')) and emailed_at is null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function email_mark_failed(uuid[], text) from public, anon, authenticated;

-- =====================================================================
-- 6. Le déclencheur appelle aussi l'envoi des courriels
-- =====================================================================
insert into public_settings (key, value)
values ('email_function_url', 'https://kzzrowymwwxoydklnkfb.supabase.co/functions/v1/email-envoyer')
on conflict (key) do nothing;

-- Le même rattrapage absolu qu'en 0018 : un courriel qui ne part pas ne doit jamais annuler la
-- confirmation d'un paiement.
create or replace function push_declencher()
returns trigger
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare
  phrase text;
  adresse text;
begin
  begin
    select decrypted_secret into phrase
      from vault.decrypted_secrets where name = 'push_trigger_secret' limit 1;
    if phrase is null then
      return null;
    end if;

    select value into adresse from public_settings where key = 'push_function_url';
    if adresse is not null then
      perform net.http_post(
        url := adresse,
        headers := jsonb_build_object('Content-Type', 'application/json', 'x-yiri-push', phrase),
        body := '{}'::jsonb, timeout_milliseconds := 5000);
    end if;

    select value into adresse from public_settings where key = 'email_function_url';
    if adresse is not null then
      perform net.http_post(
        url := adresse,
        headers := jsonb_build_object('Content-Type', 'application/json', 'x-yiri-push', phrase),
        body := '{}'::jsonb, timeout_milliseconds := 5000);
    end if;
  exception when others then
    raise notice 'Envoi des notifications impossible (sans conséquence sur l''opération) : %', sqlerrm;
  end;
  return null;
end $$;
revoke all on function push_declencher() from public, anon, authenticated;

-- Le filet de rattrapage couvre maintenant les deux canaux, par la même fonction.
create or replace function push_declencher_manuel()
returns text
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare
  phrase text;
  adresse text;
  faits text := '';
begin
  select decrypted_secret into phrase
    from vault.decrypted_secrets where name = 'push_trigger_secret' limit 1;
  if phrase is null then
    return 'Le mot de passe « push_trigger_secret » n''est pas dans le coffre. Voir la marche à suivre.';
  end if;
  for adresse in select value from public_settings where key in ('push_function_url', 'email_function_url') loop
    perform net.http_post(
      url := adresse,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-yiri-push', phrase),
      body := '{}'::jsonb, timeout_milliseconds := 5000);
    faits := faits || adresse || ' ';
  end loop;
  if faits = '' then
    return 'Aucune adresse de fonction d''envoi dans les réglages.';
  end if;
  return 'Appels envoyés. Le résultat est dans les journaux des fonctions. ' || faits;
end $$;
revoke all on function push_declencher_manuel() from public, anon, authenticated;
