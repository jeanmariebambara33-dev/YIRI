-- YIRI — 0015 : l'accès offert à un propriétaire, et la publication de ses propres logements.
--
-- Deux besoins exprimés par le fondateur, que la 0014 ne couvrait pas :
--
--   1. offrir l'accès à un PROPRIÉTAIRE pour une durée, et non logement par logement.
--      La 0014 offre un abonnement par annonce ; un partenaire avec six logements aurait
--      demandé six gestes, et ses futurs logements n'auraient rien eu. Ici l'accès est porté
--      par le compte : tous ses logements Visibilité passent, y compris ceux publiés ensuite.
--
--   2. publier ses propres logements. La règle de 0006 interdit de publier sa propre annonce
--      — celui qui poste n'est pas celui qui valide. Elle protège les annonces de TIERS. Sur
--      les logements de YIRI, YIRI est à la fois l'exploitant et le contrôleur : il n'y a pas
--      de tiers à protéger, et le fondateur travaille seul. On lève donc la règle pour les
--      administrateurs SEULEMENT, et chaque auto-publication est écrite au journal.
--
-- Ce qui N'EST PAS touché : un administrateur reste soumis à toutes les autres conditions de
-- publication (contrat de gestion ou abonnement, photo aux droits vérifiés, transitions de
-- statut). La levée ne concerne que la séparation des rôles, rien d'autre.

-- =====================================================================
-- 0. Garde : 0015 s'appuie sur 0014
-- =====================================================================
do $$
begin
  if not exists (select 1 from information_schema.columns
                  where table_schema = 'public' and table_name = 'subscriptions' and column_name = 'offert') then
    raise exception 'La migration 0014 n''est pas appliquée. Appliquez-la d''abord. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. L'accès offert, porté par le compte
-- =====================================================================
-- Une table séparée plutôt que des lignes d'abonnement à 0 : un accès commercial accordé à
-- une personne n'est pas un abonnement souscrit pour un logement, et les mélanger rendrait
-- le chiffre d'affaires illisible dès la première question du comptable.
create table if not exists owner_free_pass (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  starts_on date not null default current_date,
  ends_on date not null,
  reason text not null,
  granted_by uuid references profiles(id),
  revoked_at timestamptz,
  created_at timestamptz not null default now(),
  check (ends_on > starts_on)
);
create index if not exists owner_free_pass_actif_idx on owner_free_pass (owner_id, ends_on);
alter table owner_free_pass enable row level security;
revoke all on owner_free_pass from public, anon, authenticated;

-- Le propriétaire doit pouvoir constater son accès et sa date de fin : sinon il ne comprend
-- pas pourquoi ses annonces disparaissent un matin.
create policy free_pass_read on owner_free_pass for select
  using (owner_id = auth.uid() or has_any_perm('validation', 'paiements'));
grant select on owner_free_pass to authenticated;

/* Un accès en cours aujourd'hui. Fonction à part : la même expression est utilisée par la vue
   publique, par la garde de publication et par la tâche d'expiration. Écrite trois fois, elle
   aurait fini par diverger. */
create or replace function owner_has_free_pass(p_owner uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select exists (
    select 1 from owner_free_pass f
     where f.owner_id = p_owner and f.revoked_at is null
       and f.starts_on <= current_date and f.ends_on > current_date
  );
$$;
revoke all on function owner_has_free_pass(uuid) from public;
grant execute on function owner_has_free_pass(uuid) to anon, authenticated;

-- =====================================================================
-- 2. Accorder et retirer un accès
-- =====================================================================
create or replace function grant_owner_pass(p_owner uuid, p_days int, p_reason text)
returns owner_free_pass
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  f owner_free_pass%rowtype;
  base date;
  nom text;
begin
  if not has_role('admin') then
    raise exception 'Seul un administrateur peut offrir un accès.' using errcode = '42501';
  end if;
  if p_days is null or p_days < 1 or p_days > 1095 then
    raise exception 'Durée invalide : entre 1 et 1095 jours.';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'Indiquez le motif de cet accès offert.';
  end if;
  select full_name into nom from profiles where id = p_owner;
  if nom is null then
    raise exception 'Ce compte n''existe pas.';
  end if;

  -- On prolonge à la suite de l'accès en cours, on ne l'écrase pas.
  select coalesce(max(ends_on), current_date) into base
    from owner_free_pass
   where owner_id = p_owner and revoked_at is null and ends_on > current_date;

  insert into owner_free_pass (owner_id, starts_on, ends_on, reason, granted_by)
  values (p_owner, base, base + p_days, btrim(p_reason), uid)
  returning * into f;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after, reason)
  values (uid, 'free_pass.granted', 'profile', p_owner::text,
          jsonb_build_object('jours', p_days, 'jusqu_au', f.ends_on), btrim(p_reason));

  insert into notifications (user_id, type, payload)
  values (p_owner, 'free_pass.offert',
          jsonb_build_object('jusqu_au', f.ends_on, 'jours', p_days));

  return f;
end $$;
revoke all on function grant_owner_pass(uuid, int, text) from public, anon;
grant execute on function grant_owner_pass(uuid, int, text) to authenticated;

/* Retirer un accès. Les annonces concernées sortent de la vitrine à la lecture suivante,
   et la tâche de nuit mettra leur statut à jour. On ne supprime pas la ligne : un accès
   offert puis retiré est une information, pas une erreur à effacer. */
create or replace function revoke_owner_pass(p_owner uuid, p_reason text)
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user(); n int;
begin
  if not has_role('admin') then
    raise exception 'Seul un administrateur peut retirer un accès.' using errcode = '42501';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'Indiquez le motif du retrait.';
  end if;

  update owner_free_pass set revoked_at = now()
   where owner_id = p_owner and revoked_at is null and ends_on > current_date;
  get diagnostics n = row_count;

  if n > 0 then
    insert into audit_logs (actor_id, action, entity_type, entity_id, reason)
    values (uid, 'free_pass.revoked', 'profile', p_owner::text, btrim(p_reason));
    insert into notifications (user_id, type, payload)
    values (p_owner, 'free_pass.retire', jsonb_build_object('motif', btrim(p_reason)));
  end if;
  return n;
end $$;
revoke all on function revoke_owner_pass(uuid, text) from public, anon;
grant execute on function revoke_owner_pass(uuid, text) to authenticated;

-- =====================================================================
-- 3. La vitrine publique tient compte de l'accès offert
-- =====================================================================
-- Seule la branche « annonce » change : un logement sous gestion dépend d'un contrat, pas
-- d'un abonnement, et n'est donc pas concerné. Les colonnes sont identiques à celles de 0005 :
-- rien de ce qui lit cette vue n'a besoin d'être modifié.
create or replace view public_listings with (security_invoker = false) as
select p.id, p.offer, p.title, p.description, p.city, p.district, p.capacity, p.bedrooms, p.beds,
       p.nightly_price_xof, p.min_nights, p.house_rules, p.cancellation_policy,
       p.neighborhood, p.highlights
from properties p
where p.status = 'publiee'
  and p.is_demo = false
  and (
    (p.offer = 'annonce' and (
       exists (select 1 from subscriptions s
                where s.property_id = p.id and s.status = 'actif'
                  and current_date >= s.starts_at and current_date < s.ends_at)
       or owner_has_free_pass(p.owner_id)))
    or (p.offer in ('gestion','partenariat') and exists (
      select 1 from management_agreements m
      where m.property_id = p.id and m.signed and m.operational_check_done))
  );
grant select on public_listings to anon, authenticated;

-- =====================================================================
-- 4. La garde de publication aussi
-- =====================================================================
-- Sans ça, un propriétaire à qui on a offert l'accès verrait sa publication refusée pour
-- « abonnement manquant », alors que son annonce serait bel et bien visible.
create or replace function _listing_publish_problem(p_property uuid) returns text
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare p properties%rowtype;
begin
  select * into p from properties where id = p_property;
  if not found then return 'Annonce introuvable.'; end if;
  if p.is_demo then return 'Une annonce de démonstration ne se publie pas.'; end if;
  if p.offer = 'annonce' then
    if not exists (select 1 from subscriptions s
                    where s.property_id = p.id and s.status = 'actif'
                      and current_date >= s.starts_at and current_date < s.ends_at)
       and not owner_has_free_pass(p.owner_id) then
      return 'Un abonnement actif (paiement confirmé) est requis.';
    end if;
    if not exists (select 1 from property_contacts c where c.property_id = p.id) then
      return 'Le contact du propriétaire est manquant.';
    end if;
  else
    if not exists (select 1 from management_agreements m
                    where m.property_id = p.id and m.signed and m.operational_check_done) then
      return 'Un contrat signé et la vérification opérationnelle sont requis.';
    end if;
  end if;
  if not exists (select 1 from property_photos ph where ph.property_id = p.id and ph.rights_checked) then
    return 'Au moins une photo aux droits vérifiés est requise.';
  end if;
  return null;
end $$;
revoke all on function _listing_publish_problem(uuid) from public, anon, authenticated;

-- =====================================================================
-- 5. La tâche de nuit ne retire pas une annonce couverte par un accès offert
-- =====================================================================
-- Redéfinition de 0014 : seule la dernière requête change, celle qui passe les annonces en
-- « expirée ». Sans ce correctif, les annonces d'un partenaire à qui on vient d'offrir
-- l'accès seraient marquées expirées toutes les nuits.
create or replace function expire_subscriptions()
returns table (relances_j7 int, relances_j1 int, expires int, annonces_retirees int)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  n7 int := 0; n1 int := 0; ne int := 0; na int := 0;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Fonction réservée au serveur.' using errcode = '42501';
  end if;

  with cibles as (
    select s.id, s.owner_id, s.property_id, s.ends_at, p.title
      from subscriptions s join properties p on p.id = s.property_id
     where s.status = 'actif' and s.ends_at > current_date and s.ends_at <= current_date + 7
       and not exists (select 1 from subscription_reminders r where r.subscription_id = s.id and r.kind = 'j7')
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'j7' from cibles returning 1
  )
  insert into notifications (user_id, type, payload)
  select c.owner_id, 'subscription.bientot_expiree',
         jsonb_build_object('abonnement', c.id, 'annonce', c.property_id, 'titre', c.title,
                            'jusqu_au', c.ends_at, 'jours', c.ends_at - current_date)
    from cibles c;
  get diagnostics n7 = row_count;

  with cibles as (
    select s.id, s.owner_id, s.property_id, s.ends_at, p.title
      from subscriptions s join properties p on p.id = s.property_id
     where s.status = 'actif' and s.ends_at > current_date and s.ends_at <= current_date + 1
       and not exists (select 1 from subscription_reminders r where r.subscription_id = s.id and r.kind = 'j1')
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'j1' from cibles returning 1
  )
  insert into notifications (user_id, type, payload)
  select c.owner_id, 'subscription.expire_demain',
         jsonb_build_object('abonnement', c.id, 'annonce', c.property_id, 'titre', c.title,
                            'jusqu_au', c.ends_at)
    from cibles c;
  get diagnostics n1 = row_count;

  -- « get diagnostics » ne verrait que la DERNIÈRE écriture, c'est-à-dire le nombre de membres
  -- d'équipe prévenus — pas le nombre d'abonnements expirés. On compte donc explicitement.
  with echus as (
    update subscriptions s set status = 'expire'
     where s.status = 'actif' and s.ends_at <= current_date
    returning s.id, s.owner_id, s.property_id, s.ends_at
  ), avec_titre as (
    select e.*, p.title from echus e join properties p on p.id = e.property_id
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'expire' from avec_titre
    on conflict do nothing returning 1
  ), au_proprietaire as (
    insert into notifications (user_id, type, payload)
    select t.owner_id, 'subscription.expiree',
           jsonb_build_object('abonnement', t.id, 'annonce', t.property_id, 'titre', t.title,
                              'expire_le', t.ends_at)
      from avec_titre t
    returning 1
  ), a_equipe as (
    insert into notifications (user_id, type, payload)
    select distinct x.user_id, 'subscription.expiree.equipe',
           jsonb_build_object('abonnement', t.id, 'annonce', t.property_id, 'titre', t.title,
                              'expire_le', t.ends_at)
      from avec_titre t
      cross join (
        select tp.user_id from team_permissions tp where tp.perm in ('validation', 'paiements')
        union
        select ur.user_id from user_roles ur where ur.role = 'admin'
      ) x
     where x.user_id <> t.owner_id
    returning 1
  )
  select count(*) into ne from avec_titre;

  -- Un accès offert au propriétaire tient lieu d'abonnement : on ne retire pas ses annonces.
  update properties p set status = 'expiree'
   where p.offer = 'annonce' and p.status = 'publiee'
     and not owner_has_free_pass(p.owner_id)
     and not exists (select 1 from subscriptions s
                      where s.property_id = p.id and s.status = 'actif'
                        and s.starts_at <= current_date and s.ends_at > current_date);
  get diagnostics na = row_count;

  -- Accès offerts qui se terminent dans les 7 jours : le propriétaire doit pouvoir s'organiser.
  insert into notifications (user_id, type, payload)
  select f.owner_id, 'free_pass.bientot_fini',
         jsonb_build_object('jusqu_au', f.ends_on, 'jours', f.ends_on - current_date)
    from owner_free_pass f
   where f.revoked_at is null and f.ends_on = current_date + 7;

  return query select n7, n1, ne, na;
end $$;
revoke all on function expire_subscriptions() from public, anon, authenticated;

-- =====================================================================
-- 6. Un administrateur peut publier ses propres logements
-- =====================================================================
-- Redéfinition de set_listing_status (0006). UNE SEULE ligne change : le refus de traiter sa
-- propre annonce ne s'applique plus aux administrateurs, et le geste est journalisé.
-- Toutes les autres conditions restent : permission « validation », transitions autorisées,
-- motif obligatoire sur un refus, et la garde de publication (contrat ou abonnement, photo).
create or replace function set_listing_status(p_property uuid, p_status listing_status, p_note text default null)
returns properties
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  prop properties%rowtype;
  problem text;
  old_status listing_status;
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  select * into prop from properties where id = p_property for update;
  if not found then
    raise exception 'Annonce introuvable.';
  end if;
  -- Séparation des rôles : celui qui poste n'est pas celui qui valide. Elle protège les
  -- annonces de TIERS. Sur ses propres logements, l'administrateur de YIRI est à la fois
  -- l'exploitant et le contrôleur, et il n'y a pas de tiers à protéger : on l'autorise,
  -- et on l'écrit au journal pour que ce soit vérifiable après coup.
  if prop.owner_id = uid and not has_role('admin') then
    raise exception 'Vous ne pouvez pas valider ou publier votre propre annonce.' using errcode = '42501';
  end if;
  if prop.status in ('brouillon', 'a_corriger') then
    raise exception 'Cette annonce est en attente d''une action du propriétaire.';
  end if;
  if not listing_transition_ok(prop.status, p_status) then
    raise exception 'Changement de statut non autorisé (% vers %).', prop.status, p_status;
  end if;
  if p_status in ('a_corriger', 'refusee', 'suspendue') and char_length(coalesce(btrim(p_note), '')) < 5 then
    raise exception 'Indiquez un motif clair pour le propriétaire (5 caractères minimum).';
  end if;
  if p_status = 'publiee' then
    problem := _listing_publish_problem(p_property);
    if problem is not null then
      raise exception 'Publication refusée : %', problem;
    end if;
  end if;

  old_status := prop.status;
  update properties set status = p_status, review_note = p_note, updated_at = now()
   where id = p_property returning * into prop;

  insert into audit_logs (actor_id, action, entity_type, entity_id, before, after, reason)
  values (uid,
          case when prop.owner_id = uid then 'listing.status.self' else 'listing.status' end,
          'property', p_property::text,
          jsonb_build_object('status', old_status), jsonb_build_object('status', p_status), p_note);

  if prop.owner_id <> uid then
    insert into notifications (user_id, type, payload)
    values (prop.owner_id, 'listing.' || p_status,
            jsonb_build_object('annonce', p_property, 'titre', prop.title, 'note', p_note));
  end if;

  return prop;
end $$;
revoke all on function set_listing_status(uuid, listing_status, text) from public, anon;
grant execute on function set_listing_status(uuid, listing_status, text) to authenticated;

-- =====================================================================
-- 7. La pièce d'identité n'est pas demandée à YIRI pour ses propres logements
-- =====================================================================
-- Redéfinition du garde-fou de 0007. Il exige que le propriétaire d'une annonce approuvée ou
-- publiée soit un propriétaire VÉRIFIÉ, c'est-à-dire dont la pièce d'identité a été contrôlée.
-- C'est une protection contre les faux bailleurs. Appliquée aux logements de YIRI elle n'a
-- aucun sens : l'administrateur devrait téléverser sa propre pièce puis la valider lui-même,
-- ce qui ne vérifie rien et conserve un document d'identité sans raison.
--
-- Un seul mot change : le rôle « admin » vaut vérification, au même titre que « proprietaire ».
-- Pour tout autre compte, la règle est strictement inchangée.
create or replace function properties_owner_verified_guard() returns trigger language plpgsql
set search_path = public, pg_temp as $$
begin
  if new.status in ('approuvee', 'publiee') and old.status is distinct from new.status
     and not exists (select 1 from user_roles
                      where user_id = new.owner_id and role in ('proprietaire', 'admin')) then
    raise exception 'Le propriétaire n''est pas encore vérifié : validez d''abord sa pièce d''identité.';
  end if;
  return new;
end $$;

-- =====================================================================
-- 8. Voir les accès offerts
-- =====================================================================
create or replace function my_free_pass()
returns table (ends_on date, jours_restants int, reason text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select f.ends_on, (f.ends_on - current_date), f.reason
      from owner_free_pass f
     where f.owner_id = uid and f.revoked_at is null and f.ends_on > current_date
     order by f.ends_on desc limit 1;
end $$;
revoke all on function my_free_pass() from public, anon;
grant execute on function my_free_pass() to authenticated;

create or replace function free_passes_queue(p_limit int default 100)
returns table (id uuid, owner_id uuid, proprietaire text, email text, starts_on date, ends_on date,
               jours_restants int, reason text, revoke_at timestamptz, annonces int)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_any_perm('validation', 'paiements') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  return query
    select f.id, f.owner_id, pr.full_name, coalesce(pr.email, u.email::text),
           f.starts_on, f.ends_on, (f.ends_on - current_date), f.reason, f.revoked_at,
           (select count(*)::int from properties p where p.owner_id = f.owner_id and p.offer = 'annonce')
      from owner_free_pass f
      join profiles pr on pr.id = f.owner_id
      left join auth.users u on u.id = f.owner_id
     order by (f.revoked_at is null and f.ends_on > current_date) desc, f.ends_on desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function free_passes_queue(int) from public, anon;
grant execute on function free_passes_queue(int) to authenticated;
