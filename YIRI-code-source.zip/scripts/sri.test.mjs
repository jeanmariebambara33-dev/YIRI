// L'empreinte d'intégrité protège-t-elle RÉELLEMENT ?
//
// Écrire `integrity="..."` dans une page ne prouve rien : ce qui compte est que le navigateur
// REFUSE d'exécuter un fichier qui ne correspond pas. On le vérifie ici dans un vrai Chromium,
// avec un vrai serveur local, en servant trois fois le même script : empreinte juste, empreinte
// fausse, et fichier modifié en vol.
//
// On n'utilise pas la vraie bibliothèque Supabase (le CDN n'est pas joignable depuis cet
// environnement) : ce qui est éprouvé est le MÉCANISME, c'est-à-dire exactement ce que
// build-preview.mjs écrit dans la page.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
import { createHash } from "node:crypto";
import http from "node:http";
import fs from "node:fs";

let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const SCRIPT = 'window.__chargee = "la bibliotheque a bien ete executee";';
const sha384 = (s) => "sha384-" + createHash("sha384").update(s).digest("base64");
const BONNE = sha384(SCRIPT);

let servi = SCRIPT;
const serveur = http.createServer((req, res) => {
  if (req.url === "/lib.js") {
    res.writeHead(200, { "Content-Type": "text/javascript", "Access-Control-Allow-Origin": "*" });
    res.end(servi);
    return;
  }
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  res.end(`<!doctype html><html lang="fr"><head><meta charset="utf-8"></head><body>
<script src="http://127.0.0.1:8791/lib.js"${req.url.includes("sans") ? "" : ` integrity="${req.url.includes("fausse") ? sha384("autre chose") : BONNE}"`} crossorigin="anonymous"></script>
</body></html>`);
});
await new Promise((r) => serveur.listen(8791, "127.0.0.1", r));

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext();
const p = await ctx.newPage();
const charge = async (url) => {
  await p.goto(url);
  await p.waitForTimeout(400);
  return await p.evaluate(() => window.__chargee ?? null);
};

ok("avec la BONNE empreinte, le script s'exécute", await charge("http://127.0.0.1:8791/bonne") !== null);
ok("avec une empreinte FAUSSE, le navigateur refuse de l'exécuter", await charge("http://127.0.0.1:8791/fausse") === null);

// Le cas réel qu'on veut empêcher : le fichier du CDN est remplacé par du code hostile.
servi = 'window.__chargee = "code hostile"; window.__vole = true;';
ok("un fichier REMPLACÉ est refusé, alors que l'empreinte attendue est inchangée",
  await charge("http://127.0.0.1:8791/bonne") === null);
ok("et le code hostile n'a rien pu faire", await p.evaluate(() => window.__vole ?? false) === false);
ok("SANS empreinte, ce même code hostile s'exécuterait",
  await charge("http://127.0.0.1:8791/sans") === "code hostile");
servi = SCRIPT;

// Ce que la construction écrit réellement dans la page.
const sortie = fs.readFileSync("/home/claude/yiri/dist/yiri-demo.html", "utf8");
const balise = sortie.match(/<script src="https:\/\/cdn\.jsdelivr\.net[^>]*>/)?.[0] ?? "";
ok("la page livrée charge bien la bibliothèque depuis le CDN", balise.length > 0);
ok("avec crossorigin, sans lequel l'empreinte ne peut pas être vérifiée", /crossorigin="anonymous"/.test(balise));
const aUneEmpreinte = /integrity="sha384-/.test(balise);
ok(aUneEmpreinte
    ? "l'empreinte est posée dans la page livrée"
    : "AUCUNE empreinte dans la page livrée — protection inactive (voir assets/supabase-sri.txt)",
   aUneEmpreinte);

await b.close();
serveur.close();
console.log(fails === 0 ? "\nL'EMPREINTE PROTEGE REELLEMENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
