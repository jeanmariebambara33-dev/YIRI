import * as React from "react";
import { formatXOF } from "./lib/money";
import type { VisuelLogement } from "./lib/domain";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

export function Button({
  variant = "primary", size = "md", className, ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "danger"; size?: "sm" | "md" | "lg" }) {
  return (
    <button
      {...props}
      className={cx(
        "inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
        size === "lg" ? "px-8 py-4 text-lg" : size === "md" ? "px-5 py-2.5 text-[15px]" : "px-3.5 py-1.5 text-sm",
        variant === "primary" && "bg-brand text-on-brand hover:bg-brand-hover",
        variant === "secondary" && "border border-line-strong bg-surface text-ink hover:border-ink",
        variant === "ghost" && "text-ink hover:bg-sunk",
        variant === "danger" && "border border-danger/40 text-danger hover:bg-danger/10",
        className
      )}
    />
  );
}

export function Money({ value, className }: { value: number; className?: string }) {
  return <span className={cx("tabular-nums", className)}>{formatXOF(value)}</span>;
}

type Tone = "neutral" | "good" | "warn" | "bad" | "info" | "accent";
export function Pill({ tone = "neutral", children }: { tone?: Tone; children: React.ReactNode }) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap",
        tone === "neutral" && "bg-sunk text-muted",
        tone === "good" && "bg-good/15 text-good",
        tone === "warn" && "bg-warn/15 text-warn",
        tone === "bad" && "bg-danger/12 text-danger",
        tone === "info" && "bg-sage/20 text-sage-ink",
        tone === "accent" && "bg-accent/15 text-accent-ink"
      )}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
      {children}
    </span>
  );
}

export function DemoTag({ className }: { className?: string }) {
  return (
    <span className={cx("rounded-sm bg-ink/80 px-1.5 py-0.5 font-mono text-[10px] font-bold tracking-[0.12em] text-bg", className)}>
      DÉMO
    </span>
  );
}

export function Field({ label, hint, error, children, htmlFor }: { label: string; hint?: string; error?: string; children: React.ReactNode; htmlFor: string }) {
  return (
    <div className="flex flex-col gap-1.5 min-w-0">
      <label htmlFor={htmlFor} className="text-sm font-semibold text-ink">{label}</label>
      {children}
      {hint && !error && <p className="text-xs text-muted">{hint}</p>}
      {error && <p className="text-xs font-medium text-danger">{error}</p>}
    </div>
  );
}

export const inputCls =
  "w-full rounded-xl border border-line-strong bg-surface px-3.5 py-2.5 text-[15px] text-ink placeholder:text-faint focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/20";

/** Visuel illustratif généré : la démo n'utilise aucune photo réelle de logement. */
export function PropertyArt(props: { p: VisuelLogement & { photos?: string[] }; className?: string; tall?: boolean }) {
  const photo = props.p.photos?.[0];
  if (photo) return <img src={photo} alt="Photo du logement" className={cx("bg-sunk object-cover", props.className)} />;
  return <PropertyIllustration {...props} />;
}

function PropertyIllustration({ p, className, tall }: { p: VisuelLogement; className?: string; tall?: boolean }) {
  const seed = [...p.id].reduce((a, c) => a + c.charCodeAt(0), 0);
  const h = p.hue;
  const wall = `hsl(${h} 28% 72%)`;
  const wallDark = `hsl(${h} 24% 60%)`;
  const sky = `hsl(${(h + 30) % 360} 35% 88%)`;
  const windows = Math.min(3, Math.max(1, p.bedrooms));
  const W = 400, H = tall ? 300 : 240;
  const base = H - 40;
  return (
    <div className={cx("relative overflow-hidden bg-sunk", className)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="block h-full w-full" preserveAspectRatio="xMidYMax slice" role="img" aria-label="Visuel illustratif du logement (démo)">
        <rect width={W} height={H} fill={sky} />
        <circle cx={60 + (seed % 260)} cy={50} r={26} fill="hsl(36 80% 70%)" opacity="0.85" />
        <rect x="0" y={base} width={W} height={H - base} fill="hsl(28 30% 55%)" />
        <rect x="60" y={base - 120} width="280" height="120" fill={wall} />
        <rect x="60" y={base - 132} width="280" height="14" fill={wallDark} />
        <path d={`M180 ${base} v-62 a20 20 0 0 1 40 0 v62 z`} fill="hsl(20 35% 32%)" />
        {Array.from({ length: windows }).map((_, i) => {
          const x = i % 2 === 0 ? 90 + i * 20 : 250 + (i - 1) * 20;
          return <rect key={i} x={x} y={base - 92} width="44" height="40" rx="3" fill="hsl(200 25% 35%)" opacity="0.75" />;
        })}
        <path d={`M30 ${base} q10 -50 30 -60 q-6 30 4 60 z`} fill="hsl(95 25% 40%)" />
        <path d={`M352 ${base} q4 -70 18 -84 q8 40 2 84 z`} fill="hsl(95 22% 35%)" />
      </svg>
      <DemoTag className="absolute left-3 top-3" />
    </div>
  );
}

export function Section({ title, eyebrow, children, action, center }: { title: string; eyebrow?: string; children: React.ReactNode; action?: React.ReactNode; center?: boolean }) {
  return (
    <section className="flex flex-col gap-5">
      <div className={cx("flex flex-wrap items-end gap-3", center ? "justify-center text-center" : "justify-between")}>
        <div className={cx("flex flex-col gap-1", center && "items-center")}>
          {eyebrow && <p className="text-xs font-bold uppercase tracking-[0.14em] text-accent-ink">{eyebrow}</p>}
          <h2 className="font-display text-2xl font-bold text-ink text-balance sm:text-3xl">{title}</h2>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-line-strong px-5 py-8 text-center text-sm text-muted">{children}</div>;
}
