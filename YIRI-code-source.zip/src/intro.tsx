// Animation d'ouverture : l'aube se lève sur la photo du village, puis YIRI s'écrit.
//
// CE QUI EST ANIMÉ. La photo ne bouge pas — c'est une photo. Ce qui bouge, c'est la LUMIÈRE
// posée dessus : une nuit qui se retire, une lueur qui monte depuis sous l'horizon jusqu'au
// soleil de l'image, un éclat doré qui gagne le paysage. L'oeil y lit un lever de soleil, alors
// qu'aucun pixel de la photo n'a changé. C'est ce qui rend la chose possible sans vidéo.
//
// CE QUE ÇA COÛTE. Un seul fichier en plus : 15 Ko sur téléphone, 71 Ko sur grand écran, choisi
// par le navigateur. Une vignette de 200 octets, incluse dans la page, occupe l'écran pendant le
// téléchargement — et comme l'introduction commence dans le noir, personne ne la voit jamais.
//
// POURQUOI OPACITY ET TRANSFORM SEULEMENT. Ce sont les deux propriétés qu'un navigateur confie à
// la carte graphique sans refaire la mise en page à chaque image. Un téléphone modeste les tient
// à soixante images par seconde ; animer un filtre ou une couleur, non.
import * as React from "react";
import { HeroContenu } from "./hero";
import { PHOTO, PHOTO_LARGEURS, PHOTO_VIGNETTE } from "./data/photo";

/** Filet de sécurité, en millisecondes.
 *
 *  La fin de l'introduction n'est PAS pilotée par une minuterie : elle écoute la fin réelle du
 *  fondu de sortie (onAnimationEnd). Deux horloges ne partent pas ensemble — une minuterie
 *  JavaScript démarre au montage du composant, une animation CSS au premier affichage, qui peut
 *  arriver une seconde plus tard sur un téléphone modeste. Une minuterie aurait retiré le voile
 *  AVANT la dernière lettre du nom : mesuré, pas supposé.
 *
 *  Ce délai ne sert que si aucune animation ne se déclenche : le voile part alors de lui-même
 *  plutôt que de rester collé devant le site.
 */
const SECOURS = 9000;

const CLE = "yiri.intro.vue";

/** Décide UNE FOIS, au premier rendu, si l'introduction doit jouer. */
function doitJouer(): boolean {
  try {
    // Pas sur une page profonde : qui arrive sur #logements veut voir des logements.
    if (window.location.hash.replace(/^#/, "") !== "") return false;
    // Une fois par visite, pas à chaque retour sur l'accueil.
    if (sessionStorage.getItem(CLE) === "1") return false;
    // Mouvement réduit demandé par la personne : on respecte, sans discuter.
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return false;
    return true;
  } catch {
    // Navigateur qui refuse sessionStorage : pas d'animation, plutôt qu'une animation rejouée
    // à chaque page.
    return false;
  }
}

type Boite = { top: number; left: number; width: number };

export function Intro() {
  // useState avec fonction : la décision est prise au montage et ne change plus. C'est ce qui
  // empêche l'introduction de se relancer à chaque navigation.
  const [actif, setActif] = React.useState(doitJouer);
  const [saute, setSaute] = React.useState(false);
  const [texte, setTexte] = React.useState<Boite | null>(null);
  const [soleil, setSoleil] = React.useState<{ x: number; y: number } | null>(null);
  const bouton = React.useRef<HTMLButtonElement>(null);

  // Marque la visite tout de suite : un rechargement pendant l'animation ne la rejoue pas.
  React.useEffect(() => {
    if (!actif) return;
    try { sessionStorage.setItem(CLE, "1"); } catch { /* sans conséquence */ }
  }, [actif]);

  // Le défilement est bloqué pendant l'animation, sinon on fait défiler un site invisible.
  //
  // La largeur de la barre de défilement est rendue en marge intérieure. Sans cela, la masquer
  // élargit la page de quelques pixels puis la rétablir la rétrécit : tout le contenu sauterait
  // latéralement à la fin, et les positions mesurées ci-dessous seraient fausses.
  React.useEffect(() => {
    if (!actif) return;
    const corps = document.body;
    const avant = { o: corps.style.overflow, p: corps.style.paddingRight };
    const barre = window.innerWidth - document.documentElement.clientWidth;
    corps.style.overflow = "hidden";
    if (barre > 0) corps.style.paddingRight = `${barre}px`;
    return () => { corps.style.overflow = avant.o; corps.style.paddingRight = avant.p; };
  }, [actif]);

  // Deux mesures, refaites si l'écran change de taille.
  //
  // 1. La position du bloc de texte de la page d'accueil. L'introduction en affiche une copie
  //    posée exactement dessus : sans cela, pendant le fondu, on verrait DEUX fois le mot YIRI
  //    à deux hauteurs. Mesurer plutôt que recopier une hauteur d'en-tête évite aussi de se
  //    tromper dès que la police, la largeur d'écran ou le nombre de lignes du menu changent.
  //
  // 2. La position du soleil DANS LA PHOTO, une fois celle-ci recadrée pour remplir l'écran.
  //    On refait ici le calcul que fait le navigateur pour « object-fit: cover » : l'image est
  //    agrandie jusqu'à couvrir, puis centrée. Sans ce calcul, la lueur se lèverait à côté du
  //    soleil sur tout écran dont les proportions diffèrent de celles de la photo — c'est-à-dire
  //    sur à peu près tous.
  React.useLayoutEffect(() => {
    if (!actif) return;
    const mesurer = () => {
      const e = document.querySelector("main [data-yiri-hero]");
      if (e) {
        const r = e.getBoundingClientRect();
        setTexte({ top: r.top, left: r.left, width: r.width });
      }
      const L = window.innerWidth, H = window.innerHeight;
      const k = Math.max(L / PHOTO.largeur, H / PHOTO.hauteur);
      setSoleil({
        x: (L - PHOTO.largeur * k) / 2 + PHOTO.soleilX * k,
        y: (H - PHOTO.hauteur * k) / 2 + PHOTO.soleilY * k,
      });
    };
    mesurer();
    window.addEventListener("resize", mesurer);
    return () => window.removeEventListener("resize", mesurer);
  }, [actif]);

  // Filet : si aucune animation ne se déclenche, le voile part quand même.
  React.useEffect(() => {
    if (!actif) return;
    const t = window.setTimeout(() => setActif(false), SECOURS);
    return () => window.clearTimeout(t);
  }, [actif]);

  // Échap passe l'animation, comme dans n'importe quel lecteur.
  React.useEffect(() => {
    if (!actif) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setSaute(true); };
    window.addEventListener("keydown", onKey);
    bouton.current?.focus();
    return () => window.removeEventListener("keydown", onKey);
  }, [actif]);

  if (!actif) return null;

  // Les deux coordonnées du soleil partent en variables CSS : la feuille de style les combine
  // ensuite avec calc(). Une première version les posait en marges négatives calculées avec
  // min() — qui, sur des valeurs négatives, retient la PLUS négative : la lueur se levait à deux
  // cents pixels à côté du soleil.
  const sx = soleil ? `${Math.round(soleil.x)}px` : "58%";
  const sy = soleil ? `${Math.round(soleil.y)}px` : "49%";
  const vars = { "--yi-sx": sx, "--yi-sy": sy } as React.CSSProperties;

  return (
    <div
      className={"yi-intro fixed inset-0 z-[70] overflow-hidden bg-[#0a0810]" + (saute ? " yi-sauter" : "")}
      style={vars}
      onClick={() => setSaute(true)}
      onAnimationEnd={(e) => {
        // Seul le fondu de sortie du voile lui-même termine l'introduction : les animations des
        // lettres, de la lueur et du soleil remontent aussi jusqu'ici et ne doivent rien couper.
        if ((e.animationName === "yi-sortie" || e.animationName === "yi-saut") && e.target === e.currentTarget) setActif(false);
      }}
      role="region"
      aria-label="Animation d'ouverture"
    >
      {/* La photo. La vignette est dessous : l'écran n'est jamais vide, même avant l'arrivée du
          fichier. AVIF d'abord, WebP en secours — le navigateur prend le premier qu'il sait lire
          et la largeur qui correspond à son écran. */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${PHOTO_VIGNETTE})` }}
      >
        <picture>
          {["avif", "webp"].map((t) => (
            <source
              key={t}
              type={`image/${t}`}
              // La photo remplit l'écran en « cover ». Sur un écran plus haut que large, elle est
              // donc agrandie d'après la HAUTEUR : la largeur réellement affichée vaut une fois
              // et demie la hauteur de l'écran (la photo fait 3 pour 2), pas sa largeur. Annoncer
              // 100vw faisait choisir au navigateur une version de 540 pixels étirée sur 1265 :
              // l'ouverture était floue sur tous les téléphones.
              sizes="(max-aspect-ratio: 3/2) 150vh, 100vw"
              srcSet={PHOTO_LARGEURS.map((w) => `photo/accueil-${w}.${t} ${w}w`).join(", ")}
            />
          ))}
          <img
            src={`photo/accueil-${PHOTO_LARGEURS[1]}.webp`}
            alt=""
            fetchPriority="high"
            decoding="async"
            className="yi-photo h-full w-full object-cover"
          />
        </picture>
      </div>

      {/* La lueur qui monte de sous l'horizon jusqu'au soleil de la photo. C'est elle qui fait
          le lever : la photo, elle, ne bouge pas d'un pixel. */}
      <div
        aria-hidden="true"
        className="yi-lueur absolute"
        style={{
          background: "radial-gradient(closest-side, rgba(255,247,214,0.95) 0%, rgba(255,201,106,0.5) 12%, rgba(255,150,54,0.22) 30%, rgba(255,130,40,0) 62%)",
          mixBlendMode: "screen",
        }}
      />

      {/* L'éclat doré qui gagne le paysage, puis s'ouvre au dernier instant : le site qui apparaît
          derrière est un dessin, pas une photo, et passer par la lumière rend ce changement de
          matière beaucoup plus doux qu'un fondu direct d'une image sur l'autre. */}
      <div
        aria-hidden="true"
        className="yi-eclat absolute inset-0"
        style={{
          background: "radial-gradient(60% 60% at var(--yi-sx) var(--yi-sy), rgba(255,226,160,0.85) 0%, rgba(255,176,80,0.4) 35%, rgba(255,150,60,0) 70%)",
          mixBlendMode: "screen",
        }}
      />

      {/* La nuit qui se retire : un voile sombre posé sur tout, dont l'opacité tombe à zéro. */}
      <div
        aria-hidden="true"
        className="yi-nuit absolute inset-0"
        style={{ background: "linear-gradient(180deg, #05060f 0%, #0a0916 42%, #140d16 74%, #1b1017 100%)" }}
      />

      {/* Le lit du texte : la photo est claire, le texte est crème. Sans cet assombrissement
          resserré sous la colonne de texte, le nom et l'accroche deviennent illisibles. */}
      <div
        aria-hidden="true"
        className="yi-lit absolute inset-0"
        style={{ background: "radial-gradient(76% 52% at 50% 46%, rgba(14,6,0,0.62) 0%, rgba(14,6,0,0.42) 50%, rgba(14,6,0,0.12) 80%, rgba(14,6,0,0) 100%)" }}
      />

      {/* Le nom seul, posé exactement sur celui de la page d'accueil, pour qu'il ne bouge pas au
          moment du raccord. Ni promesse ni bouton : sur une photo, l'ouverture est un
          carton-titre, et recopier la page entière par-dessus faisait doublon avec le site qui
          apparaît juste après.
          aria-hidden : c'est une copie ; le vrai texte est dans la page, juste en dessous. Le
          bouton « Passer », lui, reste annoncé et reçoit le focus. */}
      {texte ? (
        <div aria-hidden="true" className="absolute" style={{ top: texte.top, left: texte.left, width: texte.width }}>
          <HeroContenu anim resume tag="div" />
        </div>
      ) : (
        <div aria-hidden="true" className="absolute inset-0 grid place-items-center"><HeroContenu anim resume tag="div" /></div>
      )}

      <button
        ref={bouton}
        type="button"
        onClick={(e) => { e.stopPropagation(); setSaute(true); }}
        className="yi-passer absolute bottom-5 right-5 rounded-full border border-[#f7ecd8]/40 bg-black/35 px-5 py-2.5 text-sm font-semibold text-[#f7ecd8] backdrop-blur-sm cursor-pointer hover:bg-black/55 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f8c595]"
      >
        Passer
      </button>
    </div>
  );
}
