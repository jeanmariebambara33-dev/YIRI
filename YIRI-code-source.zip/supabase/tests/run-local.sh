#!/usr/bin/env bash
# Rejoue les migrations sur une base PostgreSQL LOCALE ET VIDE (jamais sur une vraie base), puis lance les tests.
# Usage : bash supabase/tests/run-local.sh   (PostgreSQL 16 + utilisateur système « postgres »)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; MIG="${MIG_DIR:-$HERE/../migrations}"
BIN="${PG_BIN:-/usr/lib/postgresql/16/bin}"; D="${PG_TMP:-/var/tmp/yiri-db-test}"; PORT=5546
rm -rf "$D"; mkdir -p "$D"; chown postgres "$D"
su postgres -c "$BIN/initdb -D $D/data -U postgres -A trust >/dev/null && $BIN/pg_ctl -D $D/data -o '-p $PORT -k /tmp -c max_connections=60' -l $D/log -w start >/dev/null"
trap 'su postgres -c "$BIN/pg_ctl -D $D/data stop >/dev/null 2>&1" || true; rm -rf "$D"' EXIT
P="psql -h /tmp -p $PORT -U postgres -v ON_ERROR_STOP=1 -q"
cd "$HERE"

newdb() { $P -c "create database $1" && $P -d "$1" -f "$HERE/stub.sql" ${2:+-f "$HERE/stub_storage.sql"} >/dev/null; }
replay() { # $1 = base, $2 = dernière migration à appliquer (ex. 0005)
  for f in "$MIG"/0*.sql; do
    n=$(basename "$f" | cut -c1-4); [ "$n" \> "$2" ] && break
    $P -d "$1" -f "$f" 2>&1 | grep -E "ERROR" && exit 1 || true
  done
}

echo "== Phase A : 0001 à 0006 sur base vide, SANS schéma storage"
newdb a
for f in "$MIG"/0*.sql; do echo "   $(basename "$f")"; $P -d a -f "$f" 2>&1 | grep -E "ERROR|NOTICE" || true; done

echo "== Phase B5 : 0001 à 0005 + tests de la migration 0005"
newdb b5 storage; replay b5 0005
$P -d b5 -t -A -f "$HERE/0005_security.sql"

echo "== Phase B6 : 0001 à 0006 + tests de la migration 0006"
newdb b6 storage; replay b6 0006
$P -d b6 -t -A -f "$HERE/0006_functions.sql"

echo "== Phase B7 : 0001 à 0007 + tests de la migration 0007"
newdb b7 storage; replay b7 0007
$P -d b7 -t -A -f "$HERE/0007_identity.sql"

echo "== Phase B8 : 0001 à 0008 + tests de la migration 0008"
newdb b8 storage; replay b8 0008
$P -d b8 -t -A -f "$HERE/0008_queues.sql"

echo "== Phase B9 : 0001 à 0009 + tests de 0006 rejoués (confirm_payment redéfinie)"
echo "   Écarts ATTENDUS : 0007 exige désormais une pièce d'identité en attente avant d'accorder le rôle"
echo "   propriétaire, ce que les tests de 0006 ne créent pas. Quatre tests divergent pour cette raison,"
echo "   et seulement celle-là. Le comportement de confirm_payment, lui, doit rester identique."
newdb b9 storage; replay b9 0009
$P -d b9 -t -A -f "$HERE/0006_functions.sql" 2>&1 | sed 's/^/   /' || true

echo "== Phase B9b : 0001 à 0009 + tests de la migration 0009 (paiement en ligne)"
newdb b9b storage; replay b9b 0009
$P -d b9b -t -A -f "$HERE/0009_online_payment.sql"

echo "== Phase B10 : 0001 à 0010 + tests de la migration 0010 (annulation et remboursement)"
newdb b10 storage; replay b10 0010
$P -d b10 -t -A -f "$HERE/0010_refunds.sql"

echo "== Phase B11 : 0001 à 0011 + tests de la migration 0011 (voir les réservations, être prévenu)"
newdb b11 storage; replay b11 0011
$P -d b11 -t -A -f "$HERE/0011_bookings.sql"

echo "== Phase B12 : 0001 à 0012 + tests de la migration 0012 (téléphone du voyageur)"
newdb b12 storage; replay b12 0012
$P -d b12 -t -A -f "$HERE/0012_guest_phone.sql"

echo "== Phase B14 : 0001 à 0014 + tests de la migration 0014 (abonnements)"
newdb b14 storage; replay b14 0014
$P -d b14 -t -A -f "$HERE/0014_abonnements.sql"

echo "== Phase B15 : 0001 à 0015 + tests de la migration 0015 (accès offert, auto-publication)"
newdb b15 storage; replay b15 0015
$P -d b15 -t -A -f "$HERE/0015_acces_offert.sql"

echo "== Phase B16 : 0001 à 0016 + tests de la migration 0016 (abonnement par profil, 15 cas de la spec)"
newdb b16 storage; replay b16 0016
$P -d b16 -t -A -f "$HERE/0016_abonnement_profil.sql"

echo "== Phase B17 : 0001 à 0017 + tests de la migration 0017 (notifications poussées sur l'appareil)"
newdb b17 storage; replay b17 0017
$P -d b17 -t -A -f "$HERE/0017_push.sql"

echo "== Phase B18 : 0001 à 0018 + tests de la migration 0018 (le déclencheur d'envoi)"
newdb b18 storage; replay b18 0018
$P -d b18 -t -A -f "$HERE/0018_declencheur.sql"

echo "== Phase B19 : 0001 à 0019 + tests de la migration 0019 (le remboursement passe par l'équipe)"
newdb b19 storage; replay b19 0019
$P -d b19 -t -A -f "$HERE/0019_remboursement.sql"

echo "== Phase B20 : 0001 à 0020 + tests de la migration 0020 (notifications manquantes et courriels)"
newdb b20 storage; replay b20 0020
$P -d b20 -t -A -f "$HERE/0020_courriels.sql"

echo "== Phase B21 : 0001 à 0021 + tests de la migration 0021 (droits de lecture retirés)"
newdb b21 storage; replay b21 0021
$P -d b21 -t -A -f "$HERE/0021_revoke.sql"

echo "== Phase B22 : 0001 à 0022 + tests de la migration 0022 (relevés propriétaires)"
newdb b22 storage; replay b22 0022
$P -d b22 -t -A -f "$HERE/0022_releves.sql"

echo "== Phase B23 : 0001 à 0023 + tests de la migration 0023 (réclamations)"
newdb b23 storage; replay b23 0023
$P -d b23 -t -A -f "$HERE/0023_reclamations.sql"

echo "== Phase B24 : 0001 à 0024 + tests de la migration 0024 (motif d'échec des remboursements)"
newdb b24 storage; replay b24 0024
$P -d b24 -t -A -f "$HERE/0024_file_remboursements.sql"

echo "== Phase C : scénarios concurrents (plusieurs connexions simultanées)"
PSQL_C="psql -h /tmp -p $PORT -U postgres -d b6 -q -t -A" bash "$HERE/concurrency.sh"

echo "== Phase P : contrôles de préproduction (supabase/preprod/checks.sql) sur une base rejouée propre"
newdb p storage; replay p 0024
$P -d p -A -F ' | ' -f "$HERE/../preprod/checks.sql" | sed 's/^/   /'
echo "   -- fonctions attendues : sur une base rejouée au complet, la liste des absentes doit être VIDE"
echo "   -- (c'est ce contrôle qui aurait signalé la 0008 jamais appliquée en ligne)"
node "$HERE/../../scripts/fonctions-attendues.mjs" >/dev/null
$P -d p -A -F ' | ' -f "$HERE/../preprod/fonctions_manquantes.sql" | sed 's/^/   /'
echo "   -- contrôle d'accès (visiteur / utilisateur inconnu) sur la base propre :"
$P -d p -A -F ' | ' -f "$HERE/../preprod/checks_access.sql" | sed 's/^/   /'
echo "   -- le même contrôle d'accès sur la base de test REMPLIE de données (doit signaler des lignes visibles pour l'examen : ici les vues publiques) :"
$P -d b6 -A -F ' | ' -f "$HERE/../preprod/checks_access.sql" | sed 's/^/   /'

echo "== Phase R : régression — tests de 0005 rejoués sur le schéma complet 0001–0006 (écarts attendus listés)"
newdb r storage; replay r 0006
$P -d r -t -A -f "$HERE/0005_security.sql" 2>&1 | sed 's/^/   /' || true
