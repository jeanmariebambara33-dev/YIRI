import * as React from "react";
import { Button, Field, inputCls, Pill, Money } from "../ui";
import { useSession } from "../session";
import * as api from "../lib/api";
import type { Listing, Photo, IdentityState } from "../lib/api";
import { AlertesAppareil } from "../push";
import { MesRevenus, MesSignalements } from "./revenus";

// Espace propriétaire RÉEL : les données viennent de Supabase, pas du magasin de démonstration.
// Parcours voulu par YIRI : compte → brouillon → pièce d'identité au moment de publier → validation par l'équipe.

const STATUS: Record<Listing["status"], [string, "neutral" | "info" | "warn" | "good" | "bad" | "accent"]> = {
  brouillon: ["Brouillon", "neutral"],
  soumise: ["En cours de validation", "info"],
  a_corriger: ["À corriger", "warn"],
  approuvee: ["Approuvée", "good"],
  publiee: ["En ligne", "good"],
  refusee: ["Refusée", "bad"],
  suspendue: ["Suspendue", "bad"],
  expiree: ["Expirée", "warn"],
  archivee: ["Archivée", "neutral"],
};

function Alert({ tone, children }: { tone: "bad" | "good" | "warn"; children: React.ReactNode }) {
  const cls = tone === "bad" ? "border-danger/40 bg-danger/10 text-danger"
    : tone === "good" ? "border-good/40 bg-good/10 text-good"
    : "border-warn/40 bg-warn/10 text-warn";
  return <p role={tone === "bad" ? "alert" : "status"} className={`rounded-xl border px-3.5 py-2.5 text-sm font-medium ${cls}`}>{children}</p>;
}

function Card({ title, children, note }: { title: string; children: React.ReactNode; note?: string }) {
  return (
    <section className="rounded-2xl border border-line bg-surface p-5">
      <h2 className="font-display text-lg font-bold text-ink">{title}</h2>
      {note && <p className="mt-1 text-sm text-muted">{note}</p>}
      <div className="mt-4 flex flex-col gap-4">{children}</div>
    </section>
  );
}

/** Image d'un espace privé : l'adresse est temporaire et demandée au serveur. */
function PrivatePhoto({ path }: { path: string }) {
  const [url, setUrl] = React.useState<string | null>(null);
  const [failed, setFailed] = React.useState(false);
  React.useEffect(() => {
    let alive = true;
    api.photoUrl(path).then((u) => { if (alive) { setUrl(u); setFailed(!u); } }).catch(() => { if (alive) setFailed(true); });
    return () => { alive = false; };
  }, [path]);
  if (failed) return <div className="grid aspect-4/3 place-items-center rounded-xl bg-sunk text-xs text-muted">Aperçu indisponible</div>;
  if (!url) return <div className="aspect-4/3 animate-pulse rounded-xl bg-sunk" />;
  return <img src={url} alt="" className="aspect-4/3 w-full rounded-xl object-cover" />;
}

// ---------------------------------------------------------------------------
// Pièce d'identité
// ---------------------------------------------------------------------------
function IdentityBlock({ id, identity, onChange }: { id: string; identity: IdentityState; onChange: () => void }) {
  const [type, setType] = React.useState(identity.id_type ?? "cnib");
  const [number, setNumber] = React.useState("");
  const [sent, setSent] = React.useState<{ recto: boolean; verso: boolean }>({ recto: identity.files_sent >= 2, verso: identity.files_sent >= 2 });
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const send = async (side: "recto" | "verso", file: File | undefined) => {
    if (!file) return;
    setError(null); setBusy(true);
    try { await api.uploadIdentityFile(id, side, file); setSent((s) => ({ ...s, [side]: true })); }
    catch (e) { setError(e instanceof Error ? e.message : "Envoi impossible."); }
    finally { setBusy(false); }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const bad = api.checkIdNumber(number);
    if (bad) { setError(bad); return; }
    if (!sent.recto || !sent.verso) { setError("Envoyez le recto ET le verso de votre pièce."); return; }
    setError(null); setBusy(true);
    try { await api.submitIdentity(type, number); onChange(); }
    catch (e2) { setError(e2 instanceof Error ? e2.message : "Envoi impossible."); }
    finally { setBusy(false); }
  };

  if (identity.state === "en_attente") {
    return <Card title="Pièce d'identité">
      <Alert tone="good">Votre pièce est bien arrivée. L'équipe YIRI la vérifie, puis votre annonce passe en validation.</Alert>
      <p className="text-sm text-muted">Pièce : {identity.id_type} · numéro {identity.id_number_masked} · {identity.files_sent} document(s) reçu(s).</p>
    </Card>;
  }
  if (identity.state === "verifie") {
    return <Card title="Pièce d'identité">
      <Alert tone="good">Votre identité est vérifiée. {identity.files_deleted ? "Vos images ont été supprimées, comme promis." : ""}</Alert>
    </Card>;
  }
  if (identity.state === "refuse") {
    return <Card title="Pièce d'identité">
      <Alert tone="bad">Votre pièce a été refusée. {identity.decision_note ?? ""} Contactez l'équipe YIRI.</Alert>
    </Card>;
  }

  return (
    <Card title="Vérifiez votre identité pour publier"
          note="Nous demandons votre pièce une seule fois, au moment de publier. Les images sont supprimées dès que l'équipe a vérifié.">
      {identity.state === "a_renvoyer" && <Alert tone="warn">Document à renvoyer. {identity.decision_note ?? ""}</Alert>}
      {error && <Alert tone="bad">{error}</Alert>}
      <form onSubmit={submit} className="flex flex-col gap-4">
        <div className="grid gap-4 sm:grid-cols-2">
          {(["recto", "verso"] as const).map((side) => (
            <Field key={side} label={side === "recto" ? "Recto de la pièce" : "Verso de la pièce"} htmlFor={`id-${side}`}
                   hint={sent[side] ? "Envoyé." : "JPEG, PNG ou WebP, 5 Mo maximum."}>
              <input id={`id-${side}`} type="file" accept="image/jpeg,image/png,image/webp" disabled={busy}
                     className="block w-full text-sm text-muted file:mr-3 file:rounded-full file:border-0 file:bg-sunk file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-ink"
                     onChange={(e) => void send(side, e.target.files?.[0])} />
            </Field>
          ))}
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Type de pièce" htmlFor="id-type">
            <select id="id-type" className={inputCls} value={type} onChange={(e) => setType(e.target.value)}>
              {api.ID_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </Field>
          <Field label="Numéro de la pièce" htmlFor="id-num" hint="Tel qu'il figure sur le document.">
            <input id="id-num" className={inputCls} value={number} onChange={(e) => setNumber(e.target.value)} placeholder="B1234567" />
          </Field>
        </div>
        <Button type="submit" disabled={busy}>{busy ? "Envoi…" : "Envoyer ma pièce d'identité"}</Button>
      </form>
      <p className="text-xs text-muted">
        Votre numéro est conservé dans un espace fermé : ni le public, ni les voyageurs, ni les autres propriétaires
        n'y ont accès. Seule l'équipe habilitée peut l'ouvrir, et chaque consultation est enregistrée.
      </p>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Édition d'une annonce
// ---------------------------------------------------------------------------
const EMPTY: api.DraftInput = { title: "", description: "", city: "Ouagadougou", district: "", private_address: "", capacity: 2, bedrooms: 1, beds: 1, nightly_price_xof: 15000, min_nights: 1 };

function ListingForm({ listing, ownerId, identity, onSaved, onBack, reloadIdentity }: {
  listing: Listing | null; ownerId: string; identity: IdentityState;
  onSaved: () => void; onBack: () => void; reloadIdentity: () => void;
}) {
  const s = useSession();
  const [d, setD] = React.useState<api.DraftInput>(listing ? { ...listing, private_address: listing.private_address ?? "" } : EMPTY);
  const [photos, setPhotos] = React.useState<Photo[]>([]);
  const [contact, setContact] = React.useState<api.Contact>({ contact_name: "", phone: "", whatsapp: true });
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [notice, setNotice] = React.useState<string | null>(null);

  const editable = !listing || listing.status === "brouillon" || listing.status === "a_corriger";
  const set = <K extends keyof api.DraftInput>(k: K, v: api.DraftInput[K]) => setD((p) => ({ ...p, [k]: v }));

  React.useEffect(() => {
    if (!listing) return;
    let alive = true;
    void (async () => {
      try {
        const [ph, c] = await Promise.all([api.listPhotos(listing.id), api.getContact(listing.id)]);
        if (!alive) return;
        setPhotos(ph);
        if (c) setContact(c);
      } catch (e) { if (alive) setError(e instanceof Error ? e.message : "Lecture impossible."); }
    })();
    return () => { alive = false; };
  }, [listing]);

  const guard = async (fn: () => Promise<void>) => {
    setBusy(true); setError(null); setNotice(null);
    try { await fn(); } catch (e) { setError(e instanceof Error ? e.message : "Opération impossible."); }
    finally { setBusy(false); }
  };

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    const bad = api.checkDraft(d);
    if (bad) { setError(bad); return; }
    void guard(async () => {
      if (listing) { await api.updateDraft(listing.id, d); setNotice("Modifications enregistrées."); }
      else { await api.createDraft(ownerId, d); setNotice("Brouillon créé."); }
      onSaved();
    });
  };

  const addPhoto = (file: File | undefined) => {
    if (!file || !listing) return;
    void guard(async () => {
      await api.uploadPhoto(ownerId, listing.id, file, photos.length);
      setPhotos(await api.listPhotos(listing.id));
      setNotice("Photo ajoutée.");
    });
  };

  const removePhoto = (p: Photo) => {
    if (!listing) return;
    void guard(async () => { await api.deletePhoto(p); setPhotos(await api.listPhotos(listing.id)); });
  };

  const saveContact = () => {
    if (!listing) return;
    const bad = api.checkContact(contact);
    if (bad) { setError(bad); return; }
    void guard(async () => { await api.saveContact(listing.id, contact); setNotice("Contact enregistré."); });
  };

  const submit = () => {
    if (!listing) return;
    void guard(async () => {
      await api.submitListing(listing.id);
      setNotice("Annonce envoyée en validation. L'équipe YIRI vous répond sous peu.");
      onSaved();
    });
  };

  const isOwner = s.has("proprietaire");
  const identityReady = isOwner || identity.state === "en_attente" || identity.state === "verifie";
  const canSubmit = !!listing && (listing.status === "brouillon" || listing.status === "a_corriger");

  return (
    <div className="flex flex-col gap-5 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-extrabold tracking-tight text-ink">
          {listing ? listing.title : "Nouvelle annonce"}
        </h1>
        {listing && <Pill tone={STATUS[listing.status][1]}>{STATUS[listing.status][0]}</Pill>}
      </div>
      <button onClick={onBack} className="self-start text-sm font-semibold text-muted underline underline-offset-4 cursor-pointer hover:text-ink">Revenir à mes annonces</button>

      {error && <Alert tone="bad">{error}</Alert>}
      {notice && <Alert tone="good">{notice}</Alert>}
      {listing?.review_note && <Alert tone="warn">Message de l'équipe : {listing.review_note}</Alert>}

      <Card title="Le logement" note={editable ? undefined : "Cette annonce n'est plus modifiable dans son état actuel."}>
        <form onSubmit={save} className="flex flex-col gap-4">
          <Field label="Titre" htmlFor="l-titre"><input id="l-titre" className={inputCls} value={d.title} disabled={!editable} onChange={(e) => set("title", e.target.value)} placeholder="Studio meublé, quartier calme" /></Field>
          <Field label="Description" htmlFor="l-desc" hint="30 caractères minimum. Décrivez le quartier, l'équipement, l'accès.">
            <textarea id="l-desc" rows={4} className={inputCls} value={d.description} disabled={!editable} onChange={(e) => set("description", e.target.value)} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Ville" htmlFor="l-ville"><input id="l-ville" className={inputCls} value={d.city} disabled={!editable} onChange={(e) => set("city", e.target.value)} /></Field>
            <Field label="Quartier" htmlFor="l-quartier"><input id="l-quartier" className={inputCls} value={d.district} disabled={!editable} onChange={(e) => set("district", e.target.value)} /></Field>
          </div>
          <Field label="Adresse exacte" htmlFor="l-adresse" hint="Jamais affichée publiquement. Elle sert à l'équipe et au voyageur une fois la réservation confirmée.">
            <input id="l-adresse" className={inputCls} value={d.private_address} disabled={!editable} onChange={(e) => set("private_address", e.target.value)} />
          </Field>
          <div className="grid gap-4 sm:grid-cols-4">
            <Field label="Voyageurs" htmlFor="l-cap"><input id="l-cap" type="number" min={1} max={30} className={inputCls} value={d.capacity} disabled={!editable} onChange={(e) => set("capacity", +e.target.value)} /></Field>
            <Field label="Chambres" htmlFor="l-ch"><input id="l-ch" type="number" min={0} className={inputCls} value={d.bedrooms} disabled={!editable} onChange={(e) => set("bedrooms", +e.target.value)} /></Field>
            <Field label="Lits" htmlFor="l-lits"><input id="l-lits" type="number" min={0} className={inputCls} value={d.beds} disabled={!editable} onChange={(e) => set("beds", +e.target.value)} /></Field>
            <Field label="Nuits minimum" htmlFor="l-min"><input id="l-min" type="number" min={1} className={inputCls} value={d.min_nights} disabled={!editable} onChange={(e) => set("min_nights", +e.target.value)} /></Field>
          </div>
          <Field label="Prix par nuit (FCFA)" htmlFor="l-prix" hint={d.nightly_price_xof > 0 ? `Soit ${d.nightly_price_xof.toLocaleString("fr-FR")} FCFA la nuit.` : undefined}>
            <input id="l-prix" type="number" min={1} className={inputCls} value={d.nightly_price_xof} disabled={!editable} onChange={(e) => set("nightly_price_xof", +e.target.value)} />
          </Field>
          {editable && <Button type="submit" disabled={busy}>{busy ? "Enregistrement…" : listing ? "Enregistrer les modifications" : "Créer le brouillon"}</Button>}
        </form>
      </Card>

      {listing && (
        <>
          <Card title="Photos" note="La première photo sert de vignette. L'équipe vérifie que vous avez le droit de les publier.">
            {photos.length > 0 && (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {photos.map((p) => (
                  <figure key={p.id} className="flex flex-col gap-1.5">
                    <PrivatePhoto path={p.storage_path} />
                    <div className="flex items-center justify-between gap-2">
                      <Pill tone={p.rights_checked ? "good" : "neutral"}>{p.rights_checked ? "Vérifiée" : "En attente"}</Pill>
                      {editable && <button onClick={() => removePhoto(p)} disabled={busy} className="text-xs font-semibold text-danger underline cursor-pointer">Retirer</button>}
                    </div>
                  </figure>
                ))}
              </div>
            )}
            {photos.length === 0 && <p className="text-sm text-muted">Aucune photo pour l'instant.</p>}
            {editable && (
              <Field label="Ajouter une photo" htmlFor="l-photo" hint="JPEG, PNG ou WebP, 5 Mo maximum.">
                <input id="l-photo" type="file" accept="image/jpeg,image/png,image/webp" disabled={busy}
                       className="block w-full text-sm text-muted file:mr-3 file:rounded-full file:border-0 file:bg-sunk file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-ink"
                       onChange={(e) => { addPhoto(e.target.files?.[0]); e.target.value = ""; }} />
              </Field>
            )}
          </Card>

          <Card title="Contact affiché aux voyageurs" note="Le numéro n'est révélé qu'aux voyageurs connectés, et chaque consultation est comptée.">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Nom de la personne à contacter" htmlFor="l-cname"><input id="l-cname" className={inputCls} value={contact.contact_name} disabled={!editable} onChange={(e) => setContact({ ...contact, contact_name: e.target.value })} /></Field>
              <Field label="Téléphone" htmlFor="l-tel" hint="Exemple : +226 70 00 00 00"><input id="l-tel" className={inputCls} value={contact.phone} disabled={!editable} onChange={(e) => setContact({ ...contact, phone: e.target.value })} /></Field>
            </div>
            <label className="flex items-center gap-2 text-sm text-ink">
              <input type="checkbox" checked={contact.whatsapp} disabled={!editable} onChange={(e) => setContact({ ...contact, whatsapp: e.target.checked })} />
              Ce numéro est joignable sur WhatsApp
            </label>
            {editable && <Button variant="secondary" onClick={saveContact} disabled={busy}>Enregistrer le contact</Button>}
          </Card>

          {canSubmit && !isOwner && <IdentityBlock id={ownerId} identity={identity} onChange={() => { reloadIdentity(); onSaved(); }} />}

          {canSubmit && (
            <Card title="Publier" note="Votre annonce part en validation. L'équipe YIRI vérifie le contenu, puis vous indique le paiement de l'abonnement.">
              {!identityReady && <Alert tone="warn">Envoyez d'abord votre pièce d'identité, juste au-dessus.</Alert>}
              <Button size="lg" onClick={submit} disabled={busy || !identityReady}>Envoyer en validation</Button>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Liste des annonces
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Tableau de bord YIRI Annonce (migrations 0014 à 0016)
//
// Un abonnement par PROFIL : le propriétaire paie une fois et publie autant de logements
// qu'il veut. Ajouter un deuxième logement ne redemande jamais de payer.
//
// À l'expiration, ses annonces sont masquées du catalogue mais RIEN n'est supprimé, et il
// garde l'accès à cet écran. C'est précisément le moment où il a besoin de comprendre ce
// qui se passe : un écran qui se contenterait de ne plus rien afficher serait le pire.
// ---------------------------------------------------------------------------
function Compteur({ n, label, tone }: { n: number; label: string; tone?: "good" | "warn" | "bad" }) {
  const c = tone === "good" ? "text-good" : tone === "warn" ? "text-warn" : tone === "bad" ? "text-danger" : "text-ink";
  return (
    <div className="rounded-xl bg-sunk px-3 py-2.5 text-center">
      <p className={`font-display text-2xl font-extrabold ${c}`}>{n}</p>
      <p className="mt-0.5 text-xs text-muted">{label}</p>
    </div>
  );
}

function AbonnementBloc({ onAjouter }: { onAjouter: () => void }) {
  const [abo, setAbo] = React.useState<api.Subscription | null | undefined>(undefined);
  const [compteurs, setCompteurs] = React.useState<api.ListingCounts | null>(null);
  const [plan, setPlan] = React.useState<api.Plan>("mensuel");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [notice, setNotice] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const [a, c] = await Promise.all([api.mySubscription(), api.myListingCounts()]);
        if (alive) { setAbo(a); setCompteurs(c); }
      } catch (e) { if (alive) { setError(e instanceof Error ? e.message : "Lecture impossible."); setAbo(null); } }
    })();
    return () => { alive = false; };
  }, [tick]);

  // Souscrire et payer sont deux gestes distincts côté serveur : on crée la demande, puis on
  // la paie. Si le paiement en ligne est indisponible, la demande reste et peut être réglée
  // autrement — rien n'est perdu.
  const souscrire = () => void (async () => {
    setBusy(true); setError(null); setNotice(null);
    try {
      const s = await api.subscribeOwner(plan);
      const dep = await api.startOnlinePayment("abonnement", s.id);
      window.location.assign(dep.page_paiement);
    } catch (e) {
      if (e instanceof api.PaiementIndisponible) {
        setNotice("Votre demande d'abonnement est enregistrée. Le paiement en ligne est momentanément indisponible : réessayez dans un instant, ou contactez l'équipe YIRI.");
      } else {
        setError(e instanceof Error ? e.message : "Souscription impossible.");
      }
      setTick((t) => t + 1);
    } finally { setBusy(false); }
  })();

  if (abo === undefined) return <p className="text-muted">Chargement de votre abonnement…</p>;

  const c = compteurs ?? { soumis: 0, publies: 0, en_attente: 0, refuses: 0, suspendus: 0, expirees: 0 };
  const actif = abo?.actif ?? false;
  const jours = abo?.jours_restants ?? null;
  const bientot = actif && jours !== null && jours <= 7;

  return (
    <div className="rounded-2xl border border-line bg-surface p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-ink">YIRI Annonce</h2>
          <p className="mt-1 text-sm text-muted">
            Un seul abonnement pour tous vos logements. Ajouter un logement ne coûte rien de plus.
          </p>
        </div>
        <Pill tone={actif ? "good" : abo?.status === "en_attente_paiement" ? "warn" : "bad"}>
          {abo?.acces_offert ? "Accès offert par YIRI"
            : actif ? "Abonnement actif"
            : abo?.status === "en_attente_paiement" ? "En attente de paiement"
            : abo ? "Abonnement expiré" : "Aucun abonnement"}
        </Pill>
      </div>

      {error && <div className="mt-3"><Alert tone="bad">{error}</Alert></div>}
      {notice && <div className="mt-3"><Alert tone="warn">{notice}</Alert></div>}

      {actif && (
        <p className="mt-3 text-sm text-ink">
          {abo?.acces_offert && abo?.offert_jusqu_au
            ? <>Accès offert par YIRI jusqu'au <strong>{new Date(abo.offert_jusqu_au).toLocaleDateString("fr-FR")}</strong>.</>
            : <>Valable jusqu'au <strong>{abo?.ends_at ? new Date(abo.ends_at).toLocaleDateString("fr-FR") : "—"}</strong>
                {jours !== null && <> · {jours} jour{jours > 1 ? "s" : ""} restant{jours > 1 ? "s" : ""}</>}</>}
        </p>
      )}

      {bientot && !abo?.acces_offert && (
        <div className="mt-3">
          <Alert tone="warn">
            Votre abonnement se termine dans {jours} jour{jours! > 1 ? "s" : ""}. Passé cette date,
            toutes vos annonces seront masquées du catalogue jusqu'au renouvellement. Vos logements et
            vos photos sont conservés.
          </Alert>
        </div>
      )}

      {/* Le cas qui compte : expiré. On explique, on rassure, on propose l'action. */}
      {abo && !actif && abo.status !== "en_attente_paiement" && (
        <div className="mt-3">
          <Alert tone="bad">
            Votre abonnement a expiré{abo.ends_at ? ` le ${new Date(abo.ends_at).toLocaleDateString("fr-FR")}` : ""}.
            Toutes vos annonces sont temporairement masquées du catalogue. Rien n'est supprimé :
            vos logements, vos photos et vos informations sont conservés. Dès que votre renouvellement
            sera confirmé, les annonces qui étaient en ligne le redeviendront automatiquement —
            à l'exception de celles qui sont en attente de validation, refusées ou suspendues.
          </Alert>
        </div>
      )}

      {abo?.status === "en_attente_paiement" && (
        <div className="mt-3">
          <Alert tone="warn">
            Votre demande d'abonnement est enregistrée et attend le paiement. Vos annonces seront
            publiables dès que le paiement sera confirmé par le serveur.
          </Alert>
        </div>
      )}

      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Compteur n={c.soumis} label="logements" />
        <Compteur n={c.publies} label="en ligne" tone={c.publies > 0 ? "good" : undefined} />
        <Compteur n={c.en_attente} label="en validation" tone={c.en_attente > 0 ? "warn" : undefined} />
        <Compteur n={c.refuses + c.suspendus} label="refusés ou suspendus" tone={c.refuses + c.suspendus > 0 ? "bad" : undefined} />
      </div>
      {c.expirees > 0 && (
        <p className="mt-2 text-sm text-muted">
          {c.expirees} annonce{c.expirees > 1 ? "s" : ""} masquée{c.expirees > 1 ? "s" : ""} faute d'abonnement actif.
        </p>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="secondary" onClick={onAjouter}>Ajouter un logement</Button>
        {!abo?.acces_offert && (
          <>
            <select aria-label="Forfait" className={inputCls + " w-auto"} value={plan}
                    onChange={(e) => setPlan(e.target.value as api.Plan)}>
              <option value="mensuel">Mensuel — 5 000 FCFA</option>
              <option value="annuel">Annuel — 30 000 FCFA</option>
            </select>
            <Button disabled={busy} onClick={souscrire}>
              {busy ? "Patientez…" : actif ? "Renouveler" : "S'abonner et payer"}
            </Button>
          </>
        )}
      </div>

      {actif && !abo?.acces_offert && (
        <p className="mt-2 text-xs text-muted">
          Un renouvellement démarre à la fin de l'abonnement en cours : vous ne perdez aucune journée.
        </p>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Réservations sur mes logements (migration 0011)
//
// Le propriétaire ne voyait RIEN : quelqu'un pouvait réserver et payer chez lui sans qu'il
// l'apprenne par le site. Ce bloc comble ce trou.
//
// Les coordonnées du voyageur n'arrivent qu'une fois le séjour payé. Ce n'est pas l'interface
// qui les cache : la base ne les envoie pas. Un blocage de dates non payé finit souvent expiré,
// et faire circuler le nom et le numéro de quelqu'un qui n'a rien payé n'aurait aucune raison
// d'être — ni vis-à-vis du voyageur, ni vis-à-vis de la déclaration CIL.
// ---------------------------------------------------------------------------
const BK_STATUS: Record<string, [string, "neutral" | "good" | "warn" | "bad" | "info" | "accent"]> = {
  en_attente_confirmation: ["À confirmer", "warn"],
  en_attente_paiement: ["En attente de paiement", "warn"],
  confirmee: ["Confirmée", "good"],
  en_cours: ["Séjour en cours", "info"],
  terminee: ["Terminée", "neutral"],
  refusee: ["Refusée", "bad"],
  annulee: ["Annulée", "bad"],
  expiree: ["Expirée", "neutral"],
  litige: ["Litige", "bad"],
};

function jourCourt(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

function OwnerBookingRow({ b }: { b: api.OwnerBooking }) {
  const [lab, tone] = BK_STATUS[b.status] ?? [b.status, "neutral" as const];
  const proche = api.arriveBientot(b.arrivee) && (b.status === "confirmee" || b.status === "en_cours");
  return (
    <div className={`rounded-2xl border bg-surface p-4 ${proche ? "border-good/50" : "border-line"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{jourCourt(b.arrivee)} → {jourCourt(b.depart)}</p>
          <p className="text-sm text-muted">
            {b.title} · {b.nuits} nuit{b.nuits > 1 ? "s" : ""} · {b.guests} voyageur{b.guests > 1 ? "s" : ""}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {b.sous_gestion && <Pill tone="accent">YIRI s'en occupe</Pill>}
          <Pill tone={tone}>{lab}</Pill>
        </div>
      </div>

      <p className="mt-2 text-sm text-ink"><span className="text-muted">Montant du séjour : </span><Money value={b.total_xof} /></p>

      {b.coordonnees_visibles ? (
        <p className="mt-1 text-sm text-ink">
          <span className="text-muted">Voyageur : </span>{b.guest_name ?? "nom non renseigné"}
          {b.guest_phone ? ` · ${b.guest_phone}` : ""}
        </p>
      ) : (
        <p className="mt-1 text-sm text-muted">
          Les coordonnées du voyageur apparaîtront ici dès que le séjour sera payé.
        </p>
      )}
    </div>
  );
}

function MesReservations() {
  const [data, setData] = React.useState<api.OwnerBooking[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let alive = true;
    api.ownerBookings().then((r) => { if (alive) setData(r); })
      .catch((e) => { if (alive) { setError(e instanceof Error ? e.message : "Lecture impossible."); setData([]); } });
    return () => { alive = false; };
  }, []);

  if (error) return <Alert tone="bad">{error}</Alert>;
  if (data === null) return <p className="text-muted">Chargement de vos réservations…</p>;
  if (data.length === 0) return null;

  const vivantes = ["en_attente_paiement", "confirmee", "en_cours"];
  const aVenir = data.filter((b) => vivantes.includes(b.status));
  const passees = data.filter((b) => !vivantes.includes(b.status));

  return (
    <div className="flex flex-col gap-3">
      <h2 className="font-display text-xl font-bold text-ink">Réservations sur mes logements</h2>
      {aVenir.length === 0
        ? <p className="text-muted">Aucune réservation à venir.</p>
        : aVenir.map((b) => <OwnerBookingRow key={b.id} b={b} />)}
      {passees.length > 0 && (
        <details className="mt-1">
          <summary className="cursor-pointer text-sm font-semibold text-ink">
            Historique ({passees.length})
          </summary>
          <div className="mt-3 flex flex-col gap-3">
            {passees.slice(0, 20).map((b) => <OwnerBookingRow key={b.id} b={b} />)}
          </div>
        </details>
      )}
    </div>
  );
}

export function EspacePro({ onLogin }: { onLogin: () => void }) {
  const s = useSession();
  const [listings, setListings] = React.useState<Listing[] | null>(null);
  const [identity, setIdentity] = React.useState<IdentityState | null>(null);
  const [open, setOpen] = React.useState<Listing | null>(null);
  const [creating, setCreating] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    try {
      const [l, i] = await Promise.all([api.myListings(), api.myIdentity()]);
      setListings(l); setIdentity(i); setError(null);
      setOpen((cur) => (cur ? l.find((x) => x.id === cur.id) ?? null : null));
    } catch (e) { setError(e instanceof Error ? e.message : "Lecture impossible."); setListings([]); }
  }, []);

  const reloadIdentity = React.useCallback(() => { void api.myIdentity().then(setIdentity).catch(() => {}); }, []);

  React.useEffect(() => { if (s.account) void load(); }, [s.account, load]);

  if (!s.ready) return <p className="py-16 text-center text-muted">Chargement…</p>;
  if (!s.account) {
    return (
      <div className="mx-auto max-w-md py-16">
        <h1 className="font-display text-2xl font-bold text-ink">Espace propriétaire</h1>
        <p className="mt-2 text-muted">Connectez-vous pour créer et suivre vos annonces.</p>
        <Button className="mt-5" size="lg" onClick={onLogin}>Se connecter</Button>
      </div>
    );
  }

  if (creating || open) {
    return <ListingForm listing={open} ownerId={s.account.id} identity={identity ?? { state: "aucune", id_type: null, id_number_masked: null, files_sent: 0, decision_note: null, files_deleted: false }}
                        onSaved={() => void load()} onBack={() => { setOpen(null); setCreating(false); void load(); }} reloadIdentity={reloadIdentity} />;
  }

  const verified = s.has("proprietaire");
  const inProgress = (listings ?? []).filter((l) => ["brouillon", "a_corriger", "soumise"].includes(l.status)).length;
  const blocked = !verified && inProgress >= 3;

  return (
    <div className="flex flex-col gap-5 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">Mes annonces</h1>
          <p className="mt-1 text-muted">{verified ? "Votre identité est vérifiée." : "Créez votre annonce. La pièce d'identité n'est demandée qu'au moment de publier."}</p>
        </div>
        <Button onClick={() => { setCreating(true); setOpen(null); }} disabled={blocked}>Créer une annonce</Button>
      </div>

      {error && <Alert tone="bad">{error}</Alert>}
      {blocked && <Alert tone="warn">Vous avez déjà 3 annonces en cours. Terminez-en une avant d'en créer une nouvelle.</Alert>}

      <AbonnementBloc onAjouter={() => { setCreating(true); setOpen(null); }} />
      {identity?.state === "en_attente" && <Alert tone="good">Votre pièce d'identité est en cours de vérification par l'équipe YIRI.</Alert>}
      {identity?.state === "a_renvoyer" && <Alert tone="warn">Votre pièce doit être renvoyée. {identity.decision_note ?? ""}</Alert>}

      {listings === null && <p className="text-muted">Chargement de vos annonces…</p>}
      {listings !== null && listings.length === 0 && (
        <div className="rounded-2xl border border-dashed border-line-strong p-10 text-center">
          <p className="text-muted">Vous n'avez pas encore d'annonce.</p>
        </div>
      )}

      <div className="grid gap-3">
        {(listings ?? []).map((l) => (
          <button key={l.id} onClick={() => setOpen(l)}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-surface p-4 text-left cursor-pointer hover:border-ink">
            <div className="min-w-0">
              <p className="truncate font-semibold text-ink">{l.title}</p>
              <p className="text-sm text-muted">{l.district}, {l.city} · <Money value={l.nightly_price_xof} /> la nuit</p>
            </div>
            <Pill tone={STATUS[l.status][1]}>{STATUS[l.status][0]}</Pill>
          </button>
        ))}
      </div>

      <MesRevenus />
      <AlertesAppareil compact />
      <MesSignalements logements={(listings ?? []).map((l) => ({ id: l.id, title: l.title }))} />
      <MesReservations />
    </div>
  );
}
