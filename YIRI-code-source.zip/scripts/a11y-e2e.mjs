import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const p = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
const errs = []; p.on("pageerror", e => errs.push(e.message));
const routes = ["", "#logements", "#proprietaires", "#solutions", "#demande", "#merci", "#connexion", "#reservations", "#serenite", "#visibilite", "#partenariat", "#route-inconnue"];
let bad = 0;
for (const r of routes) {
  await p.goto("file:///home/claude/yiri/dist/yiri-demo.html" + r); await p.waitForSelector("h1, main, #root *");
  const res = await p.evaluate(() => {
    const out = [];
    const name = (el) => (el.getAttribute("aria-label") || el.getAttribute("title") || el.innerText || "").trim();
    document.querySelectorAll("button, a[href]").forEach(el => { if (!name(el) && !el.querySelector("img[alt]")) out.push("sans nom: " + el.outerHTML.slice(0, 70)); });
    document.querySelectorAll("input:not([type=hidden]), select, textarea").forEach(el => {
      const labelled = el.id && document.querySelector(`label[for="${el.id}"]`) || el.closest("label") || el.getAttribute("aria-label");
      if (!labelled) out.push("champ sans libellé: " + (el.id || el.name || el.type));
    });
    document.querySelectorAll("img").forEach(el => { if (!el.hasAttribute("alt")) out.push("img sans alt"); });
    if (document.documentElement.lang !== "fr") out.push("html lang != fr");
    if (!document.querySelector("h1")) out.push("pas de h1");
    if (document.documentElement.scrollWidth > innerWidth) out.push("scroll horizontal");
    return out;
  });
  console.log(res.length ? "FAIL" : "OK  ", r || "#accueil", res.slice(0, 4).join(" | "));
  bad += res.length;
}
// navigation clavier : Tab met le focus sur un élément interactif visible
await p.goto("file:///home/claude/yiri/dist/yiri-demo.html"); await p.waitForSelector("h1");
await p.keyboard.press("Tab"); await p.keyboard.press("Tab");
console.log((await p.evaluate(() => /BUTTON|A|INPUT|SELECT/.test(document.activeElement?.tagName || ""))) ? "OK   focus clavier" : "FAIL focus clavier");
console.log(errs.length ? "FAIL erreurs JS " + errs : "OK   aucune erreur JS");
await b.close();
