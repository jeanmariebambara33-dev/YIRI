// Compile l'application en une page HTML autonome (aperçu). Utilise esbuild et Tailwind v4 locaux.
import { compile } from "/opt/npm-tools/node_modules/tailwindcss/dist/lib.mjs";
import * as esbuild from "/opt/npm-tools/node_modules/esbuild/lib/main.js";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const TW = "/opt/npm-tools/node_modules/tailwindcss";

const js = await esbuild.build({
  entryPoints: [path.join(root, "src/main.tsx")],
  bundle: true, minify: true, format: "iife", write: false, jsx: "automatic",
  nodePaths: ["/opt/npm-tools/node_modules"],
  define: { "process.env.NODE_ENV": '"production"' },
  target: "es2020",
});
const code = js.outputFiles[0].text.replace(/<\/script/g, "<\\/script");

// Candidats Tailwind : tous les mots présents dans les sources
const files = [];
(function walk(d) { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); f.isDirectory() ? walk(p) : /\.(tsx?|css)$/.test(f.name) && files.push(p); } })(path.join(root, "src"));
const cand = new Set();
for (const f of files) for (const m of fs.readFileSync(f, "utf8").matchAll(/[^\s"'`<>{}]+/g)) cand.add(m[0]);

const css = fs.readFileSync(path.join(root, "src/index.css"), "utf8");
const c = await compile(css, {
  base: root,
  loadStylesheet: async (id) => {
    const rel = id === "tailwindcss" ? "index.css" : id.replace(/^tailwindcss\//, "");
    const p = path.join(TW, rel);
    return { path: p, base: TW, content: fs.readFileSync(p, "utf8") };
  },
});
const out = c.build([...cand]);

// ---------------------------------------------------------------------------
// Empreinte d'intégrité de la bibliothèque Supabase (SRI)
//
// Le fichier est chargé depuis un CDN. Sans empreinte, le navigateur exécute ce que le CDN lui
// donne, quoi qu'il contienne : si ce fichier était un jour remplacé, du code arbitraire
// tournerait dans la page AVEC la session de la personne connectée. La politique de sécurité
// n'arrête rien, puisqu'elle autorise ce domaine.
//
// L'empreinte se calcule depuis le fichier réel, et ne peut donc pas être devinée. Elle est lue
// dans assets/supabase-sri.txt. REGLE : si le fichier est absent ou vide, on construit SANS
// empreinte plutôt que d'en inventer une — une empreinte fausse empêcherait le chargement et
// casserait le site entier. L'avertissement affiché ci-dessous est alors la seule protection.
const SUPABASE_VERSION = "2.117.3";
const SUPABASE_URL_CDN = `https://cdn.jsdelivr.net/npm/@supabase/supabase-js@${SUPABASE_VERSION}/dist/umd/supabase.js`;
const fichierSri = path.join(root, "assets/supabase-sri.txt");
let empreinte = "";
try {
  empreinte = fs.readFileSync(fichierSri, "utf8").trim().split("\n")
    .map((l) => l.trim()).filter((l) => l && !l.startsWith("#"))[0] ?? "";
} catch { empreinte = ""; }
if (empreinte && !/^sha(256|384|512)-[A-Za-z0-9+/]+={0,2}$/.test(empreinte)) {
  throw new Error(`Empreinte d'intégrité mal formée dans assets/supabase-sri.txt : « ${empreinte} ». Attendu : sha384-… en base64. Construction interrompue.`);
}
const INTEGRITE = empreinte ? ` integrity="${empreinte}"` : "";
if (!empreinte) {
  console.warn("ATTENTION : la bibliothèque Supabase est chargée SANS empreinte d'intégrité.");
  console.warn("           Voir assets/supabase-sri.txt pour la commande qui la calcule.");
}

const html = `<!doctype html>
<html lang="fr">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="YIRI — location meublée de courte durée au Burkina Faso. Trouvez un logement à Ouagadougou et Bobo-Dioulasso, ou publiez le vôtre.">
<meta name="theme-color" content="#4a372f">
<meta property="og:title" content="YIRI — location meublée au Burkina Faso">
<meta property="og:description" content="Trouvez un logement meublé à Ouagadougou et Bobo-Dioulasso, ou publiez le vôtre.">
<meta property="og:type" content="website">
<meta property="og:locale" content="fr_FR">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%234a372f'/%3E%3Ctext x='16' y='22' font-family='system-ui,sans-serif' font-size='15' font-weight='800' fill='%23f3e9d8' text-anchor='middle'%3EY%3C/text%3E%3C/svg%3E">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="YIRI">
<title>YIRI — location meublée de courte durée au Burkina Faso</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700;800&display=swap">
<style>${out}</style>
<div id="root"></div>
<!-- Bibliothèque OFFICIELLE Supabase, version figée. Chargée avant l'application : elle expose window.supabase.
     Si elle ne se charge pas (hors ligne, ou empreinte refusée), l'application affiche un message clair
     au lieu d'un écran blanc. -->
<script src="${SUPABASE_URL_CDN}"${INTEGRITE} crossorigin="anonymous"></script>
<script>${code}</script>
`;
// La photo d'ouverture voyage à côté de la page, pas dedans : glissée dans le HTML elle
// pèserait sur CHAQUE visite, alors qu'en fichier séparé le navigateur la garde en cache.
const photos = path.join(root, "dist/photo");
fs.mkdirSync(photos, { recursive: true });
for (const f of fs.readdirSync(path.join(root, "assets/photo"))) {
  if (/\.(avif|webp)$/.test(f)) fs.copyFileSync(path.join(root, "assets/photo", f), path.join(photos, f));
}

fs.writeFileSync(path.join(root, "dist/yiri-demo.html"), html);
console.log("OK", (html.length / 1024).toFixed(0), "Ko");
