// Contrôle de l'animation d'ouverture : elle joue, elle se termine, elle ne gêne rien.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const PAGE = "file:///home/claude/yiri/dist/yiri-demo.html";
let echecs = 0;
const ok = (n, c, d = "") => { console.log(`${c ? "OK  " : "ECHEC"} ${n}${d && !c ? " — " + d : ""}`); if (!c) echecs++; };

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });

async function page(opts = {}) {
  const ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, ...opts });
  const p = await ctx.newPage();
  p.on("pageerror", (e) => { console.log("ERREUR JS :", e.message); echecs++; });
  return p;
}

// ---------- 1. L'animation joue au premier chargement ----------
{
  const p = await page();
  await p.goto(PAGE);
  await p.waitForSelector(".yi-intro", { timeout: 4000 });
  ok("l'introduction apparaît au premier chargement", true);

  // Le voile couvre bien tout l'écran.
  const boite = await p.locator(".yi-intro").boundingBox();
  const vue = p.viewportSize();
  ok("le voile couvre tout l'écran", boite.width >= vue.width && boite.height >= vue.height, JSON.stringify(boite));

  // La photo est bien arrivée.
  const photo = await p.evaluate(() => {
    const i = document.querySelector(".yi-photo");
    if (!i) return null;
    const r = i.getBoundingClientRect();
    // largeur réellement occupée par l'image une fois recadrée en « cover »
    const k = Math.max(r.width / 1536, r.height / 1024);
    return { w: i.naturalWidth, src: i.currentSrc.split("/").pop(), affichee: 1536 * k };
  });
  ok("la photo d'ouverture se charge", photo && photo.w > 400, JSON.stringify(photo));
  // La version choisie doit être au moins aussi large que la place qu'elle occupe, sinon elle
  // est étirée et l'ouverture est floue. C'est arrivé sur téléphone.
  ok("la version choisie est assez définie", photo && photo.w >= photo.affichee - 2,
     `${photo && photo.w} px pour ${photo && Math.round(photo.affichee)} px affichés`);

  // La lueur monte : sa position change entre deux instants.
  const y = async () => p.evaluate(() => {
    const g = document.querySelector(".yi-lueur");
    return g ? g.getBoundingClientRect().top : null;
  });
  await p.waitForTimeout(900);
  const y1 = await y();
  await p.waitForTimeout(1200);
  const y2 = await y();
  ok("la lueur se déplace réellement", y1 !== null && y2 !== null && y2 < y1 - 8, `${y1} -> ${y2}`);

  // La nuit se retire : l'opacité du voile sombre baisse.
  const nuit = await p.evaluate(() => +getComputedStyle(document.querySelector(".yi-nuit")).opacity);
  ok("la nuit s'est retirée", nuit < 0.25, String(nuit));

  // Les lettres apparaissent l'une après l'autre. On n'échantillonne pas à l'aveugle : on attend
  // que la PREMIÈRE lettre soit à moitié là, puis on regarde où en sont les autres. Le test ne
  // dépend donc pas de la vitesse de démarrage de l'appareil.
  const opacites = () => p.evaluate(() =>
    [...document.querySelectorAll(".yi-mot .yi-lettre")].map((e) => +getComputedStyle(e).opacity));
  ok("les quatre lettres sont animées", (await opacites()).length === 4);
  await p.waitForFunction(() => {
    const e = document.querySelector(".yi-mot .yi-lettre");
    return e && +getComputedStyle(e).opacity > 0.5;
  }, null, { timeout: 8000 });
  const etape = await opacites();
  ok("elles n'apparaissent pas toutes en même temps", etape[0] > etape[3], etape.join(" "));

  // LE POINT CRITIQUE : le voile ne doit pas partir avant que le nom soit entièrement écrit.
  // C'est exactement ce qui arrivait quand la fin était pilotée par une minuterie JavaScript,
  // partie au montage, alors que les animations CSS démarrent au premier affichage.
  await p.waitForFunction(() => {
    const v = document.querySelector(".yi-intro");
    return !v || +getComputedStyle(v).opacity < 0.98;
  }, null, { timeout: 9000 });
  const finales = await opacites().catch(() => []);
  ok("le nom est complet avant que le voile ne s'efface",
     finales.length === 4 && finales.every((o) => o > 0.97), finales.join(" "));

  // Le nom de l'introduction doit se trouver EXACTEMENT sur celui de la page. Sinon, pendant le
  // fondu, on voit deux fois le mot YIRI à deux hauteurs différentes. C'est arrivé aussi.
  const boites = await p.evaluate(() => {
    const b = (s) => { const e = document.querySelector(s); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; };
    return { intro: b('.yi-intro [aria-label="YIRI"]'), page: b('main [aria-label="YIRI"]') };
  });
  const colle = boites.intro && boites.page
    && Math.abs(boites.intro.x - boites.page.x) <= 2 && Math.abs(boites.intro.y - boites.page.y) <= 2
    && Math.abs(boites.intro.w - boites.page.w) <= 2 && Math.abs(boites.intro.h - boites.page.h) <= 2;
  ok("le nom de l'animation est posé pile sur celui du site", colle, JSON.stringify(boites));

  // Fin naturelle.
  await p.waitForSelector(".yi-intro", { state: "detached", timeout: 6000 });
  ok("l'introduction se termine seule", true);
  ok("le défilement est rendu", await p.evaluate(() => document.body.style.overflow !== "hidden"));
  ok("la page d'accueil est utilisable", await p.getByRole("button", { name: /Découvrir nos logements/ }).isVisible());
  await p.context().close();
}

// ---------- 2. Le bouton « Passer » ----------
{
  const p = await page();
  await p.goto(PAGE);
  await p.waitForSelector(".yi-intro");
  // On attend que l'animation ait RÉELLEMENT démarré avant de cliquer. Le voile existe dans le
  // document avant que le navigateur n'ait calculé son premier affichage ; cliquer dans cet
  // intervalle mesurerait le temps de démarrage de la page, pas la réactivité du bouton — et
  // aucune personne réelle ne peut cliquer sur un écran qui n'est pas encore dessiné.
  await p.waitForFunction(() => +getComputedStyle(document.querySelector(".yi-nuit")).opacity < 0.95,
                          null, { timeout: 8000 });
  // Chronométré DANS la page : la sonde de Playwright ajoute son propre délai d'observation.
  const duree = await p.evaluate(() => new Promise((res) => {
    const d = performance.now();
    const obs = new MutationObserver(() => {
      if (!document.querySelector(".yi-intro")) { obs.disconnect(); res(Math.round(performance.now() - d)); }
    });
    obs.observe(document.body, { childList: true, subtree: true });
    document.querySelector(".yi-passer").click();
  }));
  ok("« Passer » coupe l'animation tout de suite", duree < 600, `${duree} ms`);
  ok("la page est bien là derrière", await p.getByRole("button", { name: /Découvrir nos logements/ }).isVisible());
  await p.context().close();
}

// ---------- 2 bis. Un clic n'importe où sur le voile ----------
{
  const p = await page();
  await p.goto(PAGE);
  await p.waitForSelector(".yi-intro");
  await p.mouse.click(140, 160);
  await p.waitForSelector(".yi-intro", { state: "detached", timeout: 2000 });
  ok("un clic sur le voile coupe l'animation", true);
  await p.context().close();
}

// ---------- 3. La touche Échap ----------
{
  const p = await page();
  await p.goto(PAGE);
  await p.waitForSelector(".yi-intro");
  await p.keyboard.press("Escape");
  await p.waitForSelector(".yi-intro", { state: "detached", timeout: 2000 });
  ok("Échap coupe l'animation", true);
  await p.context().close();
}

// ---------- 4. Elle ne se rejoue pas ----------
{
  const p = await page();
  await p.goto(PAGE);
  await p.waitForSelector(".yi-intro");
  await p.getByRole("button", { name: "Passer" }).click();
  await p.waitForSelector(".yi-intro", { state: "detached" });

  // navigation interne puis retour à l'accueil
  await p.getByRole("button", { name: /Découvrir nos logements/ }).click();
  await p.waitForTimeout(400);
  await p.getByRole("button", { name: "YIRI, accueil" }).click();
  await p.waitForTimeout(600);
  ok("pas de rejeu en changeant de page", await p.locator(".yi-intro").count() === 0);

  // rechargement dans le même onglet
  await p.goto(PAGE);
  await p.waitForTimeout(700);
  ok("pas de rejeu au rechargement de la visite", await p.locator(".yi-intro").count() === 0);
  await p.context().close();
}

// ---------- 5. Arrivée sur une page profonde ----------
{
  const p = await page();
  await p.goto(PAGE + "#logements");
  await p.waitForTimeout(700);
  ok("pas d'introduction sur un lien profond", await p.locator(".yi-intro").count() === 0);
  await p.context().close();
}

// ---------- 6. Mouvement réduit ----------
{
  const p = await page({ reducedMotion: "reduce" });
  await p.goto(PAGE);
  await p.waitForTimeout(800);
  ok("mouvement réduit : aucune introduction", await p.locator(".yi-intro").count() === 0);
  ok("le site est immédiatement utilisable", await p.getByRole("button", { name: /Découvrir nos logements/ }).isVisible());
  await p.context().close();
}

// ---------- 7. Téléphone ----------
{
  const p = await page({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  await p.goto(PAGE);
  await p.waitForSelector(".yi-intro");
  await p.waitForTimeout(3300);
  // Même contrôle de définition sur téléphone : c'est là que le défaut s'était produit.
  const photoMob = await p.evaluate(() => {
    const i = document.querySelector(".yi-photo");
    if (!i) return null;
    const r = i.getBoundingClientRect();
    const k = Math.max(r.width / 1536, r.height / 1024);
    return { w: i.naturalWidth, src: i.currentSrc.split("/").pop(), affichee: 1536 * k };
  });
  ok("téléphone : la version choisie est assez définie",
     photoMob && photoMob.w >= photoMob.affichee - 2,
     `${photoMob && photoMob.src} : ${photoMob && photoMob.w} px pour ${photoMob && Math.round(photoMob.affichee)} px affichés`);

  ok("téléphone : pas de débordement horizontal",
     !(await p.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1)));
  const mot = await p.locator('.yi-intro [aria-label="YIRI"]').boundingBox();
  ok("téléphone : le nom tient dans l'écran", mot && mot.x >= -1 && mot.x + mot.width <= 391, JSON.stringify(mot));

  // La lueur doit se lever SUR le soleil de la photo, pas à côté.
  //
  // La photo est recadrée pour remplir l'écran (« cover ») : elle est agrandie jusqu'à couvrir,
  // puis centrée. La position du soleil à l'écran dépend donc des proportions de l'écran. On
  // refait ici le calcul de son côté et on vérifie que le centre de la lueur tombe dessus. Une
  // version précédente centrait la lueur par des marges négatives en min(), qui sur des valeurs
  // négatives retient la plus négative : la lueur se levait à deux cents pixels du soleil.
  const vise = await p.evaluate(() => {
    const PH = { l: 1536, h: 1024, sx: 885, sy: 497 };
    const k = Math.max(innerWidth / PH.l, innerHeight / PH.h);
    const attendu = {
      x: (innerWidth - PH.l * k) / 2 + PH.sx * k,
      y: (innerHeight - PH.h * k) / 2 + PH.sy * k,
    };
    const r = document.querySelector(".yi-lueur").getBoundingClientRect();
    return { attendu, centre: { x: r.x + r.width / 2, y: r.y + r.height / 2 } };
  });
  ok("la lueur est centrée sur le soleil de la photo",
     Math.abs(vise.centre.x - vise.attendu.x) <= 2, JSON.stringify(vise));
  ok("téléphone : le bouton Passer est visible", await p.getByRole("button", { name: "Passer" }).isVisible());
  await p.screenshot({ path: "dist/intro-mobile.png" });
  await p.waitForSelector(".yi-intro", { state: "detached", timeout: 6000 });
  ok("téléphone : l'introduction se termine", true);
  await p.context().close();
}

await b.close();
console.log(echecs === 0 ? "\nTous les contrôles passent." : `\n${echecs} contrôle(s) en échec.`);
process.exit(echecs ? 1 : 0);
