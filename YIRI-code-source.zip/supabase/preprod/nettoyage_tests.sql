-- YIRI — suppression des données de test créées pendant la validation.
-- À lancer AVANT d'ouvrir le site au public. Ne touche à aucune donnée réelle :
-- ne sont visés que les comptes en @test.local et les annonces nommées « TEST a supprimer ».
begin;

-- 1. tout ce qui dépend des comptes de test
with cibles as (select id from auth.users where email like '%@test.local')
delete from payment_notices where user_id in (select id from cibles);

with cibles as (select id from auth.users where email like '%@test.local')
delete from payment_transactions
 where booking_id in (select b.id from bookings b where b.guest_id in (select id from cibles))
    or subscription_id in (select s.id from subscriptions s where s.owner_id in (select id from cibles));

with cibles as (select id from auth.users where email like '%@test.local')
delete from bookings where guest_id in (select id from cibles);

with cibles as (select id from auth.users where email like '%@test.local')
delete from subscriptions where owner_id in (select id from cibles);

-- 2. annonces de test et ce qui s'y rattache
create temp table _props_test as
select p.id from properties p
 where p.title = 'TEST a supprimer'
    or p.owner_id in (select id from auth.users where email like '%@test.local');

delete from property_photos   where property_id in (select id from _props_test);
delete from property_contacts where property_id in (select id from _props_test);
delete from property_amenities where property_id in (select id from _props_test);
delete from availability_blocks where property_id in (select id from _props_test);
delete from contact_views     where property_id in (select id from _props_test);
delete from bookings          where property_id in (select id from _props_test);
delete from subscriptions     where property_id in (select id from _props_test);
delete from properties        where id in (select id from _props_test);

-- 3. dossiers d'identité et comptes de test
with cibles as (select id from auth.users where email like '%@test.local')
delete from owner_identity where user_id in (select id from cibles);
with cibles as (select id from auth.users where email like '%@test.local')
delete from owner_profiles where user_id in (select id from cibles);
with cibles as (select id from auth.users where email like '%@test.local')
delete from team_permissions where user_id in (select id from cibles);
with cibles as (select id from auth.users where email like '%@test.local')
delete from user_roles where user_id in (select id from cibles);
with cibles as (select id from auth.users where email like '%@test.local')
delete from profiles where id in (select id from cibles);
delete from auth.users where email like '%@test.local';

-- 4. contrôle : il ne doit plus rien rester
select
  (select count(*) from auth.users where email like '%@test.local') as comptes_test,
  (select count(*) from properties where title = 'TEST a supprimer') as annonces_test,
  (select count(*) from properties) as annonces_restantes,
  (select count(*) from auth.users) as comptes_restants;

commit;
