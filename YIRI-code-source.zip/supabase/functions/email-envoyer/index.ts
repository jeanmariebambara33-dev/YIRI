// YIRI — envoyer les notifications par courriel.
//
// Même forme que push-envoyer : la base décide QUI reçoit QUOI (email_pending relit les
// autorisations à l'envoi), cette fonction se contente de composer et d'expédier.
//
// Deux règles absolues, qui expliquent presque tout le code ci-dessous :
//
//   1. UN COURRIEL N'EST DIT PARTI QUE SI LE SERVICE L'A CONFIRMÉ. Jamais sur une supposition,
//      jamais parce que l'appel n'a pas levé d'erreur. Un identifiant de message doit revenir.
//   2. UN ÉCHEC D'ENVOI NE CASSE RIEN. La réservation est déjà confirmée par le serveur avant
//      que cette fonction n'existe dans l'histoire ; elle le reste si le courriel ne part pas.
//
// Le service est choisi par la variable EMAIL_PROVIDER : « brevo » (par défaut) ou « resend ».
// Changer de service est donc une ligne de secret à modifier, pas une réécriture.
//
// Fichier AUTONOME : rien à importer, pour pouvoir être collé tel quel dans le tableau de bord.
// À déployer SANS vérification de JWT.
//
// Secrets attendus (Edge Functions → Secrets) :
//   BREVO_API_KEY       (ou RESEND_API_KEY si EMAIL_PROVIDER = resend)
//   EMAIL_FROM          l'adresse expéditrice vérifiée, ex. notifications@yiri.bf
//   EMAIL_FROM_NAME     facultatif, « YIRI » par défaut
//   EMAIL_PROVIDER      facultatif, « brevo » par défaut
//   PUSH_TRIGGER_SECRET le même que pour les notifications du téléphone : un seul à retenir
//   SITE_URL            pour les liens dans les courriels
//   SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont fournies automatiquement par Supabase.

export function requis(nom: string): string {
  const v = Deno.env.get(nom);
  if (!v || v.trim() === "") throw new Error(`Variable d'environnement manquante : ${nom}`);
  return v.trim();
}

/** Échappe ce qui irait dans du HTML. Les noms et les titres de logements viennent des
 *  utilisateurs : sans cela, un logement nommé « <script> » casserait le courriel de tout le
 *  monde, ou pire. */
export function ech(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

export function fcfa(n: unknown): string {
  const v = typeof n === "number" ? n : Number(n);
  if (!Number.isFinite(v)) return "";
  return `${Math.round(v).toLocaleString("fr-FR").replace(/ | /g, " ")} FCFA`;
}

export function jour(d: unknown): string {
  const s = String(d ?? "");
  if (!/^\d{4}-\d{2}-\d{2}/.test(s)) return "";
  const [a, m, j] = s.slice(0, 10).split("-");
  const mois = ["janvier", "février", "mars", "avril", "mai", "juin",
                "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  return `${Number(j)} ${mois[Number(m) - 1]} ${a}`;
}

// ---------------------------------------------------------------------------
// Le contenu des courriels
// ---------------------------------------------------------------------------

export interface Courriel { sujet: string; titre: string; corps: string; bouton?: string; lien?: string }

/** Compose le courriel d'un type de notification. Les clés de la charge utile diffèrent d'une
 *  source à l'autre (« logement » pour les réservations, « titre » pour les annonces) : c'est
 *  l'existant, on s'y adapte plutôt que de réécrire des migrations validées. */
export function composer(type: string, p: Record<string, unknown>, site: string): Courriel {
  const logement = (typeof p.logement === "string" && p.logement) ||
                   (typeof p.titre === "string" && p.titre) || null;
  const motif = (typeof p.note === "string" && p.note) ||
                (typeof p.motif === "string" && p.motif) || null;
  const arrivee = jour(p.arrivee);
  const depart = jour(p.depart);
  const sejour = arrivee && depart ? `du ${arrivee} au ${depart}` : "";
  const total = typeof p.total_xof === "number" ? fcfa(p.total_xof) : "";
  const jours = typeof p.jours === "number" ? p.jours : null;
  const nj = (n: number) => `${n} jour${n > 1 ? "s" : ""}`;
  const lien = (h: string) => (site ? `${site.replace(/\/$/, "")}/${h}` : "");

  switch (type) {
    // ---- Voyageur ----
    case "booking.confirmee.voyageur":
      return {
        sujet: logement ? `Votre séjour est confirmé — ${logement}` : "Votre séjour est confirmé",
        titre: "Votre séjour est confirmé",
        corps: `Votre paiement a bien été reçu${total ? ` (${total})` : ""}. Votre réservation${logement ? ` pour <strong>${ech(logement)}</strong>` : ""} ${sejour} est confirmée.<br><br>Vous retrouvez le contact et les détails de votre séjour dans votre espace.`,
        bouton: "Voir mon séjour", lien: lien("#mes-sejours"),
      };
    case "booking.annulee.voyageur":
      return {
        sujet: logement ? `Réservation annulée — ${logement}` : "Réservation annulée",
        titre: "Votre réservation est annulée",
        corps: `Votre réservation${logement ? ` pour <strong>${ech(logement)}</strong>` : ""} ${sejour} a été annulée.<br><br>Si un remboursement vous est dû, l'équipe YIRI l'examine et revient vers vous. Vous pouvez nous écrire à tout moment.`,
        bouton: "Mes séjours", lien: lien("#mes-sejours"),
      };
    case "refund.enregistre":
      return {
        sujet: "Votre remboursement est enregistré",
        titre: "Remboursement enregistré",
        corps: `L'équipe YIRI a enregistré un remboursement de <strong>${fcfa(p.montant)}</strong> sur votre réservation. Vous en suivez l'avancement depuis vos séjours.`,
        bouton: "Mes séjours", lien: lien("#mes-sejours"),
      };

    // ---- Propriétaire ----
    case "booking.confirmee":
      return {
        sujet: logement ? `Réservation payée — ${logement}` : "Une réservation a été payée",
        titre: "Une réservation est confirmée",
        corps: `Un voyageur a réservé et payé${logement ? ` <strong>${ech(logement)}</strong>` : ""} ${sejour}${total ? `, pour ${total}` : ""}.<br><br>Les coordonnées du voyageur sont dans votre espace, maintenant que le séjour est payé.`,
        bouton: "Voir la réservation", lien: lien("#espace"),
      };
    case "booking.annulee":
      return {
        sujet: logement ? `Réservation annulée — ${logement}` : "Une réservation a été annulée",
        titre: "Une réservation a été annulée",
        corps: `La réservation${logement ? ` sur <strong>${ech(logement)}</strong>` : ""} ${sejour} a été annulée. Les dates sont de nouveau libres.`,
        bouton: "Mon espace", lien: lien("#espace"),
      };
    case "listing.approuvee":
      return {
        sujet: logement ? `Votre annonce est validée — ${logement}` : "Votre annonce est validée",
        titre: "Votre annonce est validée",
        corps: `Bonne nouvelle : l'équipe YIRI a <strong>approuvé</strong> votre annonce${logement ? ` <strong>${ech(logement)}</strong>` : ""}.<br><br>Il reste à la publier depuis votre espace pour qu'elle soit visible des voyageurs.`,
        bouton: "Publier mon annonce", lien: lien("#espace"),
      };
    case "listing.publiee":
      return {
        sujet: logement ? `Votre annonce est en ligne — ${logement}` : "Votre annonce est en ligne",
        titre: "Votre annonce est en ligne",
        corps: `Votre annonce${logement ? ` <strong>${ech(logement)}</strong>` : ""} est visible des voyageurs. Vous serez prévenu dès qu'une réservation est payée.`,
        bouton: "Voir mon annonce", lien: lien("#espace"),
      };
    case "listing.a_corriger":
      return {
        sujet: logement ? `À corriger — ${logement}` : "Votre annonce demande une correction",
        titre: "Votre annonce demande une correction",
        corps: `L'équipe YIRI a examiné votre annonce${logement ? ` <strong>${ech(logement)}</strong>` : ""} et vous demande une correction avant publication.${motif ? `<br><br><em>${ech(motif)}</em>` : ""}<br><br>Corrigez puis renvoyez-la : nous la réexaminons.`,
        bouton: "Corriger mon annonce", lien: lien("#espace"),
      };
    case "listing.refusee":
      return {
        sujet: logement ? `Annonce refusée — ${logement}` : "Votre annonce a été refusée",
        titre: "Votre annonce a été refusée",
        corps: `L'équipe YIRI n'a pas retenu votre annonce${logement ? ` <strong>${ech(logement)}</strong>` : ""}.${motif ? `<br><br><em>${ech(motif)}</em>` : ""}<br><br>Si ce refus vous semble une erreur, écrivez-nous.`,
        bouton: "Mon espace", lien: lien("#espace"),
      };
    case "listing.suspendue":
      return {
        sujet: logement ? `Annonce suspendue — ${logement}` : "Votre annonce est suspendue",
        titre: "Votre annonce est suspendue",
        corps: `Votre annonce${logement ? ` <strong>${ech(logement)}</strong>` : ""} a été retirée de la vitrine par l'équipe YIRI.${motif ? `<br><br><em>${ech(motif)}</em>` : ""}`,
        bouton: "Mon espace", lien: lien("#espace"),
      };

    // ---- Abonnement ----
    case "subscription.bientot_expiree":
      return {
        sujet: jours !== null ? `Votre abonnement YIRI expire dans ${nj(jours)}` : "Votre abonnement YIRI expire bientôt",
        titre: "Votre abonnement arrive à échéance",
        corps: `${jours !== null ? `Il reste <strong>${nj(jours)}</strong>.` : "Votre abonnement arrive à échéance."} Sans renouvellement, vos annonces seront automatiquement masquées et ne seront plus visibles des voyageurs.`,
        bouton: "Renouveler", lien: lien("#espace"),
      };
    case "subscription.expire_demain":
      return {
        sujet: "Votre abonnement YIRI expire demain",
        titre: "Votre abonnement expire demain",
        corps: "Demain, sans renouvellement, vos annonces seront masquées. Le renouvellement les remet en ligne immédiatement.",
        bouton: "Renouveler", lien: lien("#espace"),
      };
    case "subscription.expiree":
      return {
        sujet: "Votre abonnement YIRI a expiré",
        titre: "Votre abonnement a expiré",
        corps: "Vos annonces ne sont plus visibles des voyageurs. Un renouvellement les remet en ligne tout de suite, sans nouvelle validation.",
        bouton: "Renouveler", lien: lien("#espace"),
      };
    case "subscription.offerte":
      return {
        sujet: "YIRI vous offre un abonnement",
        titre: "YIRI vous offre un abonnement",
        corps: "L'équipe YIRI vous a offert un abonnement. Vos annonces peuvent être publiées sans paiement pendant toute sa durée.",
        bouton: "Mon espace", lien: lien("#espace"),
      };
    case "free_pass.offert":
      return {
        sujet: "YIRI vous offre un accès gratuit",
        titre: "YIRI vous offre un accès gratuit",
        corps: "Vous pouvez publier vos annonces sans abonnement pendant toute la durée de cet accès.",
        bouton: "Mon espace", lien: lien("#espace"),
      };
    case "free_pass.retire":
      return {
        sujet: "Votre accès gratuit YIRI a pris fin",
        titre: "Votre accès gratuit a pris fin",
        corps: "Un abonnement est désormais nécessaire pour que vos annonces restent visibles.",
        bouton: "Prendre un abonnement", lien: lien("#espace"),
      };

    // ---- Revenus et signalements ----
    case "statement.disponible":
      return {
        sujet: "Votre relevé YIRI est prêt",
        titre: "Votre relevé de revenus est prêt",
        corps: `Le relevé de vos séjours est disponible${typeof p.sejours === "number" ? ` (${p.sejours} séjour${p.sejours > 1 ? "s" : ""})` : ""}.${typeof p.montant === "number" ? ` Montant qui vous revient : <strong>${fcfa(p.montant)}</strong>.` : ""}<br><br>Le détail du calcul est dans votre espace : ce qui a été encaissé, votre part, la commission YIRI et les dépenses retenues.`,
        bouton: "Voir mon relevé", lien: lien("#espace"),
      };
    case "payout.verse":
      return {
        sujet: "Virement effectué",
        titre: "Votre virement est parti",
        corps: `YIRI vous a versé <strong>${fcfa(p.montant)}</strong>. La référence du virement figure sur votre relevé.<br><br>Si vous ne le voyez pas arriver sous 48 heures, écrivez-nous.`,
        bouton: "Voir mon relevé", lien: lien("#espace"),
      };
    case "support.traite":
      return {
        sujet: "Votre signalement a été traité",
        titre: "Votre signalement a été traité",
        corps: "L'équipe YIRI a traité votre signalement. La réponse est dans votre espace.<br><br>Si le problème persiste, répondez-nous : nous rouvrons le dossier.",
        bouton: "Voir la réponse", lien: lien("#espace"),
      };

    // ---- Équipe ----
    case "booking.confirmee.equipe":
      return {
        sujet: logement ? `[YIRI] Réservation payée — ${logement}` : "[YIRI] Une réservation a été payée",
        titre: "Réservation payée",
        // Sans détail, on dit au moins ce qui s'est passé et où regarder : « Un logement. »
        // ne rend service à personne.
        corps: ([logement ? `<strong>${ech(logement)}</strong>` : null, sejour, total]
          .filter((x) => x).join(", ")
          || "Une réservation vient d'être payée. Les détails sont dans l'espace équipe")
          + "." + (p.a_traiter ? " Ce séjour est sous gestion YIRI : il y a quelque chose à préparer." : ""),
        bouton: "Espace équipe", lien: lien("#equipe"),
      };
    case "support.ouvert.equipe":
      return {
        sujet: "[YIRI] Un signalement attend l'équipe",
        titre: "Nouveau signalement",
        corps: `${typeof p.categorie === "string" ? `<strong>${ech(p.categorie)}</strong>` : "Un signalement"}${typeof p.titre === "string" && p.titre ? ` sur ${ech(p.titre)}` : ""}.<br><br>Un problème signalé tard le soir ne doit pas attendre le lendemain.`,
        bouton: "Espace équipe", lien: lien("#equipe"),
      };
    case "refund.a_examiner.equipe":
      return {
        sujet: "[YIRI] Annulation sur un séjour payé — à examiner",
        titre: "Une annulation demande une décision",
        corps: `Un voyageur a annulé un séjour déjà payé (${fcfa(p.encaisse)} encaissés). Le barème prévoyait ${fcfa(p.net_que_le_bareme_prevoyait)}${p.palier ? ` (${ech(p.palier)})` : ""}.<br><br>Aucun remboursement n'a été créé : c'est à l'équipe de décider.`,
        bouton: "Espace équipe", lien: lien("#equipe"),
      };

    default:
      return {
        sujet: "Information YIRI",
        titre: "Information YIRI",
        corps: "Une nouvelle information concerne votre compte YIRI.",
        bouton: "Ouvrir YIRI", lien: lien(""),
      };
  }
}

/** La mise en page. Volontairement simple : des tableaux et des styles en ligne, parce que c'est
 *  ce que les clients de messagerie savent afficher. Une version texte accompagne toujours la
 *  version HTML — sans elle, beaucoup de filtres classent le message en indésirable. */
export function habiller(c: Courriel, nom: string): { html: string; texte: string } {
  const bouton = c.bouton && c.lien
    ? `<tr><td style="padding:24px 0 8px"><a href="${ech(c.lien)}" style="background:#1b1410;color:#fdfaf6;text-decoration:none;padding:13px 26px;border-radius:999px;font-weight:700;display:inline-block">${ech(c.bouton)}</a></td></tr>`
    : "";
  const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4ece4;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#1b1410">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4ece4;padding:24px 12px">
<tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#fdfaf6;border-radius:16px;padding:28px 26px">
<tr><td style="font-weight:800;font-size:20px;letter-spacing:.14em;color:#b4531d">YIRI</td></tr>
<tr><td style="padding-top:18px;font-size:20px;font-weight:700;line-height:1.3">${ech(c.titre)}</td></tr>
<tr><td style="padding-top:14px;font-size:15px;line-height:1.65">Bonjour ${ech((nom || "").split(" ")[0] || "")},</td></tr>
<tr><td style="padding-top:10px;font-size:15px;line-height:1.65">${c.corps}</td></tr>
${bouton}
<tr><td style="padding-top:26px;border-top:1px solid #e4dad0;font-size:12px;line-height:1.6;color:#6b5d53">
Vous recevez ce message parce que vous avez un compte YIRI. Pour ne plus recevoir ces courriels, répondez-nous et nous les désactiverons pour votre compte.
</td></tr>
</table></td></tr></table></body></html>`;

  // On retire les balises, PUIS on redéballe les entités, PUIS on retire encore : sans ce second
  // passage, un titre de logement nommé « <script> » — échappé en &lt;script&gt; dans le HTML —
  // ressortirait en balise dans la version texte, que certains clients affichent en HTML.
  const sansBalises = (s: string) => s.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/<[^>]*>/g, "");
  const prenom = sansBalises(ech((nom || "").split(" ")[0] || ""));
  const texte = `YIRI\n\n${sansBalises(ech(c.titre))}\n\nBonjour ${prenom},\n\n${sansBalises(c.corps)}\n${c.lien ? `\n${c.bouton} : ${c.lien}\n` : ""}
\nVous recevez ce message parce que vous avez un compte YIRI.`;
  return { html, texte };
}

// ---------------------------------------------------------------------------
// Les services d'envoi
// ---------------------------------------------------------------------------

export interface Resultat { ok: boolean; identifiant?: string; erreur?: string; definitif?: boolean }

/** Brevo. Un envoi réussi renvoie un « messageId » : c'est LUI qui fait foi, pas le code HTTP. */
export async function envoyerBrevo(
  cle: string, de: { email: string; nom: string }, vers: { email: string; nom: string },
  sujet: string, html: string, texte: string,
): Promise<Resultat> {
  const r = await fetch("https://api.brevo.com/v3/smtp/email", {
    method: "POST",
    headers: { "api-key": cle, "content-type": "application/json", "accept": "application/json" },
    body: JSON.stringify({
      sender: { email: de.email, name: de.nom },
      to: [{ email: vers.email, name: vers.nom || undefined }],
      subject: sujet, htmlContent: html, textContent: texte,
    }),
  });
  const brut = await r.text();
  if (!r.ok) {
    // 400 : adresse invalide, expéditeur non vérifié — réessayer n'y changera rien.
    return { ok: false, erreur: `Brevo ${r.status} : ${brut.slice(0, 200)}`, definitif: r.status === 400 || r.status === 401 };
  }
  let id: string | undefined;
  try { id = (JSON.parse(brut) as { messageId?: string }).messageId; } catch { id = undefined; }
  if (!id) return { ok: false, erreur: "Brevo n'a pas confirmé l'envoi (aucun messageId)." };
  return { ok: true, identifiant: id };
}

/** Resend, pour le jour où le domaine yiri.bf existera. Même contrat : un identifiant ou rien. */
export async function envoyerResend(
  cle: string, de: { email: string; nom: string }, vers: { email: string; nom: string },
  sujet: string, html: string, texte: string,
): Promise<Resultat> {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Authorization": `Bearer ${cle}`, "content-type": "application/json" },
    body: JSON.stringify({
      from: `${de.nom} <${de.email}>`, to: [vers.email],
      subject: sujet, html, text: texte,
    }),
  });
  const brut = await r.text();
  if (!r.ok) {
    return { ok: false, erreur: `Resend ${r.status} : ${brut.slice(0, 200)}`, definitif: r.status === 400 || r.status === 401 || r.status === 422 };
  }
  let id: string | undefined;
  try { id = (JSON.parse(brut) as { id?: string }).id; } catch { id = undefined; }
  if (!id) return { ok: false, erreur: "Resend n'a pas confirmé l'envoi (aucun identifiant)." };
  return { ok: true, identifiant: id };
}

// ---------------------------------------------------------------------------
// La base
// ---------------------------------------------------------------------------

async function rpc<T>(fn: string, args: Record<string, unknown>, cle: string): Promise<T> {
  const r = await fetch(`${requis("SUPABASE_URL")}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { "apikey": cle, "Authorization": `Bearer ${cle}`, "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  const texte = await r.text();
  if (!r.ok) throw new Error(`${fn} a échoué (${r.status}) : ${texte.slice(0, 300)}`);
  return (texte ? JSON.parse(texte) : null) as T;
}

interface Ligne {
  notification_id: string; user_id: string; destinataire: string; nom: string | null;
  type: string; payload: Record<string, unknown> | null; created_at: string;
}

// ---------------------------------------------------------------------------
// L'envoi
// ---------------------------------------------------------------------------

Deno.serve(async (req) => {
  const attendu = Deno.env.get("PUSH_TRIGGER_SECRET")?.trim();
  if (!attendu) return new Response("non configuré", { status: 503 });
  const fourni = req.headers.get("x-yiri-push")?.trim() ?? "";
  const egal = fourni.length === attendu.length &&
    fourni.split("").reduce((acc, c, i) => acc | (c.charCodeAt(0) ^ attendu.charCodeAt(i)), 0) === 0;
  if (!egal) return new Response("refusé", { status: 401 });

  const cleService = requis("SUPABASE_SERVICE_ROLE_KEY");
  const service = (Deno.env.get("EMAIL_PROVIDER")?.trim() || "brevo").toLowerCase();
  const site = Deno.env.get("SITE_URL")?.trim() || "";

  let cleEnvoi: string;
  let de: { email: string; nom: string };
  try {
    cleEnvoi = requis(service === "resend" ? "RESEND_API_KEY" : "BREVO_API_KEY");
    de = { email: requis("EMAIL_FROM"), nom: Deno.env.get("EMAIL_FROM_NAME")?.trim() || "YIRI" };
  } catch (e) {
    return new Response(`courriels non configurés : ${(e as Error).message}`, { status: 500 });
  }

  const lignes = await rpc<Ligne[]>("email_pending", { p_limit: 30 }, cleService);
  if (!lignes || lignes.length === 0) return Response.json({ envoyes: 0 });

  const partis: string[] = [];
  const rates: { id: string; erreur: string }[] = [];

  for (const l of lignes) {
    try {
      const c = composer(l.type, l.payload ?? {}, site);
      const { html, texte } = habiller(c, l.nom ?? "");
      const vers = { email: l.destinataire, nom: l.nom ?? "" };
      const r = service === "resend"
        ? await envoyerResend(cleEnvoi, de, vers, c.sujet, html, texte)
        : await envoyerBrevo(cleEnvoi, de, vers, c.sujet, html, texte);

      if (r.ok) {
        partis.push(l.notification_id);
      } else {
        rates.push({ id: l.notification_id, erreur: r.erreur ?? "échec" });
        console.error(`courriel non parti (${l.type}) : ${r.erreur}`);
        // Un refus définitif (adresse invalide, expéditeur non vérifié) : on consomme les trois
        // tentatives d'un coup plutôt que d'insister trois fois pour rien.
        if (r.definitif) {
          await rpc("email_mark_failed", { p_notifications: [l.notification_id], p_erreur: r.erreur }, cleService);
          await rpc("email_mark_failed", { p_notifications: [l.notification_id], p_erreur: r.erreur }, cleService);
        }
      }
    } catch (e) {
      rates.push({ id: l.notification_id, erreur: (e as Error).message });
      console.error(`courriel impossible : ${(e as Error).message}`);
    }
  }

  // On ne marque « parti » que ce que le service a confirmé, un par un.
  if (partis.length) await rpc("email_mark_sent", { p_notifications: partis }, cleService);
  for (const r of rates) {
    await rpc("email_mark_failed", { p_notifications: [r.id], p_erreur: r.erreur }, cleService);
  }

  return Response.json({ envoyes: partis.length, echoues: rates.length, examines: lignes.length, service });
});
