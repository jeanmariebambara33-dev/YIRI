-- Tests de la migration 0009 (paiement en ligne, confirmation automatique).
-- Base LOCALE ; auth.uid() simulé ; « reset role » = clé de service (postgres).
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 8) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values (t.u(7), 'paiements', t.u(5));

insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'annonce', 'Studio test', 'desc', 'Ouagadougou', 'Centre', 'adresse',
        2, 1, 1, 20000, 1, 'publiee', false);

-- Réservation du voyageur 1 : 3 nuits, total 60 000.
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof,
                      accommodation_xof, taxes_xof, discount_xof, total_xof, status)
values (t.b(1), t.p(1), t.u(1), daterange(current_date + 20, current_date + 23, '[)'), 2, 20000,
        60000, 0, 0, 60000, 'en_attente_paiement');
-- Réservation du voyageur 2, pour le cloisonnement.
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof,
                      accommodation_xof, taxes_xof, discount_xof, total_xof, status)
values (t.b(2), t.p(1), t.u(2), daterange(current_date + 40, current_date + 42, '[)'), 2, 20000,
        40000, 0, 0, 40000, 'en_attente_paiement');

-- ============ Qui peut déclencher un paiement ============
reset role; select t.as(0);
select t.must_fail('visiteur : impossible de démarrer un paiement', format($$select * from start_online_payment('reservation', %L, 'testpay')$$, t.b(1)));
reset role; select t.as(2);
select t.must_fail('on ne paie pas la réservation d''un autre', format($$select * from start_online_payment('reservation', %L, 'testpay')$$, t.b(1)));
reset role; select t.as(1);
select t.must_fail('objet inconnu refusé', format($$select * from start_online_payment('autre_chose', %L, 'testpay')$$, t.b(1)));

-- ============ Le montant vient du serveur, jamais du navigateur ============
reset role; select t.as(1);
select t.eq('le serveur recalcule 60000', format($$select amount_xof::text from start_online_payment('reservation', %L, 'testpay')$$, t.b(1)), '60000');
reset role;
select t.eq('une seule tentative enregistrée', $$select count(*)::text from payment_attempts$$, '1');
select t.eq('la référence est unique et préfixée YIRI', $$select (reference like 'YIRI%')::text from payment_attempts$$, 'true');
select t.eq('une transaction « en_attente » est créée', $$select status::text from payment_transactions where provider_reference = (select reference from payment_attempts)$$, 'en_attente');
select t.eq('aucun nom de prestataire n''est figé dans le code', $$select provider from payment_attempts$$, 'testpay');
select t.set('ref1', (select reference from payment_attempts limit 1));

-- ============ La confirmation automatique est fermée au navigateur ============
reset role; select t.as(1);
select t.must_fail('voyageur : confirmation automatique refusée', format($$select confirm_payment_online(%L, 60000)$$, t.get('ref1')));
select t.must_fail('voyageur : échec de paiement refusé', format($$select fail_online_payment(%L, 'test')$$, t.get('ref1')));
reset role; select t.as(5);
select t.must_fail('admin : confirmation automatique refusée', format($$select confirm_payment_online(%L, 60000)$$, t.get('ref1')));
reset role; select t.as(7);
select t.must_fail('équipe paiements : confirmation automatique refusée', format($$select confirm_payment_online(%L, 60000)$$, t.get('ref1')));
select t.must_fail('équipe paiements : tentatives illisibles en direct', $$select * from payment_attempts$$);
select t.ok('équipe paiements : suivi accessible par la fonction', $$select * from payment_attempts_recent()$$);

-- ============ Écart de montant : rien n'est encaissé, mais tout est tracé ============
reset role;
select t.eq('montant différent : « ecart » renvoyé', format($$select confirm_payment_online(%L, 55000)$$, t.get('ref1')), 'ecart');
select t.eq('la réservation N''EST PAS confirmée', format($$select status::text from bookings where id = %L$$, t.b(1)), 'en_attente_paiement');
select t.eq('la tentative est marquée « ecart »', $$select outcome from payment_attempts$$, 'ecart');
select t.eq('la transaction passe en échec', format($$select status::text from payment_transactions where provider_reference = %L$$, t.get('ref1')), 'echoue');
select t.eq('l''incident SURVIT dans le journal', $$select count(*)::text from audit_logs where action = 'payment.amount_mismatch'$$, '1');
select t.eq('aucune écriture au registre financier', $$select count(*)::text from financial_ledger$$, '0');
select t.eq('l''équipe voit l''issue « ecart »', $$select outcome from payment_attempts_recent() limit 1$$, 'ecart');

-- ============ Confirmation au bon montant ============
reset role; select t.as(1);
select t.eq('nouvelle tentative : montant toujours recalculé', format($$select amount_xof::text from start_online_payment('reservation', %L, 'testpay')$$, t.b(1)), '60000');
reset role;
select t.set('ref2', (select reference from payment_attempts where outcome is null limit 1));
select t.eq('confirmation au bon montant', format($$select confirm_payment_online(%L, 60000)$$, t.get('ref2')), 'confirme');
select t.eq('la réservation est confirmée', format($$select status::text from bookings where id = %L$$, t.b(1)), 'confirmee');
select t.eq('la tentative est marquée « paye »', format($$select outcome from payment_attempts where reference = %L$$, t.get('ref2')), 'paye');
select t.eq('le registre financier est crédité une fois de 60000',
  $$select count(*) || '/' || coalesce(sum(credit_xof), 0) from financial_ledger$$, '1/60000');

-- ============ Message rejoué : on n'encaisse qu'une fois ============
reset role;
select t.eq('rejeu : « deja_confirme »', format($$select confirm_payment_online(%L, 60000)$$, t.get('ref2')), 'deja_confirme');
select t.eq('le registre n''a toujours qu''une écriture',
  $$select count(*) || '/' || coalesce(sum(credit_xof), 0) from financial_ledger$$, '1/60000');
select t.must_fail('référence inconnue refusée', $$select confirm_payment_online('YIRI-INEXISTANT', 60000)$$);

-- ============ Paiement abandonné ============
reset role; select t.as(2);
select t.ok('le voyageur 2 démarre son paiement', format($$select * from start_online_payment('reservation', %L, 'testpay')$$, t.b(2)));
reset role;
select t.set('ref3', (select reference from payment_attempts where outcome is null limit 1));
select t.ok('abandon enregistré', format($$select fail_online_payment(%L, 'abandonné par le voyageur')$$, t.get('ref3')));
select t.eq('la tentative est marquée « echec »', format($$select outcome from payment_attempts where reference = %L$$, t.get('ref3')), 'echec');
select t.eq('la réservation 2 reste en attente', format($$select status::text from bookings where id = %L$$, t.b(2)), 'en_attente_paiement');
select t.eq('l''abandon est tracé', $$select count(*)::text from audit_logs where action = 'payment.failed'$$, '1');

-- ============ La confirmation manuelle par l'équipe reste le filet de sécurité ============
reset role; select t.as(1);
select t.must_fail('le voyageur ne confirme pas son propre paiement à la main', format($$select * from confirm_payment('reservation', %L, 40000)$$, t.b(2)));
reset role; select t.as(7);
select t.ok('l''équipe paiements confirme à la main', format($$select * from confirm_payment('reservation', %L, 40000)$$, t.b(2)));
select t.eq('la réservation 2 est confirmée', format($$select status::text from bookings where id = %L$$, t.b(2)), 'confirmee');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0009 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
