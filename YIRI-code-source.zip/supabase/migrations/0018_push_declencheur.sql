-- YIRI — 0018 : le déclencheur qui fait partir les notifications.
--
-- La 0017 a tout posé sauf le départ : il fallait créer un « Database Webhook » dans le tableau
-- de bord. Cette page a changé de place et n'est plus trouvable dans ce projet. Plutôt que de
-- dépendre d'une interface qui bouge, le déclencheur est écrit ici : il reste dans le projet,
-- il est relisible, et il ne disparaîtra pas au prochain remaniement du tableau de bord.
--
-- Comment ça marche : à chaque écriture dans « notifications », la base appelle la fonction
-- serveur « push-envoyer », qui vide toute la file en attente. L'appel part par pg_net, APRÈS
-- la validation de la transaction, sans jamais la retenir.
--
-- Le mot de passe de l'appel ne peut pas être écrit en clair ici : ce fichier est lisible par
-- quiconque ouvre le dépôt. Il est rangé dans le coffre (Vault) de Supabase, d'où seule la base
-- peut le lire — ni « anon », ni « authenticated », ni le site.
--
-- RÈGLE ABSOLUE DE CE FICHIER : un envoi qui échoue ne doit JAMAIS faire échouer ce qui l'a
-- provoqué. Une notification part au moment où un paiement est confirmé ; si l'envoi levait une
-- erreur, c'est l'encaissement qui serait perdu. Tout est donc enveloppé dans un rattrapage.

-- =====================================================================
-- 0. Garde : 0017 d'abord
-- =====================================================================
do $$
begin
  if to_regprocedure('public.push_pending(integer)') is null then
    raise exception 'La migration 0017 n''est pas appliquée. Appliquez-la d''abord. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. pg_net : ce qui permet à la base d'appeler une adresse web
-- =====================================================================
-- L'appel est posté dans une file et expédié par un ouvrier de fond, après la validation de la
-- transaction. C'est ce qui garantit qu'un service de notification lent ne ralentit pas une
-- réservation.
create schema if not exists extensions;
do $$
begin
  create extension if not exists pg_net with schema extensions;
exception when others then
  -- Sur une base de test locale, pg_net n'existe pas : le reste de la migration doit quand même
  -- s'appliquer, et le déclencheur restera simplement sans effet.
  raise notice 'pg_net indisponible : le déclencheur sera posé mais n''enverra rien.';
end $$;

-- =====================================================================
-- 2. L'adresse de la fonction d'envoi
-- =====================================================================
-- Une adresse n'est pas un secret : elle va dans les réglages publics, à côté de la clé publique.
-- La poser ici évite une ligne de plus à coller, tout en restant modifiable sans toucher au code.
insert into public_settings (key, value)
values ('push_function_url', 'https://kzzrowymwwxoydklnkfb.supabase.co/functions/v1/push-envoyer')
on conflict (key) do nothing;

-- =====================================================================
-- 3. Le déclencheur
-- =====================================================================
-- Au niveau de l'INSTRUCTION, pas de la ligne : une écriture de dix notifications déclenche UN
-- appel, pas dix. La fonction d'envoi vide la file entière de toute façon.
create or replace function push_declencher()
returns trigger
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare
  phrase text;
  adresse text;
begin
  -- Tout ce bloc est rattrapé : voir la règle absolue en tête de fichier.
  begin
    select decrypted_secret into phrase
      from vault.decrypted_secrets where name = 'push_trigger_secret' limit 1;
    select value into adresse from public_settings where key = 'push_function_url';

    -- Pas encore configuré : on ne fait rien, en silence. Les notifications restent lisibles
    -- dans le site, et le premier envoi réussi rattrapera tout ce qui attend.
    if phrase is null or adresse is null then
      return null;
    end if;

    perform net.http_post(
      url := adresse,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-yiri-push', phrase),
      body := '{}'::jsonb,
      timeout_milliseconds := 5000
    );
  exception when others then
    -- Journalisé, jamais propagé. Un paiement confirmé reste confirmé même si l'alerte ne part pas.
    raise notice 'Envoi des notifications impossible (sans conséquence sur l''opération) : %', sqlerrm;
  end;
  return null;
end $$;
revoke all on function push_declencher() from public, anon, authenticated;

drop trigger if exists notifications_push on notifications;
create trigger notifications_push
  after insert on notifications
  for each statement execute function push_declencher();

/* Le même appel, sans passer par un déclencheur. Séparé pour pouvoir être lancé à la main
   depuis l'éditeur SQL quand on cherche d'où vient un problème. */
create or replace function push_declencher_manuel()
returns text
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare
  phrase text;
  adresse text;
begin
  select decrypted_secret into phrase
    from vault.decrypted_secrets where name = 'push_trigger_secret' limit 1;
  if phrase is null then
    return 'Le mot de passe « push_trigger_secret » n''est pas dans le coffre. Voir la marche à suivre.';
  end if;
  select value into adresse from public_settings where key = 'push_function_url';
  if adresse is null then
    return 'L''adresse de la fonction d''envoi est absente des réglages.';
  end if;
  perform net.http_post(
    url := adresse,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-yiri-push', phrase),
    body := '{}'::jsonb,
    timeout_milliseconds := 5000
  );
  return 'Appel envoyé. Le résultat est dans les journaux de la fonction push-envoyer.';
end $$;
revoke all on function push_declencher_manuel() from public, anon, authenticated;

-- =====================================================================
-- 4. Un filet : rattraper ce qui serait resté en route
-- =====================================================================
-- Si la fonction d'envoi était indisponible au moment d'un déclenchement, les notifications
-- concernées restent en attente et plus rien ne les réveille. Cette fonction les relance ; elle
-- est faite pour être appelée par une tâche planifiée (pg_cron), toutes les cinq minutes.
create or replace function push_relancer()
returns int
language plpgsql security definer set search_path = public, extensions, pg_temp as $$
declare
  combien int;
begin
  select count(*) into combien
    from notifications n
   where n.pushed_at is null and n.push_attempts < 3
     and n.created_at > now() - interval '2 days'
     and n.created_at < now() - interval '2 minutes';   -- laisser sa chance au départ immédiat
  if combien = 0 then
    return 0;
  end if;
  perform push_declencher_manuel();
  return combien;
end $$;
revoke all on function push_relancer() from public, anon, authenticated;
