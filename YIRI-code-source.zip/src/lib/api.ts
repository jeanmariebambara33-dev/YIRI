// Accès aux données RÉELLES de YIRI (Supabase). Une seule règle : ce fichier ne décide rien.
// Il transmet, et c'est la base qui autorise ou refuse (RLS + fonctions serveur, migrations 0001 à 0010).
// Les contrôles faits ici ne servent qu'au confort : ils évitent un aller-retour inutile et affichent
// un message immédiat. Ils ne remplacent jamais la vérification du serveur.

import { getClient, clientError, frMessage, config, type SupabaseClient } from "./supabase";

export interface Listing {
  id: string;
  title: string;
  description: string;
  city: string;
  district: string;
  private_address: string | null;
  capacity: number;
  bedrooms: number;
  beds: number;
  nightly_price_xof: number;
  min_nights: number;
  status: "brouillon" | "soumise" | "a_corriger" | "approuvee" | "publiee" | "refusee" | "suspendue" | "expiree" | "archivee";
  review_note: string | null;
  created_at: string;
}

export interface Photo { id: number; property_id: string; storage_path: string; position: number; rights_checked: boolean }
export interface Contact { contact_name: string; phone: string; whatsapp: boolean }
export interface IdentityState {
  state: "aucune" | "en_attente" | "a_renvoyer" | "verifie" | "refuse";
  id_type: string | null;
  id_number_masked: string | null;
  files_sent: number;
  decision_note: string | null;
  files_deleted: boolean;
}

export const PHOTO_BUCKET = "property-photos";
export const IDENTITY_BUCKET = "owner-identity";
export const MAX_FILE_BYTES = 5 * 1024 * 1024;
export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const EXT: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };

/** Erreur destinée à l'utilisateur : toujours en français, jamais un message technique brut. */
export class ApiError extends Error {}

function sb(): SupabaseClient {
  const c = getClient();
  if (!c) throw new ApiError(clientError());
  return c;
}

function unwrap<T>(res: { data: unknown; error: unknown }, fallback: string): T {
  if (res.error) throw new ApiError(frMessage(res.error, fallback));
  return res.data as T;
}

/** Vérifie qu'un fichier est une image acceptée et pas trop lourde (la base refuse de toute façon). */
export function checkImage(file: File): string | null {
  if (!IMAGE_TYPES.includes(file.type)) return "Formats acceptés : JPEG, PNG ou WebP.";
  if (file.size > MAX_FILE_BYTES) return "Fichier trop lourd : 5 Mo maximum.";
  if (file.size === 0) return "Ce fichier est vide.";
  return null;
}

// ---------------------------------------------------------------------------
// Annonces
// ---------------------------------------------------------------------------
const LISTING_COLS = "id,title,description,city,district,private_address,capacity,bedrooms,beds,nightly_price_xof,min_nights,status,review_note,created_at";

export async function myListings(): Promise<Listing[]> {
  const res = await sb().from("properties").select(LISTING_COLS).order("created_at", { ascending: false });
  return unwrap<Listing[]>(res, "Impossible de lire vos annonces.") ?? [];
}

export interface DraftInput {
  title: string; description: string; city: string; district: string; private_address: string;
  capacity: number; bedrooms: number; beds: number; nightly_price_xof: number; min_nights: number;
}

/** Contrôles de confort avant envoi. La base refuse de toute façon les valeurs hors bornes. */
export function checkDraft(d: DraftInput): string | null {
  if (d.title.trim().length < 5) return "Donnez un titre d'au moins 5 caractères.";
  if (d.description.trim().length < 30) return "Décrivez le logement en 30 caractères au minimum.";
  if (d.city.trim().length < 2) return "Indiquez la ville.";
  if (d.district.trim().length < 2) return "Indiquez le quartier.";
  if (!(d.capacity >= 1 && d.capacity <= 30)) return "La capacité doit être comprise entre 1 et 30 voyageurs.";
  if (d.bedrooms < 0 || d.beds < 0) return "Le nombre de chambres et de lits ne peut pas être négatif.";
  if (!(d.nightly_price_xof > 0)) return "Indiquez un prix par nuit supérieur à 0.";
  if (d.min_nights < 1) return "Le séjour minimum est d'au moins 1 nuit.";
  return null;
}

export async function createDraft(ownerId: string, d: DraftInput): Promise<Listing> {
  const row = {
    owner_id: ownerId, offer: "annonce", status: "brouillon",
    title: d.title.trim(), description: d.description.trim(), city: d.city.trim(), district: d.district.trim(),
    private_address: d.private_address.trim() || null,
    capacity: d.capacity, bedrooms: d.bedrooms, beds: d.beds,
    nightly_price_xof: d.nightly_price_xof, min_nights: d.min_nights,
  };
  const res = await sb().from("properties").insert(row).select(LISTING_COLS).single();
  return unwrap<Listing>(res, "La création de l'annonce a échoué.");
}

export async function updateDraft(id: string, patch: Partial<DraftInput>): Promise<Listing> {
  const res = await sb().from("properties").update(patch).eq("id", id).select(LISTING_COLS).single();
  return unwrap<Listing>(res, "La modification a échoué.");
}

/** Envoie l'annonce en validation. Le serveur refuse si la pièce d'identité manque. */
export async function submitListing(id: string): Promise<void> {
  const res = await sb().from("properties").update({ status: "soumise" }).eq("id", id).select("id");
  const rows = unwrap<{ id: string }[]>(res, "L'envoi en validation a échoué.");
  if (!rows || rows.length === 0) throw new ApiError("L'envoi en validation a été refusé. Rechargez la page.");
}

/** Ce qui manque encore pour que l'équipe puisse publier (abonnement, contact, photo). */
export async function publishProblem(id: string): Promise<string | null> {
  const res = await sb().rpc("listing_publish_problem", { p_property: id });
  return unwrap<string | null>(res, "Vérification impossible.");
}

// ---------------------------------------------------------------------------
// Contact affiché aux voyageurs (offre YIRI Annonce)
// ---------------------------------------------------------------------------
export async function getContact(propertyId: string): Promise<Contact | null> {
  const res = await sb().from("property_contacts").select("contact_name,phone,whatsapp").eq("property_id", propertyId).maybeSingle();
  return unwrap<Contact | null>(res, "Impossible de lire le contact.");
}

export function checkContact(c: Contact): string | null {
  if (c.contact_name.trim().length < 2) return "Indiquez le nom de la personne à contacter.";
  if (!/^[+0-9][0-9 ]{7,19}$/.test(c.phone.trim())) return "Numéro invalide. Exemple : +226 70 00 00 00";
  return null;
}

export async function saveContact(propertyId: string, c: Contact): Promise<void> {
  const row = { property_id: propertyId, contact_name: c.contact_name.trim(), phone: c.phone.trim(), whatsapp: c.whatsapp };
  const res = await sb().from("property_contacts").upsert(row, { onConflict: "property_id" }).select("property_id");
  unwrap(res, "L'enregistrement du contact a échoué.");
}

// ---------------------------------------------------------------------------
// Photos du logement — rangées sous <id propriétaire>/<id annonce>/<fichier>
// ---------------------------------------------------------------------------
export async function listPhotos(propertyId: string): Promise<Photo[]> {
  const res = await sb().from("property_photos").select("id,property_id,storage_path,position,rights_checked")
    .eq("property_id", propertyId).order("position", { ascending: true });
  return unwrap<Photo[]>(res, "Impossible de lire les photos.") ?? [];
}

export async function uploadPhoto(ownerId: string, propertyId: string, file: File, position: number): Promise<void> {
  const bad = checkImage(file);
  if (bad) throw new ApiError(bad);
  const path = `${ownerId}/${propertyId}/${Date.now()}-${position}.${EXT[file.type]}`;
  const up = await sb().storage.from(PHOTO_BUCKET).upload(path, file, { contentType: file.type, upsert: false });
  if (up.error) throw new ApiError(frMessage(up.error, "L'envoi de la photo a échoué."));
  const res = await sb().from("property_photos")
    .insert({ property_id: propertyId, storage_path: path, position, rights_checked: false }).select("id");
  if (res.error) {
    await sb().storage.from(PHOTO_BUCKET).remove([path]);   // on ne laisse pas de fichier orphelin
    throw new ApiError(frMessage(res.error, "L'enregistrement de la photo a échoué."));
  }
}

export async function deletePhoto(photo: Photo): Promise<void> {
  const res = await sb().from("property_photos").delete().eq("id", photo.id).select("id");
  unwrap(res, "La suppression a échoué.");
  await sb().storage.from(PHOTO_BUCKET).remove([photo.storage_path]);
}

/** Lien temporaire pour afficher une photo d'un espace privé (1 heure). */
export async function photoUrl(path: string): Promise<string | null> {
  const res = await sb().storage.from(PHOTO_BUCKET).createSignedUrl(path, 3600);
  if (res.error || !res.data) return null;
  return res.data.signedUrl;
}

// ---------------------------------------------------------------------------
// Pièce d'identité du propriétaire (migration 0007)
// ---------------------------------------------------------------------------
export const ID_TYPES: [string, string][] = [
  ["cnib", "CNIB (carte d'identité)"], ["passeport", "Passeport"], ["permis", "Permis de conduire"], ["autre", "Autre pièce officielle"],
];

export async function myIdentity(): Promise<IdentityState> {
  const res = await sb().rpc("my_owner_identity");
  const rows = unwrap<IdentityState[]>(res, "Impossible de lire votre dossier.");
  const r = Array.isArray(rows) ? rows[0] : (rows as unknown as IdentityState | null);
  return r ?? { state: "aucune", id_type: null, id_number_masked: null, files_sent: 0, decision_note: null, files_deleted: false };
}

/** Envoie le recto ou le verso. Le fichier remplace le précédent (même nom). */
export async function uploadIdentityFile(ownerId: string, side: "recto" | "verso", file: File): Promise<void> {
  const bad = checkImage(file);
  if (bad) throw new ApiError(bad);
  const path = `${ownerId}/${side}.${EXT[file.type]}`;
  const up = await sb().storage.from(IDENTITY_BUCKET).upload(path, file, { contentType: file.type, upsert: true });
  if (up.error) throw new ApiError(frMessage(up.error, "L'envoi du document a échoué."));
}

export function checkIdNumber(n: string): string | null {
  const norm = n.replace(/[\s\-./]+/g, "").toUpperCase();
  if (!/^[A-Z0-9]{5,25}$/.test(norm)) return "Numéro invalide : 5 à 25 lettres ou chiffres.";
  return null;
}

/** Transmet le numéro. Le serveur refuse si le recto ou le verso manque. */
export async function submitIdentity(type: string, number: string): Promise<void> {
  const res = await sb().rpc("submit_owner_identity", { p_type: type, p_number: number.trim() });
  unwrap(res, "L'envoi de la pièce d'identité a échoué.");
}

// ---------------------------------------------------------------------------
// ÉQUIPE YIRI — tout est autorisé par la base (has_perm), jamais par l'interface.
// L'interface ne fait que cacher ce qui serait refusé : elle n'accorde rien.
// ---------------------------------------------------------------------------
export interface QueueEntry { user_id: string; full_name: string; email: string; id_type: string; submitted_at: string; files_sent: number; state: string }
export interface OpenedIdentity { user_id: string; id_type: string; id_number: string; state: string; submitted_at: string; files_sent: number; files_left: number }
export interface PendingFiles { user_id: string; state: string; decided_at: string; files_left: number }
export interface Notice {
  id: string; user_id: string; object: "abonnement" | "reservation";
  subscription_id: string | null; booking_id: string | null;
  declared_amount_xof: number; reference: string | null; message: string | null;
  status: "nouveau" | "traite"; created_at: string;
}

export async function identityQueue(): Promise<QueueEntry[]> {
  const res = await sb().rpc("identity_queue");
  return (unwrap<QueueEntry[]>(res, "Impossible de lire la file d'attente.") ?? []);
}

/** Ouvre un dossier : renvoie le numéro et ouvre 15 minutes de lecture des images. Journalisé côté base. */
export async function openIdentity(userId: string): Promise<OpenedIdentity> {
  const res = await sb().rpc("open_owner_identity", { p_user: userId });
  const rows = unwrap<OpenedIdentity[]>(res, "Ouverture du dossier impossible.");
  const r = Array.isArray(rows) ? rows[0] : (rows as unknown as OpenedIdentity);
  if (!r) throw new ApiError("Dossier introuvable.");
  return r;
}

export async function identityFiles(userId: string): Promise<string[]> {
  const res = await sb().rpc("identity_file_paths", { p_user: userId });
  const rows = unwrap<{ path: string }[]>(res, "Lecture des documents impossible.") ?? [];
  return rows.map((r) => r.path);
}

export async function identityFileUrl(path: string): Promise<string | null> {
  const res = await sb().storage.from(IDENTITY_BUCKET).createSignedUrl(path, 900);
  if (res.error || !res.data) return null;
  return res.data.signedUrl;
}

export async function grantOwner(userId: string): Promise<void> {
  unwrap(await sb().rpc("grant_owner_role", { p_user: userId }), "Attribution du rôle impossible.");
}

export async function rejectIdentity(userId: string, note: string, resend: boolean): Promise<void> {
  unwrap(await sb().rpc("reject_owner_identity", { p_user: userId, p_note: note, p_resend: resend }), "Refus impossible.");
}

export async function identityFilesPending(): Promise<PendingFiles[]> {
  const res = await sb().rpc("identity_files_pending");
  return unwrap<PendingFiles[]>(res, "Lecture impossible.") ?? [];
}

/** Supprime les images d'un dossier décidé, puis enregistre la confirmation. */
export async function purgeIdentityFiles(userId: string): Promise<void> {
  const paths = await identityFiles(userId);
  if (paths.length > 0) {
    const rm = await sb().storage.from(IDENTITY_BUCKET).remove(paths);
    if (rm.error) throw new ApiError(frMessage(rm.error, "Suppression impossible."));
  }
  unwrap(await sb().rpc("confirm_identity_files_deleted", { p_user: userId }), "Confirmation impossible.");
}

// --- Annonces à examiner ---
export interface TeamListing extends Listing { owner_id: string }

export async function listingsForTeam(): Promise<TeamListing[]> {
  const res = await sb().from("properties").select(LISTING_COLS + ",owner_id").order("created_at", { ascending: false });
  return unwrap<TeamListing[]>(res, "Impossible de lire les annonces.") ?? [];
}

export async function setListingStatus(id: string, status: string, note?: string): Promise<void> {
  unwrap(await sb().rpc("set_listing_status", { p_property: id, p_status: status, p_note: note ?? null }), "Changement d'état impossible.");
}

// --- Paiements ---
export async function notices(): Promise<Notice[]> {
  const res = await sb().from("payment_notices")
    .select("id,user_id,object,subscription_id,booking_id,declared_amount_xof,reference,message,status,created_at")
    .order("created_at", { ascending: false });
  return unwrap<Notice[]>(res, "Impossible de lire les avis de paiement.") ?? [];
}

/** Confirmation manuelle : le montant REELLEMENT reçu est saisi par l'équipe et recalculé par le serveur. */
export async function confirmPayment(object: "abonnement" | "reservation", id: string, receivedAmount: number): Promise<void> {
  unwrap(await sb().rpc("confirm_payment", { p_object: object, p_id: id, p_received_amount_xof: receivedAmount }), "Confirmation impossible.");
}

export async function rejectPayment(object: "abonnement" | "reservation", id: string, note: string): Promise<void> {
  unwrap(await sb().rpc("reject_payment", { p_object: object, p_id: id, p_note: note }), "Refus impossible.");
}

export async function markNoticeHandled(id: string): Promise<void> {
  unwrap(await sb().from("payment_notices").update({ status: "traite" }).eq("id", id).select("id"), "Enregistrement impossible.");
}

// ---------------------------------------------------------------------------
// VOYAGEURS — catalogue public et réservation.
// Le catalogue est lisible sans compte. Réserver, voir un contact ou déclarer un
// paiement exigent une connexion : toutes ces fonctions partent de auth.uid().
// ---------------------------------------------------------------------------
export interface PublicListing {
  id: string; offer: string; title: string; description: string; city: string; district: string;
  capacity: number; bedrooms: number; beds: number; nightly_price_xof: number; min_nights: number;
  house_rules: string | null; cancellation_policy: string | null;
}
export interface Booking {
  id: string; property_id: string; stay: string; guests: number;
  nightly_price_xof: number; accommodation_xof: number; total_xof: number;
  status: string; hold_expires_at: string | null; created_at: string;
  guest_phone?: string | null;
}
export interface BookedRange { start_date: string; end_date: string }
export interface RevealedContact { contact_name: string; phone: string; whatsapp: boolean }

export async function publicListings(): Promise<PublicListing[]> {
  const res = await sb().from("public_listings")
    .select("id,offer,title,description,city,district,capacity,bedrooms,beds,nightly_price_xof,min_nights,house_rules,cancellation_policy");
  return unwrap<PublicListing[]>(res, "Impossible de charger les logements.") ?? [];
}

export async function publicPhotos(propertyId: string): Promise<string[]> {
  const res = await sb().from("public_listing_photos").select("storage_path,position").eq("property_id", propertyId).order("position", { ascending: true });
  const rows = unwrap<{ storage_path: string }[]>(res, "Impossible de charger les photos.") ?? [];
  return rows.map((r) => r.storage_path);
}

export async function bookedRanges(propertyId: string): Promise<BookedRange[]> {
  const res = await sb().rpc("public_booked_ranges", { p_property: propertyId });
  return unwrap<BookedRange[]>(res, "Impossible de lire les disponibilités.") ?? [];
}

/** Le prix N'EST PAS envoyé : le serveur le calcule lui-même à partir de l'annonce et des dates.
 *  Le téléphone est obligatoire (migration 0012) : c'est par là que YIRI joint le voyageur pour
 *  la remise des clés. La mise en forme du numéro est faite par le serveur, pas ici. */
export async function createBooking(propertyId: string, start: string, end: string, guests: number, phone: string): Promise<Booking> {
  const res = await sb().rpc("create_booking", { p_property: propertyId, p_start: start, p_end: end, p_guests: guests, p_phone: phone });
  const rows = unwrap<Booking | Booking[]>(res, "La réservation a échoué.");
  const r = Array.isArray(rows) ? rows[0] : rows;
  if (!r) throw new ApiError("La réservation a échoué.");
  return r;
}

export async function myBookings(): Promise<Booking[]> {
  const res = await sb().from("bookings")
    .select("id,property_id,stay,guests,nightly_price_xof,accommodation_xof,total_xof,status,hold_expires_at,created_at,guest_phone")
    .order("created_at", { ascending: false });
  return unwrap<Booking[]>(res, "Impossible de lire vos réservations.") ?? [];
}

export async function revealContact(propertyId: string): Promise<RevealedContact> {
  const res = await sb().rpc("reveal_contact", { p_property: propertyId });
  const r = unwrap<RevealedContact>(res, "Contact indisponible.");
  if (!r) throw new ApiError("Contact indisponible.");
  return r;
}

/** Déclaration « J'ai payé ». Ce n'est jamais une preuve : seule l'équipe confirme, après vérification. */
export async function declarePayment(object: "abonnement" | "reservation", id: string, amount: number, reference?: string, message?: string): Promise<void> {
  unwrap(await sb().rpc("declare_payment", {
    p_object: object, p_id: id, p_amount: amount,
    p_reference: reference?.trim() || null, p_message: message?.trim() || null,
  }), "La déclaration a échoué.");
}

// ---------------------------------------------------------------------------
// PAIEMENT EN LIGNE (migration 0009 + fonction serveur « paiement-demarrer »)
// Le navigateur dit seulement CE QU'IL PAIE. Il n'envoie aucun montant : c'est la base
// qui recalcule le prix, et la fonction serveur qui détient la clé du prestataire.
// Cette clé ne descend jamais ici.
// ---------------------------------------------------------------------------
export interface PaiementDemarre { reference: string; montant_xof: number; page_paiement: string }

/** Erreur distincte des autres : elle signifie « le paiement en ligne n'est pas disponible »,
 *  pas « vous avez mal fait ». L'écran doit alors proposer le paiement hors ligne. */
export class PaiementIndisponible extends ApiError {}

export async function startOnlinePayment(object: "reservation" | "abonnement", id: string): Promise<PaiementDemarre> {
  const c = getClient();
  if (!c) throw new ApiError(clientError());
  const { data } = await c.auth.getSession();
  const jeton = data?.session?.access_token;
  if (!jeton) throw new ApiError("Reconnectez-vous pour payer en ligne.");

  const { url, anonKey } = config();
  let r: Response;
  try {
    r = await fetch(`${url}/functions/v1/paiement-demarrer`, {
      method: "POST",
      headers: { "apikey": anonKey, "Authorization": `Bearer ${jeton}`, "Content-Type": "application/json" },
      body: JSON.stringify({ objet: object, id }),
    });
  } catch {
    throw new PaiementIndisponible("Le paiement en ligne est injoignable. Vérifiez votre connexion, ou payez hors ligne.");
  }

  // 404 : la fonction serveur n'est pas encore déployée. 5xx : le prestataire ne répond pas.
  // Dans les deux cas le paiement hors ligne reste disponible, et c'est ce qu'il faut dire.
  if (r.status === 404 || r.status >= 500) {
    throw new PaiementIndisponible("Le paiement en ligne n'est pas disponible pour le moment. Vous pouvez payer hors ligne et nous le signaler.");
  }
  let corps: { ok?: boolean; erreur?: string; reference?: string; montant_xof?: number; page_paiement?: string };
  try { corps = await r.json(); } catch { throw new PaiementIndisponible("Réponse inattendue du paiement en ligne."); }
  if (!r.ok || !corps.ok) throw new ApiError(corps.erreur || "Le paiement en ligne a échoué.");
  if (!corps.page_paiement || !corps.reference) throw new PaiementIndisponible("Aucune page de paiement reçue.");
  return { reference: corps.reference, montant_xof: corps.montant_xof ?? 0, page_paiement: corps.page_paiement };
}

// ---------------------------------------------------------------------------
// ANNULATION ET REMBOURSEMENT (migration 0010)
// Le montant n'est JAMAIS calculé ici. cancelBooking() appelle la
// fonction serveur : l'écran affiche donc exactement la somme qui sera versée, et il est
// impossible qu'il promette autre chose. Seul le voyageur de la réservation peut annuler.
// ---------------------------------------------------------------------------
export interface RefundRules {
  far_days: number; far_pct: number; mid_days: number; mid_pct: number;
  near_pct: number; started_pct: number;
}
export interface CancelResult {
  booking_status: string; refund_id: string | null; net_xof: number;
  // Depuis la migration 0019, le site ne déclenche plus aucun remboursement : « mode » vaut
  // toujours « sans_remboursement_auto ». Les anciennes valeurs restent déclarées pour qu'une
  // réponse d'un serveur pas encore migré ne fasse pas planter la page.
  mode: "sans_remboursement_auto" | "automatique" | "sans_remboursement"
      | "attente_equipe_compte_inconnu" | "attente_equipe_plafond_journalier";
}
export interface MyRefund {
  id: string; booking_id: string; amount_xof: number; status: string;
  created_at: string; settled_at: string | null; failure_reason: string | null;
}

/** Le barème public, lisible sans compte : les conditions doivent être connues AVANT de réserver. */
export async function refundRules(): Promise<RefundRules | null> {
  const res = await sb().rpc("refund_rules_public", {});
  const rows = unwrap<RefundRules | RefundRules[]>(res, "Conditions d'annulation indisponibles.");
  return (Array.isArray(rows) ? rows[0] : rows) ?? null;
}

// refundQuote() a été retirée : la base ne l'ouvre plus au navigateur (migration 0019), et
// afficher une estimation reviendrait à promettre un versement que le site ne déclenche plus.
// Le barème reste public (refundRules) : les conditions doivent être connues AVANT de réserver.

export async function cancelBooking(bookingId: string, reason?: string): Promise<CancelResult> {
  const res = await sb().rpc("cancel_my_booking", { p_booking_id: bookingId, p_reason: reason?.trim() || null });
  const rows = unwrap<CancelResult | CancelResult[]>(res, "L'annulation a échoué.");
  const r = Array.isArray(rows) ? rows[0] : rows;
  if (!r) throw new ApiError("L'annulation a échoué.");
  return r;
}

export async function myRefunds(): Promise<MyRefund[]> {
  const res = await sb().rpc("my_refunds", {});
  return unwrap<MyRefund[]>(res, "Impossible de lire vos remboursements.") ?? [];
}

/** Texte du barème, construit à partir des chiffres réels de la base. Jamais écrit en dur. */
export function refundRulesText(r: RefundRules): string[] {
  const t = (p: number) => (p === 0 ? "aucun remboursement" : p === 100 ? "remboursement intégral" : `${p} % remboursés`);
  return [
    `Plus de ${r.far_days} jours avant l'arrivée : ${t(r.far_pct)}.`,
    `Entre ${r.mid_days} et ${r.far_days} jours avant l'arrivée : ${t(r.mid_pct)}.`,
    `Moins de ${r.mid_days} jours avant l'arrivée : ${t(r.near_pct)}.`,
    `Après le début du séjour : ${t(r.started_pct)}.`,
    "Les frais du prestataire de paiement restent à votre charge : ils sont retenus sur le remboursement.",
  ];
}

/** Dates d'un séjour « [2026-11-01,2026-11-04) » renvoyé par PostgreSQL. */
export function parseStay(stay: string): { start: string; end: string } {
  const m = /\[?"?(\d{4}-\d{2}-\d{2})"?,"?(\d{4}-\d{2}-\d{2})"?\)?/.exec(stay ?? "");
  return m ? { start: m[1], end: m[2] } : { start: "", end: "" };
}

// ---------------------------------------------------------------------------
// Demandes de contact des propriétaires (formulaire public, sans compte).
// La base impose le consentement et limite le nombre de demandes par heure.
// ---------------------------------------------------------------------------
export type LeadLevel = "autonomie" | "reservations" | "delegation";

export interface Lead {
  pack: "visibilite" | "serenite" | "partenariat" | "indecis";
  property_kind: string; city: string; property_count: number;
  level: LeadLevel;
  name: string; phone: string; message?: string;
}

export async function submitLead(l: Lead): Promise<void> {
  const row = {
    pack: l.pack, property_kind: l.property_kind.trim(), city: l.city.trim(),
    property_count: Math.max(1, Math.min(200, Math.round(l.property_count))),
    level: l.level, name: l.name.trim(), phone: l.phone.trim(),
    message: l.message?.trim() || null, consent: true, status: "nouvelle",
  };
  unwrap(await sb().from("owner_leads").insert(row).select("id"), "L'envoi de la demande a échoué.");
}

export interface TeamLead extends Lead { id: string; status: "nouvelle" | "contactee"; created_at: string }

export async function leadsForTeam(): Promise<TeamLead[]> {
  const res = await sb().from("owner_leads")
    .select("id,pack,property_kind,city,property_count,level,name,phone,message,status,created_at")
    .order("created_at", { ascending: false });
  return unwrap<TeamLead[]>(res, "Impossible de lire les demandes.") ?? [];
}

export async function markLeadContacted(id: string): Promise<void> {
  unwrap(await sb().from("owner_leads").update({ status: "contactee" }).eq("id", id).select("id"), "Enregistrement impossible.");
}

// ---------------------------------------------------------------------------
// ÉQUIPE — réservé aux administrateurs. La base impose les deux règles qui comptent :
// seul un administrateur accorde une autorisation, et personne ne s'en accorde à soi-même.
// L'interface ne fait que présenter ; tout refus vient du serveur.
// ---------------------------------------------------------------------------
export type Perm = "validation" | "reservations" | "partenariat" | "demandes" | "paiements" | "audit";

export const PERMS: [Perm, string, string][] = [
  ["validation", "Validation", "Vérifier les pièces d'identité et les annonces"],
  ["paiements", "Paiements", "Confirmer les paiements reçus"],
  ["reservations", "Réservations", "Suivre les réservations"],
  ["demandes", "Demandes", "Rappeler les propriétaires qui ont écrit"],
  ["partenariat", "Partenariat", "Suivre les candidatures de biens non meublés"],
  ["audit", "Journal", "Consulter l'historique des actions"],
];

export interface Member { id: string; full_name: string; email: string | null; perms: Perm[]; isAdmin: boolean }

/** Liste les personnes qui ont au moins une autorisation, plus les administrateurs. */
export async function teamMembers(): Promise<Member[]> {
  const [permsRes, rolesRes] = await Promise.all([
    sb().from("team_permissions").select("user_id,perm"),
    sb().from("user_roles").select("user_id,role"),
  ]);
  const perms = unwrap<{ user_id: string; perm: Perm }[]>(permsRes, "Impossible de lire les autorisations.") ?? [];
  const roles = unwrap<{ user_id: string; role: string }[]>(rolesRes, "Impossible de lire les rôles.") ?? [];
  const ids = [...new Set([...perms.map((p) => p.user_id), ...roles.filter((r) => r.role === "admin").map((r) => r.user_id)])];
  if (ids.length === 0) return [];
  const profRes = await sb().from("profiles").select("id,full_name,email").in("id", ids);
  const profs = unwrap<{ id: string; full_name: string; email: string | null }[]>(profRes, "Impossible de lire les profils.") ?? [];
  return ids.map((id) => {
    const p = profs.find((x) => x.id === id);
    return {
      id,
      full_name: p?.full_name ?? "(profil introuvable)",
      email: p?.email ?? null,
      perms: perms.filter((x) => x.user_id === id).map((x) => x.perm),
      isAdmin: roles.some((r) => r.user_id === id && r.role === "admin"),
    };
  }).sort((a, b) => Number(b.isAdmin) - Number(a.isAdmin) || a.full_name.localeCompare(b.full_name, "fr"));
}

/** Retrouve une personne par son adresse e-mail exacte, pour lui donner une première autorisation. */
export async function findByEmail(email: string): Promise<Member | null> {
  const res = await sb().from("profiles").select("id,full_name,email").eq("email", email.trim().toLowerCase()).maybeSingle();
  const p = unwrap<{ id: string; full_name: string; email: string | null } | null>(res, "Recherche impossible.");
  if (!p) return null;
  const [permsRes, rolesRes] = await Promise.all([
    sb().from("team_permissions").select("perm").eq("user_id", p.id),
    sb().from("user_roles").select("role").eq("user_id", p.id),
  ]);
  return {
    id: p.id, full_name: p.full_name, email: p.email,
    perms: ((permsRes.data ?? []) as { perm: Perm }[]).map((x) => x.perm),
    isAdmin: ((rolesRes.data ?? []) as { role: string }[]).some((r) => r.role === "admin"),
  };
}

export async function grantPerm(userId: string, perm: Perm, byUserId: string): Promise<void> {
  unwrap(await sb().from("team_permissions").insert({ user_id: userId, perm, granted_by: byUserId }).select("perm"),
    "Octroi impossible.");
}

export async function revokePerm(userId: string, perm: Perm): Promise<void> {
  unwrap(await sb().from("team_permissions").delete().eq("user_id", userId).eq("perm", perm).select("perm"),
    "Retrait impossible.");
}

export interface TeamLogEntry { action: string; entity_id: string; after: unknown; created_at: string; actor_id: string | null }

/** Journal des octrois et retraits, pour rendre compte de qui a donné quoi. */
export async function teamLog(): Promise<TeamLogEntry[]> {
  const res = await sb().from("audit_logs").select("action,entity_id,after,created_at,actor_id")
    .eq("entity_type", "team_permissions").order("created_at", { ascending: false }).limit(20);
  return unwrap<TeamLogEntry[]>(res, "Impossible de lire le journal.") ?? [];
}

// ---------------------------------------------------------------------------
// ÉQUIPE — remboursements (migration 0010).
// La file ne contient que ce que la base accepte de montrer à l'habilitation « paiements ».
// Le déblocage ne sert qu'aux remboursements mis en attente par un garde-fou : le cas normal
// part tout seul, sans que personne n'intervienne.
// ---------------------------------------------------------------------------
export interface TeamRefund {
  id: string; booking_id: string; guest_id: string; amount_xof: number; status: string;
  reason: string | null; created_at: string; settled_at: string | null;
  provider_reference: string | null; payer_known: boolean;
  /** Motif d'échec, écrit par fail_refund() ou par un écart de montant. Ajouté par la 0024 :
   *  l'écran l'affichait déjà, mais la fonction SQL ne le renvoyait pas. */
  failure_reason: string | null;
}

export async function refundsQueue(): Promise<TeamRefund[]> {
  const res = await sb().rpc("refunds_queue", { p_limit: 100 });
  return unwrap<TeamRefund[]>(res, "Impossible de lire les remboursements.") ?? [];
}

export async function approveRefund(id: string): Promise<void> {
  unwrap(await sb().rpc("approve_refund", { p_refund_id: id }), "Déblocage impossible.");
}

/** Modification du barème : la base n'accepte que l'administrateur, et refuse un barème incohérent. */
export async function saveRefundRules(r: RefundRules & { daily_cap_xof: number }): Promise<void> {
  unwrap(await sb().rpc("set_refund_rules", {
    p_far_days: r.far_days, p_far_pct: r.far_pct,
    p_mid_days: r.mid_days, p_mid_pct: r.mid_pct,
    p_near_pct: r.near_pct, p_started_pct: r.started_pct,
    p_daily_cap_xof: r.daily_cap_xof,
  }), "Enregistrement du barème impossible.");
}

// ---------------------------------------------------------------------------
// RÉSERVATIONS — les voir, et être prévenu (migration 0011).
//
// Jusqu'ici une réservation payée n'apparaissait nulle part : ni chez le propriétaire,
// ni chez l'équipe. Ces trois lectures comblent ce trou.
//
// À noter pour « owner_bookings » : le nom et le téléphone du voyageur arrivent VIDES
// tant que le séjour n'est pas payé. Ce n'est pas un bug d'affichage, c'est la base qui
// refuse de les donner, et « coordonnees_visibles » dit pourquoi la case est vide.
// ---------------------------------------------------------------------------
export interface TeamBooking {
  id: string; property_id: string; title: string; city: string; district: string;
  offer: string; sous_gestion: boolean;
  arrivee: string; depart: string; nuits: number; guests: number;
  total_xof: number; status: string; created_at: string; hold_expires_at: string | null;
  guest_id: string; guest_name: string | null; guest_phone: string | null; guest_email: string | null;
  paye: boolean; paye_le: string | null; reference: string | null; moyen: string | null;
}

export interface OwnerBooking {
  id: string; property_id: string; title: string; city: string; district: string;
  offer: string; sous_gestion: boolean;
  arrivee: string; depart: string; nuits: number; guests: number;
  total_xof: number; status: string; created_at: string;
  guest_name: string | null; guest_phone: string | null; coordonnees_visibles: boolean;
  paye: boolean; paye_le: string | null;
}

export async function bookingsQueue(): Promise<TeamBooking[]> {
  const res = await sb().rpc("bookings_queue", { p_limit: 200 });
  return unwrap<TeamBooking[]>(res, "Impossible de lire les réservations.") ?? [];
}

export async function ownerBookings(): Promise<OwnerBooking[]> {
  const res = await sb().rpc("owner_bookings", { p_limit: 200 });
  return unwrap<OwnerBooking[]>(res, "Impossible de lire vos réservations.") ?? [];
}

// --- Notifications ---
export interface AppNotification {
  id: string; type: string; payload: Record<string, unknown>;
  created_at: string; read_at: string | null;
}

export async function myNotifications(): Promise<AppNotification[]> {
  const res = await sb().rpc("my_notifications", { p_limit: 30 });
  return unwrap<AppNotification[]>(res, "Impossible de lire les notifications.") ?? [];
}

export async function markNotificationsRead(): Promise<number> {
  return unwrap<number>(await sb().rpc("mark_notifications_read"), "Enregistrement impossible.") ?? 0;
}

/** Les réservations d'une annonce ne concernent pas que le jour même : « bientôt » = les 7 jours
 *  qui viennent, c'est l'horizon sur lequel on peut encore faire quelque chose (prévenir, nettoyer). */
export function arriveBientot(arrivee: string): boolean {
  const j = Math.round((new Date(arrivee + "T00:00:00").getTime() - new Date(new Date().toDateString()).getTime()) / 86400000);
  return j >= 0 && j <= 7;
}

/** Tentatives de paiement en ligne (migration 0009). Elles existaient en base depuis le début
 *  mais n'étaient affichées nulle part : un paiement en ligne qui échouait ne laissait aucune trace
 *  visible, et l'équipe ne pouvait que constater l'absence de réservation. */
export interface PaymentAttempt {
  reference: string; object: string; target_id: string; amount_xof: number; provider: string;
  created_at: string; settled_at: string | null; outcome: string | null; tx_status: string | null;
}

export async function paymentAttempts(): Promise<PaymentAttempt[]> {
  const res = await sb().rpc("payment_attempts_recent", { p_limit: 50 });
  return unwrap<PaymentAttempt[]>(res, "Impossible de lire les paiements en ligne.") ?? [];
}

// ---------------------------------------------------------------------------
// YIRI ANNONCE — l'abonnement, rattaché au PROFIL (migrations 0014 à 0016).
//
// Un propriétaire paie une fois et publie autant de logements qu'il veut.
// Le montant n'est jamais envoyé d'ici : la base le recalcule à partir du forfait.
// ---------------------------------------------------------------------------
export type Plan = "mensuel" | "annuel";

export const TARIF: Record<Plan, number> = { mensuel: 5000, annuel: 30000 };

export interface Subscription {
  id: string; plan: Plan; amount_xof: number; status: string;
  starts_at: string | null; ends_at: string | null; jours_restants: number | null;
  actif: boolean; acces_offert: boolean; offert_jusqu_au: string | null;
}

export interface ListingCounts {
  soumis: number; publies: number; en_attente: number;
  refuses: number; suspendus: number; expirees: number;
}

/** Crée la demande d'abonnement. Appelée deux fois, elle renvoie la même : la base refuse
 *  les doublons, pour qu'un propriétaire ne puisse pas payer deux fois le même service. */
export async function subscribeOwner(plan: Plan): Promise<Subscription & { id: string }> {
  const res = await sb().rpc("subscribe_owner", { p_plan: plan });
  const rows = unwrap<Subscription | Subscription[]>(res, "Souscription impossible.");
  const r = Array.isArray(rows) ? rows[0] : rows;
  if (!r) throw new ApiError("Souscription impossible.");
  return r;
}

export async function mySubscription(): Promise<Subscription | null> {
  const res = await sb().rpc("my_subscription");
  const rows = unwrap<Subscription[]>(res, "Impossible de lire votre abonnement.");
  return Array.isArray(rows) ? (rows[0] ?? null) : (rows ?? null);
}

export async function myListingCounts(): Promise<ListingCounts> {
  const res = await sb().rpc("my_listing_counts");
  const rows = unwrap<ListingCounts[]>(res, "Impossible de lire vos compteurs.");
  const r = Array.isArray(rows) ? rows[0] : rows;
  return r ?? { soumis: 0, publies: 0, en_attente: 0, refuses: 0, suspendus: 0, expirees: 0 };
}

// --- Côté équipe ---
export interface TeamSubscription {
  id: string; owner_id: string; proprietaire: string; email: string | null;
  plan: Plan; amount_xof: number; status: string;
  starts_at: string | null; ends_at: string | null; jours_restants: number | null;
  peut_publier: boolean; acces_offert: boolean; annonces: number; publiees: number;
}

export async function subscriptionsQueue(): Promise<TeamSubscription[]> {
  const res = await sb().rpc("subscriptions_queue", { p_limit: 200 });
  return unwrap<TeamSubscription[]>(res, "Impossible de lire les abonnements.") ?? [];
}

export interface FreePass {
  id: string; owner_id: string; proprietaire: string; email: string | null;
  starts_on: string; ends_on: string; jours_restants: number;
  reason: string; revoke_at: string | null; annonces: number;
}

export async function freePasses(): Promise<FreePass[]> {
  const res = await sb().rpc("free_passes_queue", { p_limit: 200 });
  return unwrap<FreePass[]>(res, "Impossible de lire les accès offerts.") ?? [];
}

/** Accès offert à un propriétaire : couvre TOUS ses logements, y compris les suivants. */
export async function grantOwnerPass(ownerId: string, days: number, reason: string): Promise<void> {
  unwrap(await sb().rpc("grant_owner_pass", { p_owner: ownerId, p_days: days, p_reason: reason }),
         "Octroi impossible.");
}

export async function revokeOwnerPass(ownerId: string, reason: string): Promise<number> {
  return unwrap<number>(await sb().rpc("revoke_owner_pass", { p_owner: ownerId, p_reason: reason }),
                        "Retrait impossible.") ?? 0;
}

/** Contrat de gestion : c'est lui qui autorise la publication en YIRI Sérénité et Partenariat. */
export async function setManagementAgreement(propertyId: string, signed: boolean, checkDone: boolean): Promise<void> {
  unwrap(await sb().rpc("set_management_agreement", {
    p_property: propertyId, p_signed: signed, p_check_done: checkDone, p_version: "v1",
  }), "Enregistrement du contrat impossible.");
}

// ---------------------------------------------------------------------------
// CANDIDATURES PARTENARIAT
//
// Jusqu'ici ce formulaire écrivait dans le magasin de démonstration, c'est-à-dire dans le
// navigateur du visiteur : la candidature n'arrivait JAMAIS chez YIRI, alors que l'écran
// affichait « YIRI vous contactera ». C'est le seul endroit du site qui mentait.
//
// La table et ses règles existaient depuis la migration 0001 : il n'y avait qu'à les appeler.
// ---------------------------------------------------------------------------
export interface Application {
  contact_name: string; contact_phone: string; city: string; district: string;
  property_kind: string; rooms: number; condition_notes: string; estimated_works?: string;
}

export async function submitApplication(a: Application): Promise<void> {
  const row = {
    contact_name: a.contact_name.trim(), contact_phone: a.contact_phone.trim(),
    city: a.city, district: a.district.trim(), property_kind: a.property_kind.trim(),
    rooms: Math.max(0, Math.round(a.rooms)),
    condition_notes: a.condition_notes.trim(),
    estimated_works: a.estimated_works?.trim() || null,
    // La règle de sécurité n'accepte que « recue » sans motif : un candidat ne peut pas
    // s'auto-accepter en forgeant sa requête.
    status: "recue", decision_reason: null, consent: true,
  };
  unwrap(await sb().from("partnership_applications").insert(row).select("id"),
         "L'envoi de la candidature a échoué.");
}

export interface TeamApplication extends Application {
  id: string; status: string; decision_reason: string | null; created_at: string;
}

export async function applicationsForTeam(): Promise<TeamApplication[]> {
  const res = await sb().from("partnership_applications")
    .select("id,contact_name,contact_phone,city,district,property_kind,rooms,condition_notes,estimated_works,status,decision_reason,created_at")
    .order("created_at", { ascending: false });
  return unwrap<TeamApplication[]>(res, "Impossible de lire les candidatures.") ?? [];
}

/** Seules les colonnes « status » et « decision_reason » sont modifiables : la base l'impose. */
export async function setApplicationStatus(id: string, status: string, reason?: string): Promise<void> {
  unwrap(await sb().from("partnership_applications")
    .update({ status, decision_reason: reason?.trim() || null }).eq("id", id).select("id"),
    "Enregistrement impossible.");
}

/** Traduit le type technique d'une notification en une phrase lisible.
 *  Une seule table de correspondance, ici, plutôt que des « if » dispersés dans les écrans :
 *  un type ajouté en base se traduit en un endroit. */
export function notificationLabel(n: AppNotification): string {
  const p = (n.payload ?? {}) as Record<string, unknown>;
  const titre = typeof p.titre === "string" ? p.titre : null;
  const jours = typeof p.jours === "number" ? p.jours : null;
  const montant = typeof p.montant === "number" ? p.montant : null;
  switch (n.type) {
    case "booking.confirmee": return titre ? `Réservation payée sur ${titre}` : "Une réservation a été payée";
    case "booking.confirmee.equipe": return titre ? `Réservation payée : ${titre}` : "Une réservation a été payée";
    case "booking.annulee": return titre ? `Réservation annulée sur ${titre}` : "Une réservation a été annulée";
    case "booking.annulee.equipe": return titre ? `Réservation annulée : ${titre}` : "Une réservation a été annulée";
    case "subscription.bientot_expiree":
      return jours !== null ? `Votre abonnement expire dans ${jours} jour${jours > 1 ? "s" : ""}` : "Votre abonnement expire bientôt";
    case "subscription.expire_demain": return "Votre abonnement expire demain";
    case "subscription.expiree": return "Votre abonnement a expiré : vos annonces sont masquées";
    case "subscription.expiree.equipe": return "Un abonnement a expiré";
    case "subscription.offerte": return "YIRI vous a offert un abonnement";
    case "free_pass.offert": return "YIRI vous a offert un accès gratuit";
    case "free_pass.bientot_fini":
      return jours !== null ? `Votre accès offert se termine dans ${jours} jour${jours > 1 ? "s" : ""}` : "Votre accès offert se termine bientôt";
    case "free_pass.retire": return "Votre accès offert a été retiré";
    case "statement.disponible":
      return montant !== null ? `Votre relevé est prêt : ${montant.toLocaleString("fr-FR")} FCFA` : "Votre relevé de revenus est prêt";
    case "payout.verse":
      return montant !== null ? `Versement de ${montant.toLocaleString("fr-FR")} FCFA effectué` : "Un versement vous a été effectué";
    case "support.traite": return "Votre signalement a été traité";
    case "support.ouvert.equipe": return "Un signalement attend l'équipe";
    case "refund.automatique":
      return montant !== null ? `Remboursement de ${montant.toLocaleString("fr-FR")} FCFA en cours` : "Votre remboursement est en cours";
    case "refund.attente_equipe_compte_inconnu":
    case "refund.attente_equipe_plafond_journalier":
      return "Votre remboursement est en vérification par l'équipe";
    default:
      if (n.type.startsWith("listing.")) return "Votre annonce a changé de statut";
      return "Nouvelle information sur votre compte";
  }
}

// ---------------------------------------------------------------------------
// JOURNAL DES ACTIONS
//
// L'autorisation d'équipe « audit » existe depuis la migration 0005 et la règle de lecture
// sur audit_logs aussi (policy audit_read : has_perm('audit')). Mais aucun écran ne s'en
// servait : accorder cette autorisation ne donnait rien. Un journal que personne ne peut lire
// ne protège personne.
//
// Lecture seule, par construction : la table interdit toute modification et toute suppression
// (déclencheur audit_no_update), y compris à un administrateur.
// ---------------------------------------------------------------------------
export interface AuditEntry {
  id: number;
  actor_id: string | null;
  actor_name: string | null;
  action: string;
  entity_type: string;
  entity_id: string;
  reason: string | null;
  created_at: string;
}

export async function auditEntries(limit = 100): Promise<AuditEntry[]> {
  const res = await sb().from("audit_logs")
    .select("id,actor_id,action,entity_type,entity_id,reason,created_at")
    .order("created_at", { ascending: false }).limit(limit);
  const lignes = unwrap<Omit<AuditEntry, "actor_name">[]>(res, "Impossible de lire le journal.") ?? [];

  // Les noms viennent d'une seconde requête, jamais d'une jointure : un membre qui n'a QUE
  // l'autorisation « audit » n'a pas le droit de lire les profils, et une jointure ferait
  // alors disparaître les lignes au lieu de masquer le nom. Un échec ici n'est pas une erreur.
  const ids = [...new Set(lignes.map((l) => l.actor_id).filter((x): x is string => !!x))];
  let noms = new Map<string, string>();
  if (ids.length) {
    const r = await sb().from("profiles").select("id,full_name").in("id", ids);
    if (!r.error && Array.isArray(r.data)) {
      noms = new Map((r.data as { id: string; full_name: string | null }[])
        .filter((p) => p.full_name).map((p) => [p.id, p.full_name as string]));
    }
  }
  return lignes.map((l) => ({ ...l, actor_name: l.actor_id ? noms.get(l.actor_id) ?? null : null }));
}

/** Traduit une action du journal en français. Le code technique reste affiché à côté :
 *  c'est lui qui fait foi en cas de litige. */
export function auditActionLabel(action: string): string {
  const table: Record<string, string> = {
    "identity.approve": "Pièce d'identité acceptée",
    "identity.reject": "Pièce d'identité refusée",
    "identity.purge": "Pièces d'identité effacées",
    "listing.submit": "Annonce soumise",
    "listing.approve": "Annonce validée",
    "listing.reject": "Annonce refusée",
    "listing.publish": "Annonce publiée",
    "listing.suspend": "Annonce suspendue",
    "listing.correct": "Annonce renvoyée pour correction",
    "listing.archive": "Annonce archivée",
    "listing.expire": "Annonce expirée",
    "booking.create": "Réservation créée",
    "booking.confirm": "Réservation confirmée",
    "booking.cancel": "Réservation annulée",
    "booking.no_show": "Voyageur absent",
    "payment.init": "Paiement lancé",
    "payment.confirm": "Paiement encaissé",
    "payment.fail": "Paiement échoué",
    "payment.webhook": "Avis reçu du prestataire",
    "refund.init": "Remboursement lancé",
    "refund.done": "Remboursement effectué",
    "refund.manual": "Remboursement à traiter à la main",
    "subscription.create": "Abonnement souscrit",
    "subscription.pay": "Abonnement payé",
    "subscription.grant": "Abonnement offert",
    "subscription.expire": "Abonnement expiré",
    "free_pass.grant": "Accès offert accordé",
    "free_pass.revoke": "Accès offert retiré",
    "team.grant": "Autorisation accordée",
    "team.revoke": "Autorisation retirée",
    "role.grant": "Rôle attribué",
    "role.revoke": "Rôle retiré",
    "agreement.set": "Contrat de gestion enregistré",
    "application.decide": "Candidature tranchée",
  };
  return table[action] ?? action.replace(/[._]/g, " ");
}

// ---------------------------------------------------------------------------
// NOTIFICATIONS POUSSÉES SUR L'APPAREIL (migration 0017)
//
// Jusqu'ici, les notifications n'existaient que dans le site : il fallait l'ouvrir pour les
// voir. Une réservation payée à deux heures du matin n'était donc apprise qu'au réveil.
//
// La clé publique VAPID est lue en base plutôt qu'écrite dans le site : le site est un fichier
// construit, et l'y inscrire obligerait à le reconstruire et le redéployer à chaque rotation de
// clé. Si la clé n'est pas encore posée, tout ce qui suit renvoie « indisponible » et
// l'interface se contente de ne rien proposer.
// ---------------------------------------------------------------------------

/** Réponse unique à « est-ce que cet appareil peut recevoir, et le fait-il déjà ? ». */
export type EtatPush =
  | { etat: "impossible"; pourquoi: string }
  | { etat: "a_installer" }
  | { etat: "refuse" }
  | { etat: "inactif" }
  | { etat: "actif" };

function estIOS(): boolean {
  try {
    const ua = navigator.userAgent;
    return /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  } catch { return false; }
}

function installee(): boolean {
  try {
    if (window.matchMedia?.("(display-mode: standalone)").matches) return true;
    return (navigator as unknown as { standalone?: boolean }).standalone === true;
  } catch { return false; }
}

export async function pushPublicKey(): Promise<string | null> {
  const r = await sb().rpc("push_public_key");
  if (r.error) return null;
  const v = r.data as unknown;
  return typeof v === "string" && v.length > 20 ? v : null;
}

/** Ce que l'appareil courant peut faire. Aucune demande d'autorisation ici : on regarde, on ne
 *  demande rien. La demande ne part que sur un geste explicite de la personne. */
export async function etatPush(): Promise<EtatPush> {
  if (typeof window === "undefined") return { etat: "impossible", pourquoi: "Pas de navigateur." };
  if (!("serviceWorker" in navigator)) {
    return { etat: "impossible", pourquoi: "Ce navigateur ne sait pas recevoir de notifications." };
  }
  if (!("PushManager" in window) || !("Notification" in window)) {
    // C'est le cas d'un iPhone dont le site n'a pas été ajouté à l'écran d'accueil : Safari
    // n'expose le push qu'à une application installée.
    if (estIOS() && !installee()) return { etat: "a_installer" };
    return { etat: "impossible", pourquoi: "Ce navigateur ne sait pas recevoir de notifications." };
  }
  if (estIOS() && !installee()) return { etat: "a_installer" };
  if (!(await pushPublicKey())) {
    return { etat: "impossible", pourquoi: "Les notifications ne sont pas encore configurées côté YIRI." };
  }
  if (Notification.permission === "denied") return { etat: "refuse" };

  try {
    const reg = await navigator.serviceWorker.ready;
    const abo = await reg.pushManager.getSubscription();
    return abo && Notification.permission === "granted" ? { etat: "actif" } : { etat: "inactif" };
  } catch {
    return { etat: "inactif" };
  }
}

function b64urlVersOctets(s: string): Uint8Array {
  const net = s.replace(/-/g, "+").replace(/_/g, "/");
  const rembourre = net + "=".repeat((4 - (net.length % 4)) % 4);
  const brut = atob(rembourre);
  const out = new Uint8Array(brut.length);
  for (let i = 0; i < brut.length; i++) out[i] = brut.charCodeAt(i);
  return out;
}

function octetsVersB64url(buf: ArrayBuffer | null): string {
  if (!buf) return "";
  const o = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < o.length; i++) s += String.fromCharCode(o[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Demande l'autorisation puis enregistre l'appareil. À n'appeler que sur un clic : les
 *  navigateurs refusent — à juste titre — une demande d'autorisation non sollicitée. */
export async function activerPush(): Promise<EtatPush> {
  const cle = await pushPublicKey();
  if (!cle) return { etat: "impossible", pourquoi: "Les notifications ne sont pas encore configurées côté YIRI." };

  const reponse = await Notification.requestPermission();
  if (reponse !== "granted") return { etat: "refuse" };

  const reg = await navigator.serviceWorker.ready;
  // Un abonnement déjà en place peut porter une ANCIENNE clé publique : il faut alors le
  // refaire, sinon les messages partent chiffrés avec une clé que l'appareil ne reconnaît plus.
  const existant = await reg.pushManager.getSubscription();
  if (existant) {
    const memeCle = octetsVersB64url(existant.options?.applicationServerKey ?? null) === cle;
    if (!memeCle) {
      try { await unregisterPush(existant.endpoint); } catch { /* sans conséquence */ }
      await existant.unsubscribe();
    }
  }

  const abo = (await reg.pushManager.getSubscription())
    ?? await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: b64urlVersOctets(cle) as unknown as BufferSource,
    });

  const p256dh = octetsVersB64url(abo.getKey("p256dh"));
  const auth = octetsVersB64url(abo.getKey("auth"));
  if (!p256dh || !auth) return { etat: "impossible", pourquoi: "Le navigateur n'a pas fourni les clés de l'appareil." };

  unwrap(await sb().rpc("register_push", {
    p_endpoint: abo.endpoint, p_p256dh: p256dh, p_auth: auth,
    p_user_agent: navigator.userAgent.slice(0, 300),
  }), "Enregistrement de l'appareil impossible.");

  return { etat: "actif" };
}

/** Ne plus recevoir sur cet appareil. On retire l'enregistrement en base AVANT de se
 *  désabonner : si l'ordre était inverse et que la base refusait, l'appareil serait désabonné
 *  côté navigateur tout en restant dans la file d'envoi. */
export async function desactiverPush(): Promise<EtatPush> {
  try {
    const reg = await navigator.serviceWorker.ready;
    const abo = await reg.pushManager.getSubscription();
    if (abo) {
      await unregisterPush(abo.endpoint);
      await abo.unsubscribe();
    }
  } catch { /* l'essentiel est fait : la base n'enverra plus */ }
  return { etat: "inactif" };
}

export async function unregisterPush(endpoint: string): Promise<void> {
  unwrap(await sb().rpc("unregister_push", { p_endpoint: endpoint }), "Retrait de l'appareil impossible.");
}

export interface PushDevice {
  id: string; user_agent: string | null; created_at: string;
  last_ok_at: string | null; endpoint_court: string;
}

export async function myPushDevices(): Promise<PushDevice[]> {
  const res = await sb().rpc("my_push_devices");
  return unwrap<PushDevice[]>(res, "Impossible de lire vos appareils.") ?? [];
}

/** « Samsung SM-A135F » plutôt qu'une ligne d'identification de navigateur illisible. */
export function nomAppareil(ua: string | null): string {
  if (!ua) return "Appareil inconnu";
  if (/iPhone/.test(ua)) return "iPhone";
  if (/iPad/.test(ua)) return "iPad";
  if (/Android/.test(ua)) {
    const m = ua.match(/Android[^;)]*;\s*([^;)]+)/);
    const modele = m?.[1]?.replace(/\sBuild.*/, "").trim();
    return modele && modele.length < 40 ? `Android — ${modele}` : "Téléphone Android";
  }
  if (/Windows/.test(ua)) return "Ordinateur Windows";
  if (/Macintosh/.test(ua)) return "Mac";
  if (/Linux/.test(ua)) return "Ordinateur Linux";
  return "Appareil inconnu";
}

// ---------------------------------------------------------------------------
// ANNULATIONS À EXAMINER (migration 0019)
//
// Le voyageur ne déclenche plus de remboursement : il annule, et l'équipe décide. Cette liste
// est le travail qui remplace l'automatisme — sans elle, une annulation sur séjour payé ne
// serait vue par personne, ce qui serait pire que l'ancien système.
// ---------------------------------------------------------------------------
export interface CancellationToReview {
  booking_id: string; guest_id: string; guest_name: string | null; guest_phone: string | null;
  titre: string; ville: string; arrivee: string; depart: string;
  encaisse_xof: number; bareme_net_xof: number; palier: string | null; taux_pct: number;
  annulee_le: string; motif: string | null;
}

export async function cancellationsToReview(): Promise<CancellationToReview[]> {
  const res = await sb().rpc("cancellations_to_review", { p_limit: 100 });
  return unwrap<CancellationToReview[]>(res, "Impossible de lire les annulations à examiner.") ?? [];
}

/** Enregistre un remboursement. Le montant est décidé par la personne, pas par le site : c'est
 *  tout l'objet du changement. La base refuse ce qui dépasse l'encaissé et les doublons. */
export async function createRefund(bookingId: string, amountXof: number, reason: string): Promise<string> {
  const res = await sb().rpc("create_refund", {
    p_booking_id: bookingId, p_amount_xof: Math.round(amountXof), p_reason: reason.trim(),
  });
  return unwrap<string>(res, "Enregistrement du remboursement impossible.");
}

// ---------------------------------------------------------------------------
// RELEVÉS DE REVENUS (migration 0022)
//
// Le partage 60/40 était calculé et testé depuis le premier jour, et branché à aucun écran :
// un propriétaire sous gestion ne voyait nulle part ce que son logement lui rapportait.
//
// Le pourcentage n'est PAS 60 partout : il vient du contrat de chaque logement. Le calcul se
// fait donc en base, logement par logement, et aucun montant n'est calculé ici.
// ---------------------------------------------------------------------------
export interface Statement {
  id: string; period_start: string; period_end: string;
  rlp_xof: number; owner_share_xof: number; yiri_commission_xof: number;
  owner_expenses_xof: number; amount_due_xof: number; amount_paid_xof: number;
  status: string; verse_le: string | null; reference: string | null;
}

export async function myStatements(): Promise<Statement[]> {
  const res = await sb().rpc("my_statements");
  return unwrap<Statement[]>(res, "Impossible de lire vos relevés.") ?? [];
}

export interface TeamStatement extends Omit<Statement, "verse_le" | "reference"> {
  owner_id: string; proprietaire: string | null; telephone: string | null;
}

export async function statementsQueue(): Promise<TeamStatement[]> {
  const res = await sb().rpc("statements_queue", { p_limit: 200 });
  return unwrap<TeamStatement[]>(res, "Impossible de lire les relevés.") ?? [];
}

export interface OwnerToSettle {
  owner_id: string; proprietaire: string | null; telephone: string | null;
  logements: number; sejours_non_clotures: number; dernier_depart: string;
}

export async function ownersToSettle(): Promise<OwnerToSettle[]> {
  const res = await sb().rpc("owners_to_settle");
  return unwrap<OwnerToSettle[]>(res, "Impossible de lire les propriétaires à régler.") ?? [];
}

export interface StatementPreview {
  owner_id: string; proprietaire: string | null;
  encaisse_xof: number; remboursements_xof: number; frais_xof: number;
  rlp_xof: number; part_proprietaire_xof: number; commission_yiri_xof: number;
  sejours: number; logements: number; deja_cloture: boolean;
}

export async function statementPreview(ownerId: string, debut: string, fin: string): Promise<StatementPreview | null> {
  const res = await sb().rpc("statement_preview", { p_owner: ownerId, p_debut: debut, p_fin: fin });
  const rows = unwrap<StatementPreview | StatementPreview[]>(res, "Aperçu impossible.");
  return (Array.isArray(rows) ? rows[0] : rows) ?? null;
}

export async function closeStatement(ownerId: string, debut: string, fin: string, depenses: number): Promise<string> {
  return unwrap<string>(await sb().rpc("close_owner_statement", {
    p_owner: ownerId, p_debut: debut, p_fin: fin,
    p_depenses_proprietaire: Math.max(0, Math.round(depenses)), p_couts_yiri: 0,
  }), "Clôture impossible.");
}

export async function registerPayout(statementId: string, montant: number, destination: string, reference: string): Promise<string> {
  return unwrap<string>(await sb().rpc("register_payout", {
    p_statement: statementId, p_montant: Math.round(montant),
    p_destination_masquee: destination.trim(), p_reference: reference.trim(),
  }), "Enregistrement du versement impossible.");
}

// ---------------------------------------------------------------------------
// RÉCLAMATIONS (migration 0023)
//
// La table existait depuis la 0001 et n'avait jamais reçu une ligne : un voyageur dont la
// serrure est cassée n'avait aucun moyen de le signaler autrement qu'en téléphonant.
// ---------------------------------------------------------------------------
export const SUPPORT_CATEGORIES: [string, string][] = [
  ["acces_logement", "Je n'arrive pas à entrer dans le logement"],
  ["proprete", "Le logement n'est pas propre"],
  ["equipement", "Un équipement est cassé ou manquant"],
  ["securite", "Un problème de sécurité"],
  ["paiement", "Un problème de paiement ou de facture"],
  ["annonce_inexacte", "L'annonce ne correspond pas au logement"],
  ["comportement", "Le comportement d'une personne"],
  ["autre", "Autre chose"],
];

export function supportCategoryLabel(c: string): string {
  return SUPPORT_CATEGORIES.find(([id]) => id === c)?.[1] ?? c;
}

export const SUPPORT_STATUS_FR: Record<string, [string, "neutral" | "warn" | "good"]> = {
  ouvert: ["Reçu", "warn"],
  en_cours: ["En cours de traitement", "warn"],
  resolu: ["Résolu", "good"],
  clos: ["Clos", "neutral"],
};

export interface SupportRequest {
  id: string; category: string; message: string; status: string;
  resolution: string | null; titre: string | null;
  created_at: string; closed_at: string | null;
}

export async function mySupportRequests(): Promise<SupportRequest[]> {
  const res = await sb().rpc("my_support_requests");
  return unwrap<SupportRequest[]>(res, "Impossible de lire vos signalements.") ?? [];
}

export async function openSupportRequest(
  category: string, message: string, propertyId?: string, bookingId?: string,
): Promise<string> {
  return unwrap<string>(await sb().rpc("open_support_request", {
    p_category: category, p_message: message.trim(),
    p_property: propertyId ?? null, p_booking: bookingId ?? null,
  }), "Envoi du signalement impossible.");
}

export interface TeamSupportRequest extends SupportRequest {
  user_id: string; demandeur: string | null; telephone: string | null;
  role_demandeur: string; ville: string | null; booking_id: string | null;
}

export async function supportQueue(): Promise<TeamSupportRequest[]> {
  const res = await sb().rpc("support_queue", { p_limit: 200 });
  return unwrap<TeamSupportRequest[]>(res, "Impossible de lire les signalements.") ?? [];
}

export async function setSupportStatus(id: string, status: string, resolution?: string): Promise<void> {
  unwrap(await sb().rpc("set_support_status", {
    p_id: id, p_status: status, p_resolution: resolution?.trim() || null,
  }), "Enregistrement impossible.");
}
