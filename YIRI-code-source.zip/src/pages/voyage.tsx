import * as React from "react";
import { Button, Field, inputCls, Pill, Money } from "../ui";
import { useSession } from "../session";
import * as api from "../lib/api";
import type { PublicListing, Booking, BookedRange, RevealedContact } from "../lib/api";
import { SOCIETE } from "../data/legal";

// Parcours VOYAGEUR relié à la vraie base : catalogue public, fiche, réservation, « J'ai payé ».
// Le catalogue se consulte sans compte. Réserver, voir un contact ou déclarer un paiement exigent
// une connexion, et c'est le serveur qui calcule le prix : le navigateur ne l'envoie jamais.

function Alert({ tone, children }: { tone: "bad" | "good" | "warn"; children: React.ReactNode }) {
  const cls = tone === "bad" ? "border-danger/40 bg-danger/10 text-danger"
    : tone === "good" ? "border-good/40 bg-good/10 text-good" : "border-warn/40 bg-warn/10 text-warn";
  return <p role={tone === "bad" ? "alert" : "status"} className={`rounded-xl border px-3.5 py-2.5 text-sm font-medium ${cls}`}>{children}</p>;
}

function PublicPhoto({ path, className }: { path: string; className?: string }) {
  const [url, setUrl] = React.useState<string | null>(null);
  const [failed, setFailed] = React.useState(false);
  React.useEffect(() => {
    let alive = true;
    api.photoUrl(path).then((u) => { if (alive) { setUrl(u); setFailed(!u); } }).catch(() => { if (alive) setFailed(true); });
    return () => { alive = false; };
  }, [path]);
  if (failed) return <div className={`grid place-items-center rounded-xl bg-sunk text-xs text-muted ${className ?? "aspect-4/3"}`}>Photo indisponible</div>;
  if (!url) return <div className={`animate-pulse rounded-xl bg-sunk ${className ?? "aspect-4/3"}`} />;
  return <img src={url} alt="" className={`w-full rounded-xl object-cover ${className ?? "aspect-4/3"}`} />;
}

function Vignette({ id }: { id: string }) {
  const [path, setPath] = React.useState<string | null>(null);
  React.useEffect(() => {
    let alive = true;
    api.publicPhotos(id).then((ps) => { if (alive) setPath(ps[0] ?? null); }).catch(() => {});
    return () => { alive = false; };
  }, [id]);
  if (!path) return <div className="aspect-4/3 rounded-xl bg-sunk" />;
  return <PublicPhoto path={path} />;
}

const today = () => new Date().toISOString().slice(0, 10);
const addDays = (iso: string, n: number) => { const d = new Date(iso + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const nights = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86400000);

// ---------------------------------------------------------------------------
// Catalogue
// ---------------------------------------------------------------------------
export function CatalogueReel({ onOpen }: { onOpen: (id: string) => void }) {
  const [data, setData] = React.useState<PublicListing[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [q, setQ] = React.useState("");

  React.useEffect(() => {
    let alive = true;
    api.publicListings().then((l) => { if (alive) setData(l); })
      .catch((e) => { if (alive) { setError(e instanceof Error ? e.message : "Chargement impossible."); setData([]); } });
    return () => { alive = false; };
  }, []);

  const shown = (data ?? []).filter((l) =>
    !q.trim() || (l.title + " " + l.city + " " + l.district).toLowerCase().includes(q.trim().toLowerCase()));

  return (
    <div className="flex flex-col gap-5 py-8">
      <div>
        <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">Logements disponibles</h1>
        <p className="mt-1 text-muted">Annonces publiées et vérifiées par l'équipe YIRI.</p>
      </div>
      {error && <Alert tone="bad">{error}</Alert>}
      <Field label="Rechercher" htmlFor="v-q">
        <input id="v-q" className={inputCls} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ville, quartier ou titre" />
      </Field>
      {data === null && <p className="text-muted">Chargement…</p>}
      {data !== null && shown.length === 0 && (
        <div className="rounded-2xl border border-dashed border-line-strong p-10 text-center text-muted">
          {data.length === 0 ? "Aucun logement publié pour le moment." : "Aucun logement ne correspond à cette recherche."}
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((l) => (
          <button key={l.id} onClick={() => onOpen(l.id)} className="flex flex-col gap-2 rounded-2xl border border-line bg-surface p-3 text-left cursor-pointer hover:border-ink">
            <Vignette id={l.id} />
            <p className="truncate font-semibold text-ink">{l.title}</p>
            <p className="text-sm text-muted">{l.district}, {l.city} · {l.capacity} voyageur(s)</p>
            <p className="font-semibold text-ink"><Money value={l.nightly_price_xof} /> <span className="text-sm font-normal text-muted">la nuit</span></p>
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Fiche d'un logement + réservation
// ---------------------------------------------------------------------------
export function FicheReelle({ id, onBack, onLogin, onBookings }: {
  id: string; onBack: () => void; onLogin: () => void; onBookings: () => void;
}) {
  const s = useSession();
  const [l, setL] = React.useState<PublicListing | null>(null);
  const [photos, setPhotos] = React.useState<string[]>([]);
  const [ranges, setRanges] = React.useState<BookedRange[]>([]);
  const [start, setStart] = React.useState(addDays(today(), 7));
  const [end, setEnd] = React.useState(addDays(today(), 9));
  const [guests, setGuests] = React.useState(2);
  const [tel, setTel] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [booking, setBooking] = React.useState<Booking | null>(null);
  const [contact, setContact] = React.useState<RevealedContact | null>(null);
  const [notFound, setNotFound] = React.useState(false);

  React.useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const all = await api.publicListings();
        const found = all.find((x) => x.id === id) ?? null;
        if (!alive) return;
        setL(found); setNotFound(!found);
        if (found) { setPhotos(await api.publicPhotos(id)); setRanges(await api.bookedRanges(id)); }
      } catch (e) { if (alive) setError(e instanceof Error ? e.message : "Chargement impossible."); }
    })();
    return () => { alive = false; };
  }, [id]);

  if (notFound) return (
    <div className="py-16">
      <h1 className="font-display text-2xl font-bold text-ink">Logement introuvable</h1>
      <p className="mt-2 text-muted">Cette annonce n'est plus en ligne.</p>
      <Button className="mt-5" variant="secondary" onClick={onBack}>Revenir aux logements</Button>
    </div>
  );
  if (!l) return <p className="py-16 text-center text-muted">Chargement…</p>;

  const n = nights(start, end);
  const estimate = n > 0 ? n * l.nightly_price_xof : 0;
  // Seule l'offre « gestion » se réserve en ligne : create_booking refuse les deux autres.
  // Avant, un logement « partenariat » montrait un bouton « Réserver » qui échouait au clic.
  const bookable = l.offer === "gestion";
  // Un numéro plausible : au moins huit chiffres, un « + » éventuel en tête. Le serveur
  // revérifie et met en forme ; ce contrôle n'existe que pour éviter un aller-retour inutile.
  const telOk = /^\+?[0-9]{8,15}$/.test(tel.replace(/[\s().-]/g, ""));

  const book = () => void (async () => {
    setBusy(true); setError(null);
    try {
      const b = await api.createBooking(id, start, end, guests, tel);
      setBooking(b);
      setRanges(await api.bookedRanges(id));
    } catch (e) { setError(e instanceof Error ? e.message : "Réservation impossible."); }
    finally { setBusy(false); }
  })();

  const reveal = () => void (async () => {
    setBusy(true); setError(null);
    try { setContact(await api.revealContact(id)); }
    catch (e) { setError(e instanceof Error ? e.message : "Contact indisponible."); }
    finally { setBusy(false); }
  })();

  return (
    <div className="flex flex-col gap-5 py-8">
      <button onClick={onBack} className="self-start text-sm font-semibold text-muted underline underline-offset-4 cursor-pointer hover:text-ink">Revenir aux logements</button>
      <div>
        <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">{l.title}</h1>
        <p className="mt-1 text-muted">{l.district}, {l.city} · {l.capacity} voyageur(s) · {l.bedrooms} chambre(s) · {l.beds} lit(s)</p>
      </div>

      {photos.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-3">
          {photos.slice(0, 6).map((p) => <PublicPhoto key={p} path={p} />)}
        </div>
      )}

      <p className="whitespace-pre-wrap text-ink">{l.description}</p>
      {l.house_rules && <p className="text-sm text-muted"><span className="font-semibold text-ink">Règles : </span>{l.house_rules}</p>}
      {l.cancellation_policy && <p className="text-sm text-muted"><span className="font-semibold text-ink">Annulation : </span>{l.cancellation_policy}</p>}
      <ConditionsAnnulation />

      {error && <Alert tone="bad">{error}</Alert>}

      {ranges.length > 0 && (
        <div className="rounded-2xl border border-line bg-surface p-4">
          <h2 className="font-display font-bold text-ink">Dates déjà prises</h2>
          <ul className="mt-2 flex flex-wrap gap-2 text-sm text-muted">
            {ranges.map((r, i) => <li key={i} className="rounded-full bg-sunk px-2.5 py-1">du {r.start_date} au {r.end_date}</li>)}
          </ul>
        </div>
      )}

      {!bookable ? (
        <div className="rounded-2xl border border-line bg-surface p-5">
          <h2 className="font-display text-lg font-bold text-ink">Contacter le propriétaire</h2>
          <p className="mt-1 text-sm text-muted">Cette annonce relève de l'offre YIRI Annonce : la réservation se fait directement avec le propriétaire.</p>
          <p className="mt-2 font-semibold text-ink"><Money value={l.nightly_price_xof} /> la nuit · {l.min_nights} nuit(s) minimum</p>

          <div className="mt-4"><NePayezRienAvant /></div>

          {!s.account ? (
            <Button className="mt-4" onClick={onLogin}>Se connecter pour voir le contact</Button>
          ) : contact ? (
            <>
              <div className="mt-4 rounded-xl bg-sunk px-3.5 py-3">
                <p className="font-semibold text-ink">{contact.contact_name}</p>
                <p className="text-ink">{contact.phone}{contact.whatsapp ? " · joignable sur WhatsApp" : ""}</p>
              </div>
              {/* Répété ici, en plus visible : c'est l'écran que le voyageur a sous les yeux
                  au moment où on lui demandera de l'argent. */}
              <div className="mt-3"><NePayezRienAvant fort /></div>
            </>
          ) : (
            <Button className="mt-4" onClick={reveal} disabled={busy}>Afficher le contact</Button>
          )}
          <p className="mt-3 text-xs text-muted">Chaque consultation est comptée une fois par tranche de 24 heures. YIRI n'intervient pas dans le paiement de ces séjours.</p>
        </div>
      ) : booking ? (
        <div className="rounded-2xl border border-good/40 bg-good/10 p-5">
          <h2 className="font-display text-lg font-bold text-ink">Réservation enregistrée</h2>
          <p className="mt-1 text-ink">
            {api.parseStay(booking.stay).start} → {api.parseStay(booking.stay).end} · {booking.guests} voyageur(s) ·
            total <Money value={booking.total_xof} />
          </p>
          <p className="mt-2 text-sm text-muted">
            Le prix a été calculé par le serveur. Vos dates sont retenues 15 minutes, le temps de payer.
          </p>
          <Button className="mt-4" onClick={onBookings}>Payer et suivre ma réservation</Button>
        </div>
      ) : (
        <div className="rounded-2xl border border-line bg-surface p-5">
          <h2 className="font-display text-lg font-bold text-ink">Réserver</h2>
          <p className="mt-1 text-sm text-muted"><Money value={l.nightly_price_xof} /> la nuit · {l.min_nights} nuit(s) minimum</p>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <Field label="Arrivée" htmlFor="v-in"><input id="v-in" type="date" min={today()} className={inputCls} value={start} onChange={(e) => setStart(e.target.value)} /></Field>
            <Field label="Départ" htmlFor="v-out"><input id="v-out" type="date" min={addDays(start, 1)} className={inputCls} value={end} onChange={(e) => setEnd(e.target.value)} /></Field>
            <Field label="Voyageurs" htmlFor="v-pax"><input id="v-pax" type="number" min={1} max={l.capacity} className={inputCls} value={guests} onChange={(e) => setGuests(+e.target.value)} /></Field>
          </div>
          {/* Le téléphone est obligatoire, et la raison est écrite à côté : sans elle, une case
              de plus juste avant de payer est vécue comme une formalité et fait abandonner. */}
          <div className="mt-4">
            <Field label="Votre téléphone" htmlFor="v-tel">
              <input id="v-tel" type="tel" inputMode="tel" autoComplete="tel" placeholder="70 00 00 00"
                     className={inputCls} value={tel} onChange={(e) => setTel(e.target.value)} />
            </Field>
            <p className="mt-1.5 text-sm text-muted">
              C'est par là que l'équipe YIRI vous joint pour la remise des clés et l'arrivée.
              Il n'est jamais affiché publiquement.
            </p>
          </div>
          {n > 0 && <p className="mt-3 text-sm text-muted">Estimation : {n} nuit(s) × <Money value={l.nightly_price_xof} /> = <Money value={estimate} />. Le montant exact est calculé par le serveur.</p>}
          {!s.account
            ? <Button className="mt-4" size="lg" onClick={onLogin}>Se connecter pour réserver</Button>
            : <>
                <Button className="mt-4" size="lg" onClick={book} disabled={busy || n <= 0 || !telOk}>{busy ? "Patientez…" : "Réserver"}</Button>
                {!telOk && tel.length > 0 && <p className="mt-2 text-sm text-danger">Ce numéro ne ressemble pas à un numéro de téléphone.</p>}
                {!telOk && tel.length === 0 && <p className="mt-2 text-sm text-muted">Indiquez votre téléphone pour pouvoir réserver.</p>}
              </>}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Mes réservations + « J'ai payé »
// ---------------------------------------------------------------------------
/** Le contact YIRI, visible UNIQUEMENT une fois le séjour payé.
 *
 *  Décision du fondateur, et c'est la bonne : affiché avant paiement, ce numéro permettrait de
 *  convenir d'un séjour en direct, en liquide, et YIRI ne toucherait rien. Après paiement il n'y
 *  a plus de risque, et c'est le moment où le voyageur en a vraiment besoin.
 *
 *  Sans ce bloc, quelqu'un payait son séjour et n'avait personne à joindre pour les clés : le
 *  logement est sous gestion, donc le numéro du propriétaire reste caché, exprès.
 *
 *  Le message est pré-rempli avec les dates : l'équipe sait de quel séjour on lui parle. */
function ContactYiri({ b }: { b: Booking }) {
  if (!SOCIETE.whatsappLien) return null;
  const d = api.parseStay(b.stay);
  const texte = `Bonjour YIRI, je suis arrivé(e) au bout de ma réservation du ${d.start} au ${d.end}. Comment se passe la remise des clés ?`;
  return (
    <div className="mt-3 rounded-xl border border-good/40 bg-good/10 p-3.5">
      <p className="text-sm font-semibold text-ink">Votre séjour est payé. Pour les clés, écrivez-nous.</p>
      <p className="mt-1 text-sm text-muted">
        L'équipe YIRI vous contactera aussi au numéro que vous avez indiqué
        {b.guest_phone ? ` (${b.guest_phone})` : ""}.
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        <a href={`https://wa.me/${SOCIETE.whatsappLien}?text=${encodeURIComponent(texte)}`}
           target="_blank" rel="noopener noreferrer"
           className="rounded-full bg-ink px-4 py-2 text-sm font-semibold text-bg no-underline hover:opacity-90">
          Écrire à YIRI sur WhatsApp
        </a>
        {SOCIETE.whatsapp && (
          <a href={`tel:${SOCIETE.whatsappLien}`}
             className="rounded-full bg-sunk px-4 py-2 text-sm font-semibold text-ink no-underline hover:bg-line">
            Appeler le {SOCIETE.whatsapp}
          </a>
        )}
      </div>
    </div>
  );
}

const B_LABEL: Record<string, [string, "warn" | "good" | "bad" | "neutral" | "info"]> = {
  en_attente_paiement: ["En attente de paiement", "warn"],
  confirmee: ["Confirmée", "good"],
  en_cours: ["Séjour en cours", "good"],
  terminee: ["Terminée", "neutral"],
  expiree: ["Expirée", "bad"],
  annulee: ["Annulée", "bad"],
  refusee: ["Refusée", "bad"],
};

/** Paiement en ligne. Le bouton n'envoie qu'un identifiant de réservation : le montant est
 *  recalculé par la base, et la clé du prestataire reste sur le serveur. Si le paiement en ligne
 *  n'est pas disponible — fonction non déployée, prestataire muet — on le dit sans drame et le
 *  paiement hors ligne reste à portée de main juste en dessous. */
function PayBlock({ b }: { b: Booking }) {
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [indispo, setIndispo] = React.useState<string | null>(null);
  const [redirige, setRedirige] = React.useState(false);

  const payer = () => void (async () => {
    setBusy(true); setError(null); setIndispo(null);
    try {
      const d = await api.startOnlinePayment("reservation", b.id);
      setRedirige(true);
      // On quitte l'application pour la page du prestataire. Le retour se fait sur « Mes séjours ».
      window.location.assign(d.page_paiement);
    } catch (e) {
      if (e instanceof api.PaiementIndisponible) setIndispo(e.message);
      else setError(e instanceof Error ? e.message : "Paiement impossible.");
      setBusy(false);
    }
  })();

  return (
    <div className="mt-4 flex flex-col gap-3 border-t border-line pt-4">
      {error && <Alert tone="bad">{error}</Alert>}
      {indispo && <Alert tone="warn">{indispo}</Alert>}
      {redirige && <Alert tone="good">Ouverture de la page de paiement…</Alert>}
      {!indispo && (
        <>
          <Button size="lg" disabled={busy} onClick={payer}>
            {busy ? "Préparation…" : <>Payer <Money value={b.total_xof} /> en ligne</>}
          </Button>
          <p className="text-sm text-muted">
            Vous serez conduit sur la page sécurisée de notre prestataire de paiement. Votre réservation
            se confirme ensuite d'elle-même, sans intervention de notre part.
          </p>
        </>
      )}
    </div>
  );
}

function DeclareBlock({ b, onDone }: { b: Booking; onDone: () => void }) {
  const [amount, setAmount] = React.useState(String(b.total_xof));
  const [reference, setReference] = React.useState("");
  const [message, setMessage] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [done, setDone] = React.useState(false);

  if (done) return <Alert tone="good">Déclaration envoyée. L'équipe YIRI vérifie la réception, puis confirme votre réservation.</Alert>;

  return (
    <div className="mt-4 flex flex-col gap-3 border-t border-line pt-4">
      <p className="text-sm text-muted">
        Après avoir payé, signalez-le ici. Ce n'est pas une preuve de paiement : seule l'équipe YIRI confirme,
        après avoir vérifié le montant réellement reçu.
      </p>
      {error && <Alert tone="bad">{error}</Alert>}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Montant payé (FCFA)" htmlFor={`d-a-${b.id}`}>
          <input id={`d-a-${b.id}`} type="number" min={1} className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Référence du paiement" htmlFor={`d-r-${b.id}`} hint="Facultatif : numéro de transaction.">
          <input id={`d-r-${b.id}`} className={inputCls} value={reference} onChange={(e) => setReference(e.target.value)} />
        </Field>
      </div>
      <Field label="Message" htmlFor={`d-m-${b.id}`} hint="Facultatif.">
        <input id={`d-m-${b.id}`} className={inputCls} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Payé par Orange Money" />
      </Field>
      <Button disabled={busy} onClick={() => void (async () => {
        const v = Number(amount);
        if (!Number.isFinite(v) || v <= 0) { setError("Indiquez le montant payé."); return; }
        setBusy(true); setError(null);
        try { await api.declarePayment("reservation", b.id, v, reference, message); setDone(true); onDone(); }
        catch (e) { setError(e instanceof Error ? e.message : "Déclaration impossible."); }
        finally { setBusy(false); }
      })()}>J'ai payé</Button>
    </div>
  );
}

/** Les conditions d'annulation, lues dans la base et non écrites en dur ici :
 *  si l'administrateur change le barème, cet encadré change avec lui. */
export /** Avertissement anti-avance de paiement, sur les annonces YIRI Annonce.
 *
 *  Sur ces logements, YIRI ne tient pas la caisse et n'a aucun moyen de récupérer de l'argent
 *  versé en dehors du site. L'arnaque est connue : un faux bailleur réclame un acompte « pour
 *  bloquer les dates », encaisse, et disparaît. La seule protection possible est de dire au
 *  voyageur, AU MOMENT où il obtient le numéro, qu'il ne doit rien verser avant d'avoir les
 *  clés en main — et de le dire franchement, y compris sur ce que YIRI ne peut pas faire.
 *
 *  Montré deux fois exprès : avant d'afficher le contact, pour qu'il parte averti ; et à côté
 *  du numéro, parce que c'est là qu'il regarde quand on lui demandera de l'argent. */
function NePayezRienAvant({ fort }: { fort?: boolean }) {
  return (
    <div className={`rounded-xl border px-3.5 py-3 ${fort ? "border-danger/50 bg-danger/10" : "border-warn/40 bg-warn/10"}`}>
      <p className="text-sm font-bold text-ink">Ne versez aucun argent à l'avance.</p>
      <p className="mt-1 text-sm text-ink">
        Vous payez <strong>sur place, au moment où le propriétaire vous remet les clés</strong> —
        jamais avant. Ni acompte, ni « frais de réservation », ni transfert pour bloquer les dates.
      </p>
      <p className="mt-1.5 text-sm text-muted">
        Ce logement n'est pas géré par YIRI : nous n'encaissons rien pour lui et nous ne pourrons
        pas récupérer une somme envoyée en dehors du site. Si on vous réclame de l'argent avant
        votre arrivée, refusez et prévenez-nous.
      </p>
    </div>
  );
}

function ConditionsAnnulation({ compact }: { compact?: boolean }) {
  const [r, setR] = React.useState<api.RefundRules | null>(null);
  React.useEffect(() => {
    let alive = true;
    api.refundRules().then((x) => { if (alive) setR(x); }).catch(() => { if (alive) setR(null); });
    return () => { alive = false; };
  }, []);
  if (!r) return null;                     // indisponible : on n'affiche rien plutôt qu'un barème inventé
  return (
    <div className={compact ? "rounded-xl bg-sunk p-3" : "rounded-2xl border border-line bg-surface p-4"}>
      <h2 className={compact ? "text-sm font-semibold text-ink" : "font-display font-bold text-ink"}>
        Conditions d'annulation
      </h2>
      <ul className="mt-2 flex flex-col gap-1 text-sm text-muted">
        {api.refundRulesText(r).map((t, i) => <li key={i}>{t}</li>)}
      </ul>
    </div>
  );
}

/** Statuts où l'annulation en ligne est possible. La base tranche de toute façon :
 *  ce test n'évite qu'un aller-retour inutile. */
const ANNULABLE = ["en_attente_confirmation", "en_attente_paiement", "confirmee"];

const R_LABEL: Record<string, [string, "warn" | "good" | "bad" | "neutral"]> = {
  demande: ["Remboursement en vérification", "warn"],
  approuve: ["Remboursement en préparation", "warn"],
  en_cours: ["Remboursement envoyé", "warn"],
  reussi: ["Remboursement effectué", "good"],
  echoue: ["Remboursement en échec", "bad"],
};

/** Confirmation d'annulation. Affichée par la PAGE et non par le bloc d'annulation : ce bloc
 *  disparaît dès que la réservation n'est plus annulable, et emporterait le message avec lui.
 *
 *  Le site n'annonce plus aucun montant ni aucun remboursement automatique. YIRI ne peut pas
 *  verser toute seule — le prestataire ne le permet pas — et promettre un virement que personne
 *  ne peut déclencher vaut moins que ne rien promettre. La décision revient à l'équipe, et le
 *  voyageur sait vers qui se tourner. */
function AvisAnnulation({ r }: { r: api.CancelResult }) {
  return (
    <Alert tone="good">
      Réservation annulée. Les dates sont de nouveau libres.
      {r.booking_status === "annulee" && (
        <>
          {" "}Si vous avez payé ce séjour, écrivez à l'équipe YIRI : elle examine chaque
          annulation et revient vers vous.
        </>
      )}
    </Alert>
  );
}

/** Annulation par le voyageur.
 *
 *  Il n'y a plus de devis : afficher « vous récupérez X » reviendrait à promettre un versement
 *  que le site ne déclenche plus. Ce qui reste est exact et utile : annuler libère les dates
 *  tout de suite, et pour la suite on parle à quelqu'un. */
function CancelBlock({ b, onDone }: { b: Booking; onDone: (r: api.CancelResult) => void }) {
  const [ouvert, setOuvert] = React.useState(false);
  const [motif, setMotif] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const annuler = () => void (async () => {
    setBusy(true); setError(null);
    try { onDone(await api.cancelBooking(b.id, motif)); }
    catch (e) { setError(e instanceof Error ? e.message : "Annulation impossible."); setBusy(false); }
  })();

  if (!ouvert) {
    return (
      <div className="mt-4 border-t border-line pt-4">
        {error && <Alert tone="bad">{error}</Alert>}
        <Button variant="ghost" size="sm" onClick={() => setOuvert(true)}>Annuler ma réservation</Button>
      </div>
    );
  }

  return (
    <div className="mt-4 flex flex-col gap-3 border-t border-line pt-4">
      {error && <Alert tone="bad">{error}</Alert>}
      <p className="font-semibold text-ink">Annuler cette réservation</p>
      <p className="text-sm text-muted">
        L'annulation est définitive et libère immédiatement les dates.
      </p>
      <Alert tone="warn">
        <strong>Si vous avez déjà payé ce séjour</strong>, l'annulation ne déclenche aucun
        remboursement automatique. L'équipe YIRI examine chaque cas et vous répond. Écrivez-nous
        avant d'annuler si vous avez une question.
      </Alert>
      <Field label="Motif" htmlFor={`c-m-${b.id}`} hint="Facultatif. Cela nous aide à comprendre.">
        <input id={`c-m-${b.id}`} className={inputCls} value={motif} onChange={(e) => setMotif(e.target.value)} placeholder="Changement de programme" />
      </Field>
      <div className="flex flex-wrap gap-2">
        <Button variant="danger" disabled={busy} onClick={annuler}>
          {busy ? "Annulation…" : "Confirmer l'annulation"}
        </Button>
        <Button variant="ghost" disabled={busy} onClick={() => setOuvert(false)}>Garder ma réservation</Button>
      </div>
    </div>
  );
}

export function MesReservations({ onLogin, onCatalogue }: { onLogin: () => void; onCatalogue: () => void }) {
  const s = useSession();
  const [data, setData] = React.useState<Booking[] | null>(null);
  const [remb, setRemb] = React.useState<api.MyRefund[]>([]);
  const [avis, setAvis] = React.useState<api.CancelResult | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    if (!s.account) return;
    let alive = true;
    api.myBookings().then((b) => { if (alive) setData(b); })
      .catch((e) => { if (alive) { setError(e instanceof Error ? e.message : "Lecture impossible."); setData([]); } });
    // Les remboursements sont un complément : leur absence ne doit pas masquer les réservations.
    api.myRefunds().then((r) => { if (alive) setRemb(r); }).catch(() => { if (alive) setRemb([]); });
    return () => { alive = false; };
  }, [s.account, tick]);

  if (!s.ready) return <p className="py-16 text-center text-muted">Chargement…</p>;
  if (!s.account) return (
    <div className="mx-auto max-w-md py-16">
      <h1 className="font-display text-2xl font-bold text-ink">Mes réservations</h1>
      <p className="mt-2 text-muted">Connectez-vous pour retrouver vos réservations.</p>
      <Button className="mt-5" size="lg" onClick={onLogin}>Se connecter</Button>
    </div>
  );

  return (
    <div className="flex flex-col gap-4 py-8">
      <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">Mes réservations</h1>
      {avis && <AvisAnnulation r={avis} />}
      {(data ?? []).some((b) => b.status === "en_attente_paiement") && (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-sunk p-3">
          <span className="text-sm text-muted">
            Vous venez de payer ? La confirmation arrive en général en moins d'une minute.
          </span>
          <Button size="sm" variant="secondary" onClick={() => setTick((t) => t + 1)}>Actualiser</Button>
        </div>
      )}
      {error && <Alert tone="bad">{error}</Alert>}
      {data === null && <p className="text-muted">Chargement…</p>}
      {data !== null && data.length === 0 && (
        <div className="rounded-2xl border border-dashed border-line-strong p-10 text-center">
          <p className="text-muted">Vous n'avez pas encore de réservation.</p>
          <Button className="mt-4" variant="secondary" onClick={onCatalogue}>Voir les logements</Button>
        </div>
      )}
      {(data ?? []).map((b) => {
        const st = B_LABEL[b.status] ?? [b.status, "neutral" as const];
        const d = api.parseStay(b.stay);
        const hold = b.hold_expires_at ? new Date(b.hold_expires_at) : null;
        const left = hold ? Math.round((hold.getTime() - Date.now()) / 60000) : null;
        return (
          <div key={b.id} className="rounded-2xl border border-line bg-surface p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold text-ink">{d.start} → {d.end} · {b.guests} voyageur(s)</p>
                <p className="text-sm text-muted">Total <Money value={b.total_xof} /> · {b.nightly_price_xof.toLocaleString("fr-FR")} FCFA la nuit</p>
              </div>
              <Pill tone={st[1]}>{st[0]}</Pill>
            </div>
            {b.status === "en_attente_paiement" && left !== null && (
              <p className={`mt-2 text-sm font-medium ${left > 0 ? "text-warn" : "text-danger"}`}>
                {left > 0 ? `Vos dates sont retenues encore ${left} minute(s).` : "Le délai est dépassé : vos dates peuvent être reprises."}
              </p>
            )}
            {b.status === "en_attente_paiement" && (
              <>
                <PayBlock b={b} />
                <details className="mt-3">
                  <summary className="cursor-pointer text-sm font-semibold text-ink">Ou payer hors ligne</summary>
                  <DeclareBlock b={b} onDone={() => setTick((t) => t + 1)} />
                </details>
              </>
            )}
            {(b.status === "confirmee" || b.status === "en_cours") && <ContactYiri b={b} />}
            {ANNULABLE.includes(b.status) && (
              <CancelBlock b={b} onDone={(r) => { setAvis(r); setTick((t) => t + 1); }} />
            )}
            {remb.filter((r) => r.booking_id === b.id).map((r) => {
              const rl = R_LABEL[r.status] ?? [r.status, "neutral" as const];
              return (
                <div key={r.id} className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-sunk p-3">
                  <span className="text-sm text-muted">
                    Remboursement de <Money value={r.amount_xof} className="font-medium text-ink" />
                    {r.failure_reason ? ` — ${r.failure_reason}` : ""}
                  </span>
                  <Pill tone={rl[1]}>{rl[0]}</Pill>
                </div>
              );
            })}
          </div>
        );
      })}
      {data !== null && data.length > 0 && <ConditionsAnnulation compact />}
    </div>
  );
}
