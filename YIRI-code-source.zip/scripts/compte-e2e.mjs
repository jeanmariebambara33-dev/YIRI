// Tests de bout en bout des écrans de compte (Supabase Auth) dans un vrai navigateur.
// Le serveur Supabase est REMPLACÉ par une imitation injectée avant l'application : on vérifie ici le
// comportement de l'interface (session, erreurs, protection, déconnexion), pas le serveur lui-même,
// qui a été vérifié séparément sur le vrai projet.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

// --- Imitation de @supabase/supabase-js -------------------------------------------------------
const FAKE = `
window.__calls = [];
const USERS = { "a@yiri.test": { id: "u-1", password: "motdepasse1", confirmed: true, name: "Awa Sawadogo",
                                 roles: [{ role: "voyageur" }], perms: [] },
                "chef@yiri.test": { id: "u-2", password: "motdepasse1", confirmed: true, name: "Chef Equipe",
                                 roles: [{ role: "admin" }], perms: [{ perm: "validation" }] } };
const KEY = "fake-session";
function readSession() { try { const r = localStorage.getItem(KEY); return r ? JSON.parse(r) : null; } catch { return null; } }
function writeSession(s) { try { s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY); } catch {} }
function sessionFor(email) { const u = USERS[email]; return { access_token: "jeton-" + u.id, user: { id: u.id, email } }; }
function rows(table, id) {
  const email = Object.keys(USERS).find((e) => USERS[e].id === id);
  const u = USERS[email] || { name: "", roles: [], perms: [] };
  if (table === "profiles") return [{ full_name: u.name, phone: null }];
  if (table === "user_roles") return u.roles;
  if (table === "team_permissions") return u.perms;
  return [];
}
function builder(table) {
  let id = null;
  const self = {
    select() { return self; },
    eq(_c, v) { id = v; return self; },
    maybeSingle() { return Promise.resolve({ data: rows(table, id)[0] ?? null, error: null }); },
    then(res) { return Promise.resolve({ data: rows(table, id), error: null }).then(res); },
  };
  return self;
}
const listeners = [];
function emit(ev, s) { listeners.forEach((f) => f(ev, s)); }
window.supabase = { createClient(url, key, opts) {
  window.__calls.push(["createClient", { url, flowType: opts.auth.flowType, persist: opts.auth.persistSession, refresh: opts.auth.autoRefreshToken }]);
  return {
    auth: {
      async getSession() { return { data: { session: readSession() }, error: null }; },
      async signUp({ email, password, options }) {
        window.__calls.push(["signUp", { email, meta: options && options.data }]);
        if (USERS[email]) return { data: null, error: { message: "User already registered" } };
        USERS[email] = { id: "u-" + (Object.keys(USERS).length + 1), password, confirmed: false, name: (options.data || {}).full_name || "", roles: [{ role: "voyageur" }], perms: [] };
        return { data: { user: { id: USERS[email].id, email }, session: null }, error: null };  // confirmation requise
      },
      async signInWithPassword({ email, password }) {
        window.__calls.push(["signIn", { email }]);
        const u = USERS[email];
        if (!u || u.password !== password) return { data: null, error: { message: "Invalid login credentials" } };
        if (!u.confirmed) return { data: null, error: { message: "Email not confirmed" } };
        const s = sessionFor(email); writeSession(s); emit("SIGNED_IN", s);
        return { data: { user: s.user, session: s }, error: null };
      },
      async signOut() { window.__calls.push(["signOut", {}]); writeSession(null); emit("SIGNED_OUT", null); return { error: null }; },
      async resetPasswordForEmail(email, o) { window.__calls.push(["reset", { email, redirectTo: o && o.redirectTo }]); return { data: {}, error: null }; },
      async updateUser(attrs) { window.__calls.push(["updateUser", { hasPassword: !!attrs.password }]); return { data: { user: null }, error: null }; },
      onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() { listeners.splice(listeners.indexOf(cb), 1); } } } }; },
    },
    from: builder,
    rpc() { return Promise.resolve({ data: null, error: null }); },
    storage: { from: () => ({}) },
  };
} };
`;

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ viewport: { width: 1280, height: 900 } });
await ctx.route("**cdn.jsdelivr.net/**", (r) => r.abort());   // hors ligne ici : la vraie bibliothèque ne se charge pas
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));

// =============== 1. Sans la bibliothèque : message clair, pas d'écran blanc ===============
await p.goto(URL); await p.waitForSelector("h1");
await p.goto(URL + "#compte"); await p.waitForSelector("h1");
let body = await p.locator("body").innerText();
ok("bibliothèque absente : message clair et pas d'écran blanc", /connexion au serveur n'a pas pu être chargée/i.test(body));
ok("bibliothèque absente : l'application reste utilisable", await p.getByRole("button", { name: "Logements" }).count() > 0);

// =============== 2. Avec l'imitation du serveur ===============
await ctx.addInitScript(FAKE);
await p.goto(URL); await p.waitForSelector("h1");

const opts = await p.evaluate(() => window.__calls.find((c) => c[0] === "createClient")?.[1] ?? null);
ok("client créé avec la bonne adresse de projet", !!opts && /supabase\.co$/.test(opts.url));
ok("session conservée entre les pages (persistSession)", !!opts && opts.persist === true);
ok("renouvellement automatique du jeton (autoRefreshToken)", !!opts && opts.refresh === true);
ok("flux PKCE : pas de jeton dans l'ancre d'URL", !!opts && opts.flowType === "pkce");

ok("bouton « Connexion » visible pour un visiteur", await p.getByRole("button", { name: "Connexion" }).count() > 0);
await p.getByRole("button", { name: "Connexion" }).first().click();
await p.waitForSelector("#c-mail");
ok("l'écran de connexion s'ouvre", (await p.locator("h1").first().innerText()).includes("Connexion"));

// --- mot de passe faux ---
await p.fill("#c-mail", "a@yiri.test"); await p.fill("#c-mdp", "mauvais-mot-de-passe");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForSelector("[role=alert]");
ok("mot de passe faux : message en français, pas le texte anglais", /incorrect/i.test(await p.locator("[role=alert]").innerText()));
ok("mot de passe faux : aucune session ouverte", await p.locator("text=Se déconnecter").count() === 0);

// --- inscription : mot de passe trop court, refusé sans appeler le serveur ---
await p.getByRole("button", { name: "Créer un compte" }).click();
await p.waitForSelector("#c-nom");
await p.fill("#c-nom", "Nouveau Test"); await p.fill("#c-mail", "neuf@yiri.test"); await p.fill("#c-mdp", "court");
await p.evaluate(() => document.querySelector("#c-mdp").setAttribute("minlength", "1"));  // contourne le navigateur pour tester NOTRE contrôle
await p.getByRole("button", { name: "Créer mon compte" }).click();
await p.waitForTimeout(150);
ok("inscription : mot de passe court refusé côté application", /8 caractères/.test(await p.locator("body").innerText()));
ok("inscription : rien n'est envoyé au serveur", await p.evaluate(() => !window.__calls.some((c) => c[0] === "signUp")));

// --- inscription correcte : confirmation d'e-mail exigée ---
await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Créer mon compte" }).click();
await p.waitForSelector("[role=status]");
ok("inscription : message « confirmez votre adresse »", /confirmer votre adresse/i.test(await p.locator("[role=status]").innerText()));
const sent = await p.evaluate(() => window.__calls.find((c) => c[0] === "signUp")?.[1] ?? null);
ok("inscription : le nom est transmis, jamais un rôle", !!sent && sent.meta.full_name === "Nouveau Test" && !("role" in sent.meta));
ok("inscription : pas connecté tant que l'adresse n'est pas confirmée", await p.locator("text=Se déconnecter").count() === 0);

// --- compte non confirmé : connexion refusée ---
await p.getByRole("button", { name: "Revenir à la connexion" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "neuf@yiri.test"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForSelector("[role=alert]");
ok("adresse non confirmée : connexion refusée avec explication", /pas encore confirmée/i.test(await p.locator("[role=alert]").innerText()));

// --- mot de passe oublié : même réponse que le compte existe ou non ---
await p.getByRole("button", { name: "Mot de passe oublié" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "inconnu@yiri.test");
await p.getByRole("button", { name: "Envoyer le lien" }).click();
await p.waitForSelector("[role=status]");
ok("mot de passe oublié : la réponse ne révèle pas qui est inscrit", /si un compte existe/i.test(await p.locator("[role=status]").innerText()));

// --- connexion réussie ---
await p.getByRole("button", { name: "Revenir à la connexion" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "a@yiri.test"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForSelector("text=Se déconnecter");
body = await p.locator("body").innerText();
ok("connexion réussie : la page du compte s'affiche", /Mon compte/.test(body));
ok("le rôle affiché vient de la base (Voyageur)", /Voyageur/.test(body));
ok("l'e-mail affiché est celui du compte", /a@yiri\.test/.test(body));
ok("le prénom apparaît dans l'en-tête", await p.getByRole("button", { name: "Awa" }).count() > 0);

// --- la session survit au rechargement ---
await p.reload(); await p.waitForSelector("h1");
await p.waitForSelector("text=Se déconnecter");
ok("la session survit au rechargement de la page", /a@yiri\.test/.test(await p.locator("body").innerText()));

// --- déconnexion ---
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForSelector("#c-mail");
ok("déconnexion : retour à l'écran de connexion", await p.locator("#c-mdp").count() > 0);
ok("déconnexion : la session est effacée du navigateur", await p.evaluate(() => !localStorage.getItem("fake-session")));
await p.reload(); await p.waitForSelector("h1");
ok("déconnexion : toujours déconnecté après rechargement", await p.locator("text=Se déconnecter").count() === 0);

// --- un compte d'équipe voit ses autorisations ---
await p.goto(URL + "#compte"); await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "chef@yiri.test"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForSelector("text=Se déconnecter");
body = await p.locator("body").innerText();
ok("compte d'équipe : rôle Administrateur affiché", /Administrateur/.test(body));
ok("compte d'équipe : autorisation « Validation » affichée", /Validation/.test(body));

// --- la démo existante n'est pas cassée ---
await p.goto(URL); await p.waitForSelector("h1");
ok("page d'accueil toujours fonctionnelle", await p.getByRole("button", { name: "Logements" }).count() > 0);
await p.getByRole("button", { name: "Logements" }).first().click();
await p.waitForTimeout(200);
ok("catalogue de démonstration toujours accessible", /logement/i.test(await p.locator("body").innerText()));
ok("espace équipe de démonstration toujours présent", await p.getByRole("button", { name: "Espace équipe" }).count() > 0);

ok("aucune erreur JavaScript pendant les tests", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 3).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DU COMPTE SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
