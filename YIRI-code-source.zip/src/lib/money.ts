// Tous les montants sont des entiers en FCFA (XOF). Jamais de flottants.

export type XOF = number;

export function assertXOF(n: number, label = "montant"): XOF {
  if (!Number.isInteger(n)) throw new Error(`${label} doit être un entier XOF (reçu ${n})`);
  if (n < 0) throw new Error(`${label} ne peut pas être négatif (reçu ${n})`);
  return n;
}

/** Pourcentage entier avec arrondi au plus proche (demi vers le haut), sans flottant. */
export function percentOf(amount: XOF, percent: number): XOF {
  assertXOF(amount);
  if (!Number.isInteger(percent) || percent < 0 || percent > 100) {
    throw new Error(`pourcentage invalide : ${percent}`);
  }
  return Math.floor((amount * percent + 50) / 100);
}

export function formatXOF(n: XOF): string {
  const s = Math.abs(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${n < 0 ? "−" : ""}${s} FCFA`;
}
