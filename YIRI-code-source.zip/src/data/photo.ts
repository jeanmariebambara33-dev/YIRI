// Fichier ENGENDRÉ par scripts/photo-accueil.mjs — ne pas modifier à la main.
//
// Vignette de la photo d'ouverture : 24 pixels de large, floutée, pesant quelques centaines
// d'octets. Elle est dans la page elle-même, donc affichée sans aucun aller-retour réseau, et
// tient lieu d'image le temps que la vraie photo arrive. Pendant la première seconde
// l'introduction est de toute façon dans la nuit : personne ne voit jamais le flou.
export const PHOTO_VIGNETTE = "data:image/webp;base64,UklGRoAAAABXRUJQVlA4IHQAAACQBACdASoYABAAPulgqE2pJaQiMAgBIB0JbACdMoMYPYABXN8+6fpjPFWNbgAA/tzrfaAgxbjMbAoWQ5T4oarwTF0iVuiTTF4f98aGhbKI+gXtoK2G0vNbvHtQG0064/GMtWiSwz5F/nskDIaV6F4xD8XAAA==";

/** Largeurs engendrées, de la plus grande à la plus petite. */
export const PHOTO_LARGEURS = [1536, 1100, 760, 540] as const;

/** Dimensions de la photo d'origine, et position du soleil dedans (mesurée, pixel le plus clair). */
export const PHOTO = { largeur: 1536, hauteur: 1024, soleilX: 885, soleilY: 497 } as const;
