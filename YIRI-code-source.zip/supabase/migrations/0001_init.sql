-- YIRI — schéma initial (Supabase / PostgreSQL)
-- Principes : montants en entiers XOF, statuts contrôlés, RLS sur toutes les tables privées,
-- aucune réservation bloquante qui se chevauche, écritures financières jamais modifiées (contre-écriture).

create extension if not exists btree_gist;

-- ---------- Types ----------
create type app_role as enum ('voyageur', 'proprietaire', 'gestionnaire', 'finance', 'admin');
create type offer_type as enum ('annonce', 'gestion', 'partenariat');
create type city as enum ('Ouagadougou', 'Bobo-Dioulasso');
create type listing_status as enum ('brouillon','soumise','a_corriger','approuvee','refusee','publiee','suspendue','expiree','archivee');
create type booking_status as enum ('en_attente_confirmation','en_attente_paiement','confirmee','en_cours','terminee','refusee','annulee','expiree','litige');
create type subscription_plan as enum ('mensuel', 'annuel');
create type subscription_status as enum ('en_attente_paiement','actif','expire','annule','rembourse');
create type payment_status as enum ('cree','en_attente','reussi','echoue','annule','expire');
create type payment_purpose as enum ('subscription','booking','refund','payout');
create type application_status as enum ('recue','preselectionnee','visite_planifiee','acceptee','refusee','contrat_signe');
create type payout_status as enum ('a_calculer','a_valider','approuve','en_cours','verse','echoue','suspendu');

-- ---------- Profils et rôles ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  email text,
  language text not null default 'fr',
  created_at timestamptz not null default now()
);

create table user_roles (
  user_id uuid not null references profiles(id) on delete cascade,
  role app_role not null,
  granted_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

create or replace function has_role(r app_role) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = r);
$$;

create or replace function is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role in ('admin','gestionnaire','finance'));
$$;

create table owner_profiles (
  user_id uuid primary key references profiles(id) on delete cascade,
  proof_type text,
  verification_status text not null default 'en_attente' check (verification_status in ('en_attente','verifie','refuse')),
  payout_details_verified boolean not null default false,
  internal_notes text -- jamais exposé au propriétaire (vue staff uniquement)
);

-- ---------- Logements ----------
create table properties (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id),
  offer offer_type not null,
  title text not null,
  description text not null default '',
  city city not null,
  district text not null,
  private_address text, -- masquée publiquement
  capacity int not null check (capacity between 1 and 30),
  bedrooms int not null default 1 check (bedrooms >= 0),
  beds int not null default 1 check (beds >= 0),
  nightly_price_xof int not null check (nightly_price_xof > 0),
  min_nights int not null default 1 check (min_nights >= 1),
  currency char(3) not null default 'XOF' check (currency = 'XOF'),
  house_rules text,
  cancellation_policy text,
  status listing_status not null default 'brouillon',
  review_note text,
  is_demo boolean not null default false, -- les données DÉMO ne vont jamais en production
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index properties_public_idx on properties (status, city);

create table property_photos (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references properties(id) on delete cascade,
  storage_path text not null,
  position int not null default 0,
  alt_text text,
  rights_checked boolean not null default false
);

create table amenities (id text primary key, label text not null, category text not null);
create table property_amenities (
  property_id uuid references properties(id) on delete cascade,
  amenity_id text references amenities(id),
  primary key (property_id, amenity_id)
);

create table availability_blocks (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references properties(id) on delete cascade,
  stay daterange not null check (not isempty(stay)),
  reason text not null default 'proprietaire',
  exclude using gist (property_id with =, stay with &&)
);

-- ---------- Abonnements YIRI Annonce ----------
create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id),
  property_id uuid not null references properties(id),
  plan subscription_plan not null,
  amount_xof int not null check (
    (plan = 'mensuel' and amount_xof = 5000) or (plan = 'annuel' and amount_xof = 30000)
  ),
  currency char(3) not null default 'XOF',
  status subscription_status not null default 'en_attente_paiement',
  starts_at date,
  ends_at date,
  created_at timestamptz not null default now(),
  check (status <> 'actif' or (starts_at is not null and ends_at > starts_at))
);
create index subscriptions_due_idx on subscriptions (status, ends_at);

-- ---------- Contrats YIRI Gestion ----------
create table management_agreements (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references properties(id),
  contract_version text not null,
  owner_percent int not null default 60 check (owner_percent between 0 and 100),
  starts_on date not null,
  ends_on date,
  signed boolean not null default false,
  signature_proof_path text,
  operational_check_done boolean not null default false,
  expense_policy_version text not null
);

-- ---------- Partenariat immobilier : candidatures (MVP = candidature uniquement) ----------
create table partnership_applications (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid references profiles(id),
  contact_name text not null,
  contact_phone text not null,
  city city not null,
  district text not null,
  property_kind text not null,
  rooms int check (rooms >= 0),
  condition_notes text,
  estimated_works text,
  status application_status not null default 'recue',
  decision_reason text,
  consent boolean not null check (consent),
  created_at timestamptz not null default now()
);

-- ---------- Réservations ----------
create table bookings (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references properties(id),
  guest_id uuid not null references profiles(id),
  stay daterange not null check (not isempty(stay)),
  guests int not null check (guests >= 1),
  nightly_price_xof int not null,
  accommodation_xof int not null check (accommodation_xof >= 0),
  discount_xof int not null default 0,
  taxes_xof int not null default 0,
  total_xof int not null check (total_xof = accommodation_xof + taxes_xof - discount_xof),
  currency char(3) not null default 'XOF',
  status booking_status not null default 'en_attente_confirmation',
  hold_expires_at timestamptz,
  source text not null default 'web',
  created_at timestamptz not null default now(),
  -- Aucune réservation bloquante ne peut chevaucher une autre sur le même logement.
  exclude using gist (property_id with =, stay with &&)
    where (status in ('en_attente_paiement','confirmee','en_cours'))
);
create index bookings_property_idx on bookings (property_id, status);

-- ---------- Paiements ----------
create table payment_transactions (
  id uuid primary key default gen_random_uuid(),
  purpose payment_purpose not null,
  subscription_id uuid references subscriptions(id),
  booking_id uuid references bookings(id),
  provider text not null default 'paydunya',
  provider_reference text unique,
  idempotency_key text not null unique,
  amount_xof int not null check (amount_xof > 0),
  fee_xof int,
  currency char(3) not null default 'XOF',
  status payment_status not null default 'cree',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table payment_events (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid references payment_transactions(id),
  provider_event_id text unique,
  payload jsonb not null, -- expurgé : jamais de données de carte
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  result text
);

-- ---------- Registre financier (append-only) ----------
create table financial_ledger (
  id bigint generated always as identity primary key,
  booking_id uuid references bookings(id),
  transaction_id uuid references payment_transactions(id),
  entry_type text not null,
  debit_xof int not null default 0 check (debit_xof >= 0),
  credit_xof int not null default 0 check (credit_xof >= 0),
  currency char(3) not null default 'XOF',
  description text not null,
  corrects_entry bigint references financial_ledger(id),
  created_at timestamptz not null default now(),
  check ((debit_xof = 0) <> (credit_xof = 0))
);

create or replace function forbid_ledger_mutation() returns trigger language plpgsql as $$
begin
  raise exception 'Le registre financier est en ajout seul : utilisez une contre-écriture.';
end $$;
create trigger ledger_no_update before update or delete on financial_ledger
  for each row execute function forbid_ledger_mutation();

create table expenses (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references properties(id),
  booking_id uuid references bookings(id),
  category text not null,
  amount_xof int not null check (amount_xof > 0),
  payer text not null check (payer in ('proprietaire','yiri')),
  receipt_path text,
  approved_by uuid references profiles(id),
  status text not null default 'a_valider' check (status in ('a_valider','approuvee','refusee')),
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  check (approved_by is null or approved_by <> created_by)
);

create table owner_statements (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id),
  period_start date not null,
  period_end date not null,
  rlp_xof int not null check (rlp_xof >= 0),
  owner_share_xof int not null,
  yiri_commission_xof int not null,
  owner_expenses_xof int not null default 0,
  amount_due_xof int not null,
  amount_paid_xof int not null default 0,
  status payout_status not null default 'a_valider',
  check (owner_share_xof + yiri_commission_xof = rlp_xof)
);

create table payouts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id),
  statement_id uuid not null references owner_statements(id),
  amount_xof int not null check (amount_xof > 0),
  destination_masked text not null,
  provider_reference text unique,
  status payout_status not null default 'a_valider',
  validated_by uuid references profiles(id),
  paid_at timestamptz,
  check (status <> 'verse' or (provider_reference is not null and paid_at is not null))
);

create table refunds (
  id uuid primary key default gen_random_uuid(),
  payment_transaction_id uuid not null references payment_transactions(id),
  amount_xof int not null check (amount_xof > 0),
  reason text not null,
  status text not null default 'demande' check (status in ('demande','approuve','en_cours','reussi','echoue')),
  provider_reference text unique,
  approved_by uuid references profiles(id)
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  payload jsonb not null default '{}',
  channel text not null default 'in_app',
  status text not null default 'en_attente',
  sent_at timestamptz,
  read_at timestamptz
);

create table support_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  property_id uuid references properties(id),
  category text not null,
  message text not null,
  status text not null default 'ouvert',
  assigned_to uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references profiles(id),
  action text not null,
  entity_type text not null,
  entity_id text not null,
  before jsonb,
  after jsonb,
  reason text,
  created_at timestamptz not null default now()
);
create trigger audit_no_update before update or delete on audit_logs
  for each row execute function forbid_ledger_mutation();

create table campaign_leads (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  campaign text,
  contact text not null,
  consent boolean not null,
  status text not null default 'nouveau',
  created_at timestamptz not null default now()
);

-- ---------- Vue publique : uniquement les annonces publiables (§11) ----------
create or replace view public_listings with (security_invoker = false) as
select p.id, p.offer, p.title, p.description, p.city, p.district, p.capacity, p.bedrooms, p.beds,
       p.nightly_price_xof, p.min_nights, p.house_rules, p.cancellation_policy
from properties p
where p.status = 'publiee'
  and p.is_demo = false
  and (
    (p.offer = 'annonce' and exists (
      select 1 from subscriptions s
      where s.property_id = p.id and s.status = 'actif' and current_date >= s.starts_at and current_date < s.ends_at))
    or (p.offer in ('gestion','partenariat') and exists (
      select 1 from management_agreements m
      where m.property_id = p.id and m.signed and m.operational_check_done))
  );

-- ---------- RLS ----------
alter table profiles enable row level security;
alter table user_roles enable row level security;
alter table owner_profiles enable row level security;
alter table properties enable row level security;
alter table property_photos enable row level security;
alter table property_amenities enable row level security;
alter table availability_blocks enable row level security;
alter table subscriptions enable row level security;
alter table management_agreements enable row level security;
alter table partnership_applications enable row level security;
alter table bookings enable row level security;
alter table payment_transactions enable row level security;
alter table payment_events enable row level security;
alter table financial_ledger enable row level security;
alter table expenses enable row level security;
alter table owner_statements enable row level security;
alter table payouts enable row level security;
alter table refunds enable row level security;
alter table notifications enable row level security;
alter table support_requests enable row level security;
alter table audit_logs enable row level security;
alter table campaign_leads enable row level security;

create policy profiles_self on profiles for select using (id = auth.uid() or is_staff());
create policy profiles_self_update on profiles for update using (id = auth.uid());
create policy roles_read_own on user_roles for select using (user_id = auth.uid() or has_role('admin'));
-- Aucune policy d'écriture sur user_roles : seuls le serveur (service-role) et l'admin via fonction dédiée attribuent des rôles.

create policy owner_profiles_own on owner_profiles for select using (user_id = auth.uid() or is_staff());

create policy properties_owner_read on properties for select using (owner_id = auth.uid() or is_staff());
create policy properties_owner_insert on properties for insert
  with check (owner_id = auth.uid() and status in ('brouillon','soumise'));
-- Le propriétaire modifie ses brouillons / annonces à corriger, jamais le statut vers « approuvée » ou « publiée ».
create policy properties_owner_update on properties for update
  using (owner_id = auth.uid() and status in ('brouillon','a_corriger'))
  with check (owner_id = auth.uid() and status in ('brouillon','a_corriger','soumise'));
create policy properties_staff_update on properties for update using (has_role('admin') or has_role('gestionnaire'));

create policy photos_owner on property_photos for all
  using (exists (select 1 from properties p where p.id = property_id and (p.owner_id = auth.uid() or is_staff())));
create policy amenities_owner on property_amenities for all
  using (exists (select 1 from properties p where p.id = property_id and (p.owner_id = auth.uid() or is_staff())));
create policy blocks_owner on availability_blocks for all
  using (exists (select 1 from properties p where p.id = property_id and p.offer = 'annonce' and (p.owner_id = auth.uid() or is_staff())));

create policy subs_owner_read on subscriptions for select using (owner_id = auth.uid() or is_staff());
create policy agreements_read on management_agreements for select
  using (is_staff() or exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));

create policy applications_insert on partnership_applications for insert with check (consent);
create policy applications_read on partnership_applications for select using (applicant_id = auth.uid() or is_staff());
create policy applications_staff on partnership_applications for update using (is_staff());

-- Les réservations sont créées par le serveur (calcul du total côté serveur) : pas de policy insert côté client.
create policy bookings_read on bookings for select using (
  guest_id = auth.uid() or is_staff()
  or exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));

create policy tx_staff on payment_transactions for select using (has_role('admin') or has_role('finance'));
create policy ledger_staff on financial_ledger for select using (has_role('admin') or has_role('finance'));
create policy expenses_read on expenses for select using (
  is_staff() or exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));
create policy statements_read on owner_statements for select using (owner_id = auth.uid() or has_role('admin') or has_role('finance'));
create policy payouts_read on payouts for select using (owner_id = auth.uid() or has_role('admin') or has_role('finance'));
create policy notifications_own on notifications for select using (user_id = auth.uid());
create policy notifications_mark_read on notifications for update using (user_id = auth.uid());
create policy support_own on support_requests for all using (user_id = auth.uid() or is_staff());
create policy audit_admin on audit_logs for select using (has_role('admin'));
create policy leads_insert on campaign_leads for insert with check (consent);
create policy leads_staff on campaign_leads for select using (is_staff());

grant select on public_listings to anon, authenticated;
