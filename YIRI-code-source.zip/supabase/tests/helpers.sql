-- Outils communs aux tests (identités simulées, assertions). Test uniquement.
create schema t;
create table t.results (id serial, label text, pass boolean, detail text);
grant usage on schema t to anon, authenticated;

-- enregistre un résultat (SECURITY DEFINER : les utilisateurs de test ne peuvent pas écrire dans t.results)
create function t.rec(label text, pass boolean, detail text default null) returns void
language plpgsql security definer as $$ begin insert into t.results(label, pass, detail) values (label, pass, detail); end $$;
grant execute on function t.rec(text, boolean, text) to anon, authenticated;

create function t.u(n int) returns uuid language sql immutable as $$ select ('00000000-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
create function t.p(n int) returns uuid language sql immutable as $$ select ('aaaaaaaa-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
create function t.b(n int) returns uuid language sql immutable as $$ select ('bbbbbbbb-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid $$;
grant execute on function t.u(int), t.p(int), t.b(int) to anon, authenticated;

-- change d'identité : 0 = visiteur non connecté, sinon utilisateur n°n (connecté)
create function t.as(n int) returns void language plpgsql as $$
begin
  perform set_config('app.uid', case when n = 0 then '' else t.u(n)::text end, false);
  execute case when n = 0 then 'set role anon' else 'set role authenticated' end;
end $$;

-- doit échouer (erreur de droits, contrainte, garde…)
create function t.must_fail(label text, q text) returns void language plpgsql as $$
begin
  begin execute q; perform t.rec(label, false, 'aurait dû être refusé');
  exception when others then perform t.rec(label, true, sqlerrm); end;
end $$;
-- doit réussir
create function t.ok(label text, q text) returns void language plpgsql as $$
begin
  begin execute q; perform t.rec(label, true);
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
-- nombre de lignes affectées (UPDATE/DELETE) attendu
create function t.rows(label text, q text, expected int) returns void language plpgsql as $$
declare n int;
begin
  begin execute q; get diagnostics n = row_count; perform t.rec(label, n = expected, 'lignes : ' || n);
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
-- nombre de lignes renvoyées par une requête
create function t.cnt(label text, q text, expected int) returns void language plpgsql as $$
declare n int;
begin
  begin execute 'select count(*) from (' || q || ') s' into n; perform t.rec(label, n = expected, 'lignes : ' || n);
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
-- une valeur attendue
create function t.eq(label text, q text, expected text) returns void language plpgsql as $$
declare v text;
begin
  begin execute q into v; perform t.rec(label, v is not distinct from expected, 'valeur : ' || coalesce(v, 'NULL'));
  exception when others then perform t.rec(label, false, sqlerrm); end;
end $$;
grant execute on function t.must_fail(text, text), t.ok(text, text), t.rows(text, text, int), t.cnt(text, text, int), t.eq(text, text, text) to anon, authenticated;

-- petit magasin clé/valeur pour garder des identifiants d'un test à l'autre (écrit par une fonction privilégiée)
create table t.kv (k text primary key, v text);
create function t.set(pk text, pv text) returns void language plpgsql security definer as $$
begin insert into t.kv (k, v) values (pk, pv) on conflict (k) do update set v = excluded.v; end $$;
create function t.get(pk text) returns text language sql stable security definer as $$ select v from t.kv where k = pk $$;
grant execute on function t.set(text, text), t.get(text) to anon, authenticated;
