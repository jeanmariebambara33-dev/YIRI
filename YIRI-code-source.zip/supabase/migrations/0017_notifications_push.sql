-- YIRI — 0017 : recevoir les notifications sur son téléphone, site fermé.
--
-- Depuis la 0011, la base écrit une notification à chaque événement qui compte : réservation
-- payée, réservation annulée, abonnement qui expire, accès offert. Depuis l'audit, un écran les
-- affiche enfin. Mais il faut OUVRIR le site pour les voir. Une réservation payée à deux heures
-- du matin n'est donc apprise qu'au réveil, par quelqu'un qui pense à regarder.
--
-- Cette migration ajoute le chemin qui manquait : l'appareil de la personne s'enregistre, et une
-- fonction serveur peut ensuite lui pousser l'alerte même quand le site est fermé. Le protocole
-- est le Web Push standard (RFC 8030, 8291, 8292) : aucun prestataire, aucun abonnement à payer,
-- rien à créer ailleurs. Le téléphone parle directement au service de son navigateur.
--
-- Trois principes, les mêmes que partout ailleurs ici :
--
--   1. QUI reçoit quoi n'est pas décidé par le téléphone. Un appareil enregistré ne donne aucun
--      droit : la file d'envoi ne sort une notification que si son destinataire a bien
--      l'autorisation correspondante, relue au moment de l'envoi.
--   2. Personne ne voit les appareils de personne. Chacun gère les siens, et rien d'autre.
--   3. Les clés. La clé PUBLIQUE VAPID est publique par construction : elle est écrite en base
--      pour que le site la lise sans être reconstruit. La clé PRIVÉE ne doit JAMAIS entrer ici :
--      elle vit dans les secrets des fonctions serveur, et nulle part ailleurs.
--
-- Entièrement ADDITIF. Aucune fonction de 0001 à 0016 n'est redéfinie.

-- =====================================================================
-- 0. Garde : 0017 s'appuie sur 0011 (les notifications) et 0016 (les abonnements par profil)
-- =====================================================================
do $$
begin
  if to_regprocedure('public.my_notifications(int)') is null then
    raise exception 'La migration 0011 n''est pas appliquée. Rien n''a été modifié.';
  end if;
  if to_regprocedure('public.owner_can_publish(uuid)') is null then
    raise exception 'La migration 0016 n''est pas appliquée. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Un réglage public, lisible sans être connecté
-- =====================================================================
-- La clé publique VAPID doit arriver dans le navigateur AVANT toute connexion, et le site est
-- un fichier construit : l'y écrire obligerait à reconstruire et redéployer à chaque rotation
-- de clé. Elle passe donc par la base.
--
-- Cette table n'accueille que des valeurs publiques. Le commentaire n'est pas décoratif : il est
-- là pour que personne — moi compris, plus tard — n'y range un secret par commodité.
create table if not exists public_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);
comment on table public_settings is
  'Réglages PUBLICS uniquement, lisibles par n''importe quel visiteur. N''y mettre JAMAIS une clé privée, un jeton ou un mot de passe : la règle de lecture ci-dessous les exposerait au monde entier.';

alter table public_settings enable row level security;

drop policy if exists public_settings_read on public_settings;
create policy public_settings_read on public_settings for select using (true);
-- Pas de politique d'écriture : seul le rôle de service (ou l'éditeur SQL) peut écrire.

grant select on public_settings to anon, authenticated;
revoke insert, update, delete on public_settings from anon, authenticated;

/* Le site demande la clé publique par cette fonction plutôt qu'en lisant la table : le jour où
   le réglage change de place, le site n'a pas à le savoir. Renvoie NULL si la clé n'est pas
   encore posée — l'interface se contente alors de ne pas proposer les notifications. */
create or replace function push_public_key()
returns text
language sql stable security definer set search_path = public, pg_temp as $$
  select value from public_settings where key = 'push_vapid_public';
$$;
revoke all on function push_public_key() from public;
grant execute on function push_public_key() to anon, authenticated;

-- =====================================================================
-- 2. Les appareils enregistrés
-- =====================================================================
-- Un « abonnement push » est ce que le navigateur remet à la page : une adresse (endpoint) chez
-- le service du navigateur, et deux clés qui servent à chiffrer le message pour cet appareil-là.
-- Rien là-dedans n'est secret pour YIRI, mais tout y est personnel : c'est un identifiant
-- d'appareil. D'où la règle de lecture, stricte, sans exception d'équipe.
create table if not exists push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  label text,
  created_at timestamptz not null default now(),
  last_ok_at timestamptz,
  failures int not null default 0,
  constraint push_keys_non_vides check (length(p256dh) between 1 and 200 and length(auth) between 1 and 100),
  constraint push_endpoint_https check (endpoint like 'https://%' and length(endpoint) <= 2000)
);
create index if not exists push_subscriptions_user_idx on push_subscriptions (user_id);

alter table push_subscriptions enable row level security;

-- Chacun ses appareils, et rien de plus. Pas de dérogation pour l'équipe ni pour les
-- administrateurs : savoir sur quels appareils quelqu'un est connecté n'aide à rien ici, et une
-- liste d'appareils est une donnée de localisation déguisée.
drop policy if exists push_self_read on push_subscriptions;
create policy push_self_read on push_subscriptions for select using (user_id = auth.uid());
drop policy if exists push_self_delete on push_subscriptions;
create policy push_self_delete on push_subscriptions for delete using (user_id = auth.uid());
-- Pas d'insertion directe : elle passe par register_push, qui normalise et limite le nombre.

revoke insert, update on push_subscriptions from anon, authenticated;

/* Enregistrer l'appareil courant. Appelée après que la personne a accepté les notifications.
   Idempotente : le même endpoint peut être réenregistré sans créer de doublon, ce qui arrive à
   chaque fois que le navigateur fait tourner ses clés. */
create or replace function register_push(p_endpoint text, p_p256dh text, p_auth text, p_user_agent text default null)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  res uuid;
  combien int;
begin
  if p_endpoint is null or p_endpoint !~ '^https://' then
    raise exception 'Adresse d''appareil invalide.' using errcode = '22023';
  end if;
  if coalesce(p_p256dh, '') = '' or coalesce(p_auth, '') = '' then
    raise exception 'Clés d''appareil manquantes.' using errcode = '22023';
  end if;

  -- Un endpoint appartient à un appareil, donc à une personne à un instant donné. S'il a changé
  -- de main (appareil prêté, compte différent sur le même navigateur), il suit le nouveau
  -- propriétaire : sinon l'ancien continuerait de recevoir les alertes du nouveau.
  insert into push_subscriptions (user_id, endpoint, p256dh, auth, user_agent)
  values (uid, p_endpoint, p_p256dh, p_auth, left(coalesce(p_user_agent, ''), 300))
  on conflict (endpoint) do update
     set user_id = uid,
         p256dh = excluded.p256dh,
         auth = excluded.auth,
         user_agent = excluded.user_agent,
         failures = 0
  returning id into res;

  -- Un garde-fou, pas une limite de confort : sans lui, un script pourrait faire grossir la
  -- table indéfiniment avec des endpoints forgés. On garde les dix plus récents.
  select count(*) into combien from push_subscriptions where user_id = uid;
  if combien > 10 then
    delete from push_subscriptions
     where id in (
       select id from push_subscriptions
        where user_id = uid
        order by coalesce(last_ok_at, created_at) desc
        offset 10
     );
  end if;

  return res;
end $$;
revoke all on function register_push(text, text, text, text) from public, anon;
grant execute on function register_push(text, text, text, text) to authenticated;

/* Ne plus recevoir sur cet appareil. Silencieuse si l'appareil n'était pas enregistré : la
   personne a demandé à ne plus recevoir, et c'est le cas. */
create or replace function unregister_push(p_endpoint text)
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user(); n int;
begin
  delete from push_subscriptions where user_id = uid and endpoint = p_endpoint;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function unregister_push(text) from public, anon;
grant execute on function unregister_push(text) to authenticated;

/* Ses propres appareils, pour que la personne voie ce qui est enregistré et puisse le retirer.
   L'adresse complète n'est pas renvoyée : elle ne sert à rien à l'écran et c'est un identifiant. */
create or replace function my_push_devices()
returns table (id uuid, user_agent text, created_at timestamptz, last_ok_at timestamptz, actuel boolean, endpoint_court text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select s.id, s.user_agent, s.created_at, s.last_ok_at, false, right(s.endpoint, 12)
      from push_subscriptions s
     where s.user_id = uid
     order by coalesce(s.last_ok_at, s.created_at) desc;
end $$;
revoke all on function my_push_devices() from public, anon;
grant execute on function my_push_devices() to authenticated;

-- =====================================================================
-- 3. Ce qui a déjà été poussé
-- =====================================================================
-- Sans cette trace, un envoi rejoué enverrait deux fois la même alerte. La colonne est portée
-- par la notification, pas par l'appareil : une notification est poussée une fois, vers tous les
-- appareils de son destinataire.
alter table notifications add column if not exists pushed_at timestamptz;
alter table notifications add column if not exists push_attempts int not null default 0;
create index if not exists notifications_a_pousser_idx
  on notifications (created_at) where pushed_at is null;

-- =====================================================================
-- 4. Qui a le droit de recevoir quoi
-- =====================================================================
-- Le cœur de cette migration. Un appareil enregistré ne donne AUCUN droit : c'est ici, au
-- moment de l'envoi, qu'on relit ce que la personne a le droit de savoir. Une personne qui perd
-- son autorisation cesse de recevoir les alertes correspondantes à l'envoi suivant, sans que
-- personne n'ait à désinscrire son téléphone.
--
-- La règle est simple : une notification d'équipe (suffixe « .equipe ») exige l'autorisation
-- correspondante ; une notification personnelle appartient à son destinataire, point.
create or replace function _push_destinataire_legitime(p_user uuid, p_type text)
returns boolean
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare
  est_admin boolean;
  perms text[];
begin
  select exists (select 1 from user_roles where user_id = p_user and role = 'admin') into est_admin;
  if est_admin then
    return true;
  end if;

  -- Les notifications destinées à l'équipe ne partent que vers qui a l'autorisation voulue.
  if p_type like '%.equipe' then
    select coalesce(array_agg(perm::text), '{}') into perms
      from team_permissions where user_id = p_user;
    if p_type like 'booking.%' then
      return perms && array['reservations', 'paiements'];
    elsif p_type like 'subscription.%' or p_type like 'listing.%' then
      return perms && array['validation', 'paiements'];
    elsif p_type like 'refund.%' or p_type like 'payment.%' then
      return perms && array['paiements'];
    elsif p_type like 'identity.%' then
      return perms && array['validation'];
    elsif p_type like 'application.%' or p_type like 'lead.%' then
      return perms && array['demandes', 'partenariat'];
    end if;
    return false;  -- un type d'équipe inconnu ne part pas : refuser par défaut, jamais l'inverse
  end if;

  -- Notification personnelle : elle est à son destinataire. Il la reçoit.
  return true;
end $$;
revoke all on function _push_destinataire_legitime(uuid, text) from public, anon, authenticated;

-- =====================================================================
-- 5. La file d'envoi, fermée au navigateur
-- =====================================================================
/* Appelée UNIQUEMENT par la fonction serveur d'envoi. Elle rend, pour chaque notification pas
   encore poussée, autant de lignes que le destinataire a d'appareils — avec les clés nécessaires
   au chiffrement. Interdite depuis un navigateur : ces clés sont celles d'appareils d'autrui. */
create or replace function push_pending(p_limit int default 50)
returns table (
  notification_id uuid, subscription_id uuid, user_id uuid, type text, payload jsonb,
  created_at timestamptz, endpoint text, p256dh text, auth text
)
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;

  return query
    with a_pousser as (
      select n.id, n.user_id, n.type, n.payload, n.created_at
        from notifications n
       where n.pushed_at is null
         and n.push_attempts < 3
         -- Rien de vieux : une alerte de la semaine dernière qui arrive maintenant ne sert à
         -- rien et inquiète. Passé ce délai, la notification reste lisible dans le site.
         and n.created_at > now() - interval '2 days'
         and _push_destinataire_legitime(n.user_id, n.type)
       order by n.created_at
       limit greatest(1, least(coalesce(p_limit, 50), 200))
    )
    select p.id, s.id, p.user_id, p.type, p.payload, p.created_at, s.endpoint, s.p256dh, s.auth
      from a_pousser p
      join push_subscriptions s on s.user_id = p.user_id
     order by p.created_at;
end $$;
revoke all on function push_pending(int) from public, anon, authenticated;

/* Résultat d'un envoi, rapporté par la fonction serveur.
   p_echecs : les appareils dont le service a répondu « cette adresse n'existe plus » (404/410).
   Ils sont supprimés : un appareil désinstallé ne doit pas rester dans la table pour toujours. */
create or replace function push_mark_sent(p_notifications uuid[], p_echecs uuid[] default '{}')
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;

  delete from push_subscriptions where id = any(coalesce(p_echecs, '{}'));

  update notifications
     set pushed_at = now(), push_attempts = push_attempts + 1
   where id = any(coalesce(p_notifications, '{}')) and pushed_at is null;
  get diagnostics n = row_count;

  update push_subscriptions
     set last_ok_at = now(), failures = 0
   where user_id in (select user_id from notifications where id = any(coalesce(p_notifications, '{}')))
     and id <> all(coalesce(p_echecs, '{}'));

  return n;
end $$;
revoke all on function push_mark_sent(uuid[], uuid[]) from public, anon, authenticated;

/* Un envoi qui a échoué pour une raison passagère (service du navigateur indisponible) :
   on compte la tentative sans marquer la notification comme poussée. Au bout de trois, elle
   sort de la file et reste lisible dans le site. Sans ce compteur, une notification
   indéfiniment en échec serait réessayée pour toujours. */
create or replace function push_mark_failed(p_notifications uuid[])
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  update notifications set push_attempts = push_attempts + 1
   where id = any(coalesce(p_notifications, '{}')) and pushed_at is null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function push_mark_failed(uuid[]) from public, anon, authenticated;
