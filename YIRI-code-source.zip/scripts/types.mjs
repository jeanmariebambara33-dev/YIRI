// Vérifie les types du projet. esbuild RETIRE les annotations sans les contrôler : sans cette
// étape, une erreur de typage part en production sans un mot.
//
// Usage : node scripts/types.mjs
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const racine = path.resolve(import.meta.dirname, "..");
const candidats = [
  path.join(racine, "node_modules/typescript/bin/tsc"),
  "/opt/npm-tools/node_modules/typescript/bin/tsc",
];
const tsc = candidats.find((c) => fs.existsSync(c));
if (!tsc) {
  console.error("TypeScript introuvable. Installer : npm i -D typescript");
  process.exit(2);
}

try {
  execFileSync(process.execPath, [tsc, "-p", path.join(racine, "tsconfig.json")],
               { stdio: "inherit", cwd: racine });
  console.log("OK    aucune erreur de typage");
} catch {
  console.error("\nErreurs de typage ci-dessus. Elles ne font PAS échouer la construction : esbuild");
  console.error("ne contrôle pas les types. C'est ce contrôle-ci qui les attrape.");
  process.exit(1);
}
