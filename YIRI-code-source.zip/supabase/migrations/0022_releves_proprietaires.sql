-- YIRI — 0022 : les relevés de revenus des propriétaires sous gestion.
--
-- Constat de l'audit : le partage 60/40 était CALCULÉ et TESTÉ dans le code, et branché à aucun
-- écran. Les tables owner_statements et payouts existaient depuis la 0001 et n'avaient jamais
-- reçu une ligne. Conséquence : un propriétaire sous gestion YIRI ne voyait nulle part ce que
-- son logement lui rapportait, et YIRI n'avait aucune trace de ce qu'elle devait.
--
-- Ce fichier ne change AUCUNE règle de partage : il applique la règle du §8 du cahier des
-- charges, exactement comme computeRLP() et splitRevenue() le font dans src/lib/pricing.ts.
--
--   RLP = hébergement encaissé − remises − remboursements − taxes tiers − frais de paiement (si
--         le contrat le prévoit), avec un plancher à zéro
--   part propriétaire = 60 % du RLP, arrondie ; commission YIRI = le reste
--
-- Le partage est arrondi d'un seul côté, et la somme des deux parts égale TOUJOURS le RLP :
-- c'est une contrainte de la table depuis la 0001, pas une politesse du code.
--
-- Comment ça marche. L'équipe CLÔTURE une période pour un propriétaire : la base relit les
-- séjours réellement payés, calcule, et enregistre un relevé. Le propriétaire le voit dans son
-- espace. Le virement lui-même reste manuel — le prestataire ne permet pas de l'automatiser,
-- c'est la même contrainte que pour les remboursements — et l'équipe l'enregistre une fois fait.
--
-- Rien n'est calculé par le navigateur, et aucun montant ne lui est demandé.

-- =====================================================================
-- 0. Garde
-- =====================================================================
do $$
begin
  if to_regclass('public.owner_statements') is null then
    raise exception 'La migration 0001 n''est pas appliquée. Rien n''a été modifié.';
  end if;
  if to_regprocedure('public.create_refund(uuid,integer,text)') is null then
    raise exception 'La migration 0019 n''est pas appliquée. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Deux périodes identiques ne peuvent pas être clôturées deux fois
-- =====================================================================
-- Sans cela, une double clôture doublerait la somme due. C'est la base qui l'interdit, pas
-- l'écran : un double clic ne doit pas coûter de l'argent.
create unique index if not exists owner_statements_periode_idx
  on owner_statements (owner_id, period_start, period_end);

alter table owner_statements enable row level security;
alter table payouts enable row level security;

-- Le propriétaire lit SES relevés et SES versements. Personne d'autre, pas même un membre
-- d'équipe, ne passe par la table : l'équipe a ses propres fonctions.
drop policy if exists statements_self_read on owner_statements;
create policy statements_self_read on owner_statements for select using (owner_id = auth.uid());
drop policy if exists payouts_self_read on payouts;
create policy payouts_self_read on payouts for select
  using (owner_id = auth.uid());

revoke insert, update, delete on owner_statements from anon, authenticated;
revoke insert, update, delete on payouts from anon, authenticated;
grant select on owner_statements, payouts to authenticated;

-- =====================================================================
-- 2. Ce qu'une période a rapporté : le calcul, en un seul endroit
-- =====================================================================
-- Fonction interne, utilisée par l'aperçu ET par la clôture. Deux calculs séparés finiraient
-- par diverger, et l'écart se verrait sur un virement.
--
-- LE PARTAGE N'EST PAS 60 PARTOUT. Chaque contrat de gestion porte son propre pourcentage
-- (management_agreements.owner_percent, 60 par défaut depuis la 0001). Le calcul se fait donc
-- LOGEMENT PAR LOGEMENT, puis s'additionne : un propriétaire qui aurait négocié 65 % sur une
-- villa et 60 % sur un studio reçoit la somme juste, et non une moyenne approximative.
--
-- Les frais du prestataire de paiement ne sont PAS déduits de la part du propriétaire : la
-- règle du §8 ne les déduit que « si le contrat le prévoit », et aucune colonne ne porte cette
-- clause aujourd'hui. Par prudence, ils restent à la charge de YIRI. Le jour où la clause
-- existera, c'est ici qu'elle se branchera, et nulle part ailleurs.
create or replace function _owner_periode(p_owner uuid, p_debut date, p_fin date)
returns table (
  encaisse_xof int, remboursements_xof int, frais_xof int, rlp_xof int,
  part_proprietaire_xof int, commission_yiri_xof int,
  sejours int, logements int
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  return query
  with sejours_payes as (
    select b.id, b.property_id, b.accommodation_xof, b.discount_xof,
           coalesce(tx.fee_xof, 0) as frais,
           coalesce((select sum(f.amount_xof) from refunds f
                      where f.payment_transaction_id = tx.id
                        and f.status in ('approuve', 'en_cours', 'reussi')), 0) as rembourse
      from bookings b
      join properties p on p.id = b.property_id
      join payment_transactions tx on tx.booking_id = b.id and tx.status = 'reussi'
     where p.owner_id = p_owner
       -- Seules les offres où YIRI encaisse pour le propriétaire.
       and p.offer in ('gestion', 'partenariat')
       -- Rattachement à la période par la date de DÉPART : un séjour appartient au mois où il
       -- s'achève, sinon un séjour à cheval serait compté deux fois ou pas du tout.
       and upper(b.stay) > p_debut and upper(b.stay) <= p_fin
       and b.status in ('confirmee', 'en_cours', 'terminee')
  ),
  par_logement as (
    select s.property_id,
           sum(s.accommodation_xof)::int as encaisse,
           sum(s.discount_xof)::int as remises,
           sum(s.rembourse)::int as rembourse,
           sum(s.frais)::int as frais,
           count(*)::int as sejours,
           -- La formule du §8, plancher à zéro, appliquée au logement.
           greatest(0, sum(s.accommodation_xof) - sum(s.discount_xof) - sum(s.rembourse))::int as rlp,
           -- Le pourcentage du contrat EN VIGUEUR sur ce logement ; 60 si aucun contrat.
           coalesce((select ma.owner_percent from management_agreements ma
                      where ma.property_id = s.property_id
                        and ma.starts_on <= p_fin
                        and (ma.ends_on is null or ma.ends_on >= p_debut)
                      order by ma.starts_on desc limit 1), 60) as pct
      from sejours_payes s
     group by s.property_id
  )
  select
    coalesce(sum(l.encaisse), 0)::int,
    coalesce(sum(l.rembourse), 0)::int,
    coalesce(sum(l.frais), 0)::int,
    coalesce(sum(l.rlp), 0)::int,
    -- Arrondi par logement, vers le bas, puis additionné.
    coalesce(sum(floor(l.rlp * l.pct / 100.0)), 0)::int,
    -- La commission est TOUJOURS le reste : la somme des deux parts égale le RLP, exactement.
    coalesce(sum(l.rlp - floor(l.rlp * l.pct / 100.0)), 0)::int,
    coalesce(sum(l.sejours), 0)::int,
    count(*)::int
  from par_logement l;
end $$;
revoke all on function _owner_periode(uuid, date, date) from public, anon, authenticated;

/* Aperçu pour l'équipe : ce que donnerait la clôture, sans rien enregistrer. On regarde avant
   de signer. */
create or replace function statement_preview(p_owner uuid, p_debut date, p_fin date)
returns table (
  owner_id uuid, proprietaire text, encaisse_xof int, remboursements_xof int, frais_xof int,
  rlp_xof int, part_proprietaire_xof int, commission_yiri_xof int,
  sejours int, logements int, deja_cloture boolean
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare
  c record;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  if p_fin <= p_debut then
    raise exception 'La fin de période doit suivre son début.' using errcode = 'P0001';
  end if;

  select * into c from _owner_periode(p_owner, p_debut, p_fin);

  return query
    select p_owner, pr.full_name, c.encaisse_xof, c.remboursements_xof, c.frais_xof,
           c.rlp_xof, c.part_proprietaire_xof, c.commission_yiri_xof, c.sejours, c.logements,
           exists (select 1 from owner_statements s
                    where s.owner_id = p_owner and s.period_start = p_debut and s.period_end = p_fin)
      from profiles pr where pr.id = p_owner;
end $$;
revoke all on function statement_preview(uuid, date, date) from public, anon;
grant execute on function statement_preview(uuid, date, date) to authenticated;

-- =====================================================================
-- 3. Clôturer une période
-- =====================================================================
create or replace function close_owner_statement(
  p_owner uuid, p_debut date, p_fin date,
  p_depenses_proprietaire int default 0, p_couts_yiri int default 0
)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  c record;
  part int;
  commission int;
  du int;
  sid uuid;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  if p_fin <= p_debut then
    raise exception 'La fin de période doit suivre son début.' using errcode = 'P0001';
  end if;
  if p_fin > current_date then
    raise exception 'On ne clôture pas une période qui n''est pas terminée.' using errcode = 'P0001';
  end if;
  if coalesce(p_depenses_proprietaire, 0) < 0 or coalesce(p_couts_yiri, 0) < 0 then
    raise exception 'Les dépenses ne peuvent pas être négatives.' using errcode = 'P0001';
  end if;

  select * into c from _owner_periode(p_owner, p_debut, p_fin);
  if c.sejours = 0 then
    raise exception 'Aucun séjour payé sur cette période : il n''y a rien à clôturer.' using errcode = 'P0001';
  end if;

  part := c.part_proprietaire_xof;
  commission := c.commission_yiri_xof;     -- la somme des deux égale toujours le RLP
  du := part - coalesce(p_depenses_proprietaire, 0);   -- peut être négatif : à régulariser

  insert into owner_statements (owner_id, period_start, period_end, rlp_xof,
                                owner_share_xof, yiri_commission_xof, owner_expenses_xof,
                                amount_due_xof, status)
  values (p_owner, p_debut, p_fin, c.rlp_xof, part, commission,
          coalesce(p_depenses_proprietaire, 0), du, 'a_valider')
  returning id into sid;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'statement.closed', 'owner_statement', sid::text,
          jsonb_build_object('proprietaire', p_owner, 'debut', p_debut, 'fin', p_fin,
                             'rlp', c.rlp_xof, 'part', part, 'commission', commission,
                             'depenses', coalesce(p_depenses_proprietaire, 0), 'du', du,
                             'sejours', c.sejours));

  insert into notifications (user_id, type, payload)
  values (p_owner, 'statement.disponible',
          jsonb_build_object('releve', sid, 'debut', p_debut, 'fin', p_fin,
                             'montant', du, 'sejours', c.sejours));

  return sid;
end $$;
revoke all on function close_owner_statement(uuid, date, date, int, int) from public, anon;
grant execute on function close_owner_statement(uuid, date, date, int, int) to authenticated;

-- =====================================================================
-- 4. Enregistrer le versement, une fois le virement fait à la main
-- =====================================================================
create or replace function register_payout(
  p_statement uuid, p_montant int, p_destination_masquee text, p_reference text
)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  st owner_statements%rowtype;
  pid uuid;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;

  select * into st from owner_statements where id = p_statement for update;
  if not found then
    raise exception 'Relevé introuvable.' using errcode = 'P0001';
  end if;
  if st.status = 'verse' then
    raise exception 'Ce relevé est déjà réglé.' using errcode = 'P0001';
  end if;
  if p_montant is null or p_montant <= 0 then
    raise exception 'Montant invalide.' using errcode = 'P0001';
  end if;
  if st.amount_due_xof <= 0 then
    raise exception 'Ce relevé ne laisse rien à verser (montant dû nul ou négatif).' using errcode = 'P0001';
  end if;
  if p_montant > st.amount_due_xof - st.amount_paid_xof then
    raise exception 'Montant supérieur à ce qui reste dû (% FCFA).',
      st.amount_due_xof - st.amount_paid_xof using errcode = 'P0001';
  end if;
  if coalesce(btrim(p_destination_masquee), '') = '' or coalesce(btrim(p_reference), '') = '' then
    raise exception 'La destination et la référence du virement sont obligatoires : elles tracent le paiement.' using errcode = 'P0001';
  end if;

  insert into payouts (owner_id, statement_id, amount_xof, destination_masked,
                       provider_reference, status, validated_by, paid_at)
  values (st.owner_id, st.id, p_montant, btrim(p_destination_masquee),
          btrim(p_reference), 'verse', uid, now())
  returning id into pid;

  update owner_statements
     set amount_paid_xof = amount_paid_xof + p_montant,
         status = (case when amount_paid_xof + p_montant >= amount_due_xof then 'verse' else 'en_cours' end)::payout_status
   where id = st.id;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after, reason)
  values (uid, 'payout.registered', 'payout', pid::text,
          jsonb_build_object('releve', st.id, 'montant', p_montant, 'proprietaire', st.owner_id),
          left(btrim(p_reference), 200));

  insert into notifications (user_id, type, payload)
  values (st.owner_id, 'payout.verse',
          jsonb_build_object('releve', st.id, 'montant', p_montant));

  return pid;
end $$;
revoke all on function register_payout(uuid, int, text, text) from public, anon;
grant execute on function register_payout(uuid, int, text, text) to authenticated;

-- =====================================================================
-- 5. Ce que chacun voit
-- =====================================================================
/* Le propriétaire : ses relevés, avec le détail du calcul. Rien de caché — il doit pouvoir
   vérifier lui-même comment sa part a été obtenue. */
create or replace function my_statements()
returns table (
  id uuid, period_start date, period_end date, rlp_xof int, owner_share_xof int,
  yiri_commission_xof int, owner_expenses_xof int, amount_due_xof int,
  amount_paid_xof int, status text, verse_le timestamptz, reference text
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select s.id, s.period_start, s.period_end, s.rlp_xof, s.owner_share_xof,
           s.yiri_commission_xof, s.owner_expenses_xof, s.amount_due_xof,
           s.amount_paid_xof, s.status::text,
           (select max(po.paid_at) from payouts po where po.statement_id = s.id),
           (select max(po.provider_reference) from payouts po where po.statement_id = s.id)
      from owner_statements s
     where s.owner_id = uid
     order by s.period_end desc;
end $$;
revoke all on function my_statements() from public, anon;
grant execute on function my_statements() to authenticated;

/* L'équipe : les relevés à régler, les plus anciens d'abord. */
create or replace function statements_queue(p_limit int default 100)
returns table (
  id uuid, owner_id uuid, proprietaire text, telephone text,
  period_start date, period_end date, rlp_xof int, owner_share_xof int,
  yiri_commission_xof int, owner_expenses_xof int, amount_due_xof int,
  amount_paid_xof int, status text
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return query
    select s.id, s.owner_id, pr.full_name, pr.phone,
           s.period_start, s.period_end, s.rlp_xof, s.owner_share_xof,
           s.yiri_commission_xof, s.owner_expenses_xof, s.amount_due_xof,
           s.amount_paid_xof, s.status::text
      from owner_statements s
      join profiles pr on pr.id = s.owner_id
     order by (s.status = 'verse'), s.period_end
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function statements_queue(int) from public, anon;
grant execute on function statements_queue(int) to authenticated;

/* Les propriétaires sous gestion qui ont des séjours payés non encore clôturés : la liste de
   travail de l'équipe. Sans elle, il faudrait deviner qui clôturer. */
create or replace function owners_to_settle()
returns table (owner_id uuid, proprietaire text, telephone text, logements int,
               sejours_non_clotures int, dernier_depart date)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return query
    select p.owner_id, pr.full_name, pr.phone,
           count(distinct p.id)::int, count(*)::int, max(upper(b.stay))
      from bookings b
      join properties p on p.id = b.property_id
      join profiles pr on pr.id = p.owner_id
      join payment_transactions tx on tx.booking_id = b.id and tx.status = 'reussi'
     where p.offer in ('gestion', 'partenariat')
       and b.status in ('confirmee', 'en_cours', 'terminee')
       and upper(b.stay) <= current_date
       and not exists (
         select 1 from owner_statements s
          where s.owner_id = p.owner_id
            and upper(b.stay) > s.period_start and upper(b.stay) <= s.period_end)
     group by p.owner_id, pr.full_name, pr.phone
     order by max(upper(b.stay));
end $$;
revoke all on function owners_to_settle() from public, anon;
grant execute on function owners_to_settle() to authenticated;

-- =====================================================================
-- 6. Ces deux alertes méritent un courriel
-- =====================================================================
-- Un relevé prêt et un virement effectué sont exactement ce qu'un propriétaire veut apprendre
-- sans avoir à ouvrir le site. La liste est redéfinie en entier : elle n'est lisible que d'un
-- seul endroit, et une liste partielle retirerait les anciens types en silence.
create or replace function _email_eligible(p_type text)
returns boolean
language sql immutable set search_path = public, pg_temp as $$
  select p_type in (
    'booking.confirmee.voyageur', 'booking.annulee.voyageur', 'refund.enregistre',
    'booking.confirmee', 'booking.annulee',
    'listing.approuvee', 'listing.publiee', 'listing.a_corriger', 'listing.refusee', 'listing.suspendue',
    'subscription.bientot_expiree', 'subscription.expire_demain', 'subscription.expiree',
    'subscription.offerte', 'free_pass.offert', 'free_pass.retire',
    'booking.confirmee.equipe', 'refund.a_examiner.equipe',
    -- 0022
    'statement.disponible', 'payout.verse'
  );
$$;
revoke all on function _email_eligible(text) from public, anon, authenticated;
