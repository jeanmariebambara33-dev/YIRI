-- YIRI — 0010 : annulation par le voyageur et remboursement automatique.
--
-- Décisions du fondateur reprises telles quelles :
--   * SEUL le voyageur peut demander un remboursement (ni le propriétaire, ni l'équipe à sa place) ;
--   * le barème est dégressif selon le délai avant l'arrivée ;
--   * les frais d'encaissement du prestataire sont supportés par le voyageur, retenus sur son remboursement ;
--   * le remboursement part automatiquement, sans validation humaine, quel que soit le montant.
--
-- Deux garde-fous que j'ajoute, parce qu'un remboursement automatique fait sortir de l'argent :
--   1. un plafond sur le TOTAL d'une journée. En dessous, tout part automatiquement. Au-dessus, les
--      remboursements suivants attendent l'équipe. En fonctionnement normal il ne se déclenche jamais :
--      il n'existe que pour qu'une faille ou un bug ne puisse pas vider le solde pendant la nuit ;
--   2. l'argent ne repart QUE vers le compte qui a payé, mémorisé au moment de l'encaissement.
--      Si ce compte est inconnu, le remboursement passe en file d'attente au lieu de partir à l'aveugle.
--      Sans cette règle, il suffirait de réserver puis d'annuler en indiquant le numéro de son choix.
--
-- Le barème est une TABLE, pas du code : tu changes les chiffres sans nouvelle migration.
--
-- Rien n'est supprimé, aucune fonction existante n'est redéfinie. 0009 reste intact.

-- =====================================================================
-- 0. Garde : 0010 s'appuie sur 0009
-- =====================================================================
-- Appliquée seule, 0010 échouerait sur une erreur technique peu lisible. Ce contrôle
-- s'arrête avant d'avoir rien modifié, avec un message qui dit quoi faire.
do $$
begin
  if to_regclass('public.payment_attempts') is null then
    raise exception 'La migration 0009 n''est pas appliquée. Appliquez 0009 d''abord, puis relancez 0010. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Le barème, modifiable par l'administrateur
-- =====================================================================
create table if not exists refund_rules (
  id boolean primary key default true check (id),            -- une seule ligne possible
  far_days int not null default 7 check (far_days between 1 and 365),
  far_pct int not null default 100 check (far_pct between 0 and 100),
  mid_days int not null default 2 check (mid_days between 0 and 365),
  mid_pct int not null default 50 check (mid_pct between 0 and 100),
  near_pct int not null default 0 check (near_pct between 0 and 100),
  started_pct int not null default 0 check (started_pct between 0 and 100),
  daily_cap_xof int not null default 500000 check (daily_cap_xof >= 0),
  updated_at timestamptz not null default now(),
  updated_by uuid references profiles(id),
  check (mid_days <= far_days),
  check (near_pct <= mid_pct and mid_pct <= far_pct)         -- un barème incohérent est refusé
);
insert into refund_rules (id) values (true) on conflict (id) do nothing;

alter table refund_rules enable row level security;
revoke all on refund_rules from public, anon, authenticated;

-- =====================================================================
-- 2. Compléments de colonnes
-- =====================================================================
-- Le registre des remboursements de 0001 n'a pas de date : elle est indispensable au plafond journalier.
alter table refunds add column if not exists created_at timestamptz not null default now();
alter table refunds add column if not exists settled_at timestamptz;
alter table refunds add column if not exists failure_reason text;

-- Un même encaissement ne peut donner lieu qu'à UN remboursement vivant.
-- Un remboursement échoué ne bloque pas une nouvelle tentative.
create unique index if not exists refunds_one_live_per_tx
  on refunds (payment_transaction_id) where (status <> 'echoue');

alter table refunds enable row level security;              -- déjà activé en 0001, on le réaffirme
revoke all on refunds from public, anon, authenticated;     -- aucun accès direct : tout passe par les fonctions

-- Le compte qui a payé, mémorisé au moment de l'encaissement. C'est la seule destination autorisée
-- pour un remboursement. Rempli par la fonction serveur du prestataire, jamais par le navigateur.
alter table payment_attempts add column if not exists payer_account text;

-- L'identifiant que le prestataire donne à l'opération. Il ne reprend pas forcément notre référence :
-- sans ce lien, un message reçu de sa part serait impossible à rattacher à la bonne réservation.
alter table payment_attempts add column if not exists provider_id text;
create unique index if not exists payment_attempts_provider_id_idx
  on payment_attempts (provider_id) where (provider_id is not null);

-- =====================================================================
-- 3. Lecture du barème
-- =====================================================================
/* Le voyageur doit pouvoir lire les conditions d'annulation AVANT de réserver. */
create or replace function refund_rules_public()
returns table (far_days int, far_pct int, mid_days int, mid_pct int, near_pct int, started_pct int)
language sql stable security definer set search_path = public, pg_temp as $$
  select r.far_days, r.far_pct, r.mid_days, r.mid_pct, r.near_pct, r.started_pct from refund_rules r where r.id;
$$;
revoke all on function refund_rules_public() from public;
grant execute on function refund_rules_public() to anon, authenticated;   -- le plafond journalier n'est PAS exposé

/* Modification du barème : administrateur uniquement, et chaque changement est tracé. */
create or replace function set_refund_rules(
  p_far_days int, p_far_pct int, p_mid_days int, p_mid_pct int,
  p_near_pct int, p_started_pct int, p_daily_cap_xof int
) returns refund_rules
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  avant jsonb;
  apres refund_rules%rowtype;
begin
  if not has_role('admin') then
    raise exception 'Seul un administrateur peut modifier le barème d''annulation.' using errcode = '42501';
  end if;
  select to_jsonb(r) into avant from refund_rules r where r.id;

  update refund_rules set
    far_days = p_far_days, far_pct = p_far_pct,
    mid_days = p_mid_days, mid_pct = p_mid_pct,
    near_pct = p_near_pct, started_pct = p_started_pct,
    daily_cap_xof = p_daily_cap_xof,
    updated_at = now(), updated_by = uid
  where id returning * into apres;

  insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
  values (uid, 'refund_rules.update', 'refund_rules', 'true', avant, to_jsonb(apres));
  return apres;
end $$;
revoke all on function set_refund_rules(int, int, int, int, int, int, int) from public, anon;
grant execute on function set_refund_rules(int, int, int, int, int, int, int) to authenticated;

-- =====================================================================
-- 4. Calcul du remboursement — même formule partout
-- =====================================================================
/* Une seule source de vérité pour le montant. Appelée par l'affichage ET par l'annulation :
   le voyageur voit exactement ce qu'il recevra, impossible qu'un écran promette autre chose. */
create or replace function refund_quote(p_booking_id uuid)
returns table (
  gross_xof int,          -- ce qui a été encaissé
  rate_pct int,           -- taux appliqué par le barème
  fees_xof int,           -- frais du prestataire, retenus sur le remboursement
  net_xof int,            -- ce que le voyageur recevra réellement
  tier text,              -- 'loin' | 'moyen' | 'proche' | 'commence'
  days_before int,
  cancellable boolean,
  reason text
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  tx payment_transactions%rowtype;
  r refund_rules%rowtype;
  d int;
  pct int;
  t text;
  f int;
  g int;
  n int;
  ok boolean := true;
  why text := null;
begin
  select * into bk from bookings where id = p_booking_id;
  if not found then
    raise exception 'Réservation introuvable.' using errcode = 'P0001';
  end if;
  -- Le voyageur concerné, ou l'équipe habilitée aux paiements. Personne d'autre.
  if bk.guest_id <> uid and not has_perm('paiements') then
    raise exception 'Cette réservation n''est pas la vôtre.' using errcode = '42501';
  end if;

  select * into r from refund_rules where id;
  d := lower(bk.stay) - current_date;

  -- L'encaissement réussi rattaché à cette réservation, s'il existe.
  select * into tx from payment_transactions
   where booking_id = bk.id and status = 'reussi'
   order by updated_at desc limit 1;
  g := coalesce(tx.amount_xof, 0);
  f := coalesce(tx.fee_xof, 0);

  if d <= 0 then t := 'commence'; pct := r.started_pct;
  elsif d > r.far_days then t := 'loin'; pct := r.far_pct;
  elsif d >= r.mid_days then t := 'moyen'; pct := r.mid_pct;
  else t := 'proche'; pct := r.near_pct;
  end if;

  -- Arrondi vers le bas : jamais plus que ce que le barème autorise.
  n := greatest(0, (g * pct) / 100 - f);
  -- Un remboursement ne peut en aucun cas dépasser ce qui a été encaissé.
  n := least(n, g);

  if bk.status in ('annulee', 'terminee', 'refusee', 'expiree') then
    ok := false; why := 'Cette réservation est déjà close.';
  elsif bk.status = 'en_cours' then
    ok := false; why := 'Le séjour est en cours : contactez-nous, l''annulation ne se fait plus en ligne.';
  elsif bk.status = 'litige' then
    ok := false; why := 'Cette réservation est en litige : elle est traitée manuellement.';
  end if;

  return query select g, pct, f, n, t, d, ok, why;
end $$;
revoke all on function refund_quote(uuid) from public, anon;
grant execute on function refund_quote(uuid) to authenticated;

-- =====================================================================
-- 5. Annulation par le voyageur
-- =====================================================================
/* Le voyageur annule lui-même. Le remboursement est créé dans la foulée et part automatiquement,
   sauf si l'un des deux garde-fous s'applique — dans ce cas il attend l'équipe au lieu d'être perdu. */
create or replace function cancel_my_booking(p_booking_id uuid, p_reason text default null)
returns table (booking_status text, refund_id uuid, net_xof int, mode text)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  tx payment_transactions%rowtype;
  r refund_rules%rowtype;
  q record;
  deja int;
  compte text;
  rid uuid := null;
  md text;
begin
  select * into bk from bookings where id = p_booking_id for update;
  if not found then
    raise exception 'Réservation introuvable.' using errcode = 'P0001';
  end if;

  -- LA règle demandée : seul le voyageur de cette réservation peut annuler et déclencher un remboursement.
  if bk.guest_id <> uid then
    raise exception 'Seul le voyageur de cette réservation peut l''annuler.' using errcode = '42501';
  end if;

  select * into q from refund_quote(p_booking_id);
  if not q.cancellable then
    raise exception '%', q.reason using errcode = 'P0001';
  end if;

  select * into r from refund_rules where id;

  update bookings set status = 'annulee', hold_expires_at = null where id = bk.id;

  insert into audit_logs (actor_id, action, entity_type, entity_id, before, after, reason)
  values (uid, 'booking.cancelled_by_guest', 'booking', bk.id::text,
          jsonb_build_object('statut', bk.status),
          jsonb_build_object('statut', 'annulee', 'palier', q.tier, 'taux', q.rate_pct,
                             'encaisse', q.gross_xof, 'frais', q.fees_xof, 'net', q.net_xof),
          left(coalesce(p_reason, 'Annulation par le voyageur'), 200));

  -- Rien n'a été encaissé, ou le barème ne laisse rien : pas de remboursement à créer.
  if q.gross_xof = 0 or q.net_xof = 0 then
    return query select 'annulee'::text, null::uuid, 0, 'sans_remboursement'::text;
    return;
  end if;

  select * into tx from payment_transactions
   where booking_id = bk.id and status = 'reussi' order by updated_at desc limit 1;

  -- Garde-fou 2 : la destination doit être le compte qui a payé.
  select a.payer_account into compte from payment_attempts a
   where a.reference = tx.provider_reference;

  -- Garde-fou 1 : le total remboursé aujourd'hui.
  select coalesce(sum(amount_xof), 0) into deja from refunds
   where status in ('approuve', 'en_cours', 'reussi') and created_at >= current_date;

  if compte is null or btrim(compte) = '' then
    md := 'attente_equipe_compte_inconnu';
  elsif deja + q.net_xof > r.daily_cap_xof then
    md := 'attente_equipe_plafond_journalier';
  else
    md := 'automatique';
  end if;

  insert into refunds (payment_transaction_id, amount_xof, reason, status)
  values (tx.id, q.net_xof,
          left(coalesce(p_reason, 'Annulation par le voyageur') || ' (' || q.tier || ', ' || q.rate_pct || '%)', 200),
          case when md = 'automatique' then 'approuve' else 'demande' end)
  returning id into rid;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'refund.requested', 'refund', rid::text,
          jsonb_build_object('montant', q.net_xof, 'mode', md, 'reservation', bk.id));

  -- Mis en attente : l'équipe le voit en tête de refunds_queue(), rien d'autre à créer.
  if md <> 'automatique' then
    insert into audit_logs (actor_id, action, entity_type, entity_id, reason)
    values (uid, 'refund.held', 'refund', rid::text,
            case md when 'attente_equipe_compte_inconnu'
                      then 'Compte du payeur inconnu : vérification requise avant versement.'
                    else 'Plafond journalier de remboursement atteint : vérification requise.' end);
  end if;

  insert into notifications (user_id, type, payload)
  values (uid, 'refund.' || md, jsonb_build_object('reservation', bk.id, 'montant', q.net_xof));

  return query select 'annulee'::text, rid, q.net_xof, md;
end $$;
revoke all on function cancel_my_booking(uuid, text) from public, anon;
grant execute on function cancel_my_booking(uuid, text) to authenticated;

-- =====================================================================
-- 6. Suivi pour le voyageur et pour l'équipe
-- =====================================================================
create or replace function my_refunds()
returns table (id uuid, booking_id uuid, amount_xof int, status text, created_at timestamptz,
               settled_at timestamptz, failure_reason text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select f.id, t.booking_id, f.amount_xof, f.status, f.created_at, f.settled_at, f.failure_reason
      from refunds f
      join payment_transactions t on t.id = f.payment_transaction_id
      join bookings b on b.id = t.booking_id
     where b.guest_id = uid
     order by f.created_at desc;
end $$;
revoke all on function my_refunds() from public, anon;
grant execute on function my_refunds() to authenticated;

create or replace function refunds_queue(p_limit int default 50)
returns table (id uuid, booking_id uuid, guest_id uuid, amount_xof int, status text,
               reason text, created_at timestamptz, settled_at timestamptz,
               provider_reference text, payer_known boolean)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return query
    select f.id, t.booking_id, b.guest_id, f.amount_xof, f.status, f.reason, f.created_at, f.settled_at,
           f.provider_reference,
           (a.payer_account is not null and btrim(a.payer_account) <> '')
      from refunds f
      join payment_transactions t on t.id = f.payment_transaction_id
      join bookings b on b.id = t.booking_id
      left join payment_attempts a on a.reference = t.provider_reference
     order by (f.status = 'demande') desc, f.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200));
end $$;
revoke all on function refunds_queue(int) from public, anon;
grant execute on function refunds_queue(int) to authenticated;

/* Déblocage manuel d'un remboursement mis en attente par un garde-fou. */
create or replace function approve_refund(p_refund_id uuid)
returns refunds
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  f refunds%rowtype;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  select * into f from refunds where id = p_refund_id for update;
  if not found then
    raise exception 'Remboursement introuvable.' using errcode = 'P0001';
  end if;
  if f.status <> 'demande' then
    raise exception 'Ce remboursement n''est plus en attente (statut : %).', f.status using errcode = 'P0001';
  end if;
  update refunds set status = 'approuve', approved_by = uid where id = p_refund_id returning * into f;
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'refund.approved', 'refund', p_refund_id::text, jsonb_build_object('montant', f.amount_xof));
  return f;
end $$;
revoke all on function approve_refund(uuid) from public, anon;
grant execute on function approve_refund(uuid) to authenticated;

-- =====================================================================
-- 7. Exécution du versement — réservée à la clé de service
-- =====================================================================
/* Mémorise le compte qui a payé. Appelée par la fonction serveur quand le prestataire confirme
   l'encaissement. C'est la seule destination qu'un remboursement pourra prendre. */
create or replace function set_payment_payer(p_reference text, p_account text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  if p_account is null or btrim(p_account) = '' then
    return;
  end if;
  -- Écrit une seule fois : le compte du payeur ne se change pas après coup.
  update payment_attempts set payer_account = btrim(p_account)
   where reference = p_reference and payer_account is null;
end $$;
revoke all on function set_payment_payer(text, text) from public, anon, authenticated;

/* Enregistre l'identifiant que le prestataire a donné à l'opération, juste après l'avoir créée.
   Écrit une seule fois : un identifiant déjà posé ne se remplace pas. */
create or replace function link_payment_provider_id(p_reference text, p_provider_id text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  if p_provider_id is null or btrim(p_provider_id) = '' then
    raise exception 'Identifiant du prestataire manquant.' using errcode = 'P0001';
  end if;
  update payment_attempts set provider_id = btrim(p_provider_id)
   where reference = p_reference and provider_id is null;
  if not found then
    raise exception 'Référence inconnue, ou identifiant déjà enregistré : %', p_reference using errcode = 'P0001';
  end if;
end $$;
revoke all on function link_payment_provider_id(text, text) from public, anon, authenticated;

/* Retrouve NOTRE référence à partir de l'identifiant du prestataire. C'est le point d'entrée
   de tout message reçu de sa part. */
create or replace function payment_reference_of(p_provider_id text)
returns text
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare r text;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  select reference into r from payment_attempts where provider_id = btrim(p_provider_id);
  return r;
end $$;
revoke all on function payment_reference_of(text) from public, anon, authenticated;

/* Mémorise les frais réellement prélevés par le prestataire, car ils entrent dans le calcul
   du remboursement (le voyageur les supporte).

   ATTENTION, il y a deux façons de prélever les frais et elles ne se traitent PAS pareil :
     * DEDUCTED : le prestataire retient ses frais sur la somme encaissée. YIRI reçoit moins que
       le prix affiché. Les frais sont donc à retenir sur le remboursement, sinon YIRI rembourse
       plus qu'elle n'a reçu.
     * ADD_ON  : le prestataire ajoute ses frais par-dessus. Le voyageur a déjà payé les frais
       séparément et YIRI a reçu la totalité du prix. Les retenir une seconde fois sur le
       remboursement les ferait payer deux fois au voyageur. On enregistre donc 0. */
create or replace function record_payment_fee(p_reference text, p_fee_xof int, p_mode text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  update payment_transactions
     set fee_xof = case when upper(coalesce(p_mode, '')) = 'DEDUCTED' then greatest(0, coalesce(p_fee_xof, 0)) else 0 end,
         updated_at = now()
   where provider_reference = p_reference;
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (null, 'payment.fee_recorded', 'payment', p_reference,
          jsonb_build_object('frais', coalesce(p_fee_xof, 0), 'mode', upper(coalesce(p_mode, 'INCONNU'))));
end $$;
revoke all on function record_payment_fee(text, int, text) from public, anon, authenticated;

/* La liste de ce qui doit partir, avec la destination. Fermée aux clients. */
create or replace function refunds_to_pay(p_limit int default 20)
returns table (id uuid, amount_xof int, payer_account text, booking_id uuid, source_reference text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  return query
    select f.id, f.amount_xof, a.payer_account, t.booking_id, t.provider_reference
      from refunds f
      join payment_transactions t on t.id = f.payment_transaction_id
      join payment_attempts a on a.reference = t.provider_reference
     where f.status = 'approuve'
       and a.payer_account is not null and btrim(a.payer_account) <> ''
     order by f.created_at
     limit greatest(1, least(coalesce(p_limit, 20), 100));
end $$;
revoke all on function refunds_to_pay(int) from public, anon, authenticated;

/* Le versement a été demandé au prestataire : on note sa référence pour pouvoir le rapprocher. */
create or replace function start_refund_payout(p_refund_id uuid, p_provider_reference text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  update refunds set status = 'en_cours', provider_reference = p_provider_reference
   where id = p_refund_id and status = 'approuve';
  get diagnostics n = row_count;
  if n = 0 then
    raise exception 'Remboursement non approuvé ou déjà en cours : rien n''a été envoyé.' using errcode = 'P0001';
  end if;
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (null, 'refund.payout_started', 'refund', p_refund_id::text,
          jsonb_build_object('reference', p_provider_reference));
end $$;
revoke all on function start_refund_payout(uuid, text) from public, anon, authenticated;

/* Le prestataire confirme que l'argent est parti. On écrit alors, et alors seulement, au registre. */
create or replace function confirm_refund_paid(p_provider_reference text, p_amount_xof int)
returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  f refunds%rowtype;
  bid uuid;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  select * into f from refunds where provider_reference = p_provider_reference for update;
  if not found then
    raise exception 'Référence de remboursement inconnue : %', p_provider_reference;
  end if;
  if f.status = 'reussi' then
    return 'deja_confirme';              -- message rejoué : on ne débite qu'une fois
  end if;
  -- Écart de montant : on NE LÈVE PAS d'exception, sinon la trace serait annulée avec la transaction
  -- et il ne resterait rien de l'incident. On écrit, on renvoie « ecart », et l'équipe reprend la main.
  if p_amount_xof is distinct from f.amount_xof then
    update refunds set failure_reason =
      'Montant versé ' || p_amount_xof || ' au lieu de ' || f.amount_xof || ' : vérification requise.'
     where id = f.id;
    insert into audit_logs (actor_id, action, entity_type, entity_id, after, reason)
    values (null, 'refund.amount_mismatch', 'refund', f.id::text,
            jsonb_build_object('attendu', f.amount_xof, 'recu', p_amount_xof),
            'Montant remboursé différent du montant approuvé : traitement manuel requis.');
    return 'ecart';
  end if;

  update refunds set status = 'reussi', settled_at = now() where id = f.id;

  select t.booking_id into bid from payment_transactions t where t.id = f.payment_transaction_id;
  insert into financial_ledger (booking_id, transaction_id, entry_type, debit_xof, description)
  values (bid, f.payment_transaction_id, 'remboursement', f.amount_xof,
          'Remboursement au voyageur — ' || p_provider_reference);

  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (null, 'refund.paid', 'refund', f.id::text,
          jsonb_build_object('montant', f.amount_xof, 'reference', p_provider_reference));

  insert into notifications (user_id, type, payload)
  select b.guest_id, 'refund.paid', jsonb_build_object('montant', f.amount_xof, 'reservation', b.id)
    from payment_transactions t join bookings b on b.id = t.booking_id
   where t.id = f.payment_transaction_id;

  return 'confirme';
end $$;
revoke all on function confirm_refund_paid(text, int) from public, anon, authenticated;

/* Le versement a échoué chez le prestataire : on referme sans débiter, l'équipe reprend la main. */
create or replace function fail_refund(p_provider_reference text, p_reason text default null)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare f refunds%rowtype;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  select * into f from refunds where provider_reference = p_provider_reference for update;
  if not found then
    return;
  end if;
  if f.status = 'reussi' then
    return;                              -- déjà payé : on ne le marque pas en échec
  end if;
  update refunds set status = 'echoue', settled_at = now(),
                     failure_reason = left(coalesce(p_reason, 'Versement non abouti'), 200)
   where id = f.id;
  insert into audit_logs (actor_id, action, entity_type, entity_id, reason)
  values (null, 'refund.failed', 'refund', f.id::text, left(coalesce(p_reason, 'Versement non abouti'), 200));
end $$;
revoke all on function fail_refund(text, text) from public, anon, authenticated;
