-- Tests de la migration 0006 (fonctions serveur) : faux utilisateurs, scénarios négatifs, doubles traitements.
-- Exécutés sur une base LOCALE vide (voir run-local.sh). Les « auth.uid() » sont simulés ; aucune vraie API n'est utilisée.
\o /dev/null
\ir helpers.sql

-- ====================== Données de test (administrateur de la base) ======================
-- Utilisateurs : 1=voyageur A, 2=voyageur B, 3=propriétaire O1, 4=propriétaire O2, 5=ADMIN,
-- 6=équipe « validation » (aussi propriétaire de p10), 7=équipe « reservations », 8=équipe « paiements » (aussi propriétaire de p9),
-- 9=équipe « audit », 10=équipe « demandes », 11..12..16=voyageurs, 13=membre sans permission (délégation testée), 14=voyageur C
insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 16) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(4), 'proprietaire'), (t.u(5), 'admin'),
  (t.u(6), 'proprietaire'), (t.u(8), 'proprietaire');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'reservations', t.u(5)), (t.u(8), 'paiements', t.u(5)),
  (t.u(9), 'audit', t.u(5)), (t.u(10), 'demandes', t.u(5));

create function t.mkprop(n int, owner int, offer offer_type, st listing_status, price int, cap int, minn int,
                         contact boolean, photo boolean, photo_ok boolean) returns void language plpgsql as $$
begin
  insert into properties (id, owner_id, offer, title, description, city, district, private_address, capacity,
                          bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
  values (t.p(n), t.u(owner), offer, 'Logement ' || n, 'desc', 'Ouagadougou', 'Centre', 'adresse ' || n, cap, 1, 1, price, minn, st, false);
  if contact then
    insert into property_contacts (property_id, contact_name, phone, whatsapp) values (t.p(n), 'Contact ' || n, '+226 70 00 00 ' || lpad(n::text, 2, '0'), true);
  end if;
  if photo then
    insert into property_photos (property_id, storage_path, position, rights_checked)
    values (t.p(n), t.u(owner) || '/' || t.p(n) || '/a.jpg', 0, photo_ok);
  end if;
end $$;

--                  n  prop offre        statut       prix   cap min contact photo ok
select t.mkprop(1,  3, 'annonce', 'publiee',    18000, 4, 1, true,  true, true);
select t.mkprop(2,  4, 'annonce', 'publiee',    15000, 3, 1, true,  true, true);
select t.mkprop(3,  3, 'gestion', 'publiee',    50000, 6, 1, false, true, true);
select t.mkprop(4,  4, 'gestion', 'publiee',    30000, 4, 2, false, true, true);
select t.mkprop(5,  3, 'gestion', 'brouillon',  40000, 4, 1, false, true, true);
select t.mkprop(6,  3, 'annonce', 'approuvee',  10000, 2, 1, true,  true, true);
select t.mkprop(7,  3, 'annonce', 'approuvee',  10000, 2, 1, true,  true, true);
select t.mkprop(8,  3, 'annonce', 'approuvee',  10000, 2, 1, true,  true, false);  -- aucune photo vérifiée
select t.mkprop(9,  8, 'annonce', 'approuvee',  10000, 2, 1, true,  true, true);   -- appartient à un membre « paiements »
select t.mkprop(10, 6, 'annonce', 'soumise',    10000, 2, 1, true,  true, true);   -- appartient à un membre « validation »
select t.mkprop(11, 3, 'annonce', 'soumise',    10000, 2, 1, true,  true, true);
select t.mkprop(12, 3, 'annonce', 'brouillon',  10000, 2, 1, false, false, false);
select t.mkprop(13, 4, 'annonce', 'soumise',    10000, 2, 1, true,  true, true);
select t.mkprop(14, 4, 'gestion', 'approuvee',  25000, 4, 1, false, true, true);
select t.mkprop(15, 4, 'gestion', 'approuvee',  25000, 4, 1, false, true, true);
select t.mkprop(16, 3, 'annonce', 'publiee',    10000, 2, 1, true,  true, true);   -- abonnement expiré
select t.mkprop(n, 4, 'annonce', 'publiee', 10000, 2, 1, true, true, true) from generate_series(20, 31) n;
insert into management_agreements (property_id, contract_version, starts_on, signed, operational_check_done, expense_policy_version)
  select t.p(n), 'v1', current_date, true, true, 'v1' from unnest(array[3, 4, 14]) n;
insert into management_agreements (property_id, contract_version, starts_on, signed, operational_check_done, expense_policy_version)
  values (t.p(15), 'v1', current_date, false, false, 'v1');
insert into subscriptions (owner_id, property_id, plan, amount_xof, status, starts_at, ends_at)
  values (t.u(3), t.p(1), 'mensuel', 5000, 'actif', current_date - 1, current_date + 30),
         (t.u(4), t.p(2), 'mensuel', 5000, 'actif', current_date - 20, current_date + 10),
         (t.u(3), t.p(16), 'mensuel', 5000, 'actif', current_date - 40, current_date - 1);
insert into subscriptions (owner_id, property_id, plan, amount_xof, status, starts_at, ends_at)
  select t.u(4), t.p(n), 'mensuel', 5000, 'actif', current_date - 1, current_date + 30 from generate_series(20, 31) n;
insert into subscriptions (id, owner_id, property_id, plan, amount_xof, status) values
  ('cccccccc-0000-0000-0000-000000000006', t.u(3), t.p(6), 'mensuel', 5000, 'en_attente_paiement'),
  ('cccccccc-0000-0000-0000-000000000008', t.u(3), t.p(8), 'mensuel', 5000, 'en_attente_paiement'),
  ('cccccccc-0000-0000-0000-000000000009', t.u(8), t.p(9), 'mensuel', 5000, 'en_attente_paiement'),
  ('cccccccc-0000-0000-0000-000000000102', t.u(4), t.p(2), 'annuel', 30000, 'en_attente_paiement'),
  ('cccccccc-0000-0000-0000-000000000107', t.u(3), t.p(7), 'annuel', 30000, 'en_attente_paiement');

-- Réservations préparées (blocages, anciens états)
-- b3 d'abord, avec son paiement réussi : état incohérent volontaire, que la tâche d'expiration doit laisser intact.
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values
 (t.b(3), t.p(4), t.u(1), daterange(current_date + 220, current_date + 222), 2, 30000, 60000, 60000, 'en_attente_paiement', now() - interval '1 hour');
insert into payment_transactions (purpose, booking_id, idempotency_key, amount_xof, status, received_amount_xof)
  values ('booking', t.b(3), 'seed-b3', 60000, 'reussi', 60000);
insert into availability_blocks (property_id, stay) values (t.p(3), daterange(current_date + 150, current_date + 152));
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values
 (t.b(1), t.p(3), t.u(1), daterange(current_date + 200, current_date + 202), 2, 50000, 100000, 100000, 'en_attente_paiement', now() - interval '1 hour'),   -- blocage expiré
 (t.b(2), t.p(4), t.u(2), daterange(current_date + 210, current_date + 212), 2, 30000, 60000, 60000, 'confirmee', now() - interval '1 day'),               -- confirmée (hold périmé résiduel)
 (t.b(4), t.p(4), t.u(2), daterange(current_date + 230, current_date + 232), 2, 30000, 60000, 60000, 'en_attente_paiement', now() + interval '10 minutes'),-- blocage en cours
 (t.b(5), t.p(3), t.u(1), daterange(current_date + 240, current_date + 242), 2, 50000, 100000, 100000, 'expiree', null),                                    -- expirée, dates libres
 (t.b(6), t.p(3), t.u(2), daterange(current_date + 250, current_date + 252), 2, 50000, 100000, 100000, 'expiree', null),                                    -- expirée, dates reprises ci-dessous
 (t.b(7), t.p(3), t.u(14), daterange(current_date + 250, current_date + 252), 2, 50000, 100000, 100000, 'confirmee', null),
 (t.b(8), t.p(3), t.u(1), daterange(current_date + 260, current_date + 262), 2, 50000, 100000, 100000, 'en_attente_paiement', now() - interval '5 minutes'); -- délai dépassé, non balayé
insert into payment_transactions (id, purpose, booking_id, idempotency_key, amount_xof, status)
  values ('dddddddd-0000-0000-0000-000000000004', 'booking', t.b(4), 'seed-b4', 60000, 'en_attente');

-- ====================== A. Création de réservation ======================
reset role; select t.as(0);
select t.must_fail('visiteur : ne peut pas appeler create_booking', format($$select create_booking(%L, current_date+100, current_date+103, 2)$$, t.p(3)));
reset role; select t.as(1);
select t.ok('voyageur A : réserve p3 (3 nuits)', format($$select t.set('bA', id::text) from create_booking(%L, current_date+100, current_date+103, 2)$$, t.p(3)));
select t.eq('prix calculé par le serveur : 3 × 50 000 = 150 000', format($$select total_xof::text from bookings where id = %L$$, t.get('bA')), '150000');
select t.eq('statut initial « en attente de paiement »', format($$select status::text from bookings where id = %L$$, t.get('bA')), 'en_attente_paiement');
select t.eq('blocage de 15 minutes (14 à 16 min)', format($$select (hold_expires_at > now() + interval '14 minutes' and hold_expires_at < now() + interval '16 minutes')::text from bookings where id = %L$$, t.get('bA')), 'true');
select t.must_fail('le navigateur ne peut pas imposer un prix (paramètre inexistant)', format($$select create_booking(%L, current_date+110, current_date+112, 2, 1)$$, t.p(3)));
select t.must_fail('voyageur A : ne peut pas écrire une réservation directement (RLS)', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof) values (%L,%L,daterange(current_date+120,current_date+121),1,1,1,1)$$, t.p(3), t.u(1)));
select t.rows('voyageur A : ne peut pas modifier le prix de sa réservation', format($$update bookings set total_xof = 1, accommodation_xof = 1 where id = %L$$, t.get('bA')), 0);
select t.must_fail('dates invalides : départ avant arrivée', format($$select create_booking(%L, current_date+110, current_date+108, 2)$$, t.p(3)));
select t.must_fail('dates invalides : départ = arrivée', format($$select create_booking(%L, current_date+110, current_date+110, 2)$$, t.p(3)));
select t.must_fail('dates invalides : arrivée dans le passé', format($$select create_booking(%L, current_date-1, current_date+2, 2)$$, t.p(3)));
select t.must_fail('dates invalides : séjour de plus de 90 nuits', format($$select create_booking(%L, current_date+110, current_date+201, 2)$$, t.p(3)));
select t.must_fail('dates invalides : plus d''un an à l''avance', format($$select create_booking(%L, current_date+400, current_date+402, 2)$$, t.p(3)));
select t.must_fail('trop de voyageurs (capacité 6)', format($$select create_booking(%L, current_date+110, current_date+112, 7)$$, t.p(3)));
select t.must_fail('zéro voyageur', format($$select create_booking(%L, current_date+110, current_date+112, 0)$$, t.p(3)));
select t.must_fail('séjour minimum non respecté (p4 : 2 nuits)', format($$select create_booking(%L, current_date+110, current_date+111, 2)$$, t.p(4)));
select t.must_fail('annonce non publiée (brouillon) : refusée', format($$select create_booking(%L, current_date+110, current_date+112, 2)$$, t.p(5)));
select t.must_fail('offre « Visibilité » : pas de réservation en ligne', format($$select create_booking(%L, current_date+110, current_date+112, 2)$$, t.p(1)));
select t.must_fail('logement inexistant', $$select create_booking(gen_random_uuid(), current_date+110, current_date+112, 2)$$);
select t.must_fail('dates bloquées par le propriétaire/équipe : refusées', format($$select create_booking(%L, current_date+150, current_date+151, 2)$$, t.p(3)));
reset role; select t.as(2);
select t.must_fail('voyageur B : mêmes dates que A refusées', format($$select create_booking(%L, current_date+100, current_date+103, 2)$$, t.p(3)));
select t.must_fail('voyageur B : dates qui chevauchent partiellement refusées', format($$select create_booking(%L, current_date+102, current_date+105, 2)$$, t.p(3)));
select t.ok('voyageur B : arrivée le jour du départ de A acceptée', format($$select t.set('bB', id::text) from create_booking(%L, current_date+103, current_date+105, 2)$$, t.p(3)));
select t.ok('voyageur B : réserve 2 nuits sur p4 (séjour min respecté)', format($$select t.set('bB4', id::text) from create_booking(%L, current_date+110, current_date+112, 2)$$, t.p(4)));
select t.cnt('voyageur B : ne voit pas la réservation de A', format($$select 1 from bookings where id = %L$$, t.get('bA')), 0);
reset role; select t.as(3);
select t.must_fail('propriétaire : ne peut pas réserver son propre logement', format($$select create_booking(%L, current_date+110, current_date+112, 2)$$, t.p(3)));
-- plafond de blocages simultanés
reset role; select t.as(14);
select t.ok('voyageur C : blocage 1', format($$select create_booking(%L, current_date+300, current_date+301, 1)$$, t.p(3)));
select t.ok('voyageur C : blocage 2', format($$select create_booking(%L, current_date+302, current_date+303, 1)$$, t.p(3)));
select t.ok('voyageur C : blocage 3', format($$select create_booking(%L, current_date+304, current_date+305, 1)$$, t.p(3)));
select t.must_fail('voyageur C : 4e blocage simultané refusé', format($$select create_booking(%L, current_date+306, current_date+307, 1)$$, t.p(3)));
-- blocage expiré
reset role; select t.as(15);
select t.ok('blocage expiré : les dates sont libérées pour un autre voyageur', format($$select create_booking(%L, current_date+200, current_date+202, 2)$$, t.p(3)));
reset role;
select t.eq('blocage expiré : l''ancienne réservation passe en « expirée »', format($$select status::text from bookings where id = %L$$, t.b(1)), 'expiree');
select t.as(0);
select t.cnt('visiteur : plages publiques de p3 (hors blocage expiré), dates seulement', format('select * from public_booked_ranges(%L)', t.p(3)), 8);

-- ====================== B. Expiration planifiée ======================
reset role;
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at)
  values (t.b(10), t.p(4), t.u(1), daterange(current_date + 330, current_date + 332), 2, 30000, 60000, 60000, 'en_attente_paiement', now() - interval '16 minutes');
select t.eq('expiration : seuls les blocages dépassés expirent (b10 ; b3 a un paiement réussi → protégé ; b2 confirmée intacte)',
  $$select expire_booking_holds()::text$$, '1');
select t.eq('expiration : b10 (16 min) est expirée', format($$select status::text from bookings where id = %L$$, t.b(10)), 'expiree');
select t.eq('expiration : b8 (délai dépassé) est expirée (par la tâche ou par la libération à la demande)', format($$select status::text from bookings where id = %L$$, t.b(8)), 'expiree');
select t.eq('expiration : une réservation CONFIRMÉE n''est jamais libérée (même avec un hold périmé)', format($$select status::text from bookings where id = %L$$, t.b(2)), 'confirmee');
select t.eq('expiration : une réservation avec paiement réussi n''est pas libérée', format($$select status::text from bookings where id = %L$$, t.b(3)), 'en_attente_paiement');
select t.eq('expiration : un blocage encore valide est conservé', format($$select status::text from bookings where id = %L$$, t.b(4)), 'en_attente_paiement');
select t.eq('expiration : idempotente (2e passage = 0)', $$select expire_booking_holds()::text$$, '0');
select t.as(1);
select t.must_fail('voyageur : ne peut pas lancer l''expiration', $$select expire_booking_holds()$$);
reset role; select t.as(0);
select t.must_fail('visiteur : ne peut pas lancer l''expiration', $$select expire_booking_holds()$$);

-- ====================== C. Révélation des coordonnées ======================
reset role; select t.as(0);
select t.must_fail('visiteur : reveal_contact refusé (connexion requise)', format($$select reveal_contact(%L)$$, t.p(1)));
reset role; select t.as(1);
select t.cnt('voyageur A : la table des contacts reste illisible directement', 'select 1 from property_contacts', 0);
select t.eq('voyageur A : révèle le contact de p1', format($$select reveal_contact(%L) ->> 'phone'$$, t.p(1)), '+226 70 00 00 01');
select t.eq('voyageur A : le contact ne contient que nom, téléphone, WhatsApp', format($$select (select count(*) from jsonb_object_keys(reveal_contact(%L)))::text$$, t.p(1)), '3');
reset role; select t.as(3);
select t.eq('propriétaire O1 : voit 1 consultation (A) — la relecture dans les 24 h ne recompte pas', format('select count(*)::text from contact_views where property_id = %L', t.p(1)), '1');
select t.must_fail('propriétaire O1 : ne voit pas QUI a consulté', format('select viewer_id from contact_views where property_id = %L', t.p(1)));
select t.must_fail('propriétaire O1 : ne peut pas se révéler son propre contact', format($$select reveal_contact(%L)$$, t.p(1)));
reset role; select t.as(2);
select t.ok('voyageur B : révèle aussi le contact de p1', format($$select reveal_contact(%L)$$, t.p(1)));
reset role; select t.as(3);
select t.eq('propriétaire O1 : 2 consultations après B', format('select count(*)::text from contact_views where property_id = %L', t.p(1)), '2');
reset role; select t.as(1);
select t.must_fail('annonce non publiée (approuvée) : contact indisponible', format($$select reveal_contact(%L)$$, t.p(6)));
select t.must_fail('annonce sans abonnement actif (expiré) : contact indisponible', format($$select reveal_contact(%L)$$, t.p(16)));
select t.must_fail('offre « Sérénité » : pas de contact direct', format($$select reveal_contact(%L)$$, t.p(3)));
select t.must_fail('annonce inexistante : contact indisponible', $$select reveal_contact(gen_random_uuid())$$);
-- protection contre les abus : 10 nouvelles annonces par heure et par voyageur
reset role; select t.as(14);
select t.ok('anti-abus : 10 premières consultations acceptées', $$select count(reveal_contact(('aaaaaaaa-0000-0000-0000-' || lpad(n::text, 12, '0'))::uuid)) from generate_series(20, 29) n$$);
select t.must_fail('anti-abus : la 11e consultation de l''heure est refusée', format($$select reveal_contact(%L)$$, t.p(30)));
select t.ok('anti-abus : relire un contact déjà consulté reste possible', format($$select reveal_contact(%L)$$, t.p(20)));

-- ====================== D. « J'ai payé » ======================
reset role; select t.as(0);
select t.must_fail('visiteur : declare_payment refusé', format($$select declare_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(2);
select t.must_fail('voyageur B : ne peut pas déclarer le paiement de la réservation de A', format($$select declare_payment('reservation', %L, 150000)$$, t.get('bA')));
select t.must_fail('voyageur B : réservation inexistante', $$select declare_payment('reservation', gen_random_uuid(), 1000)$$);
reset role; select t.as(1);
select t.must_fail('montant nul refusé', format($$select declare_payment('reservation', %L, 0)$$, t.get('bA')));
select t.must_fail('montant négatif refusé', format($$select declare_payment('reservation', %L, -5)$$, t.get('bA')));
select t.must_fail('objet inconnu refusé', format($$select declare_payment('virement', %L, 150000)$$, t.get('bA')));
select t.must_fail('voyageur A : ne peut pas insérer un avis directement (passage obligé par la fonction)', format($$insert into payment_notices (object, booking_id, declared_amount_xof) values ('reservation', %L, 150000)$$, t.get('bA')));
select t.ok('voyageur A : déclare avoir payé sa réservation', format($$select t.set('nA', id::text) from declare_payment('reservation', %L, 150000, 'REF-1', 'payé par mobile money')$$, t.get('bA')));
select t.eq('l''avis ne confirme rien : la réservation reste en attente', format($$select status::text from bookings where id = %L$$, t.get('bA')), 'en_attente_paiement');
select t.eq('le blocage est prolongé (≈ 2 h) pendant la vérification', format($$select (hold_expires_at > now() + interval '110 minutes')::text from bookings where id = %L$$, t.get('bA')), 'true');
select t.set('holdA', (select hold_expires_at::text from bookings where id = t.get('bA')::uuid));
select t.ok('déclaration répétée : idempotente (même avis)', format($$select declare_payment('reservation', %L, 150000)$$, t.get('bA')));
select t.eq('déclarations répétées : le blocage n''est PAS prolongé une 2e fois', format($$select (hold_expires_at::text = t.get('holdA'))::text || '/' || hold_extensions from bookings where id = %L$$, t.get('bA')), 'true/1');
select t.rows('voyageur A : ne peut pas modifier lui-même la durée du blocage', format($$update bookings set hold_expires_at = now() + interval '30 days' where id = %L$$, t.get('bA')), 0);
select t.rows('voyageur A : ne peut pas réinitialiser le compteur de prolongation', format($$update bookings set hold_extensions = 0 where id = %L$$, t.get('bA')), 0);
select t.eq('un seul avis ouvert par réservation', format($$select count(*)::text from payment_notices where booking_id = %L$$, t.get('bA')), '1');
select t.rows('voyageur A : ne peut pas marquer son avis « traité »', $$update payment_notices set status = 'traite'$$, 0);
reset role; select t.as(3);
reset role; select t.as(14);
select t.ok('voyageur C : déclare un montant INFÉRIEUR au montant dû (avis enregistré)', format($$select declare_payment('reservation', id, 1000) from bookings where guest_id = %L and stay = daterange(current_date+300, current_date+301)$$, t.u(14)));
select t.eq('déclaration invalide (montant ≠ dû) : AUCUNE prolongation du blocage', format($$select (hold_expires_at < now() + interval '20 minutes')::text || '/' || hold_extensions from bookings where guest_id = %L and stay = daterange(current_date+300, current_date+301)$$, t.u(14)), 'true/0');
reset role; select t.as(3);
select t.eq('propriétaire O1 : abonnement p6 — déclare son paiement', format($$select status from declare_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 5000)$$), 'nouveau');
select t.eq('déclaration d''abonnement : l''abonnement n''est PAS activé et l''annonce n''est pas publiée', $$select (select status::text from subscriptions where id = 'cccccccc-0000-0000-0000-000000000006') || '/' || (select status::text from properties where id = 'aaaaaaaa-0000-0000-0000-000000000006')$$, 'en_attente_paiement/approuvee');
select t.must_fail('propriétaire O1 : ne peut pas déclarer l''abonnement d''un autre', $$select declare_payment('abonnement', 'cccccccc-0000-0000-0000-000000000102', 30000)$$);
reset role; select t.as(1);
select t.must_fail('voyageur A : ne peut pas déclarer un abonnement qui n''est pas le sien', $$select declare_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 5000)$$);
reset role; select t.as(1);
select t.ok('réservation expirée : la déclaration est acceptée (l''équipe vérifiera)', format($$select declare_payment('reservation', %L, 100000)$$, t.b(5)));
select t.eq('réservation expirée : la déclaration ne la ravive pas', format($$select status::text from bookings where id = %L$$, t.b(5)), 'expiree');
reset role; select t.as(14);
select t.must_fail('réservation confirmée par un autre : introuvable pour C', format($$select declare_payment('reservation', %L, 60000)$$, t.b(2)));
reset role; select t.as(2);
select t.must_fail('réservation déjà confirmée : plus d''attente de paiement', format($$select declare_payment('reservation', %L, 60000)$$, t.b(2)));

-- ====================== E. Confirmation manuelle des paiements ======================
reset role; select t.as(0);
select t.must_fail('visiteur : confirm_payment refusé', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(1);
select t.must_fail('voyageur A : ne peut pas confirmer SON paiement', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(3);
select t.must_fail('propriétaire : ne peut pas confirmer un paiement', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
select t.must_fail('propriétaire : ne peut pas activer son abonnement', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 5000)$$);
reset role; select t.as(6);
select t.must_fail('équipe « validation » : pas d''autorisation paiements', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(7);
select t.must_fail('équipe « reservations » : pas d''autorisation paiements', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(9);
select t.must_fail('équipe « audit » : pas d''autorisation paiements', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(13);
select t.must_fail('membre sans permission : refusé', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(8);
select t.must_fail('montant inférieur au montant attendu : refusé', format($$select confirm_payment('reservation', %L, 149999)$$, t.get('bA')));
select t.must_fail('montant supérieur au montant attendu : refusé', format($$select confirm_payment('reservation', %L, 150001)$$, t.get('bA')));
select t.must_fail('montant nul : refusé', format($$select confirm_payment('reservation', %L, 0)$$, t.get('bA')));
select t.must_fail('montant absent : refusé', format($$select confirm_payment('reservation', %L, null)$$, t.get('bA')));
select t.must_fail('objet inconnu : refusé', format($$select confirm_payment('chariow', %L, 150000)$$, t.get('bA')));
select t.must_fail('réservation inexistante : refusée', $$select confirm_payment('reservation', gen_random_uuid(), 150000)$$);
reset role;
select t.eq('après les refus : aucune transaction réussie, réservation toujours en attente', format($$select (select count(*) from payment_transactions where booking_id = %L and status = 'reussi')::text || '/' || (select status::text from bookings where id = %L)$$, t.get('bA'), t.get('bA')), '0/en_attente_paiement');
select t.as(8);
select t.ok('équipe « paiements » : confirme avec le montant exact', format($$select t.set('txA', id::text) from confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
select t.eq('réservation confirmée, blocage levé', format($$select status::text || '/' || coalesce(hold_expires_at::text, 'aucun') from bookings where id = %L$$, t.get('bA')), 'confirmee/aucun');
select t.eq('transaction : réussie, montant reçu = attendu, confirmée par le membre', format($$select status::text || '/' || received_amount_xof || '/' || amount_xof || '/' || (confirmed_by = %L)::text from payment_transactions where id = %L$$, t.u(8), t.get('txA')), 'reussi/150000/150000/true');
select t.eq('registre financier : 1 écriture de crédit de 150 000', format($$select count(*)::text || '/' || coalesce(sum(credit_xof), 0) from financial_ledger where booking_id = %L$$, t.get('bA')), '1/150000');
select t.eq('avis « J''ai payé » clôturé automatiquement', format($$select status from payment_notices where booking_id = %L$$, t.get('bA')), 'traite');
reset role; select t.as(5);
select t.eq('journal d''audit : 1 confirmation tracée (auteur, montants)', format($$select count(*)::text from audit_logs where action = 'payment.confirmed' and entity_id = %L and actor_id = %L and (after ->> 'received_xof') = '150000'$$, t.get('bA'), t.u(8)), '1');
select t.must_fail('double confirmation (admin) refusée', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
reset role; select t.as(8);
select t.must_fail('double confirmation (même membre) refusée', format($$select confirm_payment('reservation', %L, 150000)$$, t.get('bA')));
select t.eq('après les doubles : toujours 1 transaction réussie et 1 écriture', format($$select (select count(*) from payment_transactions where booking_id = %L and status = 'reussi')::text || '/' || (select count(*) from financial_ledger where booking_id = %L)::text$$, t.get('bA'), t.get('bA')), '1/1');
select t.must_fail('paiements : ne peut pas écrire directement une transaction', format($$insert into payment_transactions (purpose, booking_id, idempotency_key, amount_xof, status, received_amount_xof) values ('booking', %L, 'forge', 1, 'reussi', 1)$$, t.get('bB')));
select t.rows('paiements : ne peut pas modifier une transaction directement', $$update payment_transactions set status = 'echoue'$$, 0);
select t.rows('paiements : ne peut pas modifier une réservation directement', $$update bookings set status = 'confirmee'$$, 0);
reset role; select t.as(1);
select t.rows('voyageur A : ne peut pas annuler/rouvrir la transaction de sa réservation', $$update payment_transactions set status = 'echoue'$$, 0);
-- délai dépassé mais non encore balayé : l'argent est reçu, on confirme
reset role;
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at)
  values (t.b(9), t.p(3), t.u(1), daterange(current_date + 280, current_date + 282), 2, 50000, 100000, 100000, 'en_attente_paiement', now() - interval '5 minutes');
select t.as(8);
select t.ok('délai dépassé non balayé : l''équipe peut confirmer (paiement reçu)', format($$select confirm_payment('reservation', %L, 100000)$$, t.b(9)));
select t.eq('b9 confirmée', format($$select status::text from bookings where id = %L$$, t.b(9)), 'confirmee');
-- b8 a été passée en « expirée » par la tâche d'expiration : confirmation tardive possible si les dates sont libres
select t.ok('expirée par la tâche, dates libres : confirmation tardive acceptée (b8)', format($$select confirm_payment('reservation', %L, 100000)$$, t.b(8)));
select t.ok('réservation expirée, dates encore libres : confirmation tardive acceptée', format($$select confirm_payment('reservation', %L, 100000)$$, t.b(5)));
select t.must_fail('réservation expirée, dates REPRISES : confirmation impossible', format($$select confirm_payment('reservation', %L, 100000)$$, t.b(6)));
reset role;
select t.eq('dates reprises : aucune transaction réussie créée pour b6', format($$select count(*)::text from payment_transactions where booking_id = %L and status = 'reussi'$$, t.b(6)), '0');
select t.eq('dates reprises : b6 reste expirée', format($$select status::text from bookings where id = %L$$, t.b(6)), 'expiree');
-- transaction existante (créée avant l'avis) : mise à jour plutôt que doublon
select t.as(8);
select t.ok('transaction « en attente » existante : confirmée (pas de doublon)', format($$select confirm_payment('reservation', %L, 60000)$$, t.b(4)));
reset role;
select t.eq('b4 : 1 seule transaction, réussie', format($$select count(*)::text || '/' || min(status::text) from payment_transactions where booking_id = %L$$, t.b(4)), '1/reussi');
-- permissions déléguées
select t.as(13);
select t.must_fail('délégation : membre 13 sans permission refusé', format($$select confirm_payment('reservation', %L, 100000)$$, t.get('bB')));
reset role; select t.as(5);
select t.ok('admin : donne « paiements » au membre 13', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(13), t.u(5)));
reset role; select t.as(13);
select t.ok('délégation : membre 13 confirme maintenant (autorisation reçue)', format($$select confirm_payment('reservation', %L, 100000)$$, t.get('bB')));
reset role; select t.as(5);
select t.ok('admin : retire « paiements » au membre 13', format($$delete from team_permissions where user_id = %L and perm = 'paiements'$$, t.u(13)));
reset role; select t.as(13);
select t.must_fail('délégation retirée : membre 13 refusé de nouveau', format($$select confirm_payment('reservation', %L, 60000)$$, t.get('bB4')));
reset role; select t.as(13);
select t.must_fail('membre 13 ne peut pas s''octroyer lui-même la permission', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(13), t.u(13)));
-- pas d'auto-confirmation
reset role; select t.as(8);
select t.ok('membre « paiements » réserve lui-même un séjour', format($$select t.set('b8own', id::text) from create_booking(%L, current_date+270, current_date+272, 2)$$, t.p(3)));
select t.must_fail('membre « paiements » : ne peut pas confirmer SON PROPRE paiement', format($$select confirm_payment('reservation', %L, 100000)$$, t.get('b8own')));
select t.must_fail('membre « paiements » : ne peut pas activer SON PROPRE abonnement', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000009', 5000)$$);
reset role; select t.as(5);
select t.ok('admin : peut confirmer le paiement du membre (autre personne)', format($$select confirm_payment('reservation', %L, 100000)$$, t.get('b8own')));

-- ====================== E2. Abonnements ======================
reset role; select t.as(8);
select t.must_fail('abonnement : montant mensuel erroné (30 000 au lieu de 5 000)', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 30000)$$);
select t.must_fail('abonnement : montant inférieur refusé', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 4999)$$);
reset role;
select t.eq('abonnement p6 : toujours en attente et annonce non publiée après refus', $$select (select status::text from subscriptions where id = 'cccccccc-0000-0000-0000-000000000006') || '/' || (select status::text from properties where id = 'aaaaaaaa-0000-0000-0000-000000000006')$$, 'en_attente_paiement/approuvee');
select t.cnt('annonce non publiée : absente de la vue publique', format('select 1 from public_listings where id = %L', t.p(6)), 0);
select t.as(8);
select t.ok('abonnement p6 : confirmé avec le bon montant', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 5000)$$);
reset role;
select t.eq('abonnement p6 : actif pour 1 mois à partir d''aujourd''hui', $$select status::text || '/' || (starts_at = current_date)::text || '/' || (ends_at = (current_date + interval '1 month')::date)::text from subscriptions where id = 'cccccccc-0000-0000-0000-000000000006'$$, 'actif/true/true');
select t.eq('annonce approuvée → publiée automatiquement (validation déjà faite)', format($$select status::text from properties where id = %L$$, t.p(6)), 'publiee');
select t.cnt('annonce p6 : visible dans la vue publique', format('select 1 from public_listings where id = %L', t.p(6)), 1);
select t.eq('abonnement : ledger + audit', $$select (select count(*) from financial_ledger where entry_type = 'abonnement')::text || '/' || (select count(*) from audit_logs where action = 'payment.confirmed' and entity_type = 'subscription')::text$$, '1/1');
select t.as(8);
select t.must_fail('abonnement : double confirmation refusée', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000006', 5000)$$);
select t.ok('abonnement p8 (sans photo vérifiée) : activé', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000008', 5000)$$);
reset role;
select t.eq('p8 : abonnement actif mais annonce NON publiée (photo non vérifiée)', format($$select status::text from properties where id = %L$$, t.p(8)), 'approuvee');
select t.as(8);
select t.ok('renouvellement annuel de p2 : confirmé', $$select confirm_payment('abonnement', 'cccccccc-0000-0000-0000-000000000102', 30000)$$);
reset role;
select t.eq('renouvellement : commence à la fin de l''abonnement actif (+10 j), dure 1 an', $$select (starts_at = current_date + 10)::text || '/' || (ends_at = (current_date + 10 + interval '1 year')::date)::text from subscriptions where id = 'cccccccc-0000-0000-0000-000000000102'$$, 'true/true');

-- ====================== F. « Non reçu » ======================
reset role; select t.as(2);
select t.ok('voyageur B : déclare un paiement pour sa réservation p4', format($$select declare_payment('reservation', %L, 60000)$$, t.get('bB4')));
reset role; select t.as(1);
select t.must_fail('voyageur : ne peut pas marquer « non reçu »', format($$select reject_payment('reservation', %L, 'faux')$$, t.get('bB4')));
reset role; select t.as(8);
select t.must_fail('« non reçu » sans motif refusé', format($$select reject_payment('reservation', %L, '')$$, t.get('bB4')));
select t.ok('« non reçu » avec motif : réservation libérée', format($$select reject_payment('reservation', %L, 'Aucun paiement reçu sur Chariow')$$, t.get('bB4')));
reset role;
select t.eq('« non reçu » : réservation expirée, avis clôturé', format($$select (select status::text from bookings where id = %L) || '/' || (select status from payment_notices where booking_id = %L)$$, t.get('bB4'), t.get('bB4')), 'expiree/traite');
select t.as(15);
select t.ok('« non reçu » : les dates sont de nouveau réservables', format($$select create_booking(%L, current_date+110, current_date+112, 2)$$, t.p(4)));
reset role; select t.as(8);
select t.must_fail('« non reçu » refusé sur un paiement déjà confirmé', format($$select reject_payment('reservation', %L, 'erreur')$$, t.get('bA')));
select t.must_fail('« non reçu » : le membre ne traite pas son propre paiement', format($$select reject_payment('reservation', %L, 'moi-même')$$, t.get('b8own')));
reset role; select t.as(5);
select t.eq('journal : le refus est tracé avec son motif', $$select count(*)::text from audit_logs where action = 'payment.rejected' and reason like 'Aucun paiement%'$$, '1');

-- ====================== G. Rôle propriétaire ======================
reset role; select t.as(0);
select t.must_fail('visiteur : request_owner_role refusé', $$select request_owner_role('cni')$$);
reset role; select t.as(12);
select t.must_fail('voyageur 12 : ne peut pas créer d''annonce avant d''être propriétaire', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'annonce','Tôt','Dori','X',2,1000,'soumise')$$, t.u(12)));
select t.must_fail('voyageur 12 : ne peut pas s''ajouter le rôle directement', format($$insert into user_roles (user_id, role) values (%L,'proprietaire')$$, t.u(12)));
select t.must_fail('voyageur 12 : ne peut pas écrire owner_profiles directement', format($$insert into owner_profiles (user_id, verification_status) values (%L,'verifie')$$, t.u(12)));
select t.ok('voyageur 12 : demande à devenir propriétaire', $$select request_owner_role('cni')$$);
select t.eq('la demande ne donne PAS le rôle', format($$select count(*)::text from user_roles where user_id = %L and role = 'proprietaire'$$, t.u(12)), '0');
select t.must_fail('voyageur 12 : ne peut pas se l''attribuer', format($$select grant_owner_role(%L)$$, t.u(12)));
select t.rows('voyageur 12 : ne peut pas valider sa propre vérification', format($$update owner_profiles set verification_status = 'verifie' where user_id = %L$$, t.u(12)), 0);
reset role; select t.as(1);
select t.must_fail('voyageur A : ne peut pas attribuer le rôle', format($$select grant_owner_role(%L)$$, t.u(12)));
reset role; select t.as(8);
select t.must_fail('équipe « paiements » : ne peut pas attribuer le rôle', format($$select grant_owner_role(%L)$$, t.u(12)));
reset role; select t.as(6);
select t.must_fail('équipe « validation » : ne peut pas se l''attribuer à elle-même', format($$select grant_owner_role(%L)$$, t.u(6)));
select t.must_fail('aucune demande : attribution refusée (voyageur 2)', format($$select grant_owner_role(%L)$$, t.u(2)));
select t.must_fail('utilisateur inexistant : attribution refusée', $$select grant_owner_role(gen_random_uuid())$$);
select t.ok('équipe « validation » : attribue le rôle à 12', format($$select grant_owner_role(%L)$$, t.u(12)));
reset role;
select t.eq('rôle attribué avec traçabilité (granted_by = validation)', format($$select count(*)::text from user_roles where user_id = %L and role = 'proprietaire' and granted_by = %L$$, t.u(12), t.u(6)), '1');
select t.eq('demande marquée « verifie » + audit', format($$select (select verification_status from owner_profiles where user_id = %L) || '/' || (select count(*) from audit_logs where action = 'role.owner_granted' and entity_id = %L)::text$$, t.u(12), t.u(12)::text), 'verifie/1');
select t.as(12);
select t.ok('propriétaire 12 : peut maintenant déposer une annonce', format($$insert into properties (owner_id, offer, title, city, district, capacity, nightly_price_xof, status) values (%L,'annonce','Ma maison','Dori','X',2,1000,'soumise')$$, t.u(12)));
reset role; select t.as(5);
select t.must_fail('admin : ne peut pas non plus se l''attribuer à lui-même par cette fonction', format($$select grant_owner_role(%L)$$, t.u(5)));
-- limitation des demandes
reset role; select t.as(15);
select t.ok('demandes : 5 par jour acceptées', $$select request_owner_role('cni') from generate_series(1, 5)$$);
select t.must_fail('demandes : la 6e du jour est refusée', $$select request_owner_role('cni')$$);

-- ====================== H. Statut des annonces ======================
reset role; select t.as(0);
select t.must_fail('visiteur : set_listing_status refusé', format($$select set_listing_status(%L, 'approuvee')$$, t.p(11)));
reset role; select t.as(3);
select t.must_fail('propriétaire : ne peut pas valider sa propre annonce via la fonction', format($$select set_listing_status(%L, 'approuvee')$$, t.p(11)));
select t.must_fail('propriétaire : ne peut pas valider sa propre annonce par mise à jour directe', format($$update properties set status = 'approuvee' where id = %L$$, t.p(11)));
reset role; select t.as(1);
select t.must_fail('voyageur : refusé', format($$select set_listing_status(%L, 'approuvee')$$, t.p(11)));
reset role; select t.as(8);
select t.must_fail('équipe « paiements » : pas d''autorisation validation', format($$select set_listing_status(%L, 'approuvee')$$, t.p(11)));
reset role; select t.as(7);
select t.must_fail('équipe « reservations » : pas d''autorisation validation', format($$select set_listing_status(%L, 'approuvee')$$, t.p(11)));
reset role; select t.as(6);
select t.must_fail('validation : ne valide pas SA PROPRE annonce (p10)', format($$select set_listing_status(%L, 'approuvee')$$, t.p(10)));
select t.must_fail('validation : « à corriger » sans motif refusé', format($$select set_listing_status(%L, 'a_corriger')$$, t.p(11)));
select t.must_fail('validation : « refusée » sans motif refusé', format($$select set_listing_status(%L, 'refusee', 'non')$$, t.p(13)));
select t.must_fail('validation : transition interdite (soumise → publiée)', format($$select set_listing_status(%L, 'publiee')$$, t.p(11)));
select t.ok('validation : demande une correction avec motif', format($$select set_listing_status(%L, 'a_corriger', 'Photos floues, à refaire')$$, t.p(11)));
select t.eq('le motif est visible dans la note', format($$select review_note from properties where id = %L$$, t.p(11)), 'Photos floues, à refaire');
select t.must_fail('validation : ne force pas une annonce « à corriger » (attente du propriétaire)', format($$select set_listing_status(%L, 'approuvee')$$, t.p(11)));
select t.must_fail('validation : brouillon intouchable', format($$select set_listing_status(%L, 'approuvee')$$, t.p(12)));
select t.ok('validation : refuse p13 avec motif', format($$select set_listing_status(%L, 'refusee', 'Logement hors critères')$$, t.p(13)));
select t.must_fail('validation : publier sans abonnement actif refusé (p7)', format($$select set_listing_status(%L, 'publiee')$$, t.p(7)));
select t.must_fail('validation : la mise à jour directe vers « publiée » est aussi bloquée (p7)', format($$update properties set status = 'publiee' where id = %L$$, t.p(7)));
select t.must_fail('validation : publier sans photo vérifiée refusé (p8, abonnement actif)', format($$select set_listing_status(%L, 'publiee')$$, t.p(8)));
select t.ok('validation : publie une annonce Sérénité complète (p14)', format($$select set_listing_status(%L, 'publiee')$$, t.p(14)));
select t.must_fail('validation : contrat non signé (p15) → publication refusée', format($$select set_listing_status(%L, 'publiee')$$, t.p(15)));
select t.must_fail('validation : suspendre sans motif refusé', format($$select set_listing_status(%L, 'suspendue')$$, t.p(14)));
select t.ok('validation : suspend avec motif', format($$select set_listing_status(%L, 'suspendue', 'Signalement en cours de vérification')$$, t.p(14)));
select t.cnt('annonce suspendue : retirée de la vue publique', format('select 1 from public_listings where id = %L', t.p(14)), 0);
select t.ok('validation : republie après vérification', format($$select set_listing_status(%L, 'publiee')$$, t.p(14)));
select t.eq('listing_publish_problem : l''équipe voit le motif', format('select listing_publish_problem(%L)', t.p(7)), 'Un abonnement actif (paiement confirmé) est requis.');
reset role; select t.as(5);
select t.ok('admin : valide l''annonce d''un membre de l''équipe (autre personne)', format($$select set_listing_status(%L, 'approuvee')$$, t.p(10)));
reset role; select t.as(4);
select t.eq('propriétaire O2 : voit le motif de refus de SA annonce', format($$select review_note from properties where id = %L$$, t.p(13)), 'Logement hors critères');
select t.eq('propriétaire O2 : listing_publish_problem sur une annonce publiée prête', format('select coalesce(listing_publish_problem(%L), %L)', t.p(2), 'prête'), 'prête');
select t.eq('propriétaire O2 : listing_publish_problem sur l''annonce d''un autre → introuvable', format('select listing_publish_problem(%L)', t.p(7)), 'Annonce introuvable.');
select t.must_fail('propriétaire O2 : ne republie pas lui-même une annonce refusée', format($$update properties set status = 'publiee' where id = %L$$, t.p(13)));
reset role; select t.as(5);
select t.eq('journal : changements de statut tracés', $$select (count(*) >= 5)::text from audit_logs where action = 'listing.status_changed'$$, 'true');

-- ====================== H2. Prolongation tracée et plafonnée ======================
reset role; select t.as(5);
select t.eq('prolongation tracée au journal (auteur = voyageur, ancien et nouveau délai)', format($$select count(*)::text from audit_logs where action = 'booking.hold_extended' and entity_id = %L and actor_id = %L and (after ->> 'declared_xof') = '150000'$$, t.get('bA'), t.u(1)), '1');
select t.eq('une seule prolongation tracée par réservation et aucune pour la déclaration invalide', $$select count(*)::text from audit_logs where action = 'booking.hold_extended' and entity_id in (select id::text from bookings where guest_id = '00000000-0000-0000-0000-000000000014')$$, '0');
reset role;
select t.must_fail('plafond absolu : même le serveur ne peut pas dépasser 2 h 15', format($$update bookings set hold_expires_at = now() + interval '3 hours' where id = %L$$, t.get('bA')));
select t.must_fail('plafond absolu à la création', format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values (%L,%L,daterange(current_date+500,current_date+501),1,1,1,1,'en_attente_paiement', now() + interval '1 day')$$, t.p(3), t.u(1)));

-- ====================== H4. Montant incorrect : jamais de prolongation (tentatives répétées) ======================
reset role; select t.as(10);
select t.ok('voyageur 10 : réserve p4 (2 nuits, 60 000)', format($$select t.set('bW', id::text) from create_booking(%L, current_date+350, current_date+352, 2)$$, t.p(4)));
select t.set('holdW', (select hold_expires_at::text from bookings where id = t.get('bW')::uuid));
select t.ok('montant erroné n°1 (inférieur) : avis enregistré', format($$select declare_payment('reservation', %L, 59999)$$, t.get('bW')));
select t.ok('montant erroné n°2 (supérieur) : accepté comme signalement', format($$select declare_payment('reservation', %L, 60001)$$, t.get('bW')));
select t.ok('montant erroné n°3 (très faible)', format($$select declare_payment('reservation', %L, 1)$$, t.get('bW')));
select t.ok('montant erroné n°4 (très élevé)', format($$select declare_payment('reservation', %L, 99999999)$$, t.get('bW')));
select t.must_fail('montant nul : refusé', format($$select declare_payment('reservation', %L, 0)$$, t.get('bW')));
select t.must_fail('montant au-delà du plafond : refusé', format($$select declare_payment('reservation', %L, 100000001)$$, t.get('bW')));
select t.ok('même montant exact après un montant erroné : renvoie l''avis existant, sans prolonger', format($$select declare_payment('reservation', %L, 60000)$$, t.get('bW')));
select t.eq('après 6 tentatives : blocage inchangé et compteur de prolongation à 0', format($$select (hold_expires_at::text = t.get('holdW'))::text || '/' || hold_extensions from bookings where id = %L$$, t.get('bW')), 'true/0');
select t.eq('après 6 tentatives : un seul avis ouvert', format($$select count(*)::text from payment_notices where booking_id = %L$$, t.get('bW')), '1');
reset role; select t.as(5);
select t.eq('après 6 tentatives : aucune prolongation tracée au journal', format($$select count(*)::text from audit_logs where action = 'booking.hold_extended' and entity_id = %L$$, t.get('bW')), '0');
reset role;
select t.eq('le blocage reste à ≤ 15 min : il expire bien à l''heure initiale', format($$select (hold_expires_at <= created_at + interval '15 minutes 5 seconds')::text from bookings where id = %L$$, t.get('bW')), 'true');
-- simulation : le temps passe (15 min), la tâche d'expiration libère les dates malgré les déclarations erronées
update bookings set hold_expires_at = now() - interval '1 minute' where id = t.get('bW')::uuid;
select t.eq('15 min écoulées : la réservation à déclaration erronée expire', $$select (expire_booking_holds() >= 1)::text$$, 'true');
select t.eq('… et passe en « expirée »', format($$select status::text from bookings where id = %L$$, t.get('bW')), 'expiree');

-- ====================== H3. Rôles et permissions : aucune auto-attribution ======================
select t.as(1);
select t.must_fail('voyageur : ne peut pas s''ajouter un rôle', format($$insert into user_roles (user_id, role) values (%L,'admin')$$, t.u(1)));
select t.rows('voyageur : ne peut pas modifier un rôle', $$update user_roles set role = 'admin'$$, 0);
select t.rows('voyageur : ne peut pas supprimer un rôle', $$delete from user_roles$$, 0);
select t.must_fail('voyageur : ne peut pas s''octroyer une permission', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(1), t.u(1)));
reset role; select t.as(3);
select t.must_fail('propriétaire : ne peut pas s''octroyer une permission', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'validation',%L)$$, t.u(3), t.u(3)));
reset role; select t.as(6);
select t.must_fail('équipe « validation » : ne peut pas s''octroyer « paiements »', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(6), t.u(6)));
select t.must_fail('équipe « validation » : ne peut pas donner une permission à quelqu''un d''autre', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'paiements',%L)$$, t.u(1), t.u(6)));
select t.must_fail('équipe « validation » : ne peut pas s''ajouter le rôle admin', format($$insert into user_roles (user_id, role) values (%L,'admin')$$, t.u(6)));
reset role; select t.as(5);
select t.must_fail('admin : ne peut pas s''octroyer une permission à lui-même', format($$insert into team_permissions (user_id, perm, granted_by) values (%L,'audit',%L)$$, t.u(5), t.u(5)));
select t.must_fail('admin : ne peut pas ajouter un rôle depuis le navigateur', format($$insert into user_roles (user_id, role) values (%L,'admin')$$, t.u(1)));

-- ====================== I. Hygiène des droits d'exécution ======================
reset role;
select t.cnt('aucune fonction serveur de 0006 n''est exécutable par « anon »',
  $$select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.proname in ('create_booking','reveal_contact','declare_payment','confirm_payment','reject_payment',
       'request_owner_role','grant_owner_role','set_listing_status','listing_publish_problem','_listing_publish_problem','expire_booking_holds','require_user')
       and has_function_privilege('anon', p.oid, 'execute')$$, 0);
select t.cnt('fonctions internes/sensibles non exécutables par « authenticated » (expire, require_user, _listing_publish_problem, rate-limit)',
  $$select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.proname in ('expire_booking_holds','require_user','_listing_publish_problem','enforce_rate_limit','flag_major_change','release_expired_holds')
       and has_function_privilege('authenticated', p.oid, 'execute')$$, 0);
select t.cnt('toute fonction SECURITY DEFINER fixe son search_path',
  $$select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and p.prosecdef and p.proconfig is null$$, 0);
select t.cnt('fonctions SECURITY DEFINER exécutables par « anon » : seulement les aides de lecture prévues',
  $$select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prosecdef and p.prorettype <> 'trigger'::regtype
       and has_function_privilege('anon', p.oid, 'execute')
       and p.proname not in ('public_booked_ranges','has_role','is_staff','has_perm','has_any_perm')$$, 0);
select t.cnt('aucun paramètre « utilisateur » dans les fonctions de réservation, paiement et rôle (l''identité vient de auth.uid())',
  $$select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.proname in ('create_booking','reveal_contact','declare_payment','confirm_payment','reject_payment')
       and pg_get_function_arguments(p.oid) ~* '(user|owner|actor|role|status|price|prix)'$$, 0);
select t.cnt('toutes les tables du schéma public ont la sécurité par ligne activée',
  $$select 1 from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity$$, 0);

-- ====================== J. Abonnement expiré : fermeture IMMÉDIATE, sans tâche planifiée ======================
reset role;
select t.mkprop(40, 4, 'annonce', 'publiee', 10000, 2, 1, true, true, true);
insert into availability_blocks (property_id, stay) values (t.p(40), daterange(current_date + 5, current_date + 7));
insert into subscriptions (id, owner_id, property_id, plan, amount_xof, status, starts_at, ends_at)
  values ('cccccccc-0000-0000-0000-000000000140', t.u(4), t.p(40), 'mensuel', 5000, 'actif', current_date - 29, current_date + 1);
select t.as(0);
select t.cnt('abonnement valable (dernier jour) : annonce visible', format('select 1 from public_listings where id = %L', t.p(40)), 1);
select t.cnt('abonnement valable : photos visibles', format('select 1 from public_listing_photos where property_id = %L', t.p(40)), 1);
select t.cnt('abonnement valable : plages de dates visibles', format('select * from public_booked_ranges(%L)', t.p(40)), 1);
reset role; select t.as(1);
select t.ok('abonnement valable : contact révélable', format($$select reveal_contact(%L)$$, t.p(40)));
reset role;
-- le jour de fin (exclu) arrive : AUCUNE tâche n'est exécutée, aucun statut n'est modifié
update subscriptions set ends_at = current_date where id = 'cccccccc-0000-0000-0000-000000000140';
select t.eq('après la date de fin : statut de l''abonnement inchangé (« actif »), annonce toujours « publiée » en base',
  $$select (select status::text from subscriptions where id = 'cccccccc-0000-0000-0000-000000000140') || '/' || (select status::text from properties where id = 'aaaaaaaa-0000-0000-0000-000000000040')$$, 'actif/publiee');
select t.as(0);
select t.cnt('abonnement terminé : annonce masquée IMMÉDIATEMENT (vue publique)', format('select 1 from public_listings where id = %L', t.p(40)), 0);
select t.cnt('abonnement terminé : photos masquées', format('select 1 from public_listing_photos where property_id = %L', t.p(40)), 0);
select t.cnt('abonnement terminé : plages de dates masquées', format('select * from public_booked_ranges(%L)', t.p(40)), 0);
select t.cnt('abonnement terminé : annonce brute toujours illisible pour le public', format('select 1 from properties where id = %L', t.p(40)), 0);
reset role; select t.as(2);
select t.must_fail('abonnement terminé : contact NON révélable', format($$select reveal_contact(%L)$$, t.p(40)));
select t.cnt('abonnement terminé : visible dans la vue publique pour un autre voyageur ? non', format('select 1 from public_listings where id = %L', t.p(40)), 0);
reset role; select t.as(4);
select t.cnt('abonnement terminé : le propriétaire voit toujours son annonce et peut renouveler', format('select 1 from properties where id = %L', t.p(40)), 1);
reset role;
-- autres états qui ne donnent pas droit à l'affichage
update subscriptions set ends_at = current_date + 30, starts_at = current_date + 1 where id = 'cccccccc-0000-0000-0000-000000000140';
select t.as(0);
select t.cnt('abonnement qui ne commence que demain : masqué', format('select 1 from public_listings where id = %L', t.p(40)), 0);
reset role;
update subscriptions set starts_at = current_date - 1, status = 'annule' where id = 'cccccccc-0000-0000-0000-000000000140';
select t.as(0);
select t.cnt('abonnement annulé : masqué', format('select 1 from public_listings where id = %L', t.p(40)), 0);
reset role;
update subscriptions set status = 'expire' where id = 'cccccccc-0000-0000-0000-000000000140';
select t.as(0);
select t.cnt('abonnement marqué expiré : masqué', format('select 1 from public_listings where id = %L', t.p(40)), 0);
reset role;
-- renouvellement : l'annonce réapparaît sans aucune autre action (le statut n'avait pas été changé)
update subscriptions set status = 'actif', ends_at = current_date + 30 where id = 'cccccccc-0000-0000-0000-000000000140';
select t.as(0);
select t.cnt('renouvellement : l''annonce réapparaît immédiatement', format('select 1 from public_listings where id = %L', t.p(40)), 1);
reset role;
select t.cnt('seules deux vues sont lisibles par « anon » (annonces et photos publiées) — aucune autre voie publique d''annonce',
  $$select 1 from information_schema.role_table_grants g join pg_class c on c.relname = g.table_name and c.relkind = 'v'
     where g.grantee = 'anon' and g.table_schema = 'public' and g.privilege_type = 'SELECT'
       and g.table_name not in ('public_listings', 'public_listing_photos')$$, 0);

-- ====================== Préparation des scénarios concurrents (lancés par run-local.sh) ======================
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, hold_expires_at) values
 ('bbbbbbbb-0000-0000-0000-000000000101', t.p(3), t.u(2), daterange(current_date + 340, current_date + 342), 2, 50000, 100000, 100000, 'en_attente_paiement', now() + interval '10 minutes'),
 ('bbbbbbbb-0000-0000-0000-000000000103', t.p(4), t.u(1), daterange(current_date + 360, current_date + 362), 2, 30000, 60000, 60000, 'en_attente_paiement', now() + interval '10 minutes'),
 ('bbbbbbbb-0000-0000-0000-000000000105', t.p(4), t.u(1), daterange(current_date + 380, current_date + 382), 2, 30000, 60000, 60000, 'en_attente_paiement', now() + interval '10 minutes'),
 ('bbbbbbbb-0000-0000-0000-000000000104', t.p(4), t.u(2), daterange(current_date + 370, current_date + 372), 2, 30000, 60000, 60000, 'en_attente_paiement', now() + interval '10 minutes'),
 ('bbbbbbbb-0000-0000-0000-000000000102', t.p(4), t.u(1), daterange(current_date + 310, current_date + 312), 2, 30000, 60000, 60000, 'en_attente_paiement', now() - interval '10 minutes');

\o
do $$ begin
  if exists (select 1 from t.results where not pass) then
    raise exception 'ÉCHECS : %', (select string_agg(label || ' [' || coalesce(detail,'') || ']', E'\n  ') from t.results where not pass);
  end if;
end $$;
select count(*) || ' tests de la migration 0006 réussis, 0 échec' from t.results;
