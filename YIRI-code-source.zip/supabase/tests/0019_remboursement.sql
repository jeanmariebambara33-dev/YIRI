-- Tests de la migration 0019 : le voyageur n'enclenche plus de remboursement.
--
-- Ce qui est éprouvé ici, c'est d'abord ce qui NE doit PLUS arriver : qu'une annulation crée un
-- remboursement, et qu'un voyageur puisse en obtenir un par un autre chemin que l'interface.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'paiements', t.u(5));

insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'gestion', 'Villa Koulouba', 'd', 'Ouagadougou', 'Koulouba', 'a', 4,2,2, 20000,1, 'publiee', false);
insert into property_photos (property_id, storage_path, position, rights_checked)
values (t.p(1), 'x/1.jpg', 0, true);
insert into management_agreements (property_id, contract_version, starts_on, signed, operational_check_done, expense_policy_version)
values (t.p(1), 'v1', current_date, true, true, 'v1');

-- Une réservation PAYÉE du voyageur 1, qui arrive dans longtemps (donc annulable).
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, guest_phone)
values (t.b(1), t.p(1), t.u(1), daterange(current_date + 60, current_date + 63), 2, 20000, 60000, 60000, 'confirmee', '70000001');
insert into payment_transactions (id, booking_id, purpose, amount_xof, status, provider, provider_reference, idempotency_key)
values (gen_random_uuid(), t.b(1), 'booking', 60000, 'reussi', 'saspay', 'ref-1', 'idem-1');
insert into payment_attempts (reference, object, target_id, created_by, amount_xof, provider, payer_account)
values ('ref-1', 'reservation', t.b(1), t.u(1), 60000, 'saspay', '70000001');

-- ============ Le voyageur annule : les dates se libèrent, rien n'est remboursé ============
reset role; select t.as(1);
select t.eq('l''annulation reste possible',
  format($$select booking_status from cancel_my_booking(%L)$$, t.b(1)), 'annulee');
reset role;
select t.eq('la réservation est bien annulée',
  format($$select status::text from bookings where id = %L$$, t.b(1)), 'annulee');
select t.eq('les dates sont libérées',
  format($$select (hold_expires_at is null)::text from bookings where id = %L$$, t.b(1)), 'true');
select t.eq('AUCUN remboursement n''a été créé', $$select count(*)::text from refunds$$, '0');

-- Le mode renvoyé ne promet plus rien.
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, guest_phone)
values (t.b(2), t.p(1), t.u(2), daterange(current_date + 70, current_date + 73), 2, 20000, 60000, 60000, 'confirmee', '70000002');
insert into payment_transactions (id, booking_id, purpose, amount_xof, status, provider, provider_reference, idempotency_key)
values (gen_random_uuid(), t.b(2), 'booking', 60000, 'reussi', 'saspay', 'ref-2', 'idem-2');
insert into payment_attempts (reference, object, target_id, created_by, amount_xof, provider, payer_account)
values ('ref-2', 'reservation', t.b(2), t.u(2), 60000, 'saspay', '70000002');
select t.as(2);
-- Une seule annulation, les deux vérifications dessus : une réservation ne s'annule qu'une fois.
select t.eq('le site ne promet plus de remboursement, et ne rend aucun identifiant',
  format($$select mode || ' / ' || coalesce(refund_id::text, 'aucun') from cancel_my_booking(%L)$$, t.b(2)),
  'sans_remboursement_auto / aucun');

-- ============ Le voyageur ne peut PAS contourner ============
reset role; select t.as(1);
select t.must_fail('le voyageur ne voit plus le devis de remboursement',
  format($$select * from refund_quote(%L)$$, t.b(1)));
select t.must_fail('il ne crée pas de remboursement lui-même',
  format($$select create_refund(%L, 1000, 'je veux mon argent')$$, t.b(1)));
select t.must_fail('il n''écrit pas dans la table des remboursements',
  $$update refunds set status = 'approuve'$$);
select t.must_fail('il n''insère rien non plus',
  $$insert into refunds (payment_transaction_id, amount_xof, reason, status)
    select id, 1000, 'force', 'approuve' from payment_transactions limit 1$$);
select t.must_fail('il ne lit pas la file de l''équipe', $$select * from refunds_queue()$$);
select t.must_fail('ni la liste des annulations à examiner', $$select * from cancellations_to_review()$$);
select t.must_fail('il n''approuve aucun remboursement',
  $$select approve_refund((select id from refunds limit 1))$$);
select t.ok('mais il consulte toujours SES remboursements (lecture seule)', $$select * from my_refunds()$$);

reset role; select t.as(0);
select t.must_fail('un visiteur n''annule rien', format($$select * from cancel_my_booking(%L)$$, t.b(1)));
select t.must_fail('et ne voit aucun devis', format($$select * from refund_quote(%L)$$, t.b(1)));

-- Un autre voyageur n'annule pas la réservation d'autrui : règle de 0010, conservée.
reset role;
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, guest_phone)
values (t.b(3), t.p(1), t.u(1), daterange(current_date + 80, current_date + 83), 2, 20000, 60000, 60000, 'confirmee', '70000001');
reset role; select t.as(2);
select t.must_fail('on n''annule pas la réservation de quelqu''un d''autre',
  format($$select * from cancel_my_booking(%L)$$, t.b(3)));

-- ============ L'équipe, elle, décide ============
reset role; select t.as(7);
select t.ok('l''équipe « paiements » voit les annulations à examiner', $$select * from cancellations_to_review()$$);
select t.eq('les deux annulations payées y figurent', $$select count(*)::text from cancellations_to_review()$$, '2');
select t.eq('avec ce que le barème prévoyait, pour décider en connaissance de cause',
  format($$select (bareme_net_xof > 0)::text from cancellations_to_review() where booking_id = %L$$, t.b(1)), 'true');

select t.must_fail('un motif est exigé', format($$select create_refund(%L, 10000, 'ok')$$, t.b(1)));
select t.must_fail('un montant supérieur à l''encaissé est refusé',
  format($$select create_refund(%L, 999999, 'geste commercial exceptionnel')$$, t.b(1)));
select t.must_fail('un montant nul est refusé',
  format($$select create_refund(%L, 0, 'geste commercial exceptionnel')$$, t.b(1)));
select t.ok('avec un motif et un montant valable, le remboursement est enregistré',
  format($$select create_refund(%L, 50000, 'Annulation plus de 30 jours avant, geste integral')$$, t.b(1)));
reset role;
select t.eq('une seule ligne créée', $$select count(*)::text from refunds$$, '1');
select t.eq('au bon montant', $$select amount_xof::text from refunds$$, '50000');
select t.eq('le compte du payeur étant connu et le plafond respecté, il est approuvé',
  $$select status::text from refunds$$, 'approuve');
select t.eq('et le voyageur en est informé',
  format($$select count(*)::text from notifications where user_id = %L and type = 'refund.enregistre'$$, t.u(1)), '1');
select t.eq('le journal garde qui a décidé et pourquoi',
  $$select count(*)::text from audit_logs where action = 'refund.created_by_team' and reason like 'Annulation plus de 30 jours%'$$, '1');

select t.as(7);
select t.must_fail('on ne rembourse pas deux fois la même réservation',
  format($$select create_refund(%L, 1000, 'tentative de doublon manifeste')$$, t.b(1)));
select t.eq('la réservation remboursée sort de la liste à examiner',
  $$select count(*)::text from cancellations_to_review()$$, '1');
select t.must_fail('une réservation jamais payée n''a rien à rembourser',
  format($$select create_refund(%L, 1000, 'tentative sur une reservation impayee')$$, t.b(3)));

-- L'équipe « validation » n'a rien à faire ici : les autorisations restent cloisonnées.
reset role; select t.as(6);
select t.must_fail('l''équipe « validation » n''enregistre aucun remboursement',
  format($$select create_refund(%L, 1000, 'hors de mon perimetre habituel')$$, t.b(2)));
select t.must_fail('et ne voit pas les annulations à examiner', $$select * from cancellations_to_review()$$);

-- ============ L'équipe est prévenue d'une annulation sur séjour payé ============
reset role;
select t.eq('l''équipe « paiements » reçoit le signalement',
  format($$select count(*)::text from notifications where user_id = %L and type = 'refund.a_examiner.equipe'$$, t.u(7)), '2');
select t.eq('l''administrateur aussi',
  format($$select count(*)::text from notifications where user_id = %L and type = 'refund.a_examiner.equipe'$$, t.u(5)), '2');
select t.eq('l''équipe « validation », non : ce n''est pas son travail',
  format($$select count(*)::text from notifications where user_id = %L and type = 'refund.a_examiner.equipe'$$, t.u(6)), '0');
select t.eq('le signalement n''est PAS un remboursement : la table est restée à une ligne',
  $$select count(*)::text from refunds$$, '1');

-- Une annulation sur séjour NON payé ne dérange personne.
reset role;
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, guest_phone)
values (t.b(4), t.p(1), t.u(4), daterange(current_date + 90, current_date + 93), 2, 20000, 60000, 60000, 'en_attente_paiement', '70000004');
reset role; select t.as(4);
select t.ok('annuler un séjour impayé reste possible', format($$select * from cancel_my_booking(%L)$$, t.b(4)));
reset role;
select t.eq('et ne déclenche aucun signalement',
  format($$select count(*)::text from notifications where user_id = %L and type = 'refund.a_examiner.equipe'$$, t.u(7)), '2');

-- ============ Rien d'existant n'a été détruit ============
select t.eq('les barèmes sont intacts', $$select count(*)::text from refund_rules$$, '1');
select t.eq('les paiements encaissés sont intacts',
  $$select count(*)::text from payment_transactions where status = 'reussi'$$, '2');
select t.eq('approve_refund existe toujours pour l''équipe',
  $$select (to_regprocedure('public.approve_refund(uuid)') is not null)::text$$, 'true');
select t.eq('my_refunds reste ouverte au voyageur',
  $$select has_function_privilege('authenticated', 'public.my_refunds()', 'execute')::text$$, 'true');
select t.eq('refund_quote est bien fermée au navigateur',
  $$select has_function_privilege('authenticated', 'public.refund_quote(uuid)', 'execute')::text$$, 'false');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0019 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
