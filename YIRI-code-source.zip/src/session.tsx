import * as React from "react";
import { getClient, clientError, frMessage, storageIsPersistent, type SbSession, type SupabaseClient } from "./lib/supabase";

// Session RÉELLE (Supabase Auth). À ne pas confondre avec src/auth.tsx, qui simule l'équipe
// dans le navigateur pour la démo et reste en place le temps de la migration.
//
// Ce que ce fichier garantit :
//  * la session survit au rechargement et le jeton est renouvelé automatiquement (bibliothèque officielle) ;
//  * le rôle et les autorisations ne sont JAMAIS déduits du navigateur : ils sont relus dans la base,
//    où les règles RLS n'autorisent chacun à voir que ses propres lignes ;
//  * toute erreur est traduite en français et affichée, jamais avalée en silence.

export type AppRole = "voyageur" | "proprietaire" | "gestionnaire" | "finance" | "admin";
export type TeamPerm = "validation" | "reservations" | "partenariat" | "demandes" | "paiements" | "audit";

export interface Account {
  id: string;
  email: string;
  fullName: string;
  phone: string | null;
  roles: AppRole[];
  perms: TeamPerm[];
}

interface SessionCtx {
  ready: boolean;                 // le premier chargement est terminé
  busy: boolean;                  // une opération est en cours
  account: Account | null;        // null = personne n'est connecté
  error: string | null;
  notice: string | null;          // message d'information (e-mail envoyé…)
  recovery: boolean;              // l'utilisateur arrive d'un lien « mot de passe oublié »
  warning: string | null;         // avertissement technique (stockage indisponible…)
  signUp(email: string, password: string, fullName: string): Promise<boolean>;
  signIn(email: string, password: string): Promise<boolean>;
  signOut(): Promise<void>;
  sendReset(email: string): Promise<boolean>;
  setPassword(password: string): Promise<boolean>;
  refresh(): Promise<void>;
  clearMessages(): void;
  has(role: AppRole): boolean;
  can(perm: TeamPerm): boolean;
}

const Ctx = React.createContext<SessionCtx | null>(null);

/** Relit l'identité dans la base : profil, rôles, autorisations d'équipe. Jamais depuis le navigateur. */
async function loadAccount(sb: SupabaseClient, session: SbSession): Promise<Account> {
  const id = session.user.id;
  const [prof, roles, perms] = await Promise.all([
    sb.from("profiles").select("full_name,phone").eq("id", id).maybeSingle(),
    sb.from("user_roles").select("role").eq("user_id", id),
    sb.from("team_permissions").select("perm").eq("user_id", id),
  ]);
  const p = (prof.data ?? {}) as { full_name?: string; phone?: string | null };
  return {
    id,
    email: session.user.email ?? "",
    fullName: p.full_name ?? "",
    phone: p.phone ?? null,
    roles: ((roles.data ?? []) as { role: AppRole }[]).map((r) => r.role),
    perms: ((perms.data ?? []) as { perm: TeamPerm }[]).map((r) => r.perm),
  };
}

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [account, setAccount] = React.useState<Account | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [notice, setNotice] = React.useState<string | null>(null);
  const [recovery, setRecovery] = React.useState(false);
  const [warning, setWarning] = React.useState<string | null>(null);

  const sb = React.useMemo(() => getClient(), []);
  const alive = React.useRef(true);
  React.useEffect(() => () => { alive.current = false; }, []);

  const apply = React.useCallback(async (session: SbSession | null) => {
    if (!sb || !session) { if (alive.current) setAccount(null); return; }
    try {
      const acc = await loadAccount(sb, session);
      if (alive.current) setAccount(acc);
    } catch (e) {
      if (alive.current) { setAccount(null); setError(frMessage(e, "Impossible de lire votre compte.")); }
    }
  }, [sb]);

  // Démarrage : session existante + abonnement aux changements (connexion, déconnexion,
  // renouvellement du jeton, retour d'un lien e-mail).
  React.useEffect(() => {
    if (!sb) { setError(clientError()); setReady(true); return; }
    let sub: { unsubscribe(): void } | null = null;
    (async () => {
      const { data, error: e } = await sb.auth.getSession();
      if (e) setError(frMessage(e));
      await apply(data?.session ?? null);
      if (alive.current) setReady(true);
      sub = sb.auth.onAuthStateChange((event, session) => {
        if (event === "PASSWORD_RECOVERY") setRecovery(true);
        if (event === "SIGNED_OUT") { setAccount(null); return; }
        void apply(session);
      }).data.subscription;
    })();
    return () => sub?.unsubscribe();
  }, [sb, apply]);

  React.useEffect(() => {
    if (!storageIsPersistent) setWarning("Votre navigateur bloque l'enregistrement local : vous devrez vous reconnecter en changeant d'onglet.");
  }, [ready]);

  const guard = React.useCallback(async (fn: () => Promise<boolean>): Promise<boolean> => {
    if (!sb) { setError(clientError()); return false; }
    setBusy(true); setError(null); setNotice(null);
    try { return await fn(); }
    catch (e) { setError(frMessage(e)); return false; }
    finally { if (alive.current) setBusy(false); }
  }, [sb]);

  const redirectTo = typeof location !== "undefined" && location.protocol.startsWith("http")
    ? location.origin + location.pathname
    : undefined;

  const value: SessionCtx = {
    ready, busy, account, error, notice, recovery, warning,

    signUp: (email, password, fullName) => guard(async () => {
      const name = fullName.trim();
      if (name.length < 2) { setError("Indiquez votre nom complet."); return false; }
      if (password.length < 8) { setError("Le mot de passe doit contenir au moins 8 caractères."); return false; }
      // Le rôle n'est jamais envoyé par le navigateur : le déclencheur de la base attribue « voyageur ».
      const { data, error: e } = await sb!.auth.signUp({
        email: email.trim(), password,
        options: { data: { full_name: name }, emailRedirectTo: redirectTo },
      });
      if (e) { setError(frMessage(e)); return false; }
      if (data?.session) { await apply(data.session); setNotice("Votre compte est créé."); return true; }
      setNotice("Compte créé. Ouvrez le message envoyé à " + email.trim() + " pour confirmer votre adresse, puis connectez-vous.");
      return true;
    }),

    signIn: (email, password) => guard(async () => {
      const { data, error: e } = await sb!.auth.signInWithPassword({ email: email.trim(), password });
      if (e) { setError(frMessage(e)); return false; }
      await apply(data?.session ?? null);
      return true;
    }),

    signOut: async () => {
      if (!sb) return;
      setBusy(true);
      try { await sb.auth.signOut(); } catch (e) { setError(frMessage(e)); }
      finally {
        if (alive.current) { setAccount(null); setRecovery(false); setBusy(false); setNotice("Vous êtes déconnecté."); }
      }
    },

    sendReset: (email) => guard(async () => {
      const { error: e } = await sb!.auth.resetPasswordForEmail(email.trim(), { redirectTo });
      if (e) { setError(frMessage(e)); return false; }
      // Réponse volontairement identique que le compte existe ou non : on n'indique pas qui est inscrit.
      setNotice("Si un compte existe pour " + email.trim() + ", un lien de réinitialisation vient d'être envoyé.");
      return true;
    }),

    setPassword: (password) => guard(async () => {
      if (password.length < 8) { setError("Le mot de passe doit contenir au moins 8 caractères."); return false; }
      const { error: e } = await sb!.auth.updateUser({ password });
      if (e) { setError(frMessage(e)); return false; }
      setRecovery(false);
      setNotice("Mot de passe modifié.");
      return true;
    }),

    refresh: async () => {
      if (!sb) return;
      const { data } = await sb.auth.getSession();
      await apply(data?.session ?? null);
    },

    clearMessages: () => { setError(null); setNotice(null); },
    has: (role) => !!account && (account.roles.includes(role) || account.roles.includes("admin")),
    can: (perm) => !!account && (account.roles.includes("admin") || account.perms.includes(perm)),
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSession(): SessionCtx {
  const c = React.useContext(Ctx);
  if (!c) throw new Error("useSession doit être utilisé dans <SessionProvider>");
  return c;
}

/** Protection d'accès : rien ne s'affiche tant que l'identité n'est pas confirmée par le serveur. */
export function Protected({ role, perm, children, fallback }: {
  role?: AppRole; perm?: TeamPerm; children: React.ReactNode; fallback: React.ReactNode;
}) {
  const s = useSession();
  if (!s.ready) return <p className="py-16 text-center text-muted">Chargement…</p>;
  if (!s.account) return <>{fallback}</>;
  if (role && !s.has(role)) return <AccessDenied what={role} />;
  if (perm && !s.can(perm)) return <AccessDenied what={perm} />;
  return <>{children}</>;
}

function AccessDenied({ what }: { what: string }) {
  return (
    <div className="mx-auto max-w-md py-16">
      <h1 className="font-display text-2xl font-bold text-ink">Accès refusé</h1>
      <p className="mt-2 text-muted">Votre compte n'a pas l'autorisation « {what} ». Si c'est une erreur, contactez l'équipe YIRI.</p>
    </div>
  );
}
