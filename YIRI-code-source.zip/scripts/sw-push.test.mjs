// Tests des gestionnaires du service worker, sur le fichier RÉELLEMENT déployé (assets/sw.js).
//
// Un service worker ne s'exécute pas sous Node : on lui fournit le « self » qu'il attend, puis on
// déclenche les événements à la main. Ce qui est éprouvé est donc bien le code livré.
//
// Pourquoi ces tests : un navigateur qui reçoit un push et n'affiche AUCUNE notification finit
// par retirer l'autorisation à l'application. Un contenu illisible ne doit donc jamais aboutir
// à un silence.
import fs from "node:fs";
import vm from "node:vm";

let reussis = 0, total = 0;
const echecs = [];
const ok = (l, v, d = "") => { total++; if (v) reussis++; else echecs.push(`${l}${d ? " — " + d : ""}`); };

function chargerSW() {
  const ecoutes = {};
  const affichees = [];
  const ouvertes = [];
  const messages = [];
  let fenetres = [];
  const self = {
    location: { origin: "https://yiri.bf" },
    addEventListener: (type, fn) => { (ecoutes[type] ||= []).push(fn); },
    skipWaiting: async () => {},
    registration: {
      showNotification: async (titre, opts) => { affichees.push({ titre, ...opts }); },
    },
    clients: {
      claim: async () => {},
      matchAll: async () => fenetres,
      openWindow: async (u) => { ouvertes.push(u); },
    },
    caches: {
      open: async () => ({ add: async () => {}, put: async () => {}, match: async () => undefined }),
      keys: async () => [],
      delete: async () => {},
      match: async () => undefined,
    },
  };
  const ctx = {
    self, caches: self.caches, fetch: async () => ({ ok: true, clone: () => ({}) }),
    Response: { error: () => ({}) }, URL, console,
  };
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync("assets/sw.js", "utf8"), ctx);

  // On attrape tout : un gestionnaire qui lève une exception doit se traduire par un test
  // en ÉCHEC, pas par un arrêt brutal du fichier de tests.
  const declencher = async (type, e) => {
    const attentes = [];
    const ev = { ...e, waitUntil: (p) => attentes.push(p) };
    for (const fn of ecoutes[type] ?? []) {
      try { fn(ev); } catch (err) { echecs.push(`gestionnaire « ${type} » a levé : ${err.message}`); total++; }
    }
    try { await Promise.all(attentes); } catch (err) { echecs.push(`gestionnaire « ${type} » a échoué : ${err.message}`); total++; }
  };
  return { declencher, affichees, ouvertes, messages, ecoutes,
           setFenetres: (f) => { fenetres = f; } };
}

// ---------------------------------------------------------------------------
// 1. Un push normal s'affiche
// ---------------------------------------------------------------------------
{
  const sw = chargerSW();
  ok("le service worker écoute bien les pushs", (sw.ecoutes.push ?? []).length === 1);
  ok("et les clics sur notification", (sw.ecoutes.notificationclick ?? []).length === 1);
  ok("et le renouvellement d'abonnement", (sw.ecoutes.pushsubscriptionchange ?? []).length === 1);

  await sw.declencher("push", {
    data: { json: () => ({ titre: "Réservation payée", corps: "Studio Gounghin. À préparer.", lien: "https://yiri.bf/#equipe", id: "n-1" }) },
  });
  const n = sw.affichees[0];
  ok("la notification est affichée", sw.affichees.length === 1);
  ok("avec le titre reçu", n && n.titre === "Réservation payée");
  ok("et le texte reçu", n && n.body === "Studio Gounghin. À préparer.");
  ok("l'icône de YIRI est utilisée", n && n.icon === "/icone-192.png");
  ok("la langue est déclarée en français", n && n.lang === "fr");
  ok("l'identifiant sert d'étiquette, pour ne pas empiler deux fois la même alerte", n && n.tag === "n-1");
  ok("le lien est gardé pour le clic", n && n.data && n.data.lien === "https://yiri.bf/#equipe");
}

// ---------------------------------------------------------------------------
// 2. Un contenu abîmé n'aboutit JAMAIS au silence
// ---------------------------------------------------------------------------
{
  const sw = chargerSW();
  await sw.declencher("push", { data: { json: () => { throw new Error("illisible"); } } });
  ok("un contenu illisible affiche quand même une notification", sw.affichees.length === 1);
  ok("sous le nom de YIRI", sw.affichees[0]?.titre === "YIRI");
}
{
  const sw = chargerSW();
  await sw.declencher("push", { data: null });
  ok("un push sans contenu affiche quand même une notification", sw.affichees.length === 1);
}
{
  const sw = chargerSW();
  await sw.declencher("push", { data: { json: () => ({ titre: "", corps: 42, lien: null }) } });
  const n = sw.affichees[0];
  ok("un titre vide est remplacé", n?.titre === "YIRI");
  ok("un texte qui n'est pas du texte est ignoré sans casser", n && n.body === "");
  ok("un lien absent renvoie à l'accueil", n && n.data.lien === "/");
}

// ---------------------------------------------------------------------------
// 3. Le clic ouvre le bon écran, sans empiler les onglets
// ---------------------------------------------------------------------------
{
  const sw = chargerSW();
  const visitees = [];
  sw.setFenetres([{ url: "https://yiri.bf/#espace", focus: async () => visitees.push("focus"), navigate: async (u) => visitees.push(u) }]);
  await sw.declencher("notificationclick", {
    notification: { close: () => visitees.push("fermee"), data: { lien: "https://yiri.bf/#equipe" } },
  });
  ok("la notification est refermée", visitees[0] === "fermee");
  ok("l'onglet déjà ouvert est réutilisé", visitees.includes("focus"));
  ok("et amené sur le bon écran", visitees.includes("https://yiri.bf/#equipe"));
  ok("aucun nouvel onglet n'est ouvert", sw.ouvertes.length === 0);
}
{
  const sw = chargerSW();
  sw.setFenetres([]);
  await sw.declencher("notificationclick", {
    notification: { close: () => {}, data: { lien: "https://yiri.bf/#espace" } },
  });
  ok("sans onglet ouvert, un onglet est ouvert", sw.ouvertes.length === 1 && sw.ouvertes[0] === "https://yiri.bf/#espace");
}
{
  // Un onglet d'un autre site ne doit pas être détourné.
  const sw = chargerSW();
  let detourne = false;
  sw.setFenetres([{ url: "https://autre-site.example/page", focus: async () => { detourne = true; }, navigate: async () => { detourne = true; } }]);
  await sw.declencher("notificationclick", { notification: { close: () => {}, data: { lien: "https://yiri.bf/#equipe" } } });
  ok("un onglet d'un autre site n'est jamais détourné", !detourne);
  ok("c'est un nouvel onglet YIRI qui s'ouvre", sw.ouvertes.length === 1);
}
{
  // Certains navigateurs interdisent navigate() : le focus doit suffire, sans erreur.
  const sw = chargerSW();
  let focalise = false;
  sw.setFenetres([{ url: "https://yiri.bf/", focus: async () => { focalise = true; }, navigate: async () => { throw new Error("interdit"); } }]);
  let leve = false;
  try {
    await sw.declencher("notificationclick", { notification: { close: () => {}, data: { lien: "https://yiri.bf/#equipe" } } });
  } catch { leve = true; }
  ok("un navigateur qui interdit la navigation ne provoque aucune erreur", !leve);
  ok("l'onglet est au moins ramené au premier plan", focalise);
}

// ---------------------------------------------------------------------------
// 4. Le renouvellement d'abonnement prévient le site
// ---------------------------------------------------------------------------
{
  const sw = chargerSW();
  const recus = [];
  sw.setFenetres([{ url: "https://yiri.bf/", postMessage: (m) => recus.push(m) }]);
  await sw.declencher("pushsubscriptionchange", {});
  ok("le site est averti qu'il faut réenregistrer l'appareil",
    recus.length === 1 && recus[0].yiri === "push-a-reenregistrer");
}

// ---------------------------------------------------------------------------
// 5. La version du cache a bien été changée
// ---------------------------------------------------------------------------
{
  const source = fs.readFileSync("assets/sw.js", "utf8");
  ok("la version du cache n'est plus v1 : sinon les anciens appareils gardent l'ancien service worker, sans push",
    /const VERSION = "yiri-v[2-9]/.test(source));
  ok("le service worker ne s'interpose jamais entre l'application et Supabase",
    /url.origin !== self.location.origin/.test(source));
}

console.log(`${reussis} / ${total} contrôles du service worker réussis`);
for (const e of echecs) console.log("ECHEC", e);
process.exit(echecs.length === 0 ? 0 : 1);
