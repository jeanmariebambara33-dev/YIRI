// Tests de la version installable : manifeste, icônes, service worker, hors connexion, invitation à installer.
// Un vrai serveur local est lancé, car un service worker ne fonctionne qu'en https ou sur localhost.
import { chromium, devices } from "/opt/npm-tools/node_modules/playwright/index.mjs";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const DOSSIER = "/home/claude/yiri/dist/site-yiri";
const PORT = 8787;
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8", ".png": "image/png", ".txt": "text/plain", ".json": "application/json" };

const serveur = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
  if (p === "/") p = "/index.html";
  const f = path.join(DOSSIER, p);
  if (!f.startsWith(DOSSIER) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); res.end("introuvable"); return; }
  res.writeHead(200, { "Content-Type": TYPES[path.extname(f)] || "application/octet-stream" });
  res.end(fs.readFileSync(f));
});
await new Promise((r) => serveur.listen(PORT, "127.0.0.1", r));
const URL_ = `http://127.0.0.1:${PORT}/`;

let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run", "--disable-default-apps", "--no-default-browser-check"] });

// ===================== 1. Manifeste et icônes =====================
{
  const ctx = await b.newContext({ ...devices["Pixel 7"] });
  await ctx.route("**/*", (r) => (r.request().url().startsWith("http://127.0.0.1:") ? r.continue() : r.abort()));
  const p = await ctx.newPage();
  const errs = []; p.on("pageerror", (e) => errs.push(e.message));
  await p.goto(URL_); await p.waitForTimeout(900);

  const m = await p.evaluate(async () => {
    const lien = document.querySelector('link[rel=manifest]');
    if (!lien) return null;
    const r = await fetch(lien.getAttribute("href"));
    return { statut: r.status, type: r.headers.get("content-type"), json: await r.json() };
  });
  ok("le manifeste est lié et se charge", !!m && m.statut === 200);
  ok("le manifeste est servi avec le bon type", !!m && /manifest\+json/.test(m.type || ""));
  ok("nom court « YIRI »", m?.json.short_name === "YIRI");
  ok("ouverture en plein écran (standalone)", m?.json.display === "standalone");
  ok("couleur de thème de la marque", m?.json.theme_color === "#49372f");
  ok("trois icônes dont une « maskable »", m?.json.icons.length === 3 && m.json.icons.some((i) => i.purpose === "maskable"));
  ok("raccourcis vers les pages clés", (m?.json.shortcuts || []).length === 3);

  const icones = await p.evaluate(async () => {
    const out = {};
    for (const u of ["/icone-192.png", "/icone-512.png", "/icone-maskable-512.png", "/apple-touch-icon.png"]) {
      const r = await fetch(u); out[u] = r.status === 200 && (r.headers.get("content-type") || "").includes("image/png");
    }
    return out;
  });
  ok("les quatre icônes existent et sont des PNG", Object.values(icones).every(Boolean));
  ok("icône Apple déclarée dans la page", await p.locator('link[rel="apple-touch-icon"]').count() === 1);
  ok("titre court pour l'écran d'accueil iOS", await p.locator('meta[name="apple-mobile-web-app-title"]').count() === 1);
  ok("aucune erreur JavaScript", errs.length === 0);
  await ctx.close();
}

// ===================== 2. Service worker et hors connexion =====================
{
  const ctx = await b.newContext({ ...devices["Pixel 7"] });
  await ctx.route("**/*", (r) => (r.request().url().startsWith("http://127.0.0.1:") ? r.continue() : r.abort()));
  const p = await ctx.newPage();
  await p.goto(URL_);
  const actif = await p.evaluate(async () => {
    const r = await navigator.serviceWorker.ready;
    return !!r.active;
  });
  ok("le service worker s'installe et devient actif", actif);

  await p.waitForTimeout(1200);
  await ctx.setOffline(true);
  const reponse = await p.goto(URL_, { waitUntil: "domcontentloaded" }).catch(() => null);
  const texte = reponse ? await p.locator("body").innerText() : "";
  ok("hors connexion : la page s'ouvre quand même", /YIRI/.test(texte));
  ok("hors connexion : le menu est présent", /Logements/.test(texte) && /Propriétaires/.test(texte));

  // le service worker ne doit JAMAIS servir Supabase depuis sa mémoire
  const distant = await p.evaluate(async () => {
    try { await fetch("https://kzzrowymwwxoydklnkfb.supabase.co/rest/v1/public_listings"); return "repondu"; }
    catch { return "echec reseau"; }
  });
  ok("hors connexion : les appels au serveur échouent, ils ne sont pas inventés", distant === "echec reseau");

  await ctx.setOffline(false);
  await p.goto(URL_); await p.waitForTimeout(600);
  ok("retour en ligne : la page se recharge normalement", /YIRI/.test(await p.locator("body").innerText()));
  await ctx.close();
}

// ===================== 3. Invitation à installer, Android =====================
{
  const ctx = await b.newContext({ ...devices["Pixel 7"] });
  await ctx.route("**/*", (r) => (r.request().url().startsWith("http://127.0.0.1:") ? r.continue() : r.abort()));
  const p = await ctx.newPage();
  await p.goto(URL_); await p.waitForTimeout(800);
  ok("aucun bandeau tant que le navigateur ne propose rien", await p.locator("text=Installer YIRI").count() === 0);

  await p.evaluate(() => {
    const e = new Event("beforeinstallprompt");
    e.prompt = async () => { window.__promptAppele = true; };
    Object.defineProperty(e, "userChoice", { value: Promise.resolve({ outcome: "accepted" }) });
    window.dispatchEvent(e);
  });
  await p.waitForTimeout(400);
  ok("le bandeau apparaît quand le navigateur le propose", await p.locator("text=Installer YIRI").count() === 1);
  ok("le bouton « Installer » est présent", await p.getByRole("button", { name: "Installer", exact: true }).count() === 1);
  await p.getByRole("button", { name: "Installer", exact: true }).click();
  await p.waitForTimeout(500);
  ok("le clic déclenche bien l'installation du navigateur", await p.evaluate(() => window.__promptAppele === true));
  ok("le bandeau disparaît après la décision", await p.locator("text=Installer YIRI").count() === 0);

  await p.reload(); await p.waitForTimeout(800);
  await p.evaluate(() => {
    const e = new Event("beforeinstallprompt");
    e.prompt = async () => {};
    Object.defineProperty(e, "userChoice", { value: Promise.resolve({ outcome: "dismissed" }) });
    window.dispatchEvent(e);
  });
  await p.waitForTimeout(400);
  ok("le bandeau ne revient pas après une première décision", await p.locator("text=Installer YIRI").count() === 0);
  await ctx.close();
}

// ===================== 4. Invitation à installer, iPhone =====================
{
  const ctx = await b.newContext({ ...devices["iPhone 13"] });
  await ctx.route("**/*", (r) => (r.request().url().startsWith("http://127.0.0.1:") ? r.continue() : r.abort()));
  const p = await ctx.newPage();
  await p.goto(URL_); await p.waitForTimeout(800);
  ok("iPhone : rien ne s'affiche tout de suite", await p.locator("text=Installer YIRI").count() === 0);
  await p.waitForTimeout(4300);
  const vu = await p.locator("text=Installer YIRI").count() === 1;
  ok("iPhone : l'explication apparaît après quelques secondes", vu);
  if (vu) {
    const t = await p.locator("text=Sur l'écran d'accueil").count();
    ok("iPhone : le geste exact est expliqué (Partager → Sur l'écran d'accueil)", t === 1);
    await p.getByRole("button", { name: "Fermer" }).click();
    await p.waitForTimeout(300);
    ok("iPhone : le bandeau se ferme", await p.locator("text=Installer YIRI").count() === 0);
    await p.reload(); await p.waitForTimeout(5000);
    ok("iPhone : il ne revient pas après fermeture", await p.locator("text=Installer YIRI").count() === 0);
  }
  await ctx.close();
}

await b.close();
serveur.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DE LA VERSION INSTALLABLE SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
