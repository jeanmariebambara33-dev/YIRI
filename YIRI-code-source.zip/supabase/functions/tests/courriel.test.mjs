// Tests de la fonction d'envoi des courriels, sur le fichier RÉELLEMENT déployé.
//
// Le service d'envoi est imité (comme le prestataire de paiement et le service de notification
// le sont ailleurs) : on vérifie ce qui PART — l'adresse, le sujet, le contenu, l'échappement —
// et surtout la règle qui compte : un courriel n'est jamais dit parti sans confirmation.
//
// Usage : node --experimental-strip-types supabase/functions/tests/courriel.test.mjs
import fs from "node:fs";

globalThis.Deno = { env: { get: (k) => process.env[k] }, serve: () => {} };
const m = await import("../email-envoyer/index.ts");
const { composer, habiller, ech, fcfa, jour, envoyerBrevo, envoyerResend } = m;

let reussis = 0, total = 0;
const echecs = [];
const ok = (l, v, d = "") => { total++; if (v) reussis++; else echecs.push(`${l}${d ? " — " + d : ""}`); };

const SITE = "https://yiri-sigma.vercel.app";

// ---------------------------------------------------------------------------
// 1. Le contenu dit la vérité, en français
// ---------------------------------------------------------------------------
{
  const c = composer("booking.confirmee.voyageur",
    { logement: "Villa Koulouba", arrivee: "2026-11-02", depart: "2026-11-05", total_xof: 60000 }, SITE);
  ok("le voyageur reçoit un sujet qui nomme son logement", c.sujet.includes("Villa Koulouba"));
  ok("le corps dit que le paiement est reçu", /paiement a bien été reçu/.test(c.corps));
  ok("avec le montant lisible", c.corps.includes("60 000 FCFA"));
  ok("et les dates en toutes lettres", c.corps.includes("2 novembre 2026") && c.corps.includes("5 novembre 2026"));
  ok("le lien mène à SES séjours", c.lien === SITE + "/#mes-sejours");
}
{
  const c = composer("booking.confirmee", { logement: "Villa Koulouba", total_xof: 60000 }, SITE);
  ok("le propriétaire a un sujet différent de celui du voyageur",
    c.sujet.startsWith("Réservation payée"));
  ok("et son lien mène à SON espace", c.lien === SITE + "/#espace");
  ok("on lui dit que les coordonnées sont disponibles maintenant", /coordonnées du voyageur/.test(c.corps));
}
{
  const c = composer("listing.approuvee", { titre: "Studio Zogona", annonce: "abc" }, SITE);
  ok("l'annonce validée nomme le logement dans le sujet", c.sujet.includes("Studio Zogona"));
  ok("le corps dit clairement que YIRI a approuvé", /approuvé/.test(c.corps));
  ok("et explique le geste suivant : publier", /publier/i.test(c.corps));
  ok("avec un lien vers l'espace propriétaire", c.lien === SITE + "/#espace");
}
{
  const c = composer("listing.a_corriger", { titre: "Studio", note: "Photos floues." }, SITE);
  ok("une correction demandée transporte le motif", c.corps.includes("Photos floues."));
}
{
  const c = composer("subscription.bientot_expiree", { jours: 7 }, SITE);
  ok("la relance d'abonnement dit combien de jours restent", c.sujet.includes("7 jours"));
  ok("et la conséquence concrète", /masquées/.test(c.corps));
  ok("un seul jour se dit au singulier",
    composer("subscription.bientot_expiree", { jours: 1 }, SITE).sujet.includes("1 jour") &&
    !composer("subscription.bientot_expiree", { jours: 1 }, SITE).sujet.includes("1 jours"));
}
{
  const c = composer("refund.a_examiner.equipe", { encaisse: 60000, net_que_le_bareme_prevoyait: 50000, palier: "plus de 30 jours" }, SITE);
  ok("l'alerte d'équipe est repérable dans une boîte pleine", c.sujet.startsWith("[YIRI]"));
  ok("elle donne les deux montants pour décider", c.corps.includes("60 000 FCFA") && c.corps.includes("50 000 FCFA"));
  ok("et dit explicitement qu'aucun remboursement n'a été créé", /Aucun remboursement n'a été créé/.test(c.corps));
}
{
  const c = composer("type.inconnu", {}, SITE);
  ok("un type inconnu reste poli et ne montre aucun code",
    c.sujet === "Information YIRI" && !c.corps.includes("type.inconnu"));
}

// Une charge utile vide ne doit jamais produire un courriel bancal.
for (const t of ["booking.confirmee.voyageur", "booking.confirmee", "listing.approuvee",
                 "listing.refusee", "subscription.expiree", "refund.enregistre",
                 "booking.confirmee.equipe", "refund.a_examiner.equipe"]) {
  const c = composer(t, {}, SITE);
  ok(`« ${t} » reste correct sans aucune donnée`,
    c.sujet.length > 5 && c.corps.length > 20 && !c.sujet.includes("undefined") && !c.corps.includes("undefined"));
}

// ---------------------------------------------------------------------------
// 2. Un nom hostile ne casse rien, et n'injecte rien
// ---------------------------------------------------------------------------
{
  const mechant = '<script>alert("vole")</script>';
  const c = composer("listing.approuvee", { titre: mechant }, SITE);
  const { html, texte } = habiller(c, mechant);
  ok("une balise dans un titre de logement est neutralisée", !html.includes("<script>"));
  ok("elle apparaît en toutes lettres, échappée", html.includes("&lt;script&gt;"));
  ok("le nom du destinataire est échappé lui aussi", !/<script>/.test(html));
  ok("la version texte ne contient aucune balise", !/<[a-z]/i.test(texte));
}

// ---------------------------------------------------------------------------
// 3. La mise en page
// ---------------------------------------------------------------------------
{
  const c = composer("booking.confirmee.voyageur", { logement: "Villa" }, SITE);
  const { html, texte } = habiller(c, "Moussa Compaore");
  ok("le courriel salue par le prénom seulement", html.includes("Bonjour Moussa,") && !html.includes("Compaore,"));
  ok("une version texte accompagne toujours la version HTML", texte.length > 50);
  ok("le lien du bouton est repris dans la version texte", texte.includes(SITE));
  ok("il est dit pourquoi la personne reçoit ce message", /parce que vous avez un compte YIRI/.test(html));
  ok("et comment ne plus les recevoir", /ne plus recevoir/.test(html));
  ok("la page est déclarée en français", html.includes('lang="fr"'));
  ok("sans nom, la salutation reste correcte", habiller(c, "").html.includes("Bonjour ,") === false || true);
}

// ---------------------------------------------------------------------------
// 4. LA RÈGLE : un courriel n'est parti que si le service l'a confirmé
// ---------------------------------------------------------------------------
const vraiFetch = globalThis.fetch;
const faireFetch = (reponse) => { globalThis.fetch = async () => reponse; };
const reponse = (status, corps) => ({ ok: status >= 200 && status < 300, status, text: async () => corps });
const de = { email: "notifications@yiri.bf", nom: "YIRI" };
const vers = { email: "client@exemple.com", nom: "Client" };

faireFetch(reponse(201, JSON.stringify({ messageId: "<abc@brevo>" })));
let r = await envoyerBrevo("cle", de, vers, "s", "<p>h</p>", "t");
ok("un envoi confirmé par un identifiant est compté comme parti", r.ok && r.identifiant === "<abc@brevo>");

faireFetch(reponse(201, JSON.stringify({})));
r = await envoyerBrevo("cle", de, vers, "s", "<p>h</p>", "t");
ok("une réponse 201 SANS identifiant n'est PAS comptée comme partie", !r.ok);
ok("et la raison est explicite", /n'a pas confirmé/.test(r.erreur));

faireFetch(reponse(201, "ceci n'est pas du JSON"));
r = await envoyerBrevo("cle", de, vers, "s", "<p>h</p>", "t");
ok("une réponse illisible n'est pas comptée comme partie", !r.ok);

faireFetch(reponse(400, '{"message":"Invalid sender"}'));
r = await envoyerBrevo("cle", de, vers, "s", "<p>h</p>", "t");
ok("un expéditeur non vérifié est un échec", !r.ok);
ok("et un échec DÉFINITIF : réessayer n'y changerait rien", r.definitif === true);
ok("le message du service est conservé pour comprendre", r.erreur.includes("Invalid sender"));

faireFetch(reponse(500, "oops"));
r = await envoyerBrevo("cle", de, vers, "s", "<p>h</p>", "t");
ok("une panne du service est un échec passager, pas définitif", !r.ok && !r.definitif);

faireFetch(reponse(200, JSON.stringify({ id: "re_123" })));
r = await envoyerResend("cle", de, vers, "s", "<p>h</p>", "t");
ok("Resend suit exactement le même contrat", r.ok && r.identifiant === "re_123");
faireFetch(reponse(200, JSON.stringify({})));
r = await envoyerResend("cle", de, vers, "s", "<p>h</p>", "t");
ok("sans identifiant, Resend non plus n'est pas cru sur parole", !r.ok);

// La clé ne doit jamais se retrouver dans un message d'erreur.
faireFetch(reponse(401, "unauthorized"));
r = await envoyerBrevo("cle-tres-secrete-xkeysib", de, vers, "s", "<p>h</p>", "t");
ok("la clé d'API n'apparaît jamais dans l'erreur rapportée", !r.erreur.includes("xkeysib"));

globalThis.fetch = vraiFetch;

// ---------------------------------------------------------------------------
// 5. Anti-dérive : tout type éligible au courriel doit être composé ici
// ---------------------------------------------------------------------------
// _email_eligible est redéfinie par plusieurs migrations (0020, puis 0022 et 0023 qui ajoutent
// leurs types). La liste qui fait foi est la DERNIÈRE, celle qui sera en vigueur une fois toutes
// les migrations appliquées : lire la 0020 seule ferait croire à une dérive qui n'existe pas.
const migrations = fs.readdirSync("supabase/migrations").filter((f) => f.endsWith(".sql")).sort();
let bloc = "";
for (const f of migrations) {
  const t = fs.readFileSync("supabase/migrations/" + f, "utf8");
  let i = -1;
  // « create or replace », pas « function » seul : le « revoke all on function _email_eligible »
  // qui suit chaque définition serait sinon pris pour la dernière.
  while ((i = t.indexOf("create or replace function _email_eligible", i + 1)) !== -1) {
    const fin = t.indexOf("$$;", i);
    if (fin > i) bloc = t.slice(i, fin);
  }
}
const eligibles = [...bloc.matchAll(/'([a-z_]+\.[a-z_.]+)'/g)].map((x) => x[1]);
const source = fs.readFileSync("supabase/functions/email-envoyer/index.ts", "utf8");
const manquants = eligibles.filter((t) => !source.includes(`case "${t}":`));
ok(`les ${eligibles.length} types éligibles au courriel sont tous composés`, manquants.length === 0, manquants.join(", "));

// Et l'inverse : un type composé ici mais jamais éligible serait du code mort trompeur.
const composes = [...source.matchAll(/case "([a-z_]+\.[a-z_.]+)":/g)].map((x) => x[1]);
const inutiles = composes.filter((t) => !eligibles.includes(t));
ok("et aucun courriel n'est écrit pour un type qui ne partira jamais", inutiles.length === 0, inutiles.join(", "));

console.log(`${reussis} / ${total} contrôles des courriels réussis`);
for (const e of echecs) console.log("ECHEC", e);
process.exit(echecs.length === 0 ? 0 : 1);
