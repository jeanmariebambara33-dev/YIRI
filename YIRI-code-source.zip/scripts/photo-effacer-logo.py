# Lancement : python3 scripts/photo-effacer-logo.py   (pillow, numpy, scipy, opencv)
#
# Part de la photo fournie et produit assets/photo/accueil-source.png, sans le logo incrusté.
# Conservé pour que la retouche soit refaisable et vérifiable, plutôt que d'avoir dans le dépôt
# une image dont personne ne saurait dire comment elle a été obtenue.
# Efface le logo incrusté dans la photo de référence.
#
# Le logo ne recouvre que du ciel : le coeur du soleil est à (885, 497) et le bas des lettres
# s'arrête à y≈490. Il n'y a donc qu'une étendue lisse à reconstruire, pas un sujet.
#
# Méthode : reconstruction harmonique. On impose à la zone effacée de valoir, sur tout son
# pourtour, le ciel réel qui l'entoure, et d'être partout ailleurs aussi plate que possible
# (laplacien nul). La surface obtenue est la « membrane » tendue sur ce contour : elle rejoint le
# ciel sans couture et suit sa montée vers le soleil, puisque le bord bas du trou est déjà clair.
#
# Un ajustement ligne par ligne avait été essayé d'abord : il ne voyait que la gauche et la
# droite, ignorait le haut et le bas, et produisait un plateau plus clair que le ciel, visible
# comme une pièce rapportée.
import numpy as np, cv2
from PIL import Image
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import spsolve

SRC = "/root/.claude/uploads/bccfc1ab-e639-5eb6-9792-eac06cd6c9b3/98ee428a-image.png"
DST = "/home/claude/yiri/assets/photo/accueil-source.png"

im = np.asarray(Image.open(SRC).convert("RGB")).astype(np.float64)
H, W, _ = im.shape
X0, X1, Y0, Y1 = 588, 958, 318, 505
GAUCHE, DROITE = slice(420, X0 - 4), slice(X1 + 4, 1130)

# --- 1. masque du logo ---
masque = np.zeros((H, W), bool)
for y in range(Y0, Y1):
    ref = np.median(np.concatenate([im[y, GAUCHE], im[y, DROITE]]), axis=0)
    b = im[y, X0:X1]
    masque[y, X0:X1] = (b.sum(1) < ref.sum() - 40) | ((b[:, 0] - b[:, 2]) < (ref[0] - ref[2]) - 25)
masque = cv2.dilate(masque.astype(np.uint8), np.ones((7, 7), np.uint8), 2).astype(bool)
masque[:Y0] = masque[Y1:] = False
masque[:, :X0] = masque[:, X1:] = False
ys, xs = np.where(masque)
y0, y1, x0, x1 = ys.min() - 2, ys.max() + 3, xs.min() - 2, xs.max() + 3
print(f"zone {x1-x0}x{y1-y0}, {masque.sum()} pixels à reconstruire")

# --- 2. membrane : laplacien nul à l'intérieur, ciel réel au bord ---
#
# Deux passes. La première efface le gros du logo ; la seconde rattrape ce que le seuil de la
# première a laissé passer — le pied des lettres, où le logo était presque transparent et donc
# à peine plus sombre que le ciel. On ne peut pas simplement baisser ce seuil : il emporterait
# les nuages et la ligne d'horizon. On repère donc les restes SUR LE RÉSULTAT, en les comparant
# à sa propre version très floue : un ciel lisse ne s'écarte pas de son flou, un fantôme si.
SOLEIL = (885, 499, 24)          # x, y, rayon protégé : seul le COEUR du soleil est intouchable.
                                 # Un rayon large couvrait aussi le pied du R et du I, qui
                                 # restaient alors en place : la protection recréait le défaut.

def resoudre(image, masque):
    ys, xs = np.where(masque)
    y0, y1, x0, x1 = ys.min() - 2, ys.max() + 3, xs.min() - 2, xs.max() + 3
    sous = masque[y0:y1, x0:x1]
    h, w = sous.shape
    idx = -np.ones((h, w), int); idx[sous] = np.arange(sous.sum())
    n = int(sous.sum())
    A = lil_matrix((n, n)); B = np.zeros((n, 3))
    for j, i in zip(*np.where(sous)):
        k = idx[j, i]; A[k, k] = 4
        for dj, di in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            vj, vi = j + dj, i + di
            if sous[vj, vi]: A[k, idx[vj, vi]] = -1
            else: B[k] += image[y0 + vj, x0 + vi]
    A = csr_matrix(A)
    out = image.copy()
    for c in range(3):
        out[y0:y1, x0:x1][sous, c] = spsolve(A, B[:, c])
    return out, (y0, y1, x0, x1, sous)

def proteger(m):
    sx, sy, r = SOLEIL
    yy, xx = np.ogrid[:H, :W]
    m[((xx - sx) ** 2 + (yy - sy) ** 2) < r * r] = False
    m[:Y0] = m[Y1 + 2:] = False
    m[:, :X0] = m[:, X1:] = False
    return m

masque = proteger(masque)
print(f"passe 1 : {int(masque.sum())} pixels")
sortie, _ = resoudre(im, masque)

# passes suivantes : ce qui reste, vu comme un écart à son propre flou. Deux seuils, du plus
# franc au plus ténu, et strictement cantonnées au rectangle qu'occupait le logo — ailleurs,
# un écart au flou n'est pas un fantôme, c'est un nuage.
reste = np.zeros((H, W), bool)
for seuil, sigma in ((-20, 22), (-11, 30)):
    travail = sortie[Y0 - 10:Y1 + 12, X0 - 10:X1 + 10]
    ecart = (travail - cv2.GaussianBlur(travail, (0, 0), sigma)).sum(2)
    r = np.zeros((H, W), bool)
    r[Y0 - 10:Y1 + 12, X0 - 10:X1 + 10] = ecart < seuil
    r = cv2.dilate(r.astype(np.uint8), np.ones((7, 7), np.uint8), 1).astype(bool)
    r = proteger(r)
    if not r.sum():
        continue
    print(f"rattrapage (seuil {seuil}) : {int(r.sum())} pixels")
    sortie, _ = resoudre(sortie, r)
    reste |= r

masque = masque | reste
ys, xs = np.where(masque)
y0, y1, x0, x1 = ys.min() - 2, ys.max() + 3, xs.min() - 2, xs.max() + 3
sous = masque[y0:y1, x0:x1]

# --- 3. grain, relevé sur une bande de ciel propre juste au-dessus ---
bande = im[Y0 - 80:Y0 - 10, X0:X1]
grain = bande - cv2.GaussianBlur(bande, (0, 0), 5)
grain = np.resize(grain, (y1 - y0, x1 - x0, 3))
sortie[y0:y1, x0:x1][sous] += grain[sous] * 0.7

sortie = np.clip(sortie, 0, 255).astype(np.uint8)
Image.fromarray(sortie).save(DST)
Image.fromarray(sortie).crop((540, 290, 1010, 540)).resize((940, 500), Image.LANCZOS)\
    .save("/tmp/claude-0/-home-claude/bccfc1ab-e639-5eb6-9792-eac06cd6c9b3/scratchpad/img/apres.png")
print("écrit :", DST)
