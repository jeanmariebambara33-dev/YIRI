import { test } from "node:test";
import assert from "node:assert/strict";
import { percentOf, formatXOF } from "./money";
import { nightsBetween, rangesOverlap, addMonths } from "./dates";
import { quoteBooking, splitRevenue, buildStatement, computeRLP } from "./pricing";
import { activateSubscription, subscriptionState, reminderDue, isPubliclyVisible, canTransitionListing, type Subscription } from "./domain";

test("arrondis entiers XOF", () => {
  assert.equal(percentOf(500_000, 60), 300_000);
  assert.equal(percentOf(1, 60), 1);
  assert.equal(percentOf(0, 60), 0);
  assert.throws(() => percentOf(10.5, 60));
  assert.equal(formatXOF(30000), "30 000 FCFA");
});

test("partage 60/40 : la somme est toujours exacte", () => {
  for (const rlp of [0, 1, 3, 7, 99, 333_333, 500_000, 1_234_567]) {
    const s = splitRevenue(rlp);
    assert.equal(s.ownerShare + s.yiriCommission, rlp);
  }
  assert.deepEqual(splitRevenue(500_000), { rlp: 500_000, ownerShare: 300_000, yiriCommission: 200_000 });
});

test("exemple du §8 du cahier des charges", () => {
  const st = buildStatement({
    accommodationCollected: 500_000,
    deductPaymentFees: false,
    ownerExpenses: 45_000,
    yiriVariableCosts: 60_000 + 15_000 + 10_000,
  });
  assert.equal(st.ownerShare, 300_000);
  assert.equal(st.yiriCommission, 200_000);
  assert.equal(st.yiriContribution, 115_000);
  assert.equal(st.ownerNet, 255_000);
});

test("RLP : remboursement total = base zéro, aucune commission", () => {
  assert.equal(computeRLP({ accommodationCollected: 200_000, refunds: 200_000, deductPaymentFees: false }), 0);
  assert.equal(splitRevenue(0).yiriCommission, 0);
  assert.equal(
    computeRLP({ accommodationCollected: 200_000, discounts: 10_000, thirdPartyTaxes: 5_000, paymentFees: 4_000, deductPaymentFees: true }),
    181_000
  );
  assert.equal(computeRLP({ accommodationCollected: 200_000, paymentFees: 4_000, deductPaymentFees: false }), 200_000);
});

test("nuitées et chevauchements (départ = arrivée n'est pas un conflit)", () => {
  assert.equal(nightsBetween("2026-10-10", "2026-10-13"), 3);
  assert.equal(nightsBetween("2026-12-31", "2027-01-02"), 2);
  assert.equal(rangesOverlap("2026-10-10", "2026-10-13", "2026-10-13", "2026-10-15"), false);
  assert.equal(rangesOverlap("2026-10-10", "2026-10-13", "2026-10-12", "2026-10-15"), true);
  assert.equal(addMonths("2027-01-31", 1), "2027-02-28");
});

test("devis de réservation", () => {
  const p = { nightlyPrice: 25_000, capacity: 4, minNights: 2 };
  const ok = quoteBooking(p, "2026-11-01", "2026-11-04", 2);
  assert.ok(ok.ok && ok.quote.total === 75_000 && ok.quote.accommodation === 75_000);
  assert.deepEqual(quoteBooking(p, "2026-11-01", "2026-11-02", 2), { ok: false, error: "SEJOUR_TROP_COURT" });
  assert.deepEqual(quoteBooking(p, "2026-11-01", "2026-11-04", 5), { ok: false, error: "CAPACITE_DEPASSEE" });
  assert.deepEqual(quoteBooking(p, "2026-11-04", "2026-11-01", 2), { ok: false, error: "DATES_INVALIDES" });
  assert.deepEqual(
    quoteBooking(p, "2026-11-01", "2026-11-04", 2, [{ start: "2026-11-03", end: "2026-11-06" }]),
    { ok: false, error: "DATES_INDISPONIBLES" }
  );
});

test("abonnement : activation unique, montant contrôlé, échéances", () => {
  const s: Subscription = { id: "s1", propertyId: "p1", plan: "mensuel", amount: 5_000, status: "en_attente_paiement" };
  assert.throws(() => activateSubscription(s, 4_000, "2026-10-09"));
  const a = activateSubscription(s, 5_000, "2026-10-09");
  assert.equal(a.endsAt, "2026-11-09");
  assert.equal(activateSubscription(a, 5_000, "2026-10-20"), a); // callback répété
  assert.equal(subscriptionState(a, "2026-10-20"), "actif");
  assert.equal(subscriptionState(a, "2026-11-05"), "echeance_proche");
  assert.equal(subscriptionState(a, "2026-11-09"), "expire");
  assert.equal(reminderDue(a, "2026-11-02"), "J-7");
  assert.equal(reminderDue(a, "2026-11-08"), "J-1");
  const y = activateSubscription({ ...s, plan: "annuel", amount: 30_000 }, 30_000, "2026-10-09");
  assert.equal(y.endsAt, "2027-10-09");
});

test("visibilité publique (§11)", () => {
  const sub = activateSubscription({ id: "s", propertyId: "p", plan: "mensuel", amount: 5000, status: "en_attente_paiement" }, 5000, "2026-10-01");
  assert.equal(isPubliclyVisible({ offer: "annonce", status: "publiee", complete: true, subscription: sub }, "2026-10-09"), true);
  assert.equal(isPubliclyVisible({ offer: "annonce", status: "publiee", complete: true, subscription: sub }, "2026-11-02"), false);
  assert.equal(isPubliclyVisible({ offer: "annonce", status: "soumise", complete: true, subscription: sub }, "2026-10-09"), false);
  assert.equal(isPubliclyVisible({ offer: "gestion", status: "publiee", complete: true, agreementSigned: true, operationalCheckDone: false }, "2026-10-09"), false);
  assert.equal(canTransitionListing("brouillon", "publiee"), false);
  assert.equal(canTransitionListing("soumise", "approuvee"), true);
});
