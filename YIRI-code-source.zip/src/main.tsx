import * as React from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import { enregistrerServiceWorker } from "./install";

/** Évite l'écran blanc : en cas d'erreur inattendue, on affiche un message clair et un moyen de recharger. */
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: unknown) { console.error("YIRI : erreur d'affichage", error instanceof Error ? error.message : "inconnue"); }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <main role="alert" style={{ maxWidth: 520, margin: "20vh auto", padding: 24, fontFamily: "system-ui, sans-serif", textAlign: "center" }}>
        <h1 style={{ fontSize: 24, marginBottom: 8 }}>Une erreur est survenue</h1>
        <p style={{ marginBottom: 16 }}>Rien n'a été perdu. Rechargez la page pour continuer.</p>
        <button onClick={() => { location.hash = ""; location.reload(); }} style={{ padding: "12px 24px", borderRadius: 999, border: 0, background: "#4a372f", color: "#fff", fontWeight: 600, cursor: "pointer" }}>Recharger</button>
      </main>
    );
  }
}

document.documentElement.lang = "fr";
enregistrerServiceWorker();
createRoot(document.getElementById("root")!).render(<ErrorBoundary><App /></ErrorBoundary>);
