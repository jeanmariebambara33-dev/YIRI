// Tests des pages légales : accessibilité depuis le pied de page, contenu fidèle au fonctionnement
// réel de la plateforme, et signalement visible de tout ce qui reste à compléter.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ viewport: { width: 1280, height: 1000 } });
await ctx.route("**cdn.jsdelivr.net/**", (r) => r.abort());
const p = await ctx.newPage();
const errs = []; p.on("pageerror", (e) => errs.push(e.message));

await p.goto(URL); await p.waitForTimeout(500);
const footer = await p.locator("footer").innerText();
for (const l of ["Mentions légales", "Conditions générales", "Confidentialité", "Cookies"])
  ok("lien « " + l + " » dans le pied de page", footer.includes(l));
for (const l of ["Trouver un logement", "Mes séjours", "Mon compte", "Publier un logement", "Nos solutions", "Être rappelé"])
  ok("lien « " + l + " » dans le pied de page", footer.includes(l));
ok("pied de page : colonnes Voyageurs / Propriétaires / Informations", /Voyageurs/.test(footer) && /Propriétaires/.test(footer) && /Informations/.test(footer));
ok("pied de page : mention de droits d'auteur avec l'année", /© 20\d\d YIRI/.test(footer));
ok("pied de page : aucun nom de personne", !/Bambara|Jean-Marie/i.test(footer));
ok("pied de page : adresse de contact affichée", /infos\.yiri@gmail\.com/.test(footer));
ok("pied de page : WhatsApp affiché avec le bon indicatif", /\+226 06 44 33 15/.test(footer));

// --- mentions légales ---
await p.getByRole("button", { name: "Mentions légales" }).click();
await p.waitForTimeout(400);
let t = await p.locator("main").innerText();
ok("mentions : hébergement hors du Burkina Faso indiqué", /hors du Burkina Faso/.test(t));
ok("mentions : hébergeur nommé", /Supabase/.test(t));
ok("mentions : loi burkinabè et CIL citées", /001-2021/.test(t) && /Commission de l'informatique et des libertés/i.test(t));
ok("mentions : aucune mention « à compléter » visible", await p.locator("mark").count() === 0 && !/COMPLÉTER/i.test(t));
ok("mentions : aucun nom de personne", !/Bambara|Jean-Marie/i.test(t));
ok("mentions : le service est nommé", /YIRI est un service/.test(t));
ok("mentions : contact e-mail et WhatsApp présents", /infos\.yiri@gmail\.com/.test(t) && /\+226 06 44 33 15/.test(t));
ok("mentions : aucune ligne vide ou incomplète", !/ : \s*$/m.test(t) && !/undefined|null/.test(t));

// --- CGU ---
await p.goto(URL + "#cgu"); await p.waitForTimeout(400);
t = await p.locator("main").innerText();
ok("CGU : YIRI se présente comme intermédiaire, pas comme loueur", /n'est ni propriétaire ni locataire/.test(t));
ok("CGU : le rôle n'est jamais donné par l'application", /jamais demandé par l'application/.test(t));
ok("CGU : vérification d'identité décrite", /recto, le verso et le numéro/.test(t));
ok("CGU : suppression des images annoncée", /supprimées dès que la décision est prise/.test(t));
ok("CGU : numéro conservé, raison donnée", /numéro de la pièce est conservé/.test(t));
ok("CGU : prix calculé par la plateforme", /calculé par la plateforme/.test(t));
ok("CGU : blocage de 15 minutes annoncé", /15 minutes/.test(t));
ok("CGU : « J'ai payé » n'est pas une preuve", /n'est pas une preuve de paiement/.test(t));
ok("CGU : seule l'équipe confirme un paiement", /Seule l'équipe YIRI confirme/.test(t));
ok("CGU : tarifs d'abonnement exacts", /5 000 FCFA/.test(t) && /30 000 FCFA/.test(t));
ok("CGU : expiration immédiate et renouvellement sans perte", /cesse d'être visible immédiatement/.test(t));
ok("CGU : YIRI Annonce hors plateforme pour le paiement", /hors de la plateforme/.test(t));
ok("CGU : remboursements non gérés", /ne gère pas les remboursements/.test(t));
ok("CGU : aucune information manquante sur cette page", await p.locator("mark").count() === 0);
ok("CGU : droit burkinabè et tribunaux de Ouagadougou", /droit burkinabè/.test(t) && /Ouagadougou/.test(t));

// --- confidentialité ---
await p.goto(URL + "#confidentialite"); await p.waitForTimeout(400);
t = await p.locator("main").innerText();
ok("confidentialité : aucune donnée bancaire collectée", /aucune donnée bancaire/.test(t));
ok("confidentialité : mot de passe jamais lisible", /jamais lisible par YIRI/.test(t));
ok("confidentialité : qui voit quoi, par rôle", /L'équipe YIRI : seulement ce que son autorisation permet/.test(t));
ok("confidentialité : consultation du numéro tracée", /trace nominative/.test(t));
ok("confidentialité : règles appliquées par la base", /appliquées par la base de données/.test(t));
ok("confidentialité : durées de conservation chiffrées", /cinq ans/.test(t) && /trois ans/.test(t) && /dix ans/.test(t));
ok("confidentialité : aucune mention « à compléter »", !/COMPLÉTER/i.test(t));
ok("confidentialité : aucun nom de personne", !/Bambara|Jean-Marie/i.test(t));
ok("confidentialité : villes d'activité indiquées", /Ouagadougou et Bobo-Dioulasso/.test(t));
ok("confidentialité : droits d'accès, rectification, effacement, opposition", /accès, de rectification/.test(t) && /opposition/.test(t));
ok("confidentialité : recours à la CIL indiqué", /saisir la Commission/.test(t));
ok("confidentialité : adresse pour exercer ses droits", /infos\.yiri@gmail\.com/.test(t));
ok("confidentialité : hébergement hors du pays signalé", /hors du Burkina Faso/.test(t));
ok("confidentialité : comptage des consultations de contact", /vingt-quatre heures/.test(t));

// --- cookies ---
await p.goto(URL + "#cookies"); await p.waitForTimeout(400);
t = await p.locator("main").innerText();
ok("cookies : aucun traceur publicitaire", /aucun cookie publicitaire/.test(t));
ok("cookies : jeton de connexion expliqué", /jeton de connexion/.test(t));
ok("cookies : polices externes signalées", /polices/i.test(t));
ok("cookies : pas de bannière, raison donnée", /aucune bannière de consentement/.test(t));

for (const h of ["mentions", "cgu", "confidentialite", "cookies"]) {
  await p.goto(URL + "#" + h); await p.waitForTimeout(300);
  const txt = await p.locator("main").innerText();
  ok("page #" + h + " : aucun trou ni nom de personne", !/COMPLÉTER/i.test(txt) && !/Bambara|Jean-Marie/i.test(txt));
}
ok("aucune erreur JavaScript", errs.length === 0);
await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DES PAGES LEGALES SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
