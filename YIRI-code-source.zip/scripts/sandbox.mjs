import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
import fs from "node:fs";
const html = fs.readFileSync("dist/yiri-demo.html", "utf8");
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
for (const sb of ["allow-scripts", "allow-scripts allow-same-origin"]) {
  const p = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  const errs = []; p.on("pageerror", (e) => errs.push(e.message));
  await p.setContent(`<body style="margin:0"><iframe id="f" sandbox="${sb}" style="width:1280px;height:900px;border:0"></iframe></body>`);
  await p.evaluate((h) => { document.getElementById("f").srcdoc = "<!doctype html><meta charset=utf-8>" + h; }, html);
  const f = p.frameLocator("#f");
  await f.locator("h1").first().waitFor();
  await f.getByRole("button", { name: /Découvrir nos logements/ }).click();
  await p.waitForTimeout(500);
  const ok = await f.locator("text=Nos logements").count();
  console.log(sb, "-> page logements:", ok > 0, errs);
}
await b.close();
