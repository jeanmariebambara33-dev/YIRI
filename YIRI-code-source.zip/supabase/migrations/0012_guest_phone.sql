-- YIRI — 0012 : le numéro du voyageur, pour pouvoir se parler.
--
-- Le constat : TOUTE réservation payée sur YIRI porte sur un logement en offre « gestion »
-- (create_booking refuse les autres). C'est donc toujours YIRI qui remet les clés. Or :
--
--   * l'inscription ne demande jamais de téléphone (nom, adresse, mot de passe) : profiles.phone
--     est vide pour tous les voyageurs, et l'équipe n'avait qu'une adresse électronique ;
--   * reveal_contact() ne révèle un contact que sur une annonce « Visibilité », donc sur un
--     logement sous gestion le voyageur payait et n'avait personne à joindre.
--
-- Décision du fondateur : le téléphone est OBLIGATOIRE au moment de réserver.
--
-- Le numéro est porté par la RÉSERVATION, pas par le profil. Deux raisons :
--   1. on voyage parfois avec le téléphone d'un proche, ou avec une autre puce : le bon numéro
--      est celui du séjour, pas celui de l'inscription ;
--   2. minimisation : le numéro est rattaché au séjour qui le justifie, et pas conservé
--      indéfiniment sur le compte. C'est aussi plus simple à expliquer à la CIL.
--
-- Rien n'est supprimé. L'ancienne version de create_booking à quatre arguments est CONSERVÉE
-- volontairement : le site actuellement en ligne l'appelle encore, et la retirer casserait le
-- bouton « Réserver » en production entre l'exécution de ce fichier et le redéploiement du site.
-- Elle sera retirée dans une migration suivante, une fois le nouveau site en place.

-- =====================================================================
-- 0. Garde : 0012 s'appuie sur 0011
-- =====================================================================
do $$
begin
  if to_regprocedure('public.bookings_queue(int)') is null then
    raise exception 'La migration 0011 n''est pas appliquée. Appliquez 0011 d''abord. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. La colonne, et ce qu'on accepte d'y mettre
-- =====================================================================
alter table bookings add column if not exists guest_phone text;

-- Un contrôle de FORME, pas de validité : on n'a aucun moyen de vérifier qu'un numéro sonne.
-- Il sert seulement à empêcher qu'on enregistre « oui » ou « je t'appelle » à la place d'un numéro.
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'bookings_guest_phone_forme') then
    alter table bookings add constraint bookings_guest_phone_forme
      check (guest_phone is null or guest_phone ~ '^\+?[0-9]{8,15}$');
  end if;
end $$;

/* Met un numéro saisi à la main sous une forme unique : on retire les espaces, points, tirets
   et parenthèses, et on garde un éventuel « + » de tête. « 70 00 00 01 », « 70-00-00-01 » et
   « +226 70 00 00 01 » cessent ainsi d'être trois numéros différents dans la base. */
create or replace function normalize_phone(p_raw text)
returns text
language plpgsql immutable set search_path = public, pg_temp as $$
declare s text;
begin
  if p_raw is null then return null; end if;
  s := regexp_replace(btrim(p_raw), '[\s().\-]', '', 'g');
  -- Le « 00 » international des appels depuis l'Afrique de l'Ouest devient « + ».
  if s ~ '^00[0-9]{8,}$' then s := '+' || substring(s from 3); end if;
  if s ~ '^\+?[0-9]{8,15}$' then return s; end if;
  return null;   -- illisible : l'appelant décide quoi en faire
end $$;
revoke all on function normalize_phone(text) from public;
grant execute on function normalize_phone(text) to anon, authenticated;

-- =====================================================================
-- 2. Réserver exige désormais un numéro
-- =====================================================================
-- Nouvelle signature à CINQ arguments. Le corps reprend celui de 0006 à l'identique, avec
-- l'ajout du numéro : je ne profite pas de cette réécriture pour changer une autre règle.
create or replace function create_booking(p_property uuid, p_start date, p_end date, p_guests int, p_phone text)
returns bookings
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  prop properties%rowtype;
  nights int;
  holds int;
  tel text;
  b bookings%rowtype;
begin
  if p_property is null or p_start is null or p_end is null or p_guests is null then
    raise exception 'Informations de réservation incomplètes.';
  end if;

  -- Le numéro est contrôlé AVANT tout le reste : inutile de verrouiller le logement et de
  -- calculer un prix pour échouer ensuite sur une case mal remplie.
  tel := normalize_phone(p_phone);
  if tel is null then
    raise exception 'Indiquez un numéro de téléphone valide : c''est par là que nous vous joindrons pour la remise des clés.';
  end if;

  perform enforce_rate_limit('book:' || uid::text, 20, interval '1 hour');

  -- 1er verrou : le logement (sérialise toutes les réservations et blocages de dates de ce logement).
  select * into prop from properties where id = p_property for update;
  if not found or not exists (select 1 from public_listings l where l.id = p_property) then
    raise exception 'Ce logement n''est pas disponible à la réservation.';
  end if;
  if prop.offer <> 'gestion' then
    raise exception 'Ce logement ne se réserve pas en ligne : contactez directement le propriétaire.';
  end if;
  if prop.owner_id = uid then
    raise exception 'Vous ne pouvez pas réserver votre propre logement.';
  end if;

  if p_start < current_date or p_end <= p_start then
    raise exception 'Dates invalides : l''arrivée doit être future et le départ après l''arrivée.';
  end if;
  if p_start > current_date + 365 then
    raise exception 'Réservation possible jusqu''à un an à l''avance.';
  end if;
  nights := p_end - p_start;
  if nights < prop.min_nights then
    raise exception 'Séjour minimum : % nuit(s).', prop.min_nights;
  end if;
  if nights > 90 then
    raise exception 'Séjour maximum : 90 nuits.';
  end if;
  if p_guests < 1 or p_guests > prop.capacity then
    raise exception 'Nombre de voyageurs invalide (maximum : %).', prop.capacity;
  end if;

  -- Libère les blocages expirés de ce logement, puis limite les blocages simultanés d'un même voyageur.
  perform release_expired_holds(prop.id);
  select count(*) into holds from bookings
   where guest_id = uid and status = 'en_attente_paiement' and hold_expires_at > now();
  if holds >= 3 then
    raise exception 'Vous avez déjà 3 réservations en attente de paiement. Finalisez-les ou attendez leur expiration.';
  end if;

  begin
    insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof,
                          discount_xof, taxes_xof, total_xof, status, hold_expires_at, guest_phone)
    values (prop.id, uid, daterange(p_start, p_end), p_guests, prop.nightly_price_xof,
            nights * prop.nightly_price_xof, 0, 0, nights * prop.nightly_price_xof,
            'en_attente_paiement', now() + interval '15 minutes', tel)
    returning * into b;
  exception when exclusion_violation then
    raise exception 'Ces dates ne sont plus disponibles.' using errcode = '23P01';
  end;
  return b;
end $$;
revoke all on function create_booking(uuid, date, date, int, text) from public, anon;
grant execute on function create_booking(uuid, date, date, int, text) to authenticated;

-- =====================================================================
-- 3. Les écrans reçoivent le bon numéro
-- =====================================================================
-- Avant : le téléphone venait du profil, toujours vide. Désormais celui du séjour, avec le
-- profil en repli pour les quelques réservations créées avant cette migration.
create or replace function bookings_queue(p_limit int default 100)
returns table (
  id uuid, property_id uuid, title text, city text, district text,
  offer text, sous_gestion boolean,
  arrivee date, depart date, nuits int, guests int,
  total_xof int, status text, created_at timestamptz, hold_expires_at timestamptz,
  guest_id uuid, guest_name text, guest_phone text, guest_email text,
  paye boolean, paye_le timestamptz, reference text, moyen text
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_any_perm('reservations', 'paiements') then
    raise exception 'Action réservée à l''équipe habilitée (réservations).' using errcode = '42501';
  end if;
  return query
    select b.id, p.id, p.title, p.city::text, p.district,
           p.offer::text, (p.offer in ('gestion', 'partenariat')),
           lower(b.stay), upper(b.stay), (upper(b.stay) - lower(b.stay))::int, b.guests,
           b.total_xof, b.status::text, b.created_at, b.hold_expires_at,
           b.guest_id, pr.full_name, coalesce(b.guest_phone, pr.phone), coalesce(pr.email, u.email::text),
           (t.id is not null), t.updated_at, t.provider_reference, (m.after ->> 'moyen')
      from bookings b
      join properties p on p.id = b.property_id
      join profiles pr on pr.id = b.guest_id
      left join auth.users u on u.id = b.guest_id
      -- Un seul encaissement réussi possible par réservation (index unique de 0006).
      left join payment_transactions t
             on t.booking_id = b.id and t.purpose = 'booking' and t.status = 'reussi'
      -- Le moyen de paiement (Orange Money, Moov…) n'est pas une colonne : 0009 l'écrit dans
      -- le journal d'audit. On va le chercher là plutôt que d'ajouter une colonne et de
      -- redéfinir une fonction déjà validée.
      left join lateral (
        select l.after from audit_logs l
         where l.action = 'payment.method' and l.entity_type = 'reservation'
           and l.entity_id = b.id::text
         order by l.created_at desc limit 1
      ) m on true
     order by
       -- D'abord ce qui est vivant, et dedans la prochaine arrivée en tête : c'est la question
       -- qu'on se pose vraiment en ouvrant cet écran — « qui arrive bientôt ? ».
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then 0 else 1 end),
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then lower(b.stay) end) asc nulls last,
       b.created_at desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function bookings_queue(int) from public, anon;
grant execute on function bookings_queue(int) to authenticated;

create or replace function owner_bookings(p_limit int default 100)
returns table (
  id uuid, property_id uuid, title text, city text, district text,
  offer text, sous_gestion boolean,
  arrivee date, depart date, nuits int, guests int,
  total_xof int, status text, created_at timestamptz,
  guest_name text, guest_phone text, coordonnees_visibles boolean,
  paye boolean, paye_le timestamptz
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select b.id, p.id, p.title, p.city::text, p.district,
           p.offer::text, (p.offer in ('gestion', 'partenariat')),
           lower(b.stay), upper(b.stay), (upper(b.stay) - lower(b.stay))::int, b.guests,
           b.total_xof, b.status::text, b.created_at,
           case when b.status in ('confirmee', 'en_cours', 'terminee') then pr.full_name end,
           case when b.status in ('confirmee', 'en_cours', 'terminee') then coalesce(b.guest_phone, pr.phone) end,
           (b.status in ('confirmee', 'en_cours', 'terminee')),
           (t.id is not null), t.updated_at
      from bookings b
      join properties p on p.id = b.property_id
      join profiles pr on pr.id = b.guest_id
      left join payment_transactions t
             on t.booking_id = b.id and t.purpose = 'booking' and t.status = 'reussi'
     where p.owner_id = uid
     order by
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then 0 else 1 end),
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then lower(b.stay) end) asc nulls last,
       b.created_at desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function owner_bookings(int) from public, anon;
grant execute on function owner_bookings(int) to authenticated;

-- Note : le voyageur relit son propre numéro sans qu'il y ait rien à ajouter ici. La règle de
-- sécurité de 0005 limite déjà la lecture d'une réservation à son voyageur, à l'équipe habilitée
-- et au propriétaire du logement ; la nouvelle colonne hérite de cette règle. L'application n'a
-- qu'à demander la colonne dans sa lecture de « bookings ».
