import * as React from "react";
import { CityField } from "../cityfield";
import { useStore } from "../store";
import { submitLead, type LeadLevel } from "../lib/api";
import { Button, Field, inputCls, Money, Pill, cx } from "../ui";
import { PLANS } from "../lib/pricing";
import { isValidPhone } from "../lib/contact";
import { COMPARE, PACKS, PACK_ORDER, type Pack, type PackId } from "../data/packs";
import { OwnerScene } from "../hero";

export type IconName = "eye" | "calendar" | "sliders" | "receipt" | "key" | "camera" | "search";
const ICONS: Record<IconName, React.ReactNode> = {
  eye: <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></>,
  sliders: <><path d="M4 6h8M18 6h2M4 12h2M12 12h8M4 18h10M20 18h0" /><circle cx="15" cy="6" r="2" /><circle cx="9" cy="12" r="2" /><circle cx="17" cy="18" r="2" /></>,
  receipt: <><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z" /><path d="M9 8h6M9 12h6" /></>,
  key: <><circle cx="8" cy="15" r="4" /><path d="M11 12l9-9M16 7l3 3" /></>,
  camera: <><path d="M4 8h3l2-3h6l2 3h3v11H4z" /><circle cx="12" cy="13" r="3.5" /></>,
  search: <><circle cx="11" cy="11" r="6" /><path d="M20 20l-4.2-4.2" /></>,
};
export function Icon({ name, className }: { name: IconName; className?: string }) {
  return <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>{ICONS[name]}</svg>;
}

/** Les quatre façons de louer : partagées entre l'accueil et la page Propriétaires. */
export type NeedId = "autonome" | "reservations" | "delegation" | "nonmeuble";
export const NEEDS: { id: NeedId; icon: IconName; title: string; text: string; pack: PackId; why: string }[] = [
  { id: "autonome", icon: "eye", title: "Je veux gérer mon logement moi-même", text: "Je souhaite gagner en visibilité tout en gardant le contrôle de mon activité.", pack: "visibilite",
    why: "Vous restez maître de vos prix, de vos échanges avec les voyageurs et de l'accueil. YIRI rend votre logement visible et affiche votre contact aux voyageurs." },
  { id: "reservations", icon: "calendar", title: "J'ai besoin d'aide pour les réservations", text: "Je souhaite être accompagné dans la gestion des demandes et des réservations, selon les services disponibles.", pack: "serenite",
    why: "Les voyageurs réservent et paient en ligne via YIRI, qui traite les demandes selon le contrat standard. Cela suppose une visite du logement et la signature du contrat." },
  { id: "delegation", icon: "key", title: "Je souhaite déléguer une partie de la gestion quotidienne", text: "Je recherche un accompagnement pour certaines tâches liées à l'accueil et au suivi des voyageurs.", pack: "serenite",
    why: "YIRI peut prendre en charge l'accueil, la remise des clés et le ménage entre les séjours, dans le cadre du contrat standard signé après la visite." },
  { id: "nonmeuble", icon: "sliders", title: "Mon logement n'est pas encore meublé", text: "Je souhaite comprendre les possibilités qui existent pour préparer mon bien à la location.", pack: "partenariat",
    why: "Les biens non meublés sont étudiés au cas par cas. Cette formule est en cours de validation : votre demande permet d'être renseigné, sans engagement et sans promesse avant étude." },
];

export const BENEFITS: { icon: IconName; title: string; text: string }[] = [
  { icon: "eye", title: "Plus de visibilité", text: "Votre logement rejoint un catalogue dédié aux séjours au Burkina Faso, visible par tous les voyageurs qui le consultent." },
  { icon: "camera", title: "Un bien bien présenté", text: "Au moins 3 photos et une description complète de tout ce que votre logement propose : le voyageur sait à quoi s'attendre." },
  { icon: "search", title: "Plus facile à découvrir", text: "Ville, quartier, équipements, prix par nuit : les voyageurs filtrent et trouvent le logement qui leur correspond." },
  { icon: "sliders", title: "Votre niveau d'implication", text: "Vous gérez vous-même, ou vous demandez un accompagnement. Vous décidez de ce que vous gardez et de ce que vous confiez." },
  { icon: "key", title: "Un accompagnement, si vous le souhaitez", text: "Avec YIRI Sérénité, l'équipe prend en charge les tâches prévues au contrat standard, après visite et signature." },
];

const FAQ: { q: string; a: string; confirm?: boolean }[] = [
  { q: "Comment publier mon logement sur YIRI ?", a: "Cliquez sur « Publier mon logement », ajoutez au moins 3 photos, décrivez tout ce que votre logement propose et indiquez votre contact. L'équipe YIRI vérifie l'annonce avant sa mise en ligne." },
  { q: "Puis-je gérer moi-même mes réservations ?", a: "Oui, avec YIRI Annonce. Les voyageurs vous contactent directement par téléphone ou WhatsApp. Vous gérez les prix, les disponibilités, l'accueil et le paiement avec eux." },
  { q: "Comment fonctionne l'accompagnement ?", a: "Avec YIRI Sérénité : vous envoyez une demande, l'équipe visite le logement, un contrat standard est signé, puis le logement est publié. Le périmètre exact des services est fixé au contrat, en cours de validation juridique.", confirm: true },
  { q: "Quels sont les frais ?", a: "YIRI Annonce : un abonnement de 5 000 FCFA par mois ou 30 000 FCFA par an, sans commission de YIRI sur vos séjours. Sérénité : partage du revenu locatif, avec une hypothèse de départ de 60 % pour vous et 40 % pour YIRI. Eau, électricité, Wi-Fi, réparations et assurance restent à votre charge.", confirm: true },
  { q: "Qui échange avec le voyageur ?", a: "Avec YIRI Annonce, c'est vous. Avec Sérénité, c'est YIRI, selon le contrat." },
  { q: "Comment se déroulent les paiements ?", a: "YIRI Annonce : le paiement se fait entre vous et le voyageur. Sérénité : le voyageur paie en ligne via YIRI, qui vous reverse votre part avec un relevé mensuel. Les délais de versement seront précisés au contrat. Dans cette démonstration, les paiements sont simulés.", confirm: true },
  { q: "Que se passe-t-il si mon logement n'est pas encore meublé ?", a: "Votre bien peut être étudié au cas par cas, après une candidature. Cette formule est en cours de validation et rien n'est promis avant la visite, l'étude et un contrat. Vous pouvez demander des renseignements sans engagement." },
];

function Eyebrow({ children, light }: { children: React.ReactNode; light?: boolean }) {
  return <p className={cx("text-xs font-bold uppercase tracking-[0.16em]", light ? "opacity-80" : "text-accent-ink")}>{children}</p>;
}

function useStart() {
  const { go } = useStore();
  return {
    go,
    publish: () => go({ name: "nouvelle-annonce" }),
    ask: (pack: PackId | "indecis" = "indecis") => go({ name: "demande", pack }),
    open: (route: Pack["route"]) => go({ name: route }),
  };
}

function startFor(pack: PackId, st: ReturnType<typeof useStart>) {
  return pack === "visibilite"
    ? { label: "Publier mon logement", run: st.publish }
    : pack === "serenite"
      ? { label: "Demander à être contacté", run: () => st.ask("serenite") }
      : { label: "Demander des renseignements", run: () => st.ask("partenariat") };
}

/* ───────────── Page « Propriétaires » : A → G ───────────── */
export function ProprietairesPage({ need: initialNeed, at }: { need?: string; at?: string }) {
  const st = useStart();
  const [need, setNeed] = React.useState<NeedId | null>((NEEDS.find((n) => n.id === initialNeed)?.id) ?? null);
  const chooseRef = React.useRef<HTMLElement>(null);
  const solRef = React.useRef<HTMLElement>(null);

  React.useEffect(() => {
    const target = at === "solutions" ? solRef.current : initialNeed ? chooseRef.current : null;
    if (target) setTimeout(() => { try { target.scrollIntoView({ block: "start" }); } catch {} }, 60);
  }, [at, initialNeed]);

  const chosen = NEEDS.find((n) => n.id === need) ?? null;

  return (
    <div className="flex flex-col gap-20 pb-10 pt-6">
      {/* A — introduction */}
      <header className="relative isolate flex min-h-[520px] flex-col justify-center gap-5 overflow-hidden rounded-3xl bg-[#1a0f12] px-6 py-14 text-[#f7ecd8] sm:px-12">
        <OwnerScene />
        <Eyebrow light>Propriétaires</Eyebrow>
        <h1 className="max-w-[20ch] font-display text-[clamp(2.1rem,5.4vw,3.8rem)] font-extrabold leading-[1.04] tracking-tight text-balance">Votre logement a du potentiel. Donnez-lui les moyens d'aller plus loin.</h1>
        <p className="max-w-[54ch] text-lg leading-relaxed opacity-95">Vous possédez un appartement, une maison ou un logement meublé ? YIRI vous aide à le présenter aux voyageurs et vous permet de choisir comment vous souhaitez gérer sa location.</p>
        <p className="max-w-[54ch] leading-relaxed opacity-85">Vous gardez la main sur votre activité, ou vous choisissez un accompagnement adapté à vos besoins.</p>
        <div className="mt-2 flex flex-col gap-3 sm:flex-row">
          <button onClick={() => st.go({ name: "proprietaires", at: "solutions" })} className="inline-flex items-center justify-center gap-2 rounded-full bg-[#f2b27a] px-8 py-4 text-lg font-extrabold text-[#2a1a12] shadow-[0_12px_40px_-10px_rgb(242_178_122/0.55)] transition-colors hover:bg-[#f8c595] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]">
            Découvrir les solutions propriétaires <span aria-hidden="true">→</span>
          </button>
          <button onClick={st.publish} className="inline-flex items-center justify-center rounded-full border border-[#f7ecd8]/60 px-8 py-4 text-lg font-bold text-[#f7ecd8] transition-colors hover:bg-white/10 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]">
            Publier mon logement
          </button>
        </div>
      </header>

      {/* B — bénéfices */}
      <section aria-labelledby="benef" className="flex flex-col gap-6">
        <div className="flex flex-col gap-1"><Eyebrow>Ce que YIRI peut vous apporter</Eyebrow><h2 id="benef" className="max-w-[24ch] font-display text-2xl font-bold text-ink text-balance sm:text-3xl">Faire découvrir votre logement, à votre manière</h2></div>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
          {BENEFITS.map((b, i) => (
            <li key={b.title} className={cx("flex flex-col gap-3 rounded-3xl border border-line bg-surface p-6", i < 2 ? "lg:col-span-3" : "lg:col-span-2")}>
              <span className="grid size-12 place-items-center rounded-2xl bg-sunk text-accent-ink"><Icon name={b.icon} /></span>
              <h3 className="font-display text-lg font-bold leading-snug text-ink">{b.title}</h3>
              <p className="text-sm leading-relaxed text-muted">{b.text}</p>
            </li>
          ))}
        </ul>
        <p className="max-w-[70ch] text-sm text-muted">YIRI ne promet ni revenus, ni nombre de réservations, ni taux d'occupation. Le résultat dépend de votre logement, de sa présentation et de sa disponibilité.</p>
      </section>

      {/* C — identifier son besoin */}
      <section ref={chooseRef} aria-labelledby="choix" className="flex scroll-mt-28 flex-col gap-6">
        <div className="flex flex-col gap-1"><Eyebrow>Votre situation</Eyebrow><h2 id="choix" className="font-display text-2xl font-bold text-ink text-balance sm:text-3xl">Comment souhaitez-vous louer votre logement ?</h2></div>
        <ul className="grid gap-4 sm:grid-cols-2">
          {NEEDS.map((n) => (
            <li key={n.id}>
              <button onClick={() => setNeed(n.id)} aria-pressed={need === n.id}
                className={cx("flex h-full w-full flex-col gap-2 rounded-3xl border p-6 text-left transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-accent", need === n.id ? "border-brand bg-brand/5 ring-2 ring-brand" : "border-line bg-surface hover:border-brand")}>
                <span className="flex items-center gap-3 text-accent-ink"><Icon name={n.icon} /></span>
                <span className="font-display text-lg font-bold leading-snug text-ink">{n.title}</span>
                <span className="text-sm leading-relaxed text-muted">{n.text}</span>
              </button>
            </li>
          ))}
        </ul>
        {chosen ? <NeedResult need={chosen} st={st} /> : <p className="text-sm text-muted">Choisissez la situation qui vous ressemble : nous vous montrons la solution correspondante.</p>}
      </section>

      {/* D — les trois solutions : description puis prix en bas de chaque carte */}
      <section ref={solRef} aria-labelledby="solutions" className="flex scroll-mt-28 flex-col gap-8">
        <div className="flex flex-col gap-2">
          <Eyebrow>Les solutions YIRI</Eyebrow>
          <h2 id="solutions" className="font-display text-2xl font-bold text-ink text-balance sm:text-3xl">À chaque propriétaire, sa solution.</h2>
        </div>
        <SolutionGrid st={st} />
        <CompareTable />
      </section>

      {/* F — questions fréquentes */}
      <section aria-labelledby="faq" className="flex flex-col gap-6">
        <div className="flex flex-col gap-1"><Eyebrow>Questions fréquentes</Eyebrow><h2 id="faq" className="font-display text-2xl font-bold text-ink text-balance sm:text-3xl">Vous vous posez peut-être ces questions</h2></div>
        <div className="flex flex-col divide-y divide-line rounded-3xl border border-line bg-surface">
          {FAQ.map((f) => (
            <details key={f.q} className="group p-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold text-ink">
                <span>{f.q}</span><span aria-hidden="true" className="text-accent-ink transition-transform group-open:rotate-45">＋</span>
              </summary>
              <div className="mt-3 flex flex-col gap-2 text-sm leading-relaxed text-muted">
                <p>{f.a}</p>
                {f.confirm && <p><Pill tone="warn">À confirmer</Pill> <span className="ml-1">Une partie de cette réponse dépend de règles encore en validation.</span></p>}
              </div>
            </details>
          ))}
        </div>
      </section>

      {/* G — appel à l'action final */}
      <section aria-labelledby="final" className="flex flex-col items-center gap-5 rounded-3xl bg-[#1a0f12] px-6 py-14 text-center text-[#f7ecd8] sm:px-12">
        <h2 id="final" className="max-w-[22ch] font-display text-[clamp(1.9rem,4.6vw,3.2rem)] font-extrabold leading-[1.05] tracking-tight text-balance">Votre logement peut être la prochaine belle découverte sur YIRI.</h2>
        <p className="max-w-[54ch] text-lg leading-relaxed opacity-90">Présentez votre bien, choisissez la façon dont vous souhaitez le gérer et découvrez la solution adaptée à votre situation.</p>
        <div className="mt-2 flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
          <button onClick={() => st.go({ name: "proprietaires", at: "solutions" })} className="inline-flex items-center justify-center gap-2 rounded-full bg-[#f2b27a] px-9 py-4 text-lg font-extrabold text-[#2a1a12] shadow-[0_12px_40px_-10px_rgb(242_178_122/0.55)] transition-colors hover:bg-[#f8c595] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]">Commencer avec YIRI <span aria-hidden="true">→</span></button>
          <button onClick={() => st.ask("indecis")} className="inline-flex items-center justify-center rounded-full border border-[#f7ecd8]/60 px-9 py-4 text-lg font-bold transition-colors hover:bg-white/10 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]">Poser une question</button>
        </div>
              </section>
    </div>
  );
}

function NeedResult({ need, st }: { need: (typeof NEEDS)[number]; st: ReturnType<typeof useStart> }) {
  const p = PACKS[need.pack];
  const go = startFor(need.pack, st);
  return (
    <div role="status" aria-live="polite" className="flex flex-col gap-4 rounded-3xl bg-brand p-6 text-on-brand sm:p-8">
      <div className="flex flex-wrap items-center gap-2"><p className="text-xs font-bold uppercase tracking-[0.14em] opacity-80">La solution qui vous correspond</p><Pill tone={p.availability.tone}>{p.availability.label}</Pill></div>
      <h3 className="font-display text-2xl font-bold">{p.name}</h3>
      <p className="max-w-[64ch] leading-relaxed opacity-95">{need.why}</p>
      {need.pack !== "partenariat" && (
        <div className="grid gap-4 text-sm sm:grid-cols-2">
          <div><p className="mb-1 font-semibold">YIRI s'occupe de</p><ul className="flex flex-col gap-1 opacity-90">{p.included.slice(0, 3).map((x) => <li key={x}>• {x}</li>)}</ul></div>
          <div><p className="mb-1 font-semibold">Vous gardez</p><ul className="flex flex-col gap-1 opacity-90">{p.ownerDuties.slice(0, 3).map((x) => <li key={x}>• {x}</li>)}</ul></div>
        </div>
      )}
      <div className="flex flex-wrap gap-2 pt-1">
        <Button variant="secondary" onClick={go.run}>{go.label}</Button>
        <button onClick={() => st.open(p.route)} className="rounded-full border border-current/50 px-5 py-2.5 text-[15px] font-semibold hover:bg-white/10 cursor-pointer">Voir les détails de {p.name}</button>
      </div>
    </div>
  );
}

function SolutionGrid({ st }: { st: ReturnType<typeof useStart> }) {
  return <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">{PACK_ORDER.map((id) => <SolutionCard key={id} pack={PACKS[id]} st={st} />)}</div>;
}

function SolutionCard({ pack: p, st }: { pack: Pack; st: ReturnType<typeof useStart> }) {
  const go = startFor(p.id, st);
  return (
    <article className="flex min-w-0 flex-col gap-5 rounded-3xl border border-line bg-surface p-6">
      <div className="flex flex-col gap-2">
        <h3 className="font-display text-2xl font-bold text-ink">{p.name}</h3>
        <p className="text-sm font-semibold text-accent-ink">{p.tagline}</p>
        <div><Pill tone={p.availability.tone}>{p.availability.label}</Pill></div>
      </div>
      <div className="flex flex-col gap-3 text-sm">
        <p><span className="font-semibold text-ink">Pour qui ? </span><span className="text-muted">{p.profile}</span></p>
        <p className="rounded-2xl bg-sunk p-3 leading-relaxed text-ink">{p.value}</p>
      </div>
      <div className="flex flex-col gap-2"><h4 className="text-xs font-bold uppercase tracking-[0.12em] text-muted">Ce qui est inclus</h4><ul className="flex flex-col gap-1.5 text-sm text-ink">{p.included.slice(0, 4).map((x) => <li key={x} className="flex gap-2"><span className="text-good" aria-hidden="true">✓</span>{x}</li>)}</ul></div>
      <div className="flex flex-col gap-2"><h4 className="text-xs font-bold uppercase tracking-[0.12em] text-muted">Ce que vous gardez</h4><ul className="flex flex-col gap-1.5 text-sm text-ink">{p.ownerDuties.slice(0, 3).map((x) => <li key={x} className="flex gap-2"><span className="text-accent" aria-hidden="true">●</span>{x}</li>)}</ul></div>
      <div className="mt-auto flex flex-col gap-4 pt-1">
        <PriceBlock pack={p} />
        <Button onClick={go.run}>{go.label}</Button>
        <button onClick={() => st.open(p.route)} className="text-sm font-semibold text-brand underline underline-offset-4 cursor-pointer">Tous les détails de {p.name} →</button>
      </div>
    </article>
  );
}

function CompareTable() {
  return (
    <div className="overflow-x-auto rounded-2xl border border-line bg-surface">
      <table className="w-full min-w-[720px] text-left text-sm">
        <caption className="sr-only">Qui s'en charge, selon la solution</caption>
        <thead className="border-b border-line text-xs uppercase tracking-[0.08em] text-muted">
          <tr><th className="px-4 py-3">Qui s'en charge ?</th>{PACK_ORDER.map((id) => <th key={id} className="px-4 py-3">{PACKS[id].name}</th>)}</tr>
        </thead>
        <tbody>
          {COMPARE.map((r) => (
            <tr key={r.label} className="border-b border-line last:border-0">
              <th scope="row" className="px-4 py-3 font-semibold text-ink">{r.label}</th>
              {r.cells.map((c, i) => <td key={i} className="px-4 py-3 text-muted">{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Page « Solutions » : on y arrive directement depuis « Découvrir les solutions propriétaires ». */
export function SolutionsPage() {
  const st = useStart();
  const { go } = useStore();
  return (
    <div className="flex flex-col gap-10 py-8">
      <header className="flex flex-col gap-3">
        <Eyebrow>Solutions propriétaires</Eyebrow>
        <h1 className="font-display text-[clamp(2rem,5vw,3.2rem)] font-extrabold leading-[1.02] tracking-tight text-ink text-balance">À chaque propriétaire, sa solution.</h1>
      </header>
      <SolutionGrid st={st} />
      <section className="flex flex-col gap-3"><h2 className="font-display text-2xl font-bold text-ink">Comparer les solutions</h2><CompareTable /></section>
      <section className="flex flex-col items-start gap-3 rounded-3xl bg-sunk p-6 sm:flex-row sm:items-center sm:justify-between">
        <div><h2 className="font-display text-xl font-bold text-ink">Vous hésitez ?</h2><p className="text-sm text-muted">Dites-nous où est votre logement et ce que vous souhaitez : l'équipe YIRI vous rappelle.</p></div>
        <div className="flex flex-wrap gap-2"><Button onClick={() => st.ask("indecis")}>Poser une question</Button><Button variant="secondary" onClick={() => go({ name: "proprietaires" })}>Pourquoi YIRI ?</Button></div>
      </section>
    </div>
  );
}

/* ───────────── Prix : toujours après la valeur ───────────── */
export function PriceBlock({ pack, compact }: { pack: Pack; compact?: boolean }) {
  return (
    <div className="flex flex-col gap-2 rounded-2xl bg-sunk p-4">
      <p className="text-xs font-bold uppercase tracking-[0.12em] text-muted">Tarif et facturation</p>
      {pack.price.main === "plans" ? (
        <div className="flex flex-col gap-0.5 text-ink">
          <p className={cx("font-extrabold tabular-nums", compact ? "text-lg" : "text-2xl")}><Money value={PLANS.mensuel.price} /> <span className="text-base font-semibold">par mois</span></p>
          <p className="font-bold tabular-nums"><span className="font-normal text-muted">ou </span><Money value={PLANS.annuel.price} /> <span className="font-semibold">par an</span></p>
        </div>
      ) : (
        <p className={cx("font-extrabold tabular-nums text-ink", compact ? "text-lg" : "text-2xl")}>{pack.price.main}</p>
      )}
      {pack.price.sub && <p className="text-sm text-muted">{pack.price.sub}</p>}
      <p className="text-sm text-muted">{pack.price.billing}</p>
    </div>
  );
}

/* ───────────── Demande de contact propriétaire (enregistrée côté admin) ───────────── */
const LEVELS: [LeadLevel, string][] = [
  ["autonomie", "Je gère moi-même mon logement"],
  ["reservations", "J'ai besoin d'aide pour les réservations"],
  ["delegation", "Je préfère déléguer la gestion quotidienne"],
];

export function DemandePage({ pack: initialPack }: { pack?: PackId | "indecis" }) {
  const { go } = useStore();
  const [f, setF] = React.useState({ pack: (initialPack ?? "indecis") as PackId | "indecis", kind: "Villa", city: "Ouagadougou", count: 1, level: "delegation" as LeadLevel, name: "", phone: "", message: "" });
  const [consent, setConsent] = React.useState(false);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [sent, setSent] = React.useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: k === "count" ? Math.max(1, Math.round(+e.target.value || 1)) : e.target.value });

  const [busy, setBusy] = React.useState(false);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (f.name.trim().length < 2) er.name = "Indiquez votre nom.";
    if (!isValidPhone(f.phone)) er.phone = "Numéro invalide. Exemple : 70 12 34 56.";
    if (!consent) er.consent = "Votre accord est nécessaire pour que YIRI puisse vous rappeler.";
    setErrors(er);
    if (Object.keys(er).length) return;
    setBusy(true);
    void submitLead({
      pack: f.pack === "visibilite" || f.pack === "serenite" || f.pack === "partenariat" ? f.pack : "indecis",
      property_kind: f.kind, city: f.city, property_count: f.count, level: f.level,
      name: f.name.trim(), phone: f.phone.trim(), message: f.message.trim() || undefined,
    }).then(() => setSent(true))
      .catch((err) => setErrors({ envoi: err instanceof Error ? err.message : "Envoi impossible. Réessayez." }))
      .finally(() => setBusy(false));
  }

  if (sent) {
    return (
      <div className="mx-auto flex max-w-xl flex-col gap-4 py-12">
        <h1 className="font-display text-3xl font-bold text-ink">Demande envoyée</h1>
        <p className="text-muted">L'équipe YIRI a bien reçu votre demande et vous rappelle au numéro indiqué. Cette demande n'engage ni vous ni YIRI.</p>
        <div className="flex flex-wrap gap-2"><Button onClick={() => go({ name: "accueil" })}>Retour à l'accueil</Button><Button variant="secondary" onClick={() => go({ name: "proprietaires", at: "solutions" })}>Revoir les solutions</Button></div>
      </div>
    );
  }
  return (
    <form onSubmit={submit} noValidate className="mx-auto flex max-w-2xl flex-col gap-6 py-8">
      <header className="flex flex-col gap-2">
        <Eyebrow>Être contacté par YIRI</Eyebrow>
        <h1 className="font-display text-3xl font-bold text-ink text-balance">Parlons de votre logement</h1>
        <p className="text-muted">Quelques informations suffisent. Cette demande envoie un message à l'équipe YIRI : elle ne publie rien et n'engage ni vous ni YIRI.</p>
      </header>
      <Field label="Solution qui vous intéresse" htmlFor="d-pack">
        <select id="d-pack" className={inputCls} value={f.pack} onChange={set("pack")}>
          {PACK_ORDER.map((id) => <option key={id} value={id}>{PACKS[id].name}</option>)}
          <option value="indecis">Je ne sais pas encore, conseillez-moi</option>
        </select>
      </Field>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Type de logement" htmlFor="d-kind"><select id="d-kind" className={inputCls} value={f.kind} onChange={set("kind")}><option>Villa</option><option>Appartement</option><option>Studio</option><option>Chambre-salon</option><option>Autre</option></select></Field>
        <CityField id="d-city" value={f.city} onChange={(v) => setF({ ...f, city: v })} />
        <Field label="Nombre de logements" htmlFor="d-count"><input id="d-count" type="number" min={1} className={inputCls} value={f.count} onChange={set("count")} /></Field>
      </div>
      <fieldset className="flex flex-col gap-2">
        <legend className="mb-1 text-sm font-semibold text-ink">Niveau de gestion souhaité</legend>
        {LEVELS.map(([k, label]) => (
          <label key={k} className={cx("flex cursor-pointer items-center gap-3 rounded-2xl border p-3 text-sm", f.level === k ? "border-brand bg-brand/5" : "border-line bg-surface")}>
            <input type="radio" name="level" checked={f.level === k} onChange={() => setF({ ...f, level: k })} className="accent-[var(--brand)]" />{label}
          </label>
        ))}
      </fieldset>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Votre nom" htmlFor="d-name" error={errors.name}><input id="d-name" className={inputCls} value={f.name} onChange={set("name")} autoComplete="name" /></Field>
        <Field label="Téléphone (pour vous rappeler)" htmlFor="d-phone" error={errors.phone}><input id="d-phone" type="tel" inputMode="tel" className={inputCls} value={f.phone} onChange={set("phone")} placeholder="70 12 34 56" /></Field>
      </div>
      <Field label="Votre question (facultatif)" htmlFor="d-msg">
        <textarea id="d-msg" rows={3} className={inputCls} value={f.message} onChange={set("message")} maxLength={600} placeholder="Ex. : Mon logement est à Banfora, est-il possible d'être accompagné ?" />
      </Field>
      <div className="flex flex-col gap-1">
        <label className="flex items-start gap-3 text-sm text-ink" htmlFor="d-consent">
          <input id="d-consent" type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1 size-4 accent-[var(--brand)]" />
          J'accepte que YIRI utilise ces informations pour me rappeler au sujet de mon logement.
        </label>
        {errors.consent && <p className="text-xs font-medium text-danger">{errors.consent}</p>}
      </div>
      {errors.envoi && <p role="alert" className="rounded-xl border border-danger/40 bg-danger/10 px-3.5 py-2.5 text-sm font-medium text-danger">{errors.envoi}</p>}
      <Button type="submit" className="self-start" disabled={busy}>{busy ? "Envoi…" : "Envoyer ma demande à YIRI"}</Button>
    </form>
  );
}
