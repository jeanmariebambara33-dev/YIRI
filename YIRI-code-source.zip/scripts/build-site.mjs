// Prépare le dossier à déposer sur Vercel (vercel.com/drop) : page, en-têtes de sécurité, robots.
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

const root = path.resolve(import.meta.dirname, "..");
const out = path.join(root, "dist", "site-yiri");

execFileSync(process.execPath, [path.join(root, "scripts/build-preview.mjs")], { stdio: "inherit" });

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
fs.copyFileSync(path.join(root, "dist/yiri-demo.html"), path.join(out, "index.html"));

// Politique de sécurité : on n'autorise que ce que le site utilise vraiment.
const csp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com data:",
  "img-src 'self' data: blob: https://*.supabase.co",
  "connect-src 'self' https://*.supabase.co",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
  "upgrade-insecure-requests",
].join("; ");

fs.writeFileSync(path.join(out, "vercel.json"), JSON.stringify({
  $schema: "https://openapi.vercel.sh/vercel.json",
  headers: [{
    source: "/sw.js",
    headers: [{ key: "Cache-Control", value: "no-cache, no-store, must-revalidate" }],
  }, {
    source: "/manifest.webmanifest",
    headers: [{ key: "Content-Type", value: "application/manifest+json; charset=utf-8" }],
  }, {
    source: "/(.*)",
    headers: [
      { key: "Content-Security-Policy", value: csp },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "X-Frame-Options", value: "DENY" },
      { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=()" },
      { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
    ],
  }],
  cleanUrls: true,
}, null, 2) + "\n");

for (const f of ["manifest.webmanifest", "sw.js", "icone-192.png", "icone-512.png", "icone-maskable-512.png", "apple-touch-icon.png"]) {
  fs.copyFileSync(path.join(root, "assets", f), path.join(out, f));
}

fs.mkdirSync(path.join(out, "photo"), { recursive: true });
for (const f of fs.readdirSync(path.join(root, "assets/photo"))) {
  if (/\.(avif|webp)$/.test(f)) fs.copyFileSync(path.join(root, "assets/photo", f), path.join(out, "photo", f));
}

fs.writeFileSync(path.join(out, "robots.txt"), "User-agent: *\nAllow: /\n");

const taille = (fs.statSync(path.join(out, "index.html")).size / 1024).toFixed(0);
console.log(`Dossier prêt : dist/site-yiri — ${fs.readdirSync(out).length} fichiers, page de ${taille} Ko`);
for (const f of fs.readdirSync(out).sort()) console.log("   " + f);
