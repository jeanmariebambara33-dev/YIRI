# YIRI — Appliquer les migrations 0001 à 0006 au projet Supabase (procédure pas à pas)

> **Statut : préparée, rien n'a été exécuté sur le projet distant.** Aucune clé n'est nécessaire : tout se fait dans le tableau de
> bord Supabase, connecté avec ton compte. **Ne colle jamais de clé, de mot de passe ou de jeton dans une conversation.**
> Ce projet est traité comme **PRÉPRODUCTION** : aucune donnée réelle, aucune donnée de démonstration, jusqu'à validation écrite.

## Où sont les migrations
Dépôt Git du projet, dossier `supabase/migrations/` (espace de travail de Claude ; la copie qui fait foi est le commit Git, repère
`v1-migrations-0001-0006`). Empreintes SHA-256 dans `supabase/MIGRATIONS.sha256`.

| Ordre | Fichier | Lignes | Rôle |
|---|---|---|---|
| 1 | `0001_init.sql` | 416 | schéma de base, types, tables, sécurité par ligne initiale |
| 2 | `0002_team_access.sql` | 46 | permissions déléguées de l'équipe |
| 3 | `0003_all_localities.sql` | 24 | toutes les localités du Burkina |
| 4 | `0004_booking_flow.sql` | 34 | réservation avec paiement immédiat, contraintes de paiement |
| 5 | `0005_multiuser_security.sql` | 652 | socle multi-utilisateur : droits, contacts, avis de paiement, dates, stockage, inscription |
| 6 | `0006_server_functions.sql` | 634 | fonctions serveur (réservation, contact, paiement manuel, rôles, statuts) + expiration |

À appliquer **dans cet ordre, une seule fois, un fichier à la fois**. Les migrations ne sont pas rejouables : en cas d'erreur, on ne
« répare » pas à la main (voir « Si une étape échoue »).

## Inventaire attendu après chaque migration (script `preprod/inventory.sql`)
Calculé en rejouant les fichiers sur PostgreSQL 16 local. Les chiffres du projet Supabase doivent être **identiques**.

| Après | tables | vues | politiques | fonctions | déclencheurs | types enum | index |
|---|---|---|---|---|---|---|---|
| 0001 | 23 | 1 | 28 | 3 | 2 | 11 | 33 |
| 0002 | 24 | 1 | 31 | 5 | 3 | 12 | 34 |
| 0003 | 24 | 1 | 31 | 5 | 3 | 11 | 34 |
| 0004 | 24 | 1 | 31 | 6 | 3 | 11 | 34 |
| 0005 | 29 | 2 | 52 | 24 | 14 | 11 | 42 |
| 0006 | 29 | 2 | 51 | 37 | 16 | 11 | 46 |

## Les étapes
0. **Avant tout** — `preprod/preflight.sql` (lecture seule) : confirme que le projet est vide et conforme. On corrige les écarts avant de continuer.
1. Activer l'extension **pg_cron** (Database → Extensions) — avant la 0006.
2. Appliquer `0001`, puis inventaire, puis `0002`, inventaire… jusqu'à `0006`.
3. `preprod/checks.sql` puis `preprod/checks_access.sql` (lecture seule).
4. Créer le premier administrateur (voir `PREPROD.md` §4).
5. Régler Auth (voir `PREPROD.md` §3).
6. Tests API (voir `PREPROD.md` §6) — seulement après accord explicite.

## Pourquoi cette méthode est la plus sûre
- **Un fichier = un lot unique** dans l'éditeur SQL : l'éditeur exécute le texte collé d'un seul envoi, donc en principe tout ou rien
  (*à confirmer au premier essai : si une erreur survient, l'inventaire doit rester identique à l'étape précédente*).
- **Inventaire chiffré après chaque fichier** : on détecte immédiatement une application partielle ou un objet inattendu.
- **Aucune clé, aucun outil externe** : pas de CLI, pas de jeton, pas de mot de passe de base de données.
- **Projet vide et jetable** : le pire scénario est de le supprimer et d'en recréer un.
- **Les tests (`supabase/tests/`) ne sont JAMAIS collés** sur ce projet : ils créent un schéma `t` et de faux comptes.
- Messages normaux à attendre : `NOTICE` (déclencheur/policy « n'existe pas, ignoré »). La 0005 et la 0006 contiennent des `drop policy` :
  le tableau de bord peut demander une confirmation « requête destructive » ; c'est attendu pour ces deux fichiers (ils ne suppriment
  que des règles créées par les migrations précédentes, jamais des données).

## Différences possibles entre PostgreSQL local et Supabase
| Sujet | Local (testé) | Supabase (non testé) | Conséquence / protection |
|---|---|---|---|
| Version | PostgreSQL 16.15 | probablement 15 ou 17 (le contrôle n°1 l'affiche) ; **17 non testable ici** | rien de spécifique à une version n'est utilisé ; à confirmer par l'inventaire |
| Rôle d'exécution | `postgres` **super-utilisateur** | `postgres` **non** super-utilisateur ; les schémas `auth` et `storage` appartiennent à des rôles internes | risque : refus lors de la création du déclencheur sur `auth.users` ou des règles sur `storage.objects` (0005 §7-8). La pratique documentée est de le faire depuis l'éditeur SQL (à confirmer). Un refus annule tout le fichier : sans danger |
| `auth.uid()` | simulé par un réglage de session | lit le jeton de connexion (JWT) | même sens ; testé seulement à l'étape API |
| `anon` / `authenticated` | rôles simulés | rôles réels de PostgREST | droits d'exécution et lecture contrôlés par `checks.sql` |
| Droits par défaut | reproduits dans `tests/stub.sql` (tables **et** fonctions accessibles à `anon`/`authenticated`) | à confirmer ; peuvent différer | si moins ouverts : erreur « permission denied » (échec sûr, pas une faille), corrigée par une migration |
| Stockage | faux schéma `storage` minimal | vrai service (limite de taille, types MIME, URL signées) | bucket + 6 règles vérifiés par SQL (contrôles 8-9) ; comportement réel testé en étape API |
| `pg_cron` | absent | extension à activer | contrôle n°10 ; script `enable_cron.sql` |
| Extension `btree_gist` | schéma `public` | `public` ou `extensions` | sans effet sur les contraintes ; `checks.sql` exclut les fonctions d'extension |
| API de données | aucune | PostgREST (cache de schéma, appels `rpc/` en JSON, paramètres nommés `p_…`) | testé seulement à l'étape API |
| Fuseau horaire | Africa/Ouagadougou (+00:00) | UTC par défaut | identiques (Burkina = UTC+0) ; contrôle n°3 de `preflight.sql` |
| Concurrence | vraies connexions simultanées (26 contrôles) | idem, mais via l'API | refaire les tests 11 et 14 |
| Conseiller de sécurité Supabase | — | avertissements **attendus** : « Security Definer View » sur `public_listings` / `public_listing_photos` (ce sont volontairement les seules vues publiques) ; « RLS sans politique » sur `rate_events`, `payment_events` (fermées aux clients exprès) | à me recopier ; tout autre avertissement est à examiner |
| Dossier de scripts de test | contient `t.*` et faux comptes | **ne doit jamais exister** | contrôle n°11 de `checks.sql` |

## Si une étape échoue
1. **Arrête-toi.** Ne relance pas le même fichier, ne « corrige » pas à la main.
2. Recopie-moi le message d'erreur complet (aucune clé n'y figure) et le résultat de `inventory.sql`.
3. Si l'inventaire est identique à l'étape précédente : le fichier a été annulé en entier ; je corrige et on réessaie.
4. S'il est différent : application partielle ; le plus sûr est de supprimer le projet de préproduction (vide) et d'en recréer un.
   Je ne te demanderai jamais d'exécuter une commande de suppression de données sans te l'expliquer et sans ton accord écrit.

## Migration 0007 — pièce d'identité du propriétaire (à appliquer APRÈS 0001–0006, sur accord)
- Fichier : `migrations/0007_owner_identity.sql` (369 lignes). Tests locaux : 134 (`tests/0007_identity.sql`).
- Parcours : compte → brouillons (3 au plus tant que non vérifié) → au moment de « Publier », recto + verso + numéro → l'équipe « validation » ouvre le dossier (journalisé), accorde le rôle, approuve l'annonce → les images sont supprimées par l'API Storage, puis `confirm_identity_files_deleted`.
- Avertissement « destructive » attendu : `drop policy` (properties_owner_insert, yiri_photos_insert_owner).
- Inventaire attendu après 0007 (inventory.sql) : 30 | 2 | 51 | 51 | 18 | 11 | 48 (mesuré sur la base locale rejouée ; à confirmer sur Supabase).
- À confirmer sur le vrai Supabase (non prouvable en local) : suppression d'objet via l'API Storage par l'équipe après `open_owner_identity` ; refus d'envoi hors règles ; lecture de l'URL signée.
- Non implémenté : purge automatique des brouillons abandonnés (durée à fixer) et suppression de leurs photos du Storage.

## Migration 0008 — files d'attente de l'équipe (lecture seule)
- Fichier : `migrations/0008_team_queues.sql` (45 lignes). Tests locaux : 27 (`tests/0008_queues.sql`).
- Ajoute `identity_queue()` et `identity_file_paths()` : l'équipe « validation » voit qu'un dossier attend, SANS lire le numéro de la pièce (qui reste réservé à `open_owner_identity`, journalisé).
- N'ajoute aucune table, aucune politique, ne modifie rien de 0001 à 0007. Aucun avertissement « destructive » attendu.
- Inventaire attendu après 0008 : 30 | 2 | 51 | 53 | 18 | 11 | 48.
