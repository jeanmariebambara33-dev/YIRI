-- YIRI — 0011 : voir les réservations, et être prévenu quand il s'en passe une.
--
-- Le constat qui a provoqué cette migration : quelqu'un réservait, payait, la réservation
-- passait toute seule en « confirmée »… et PERSONNE du côté YIRI ne l'apprenait.
-- Le propriétaire ne voyait rien dans son espace, l'équipe ne voyait rien dans son tableau de
-- bord, et aucune notification n'était écrite. L'argent arrivait en silence.
--
-- Ce fichier répare ça en trois morceaux, tous ADDITIFS. Rien de 0001 à 0010 n'est redéfini :
--
--   1. une notification écrite automatiquement quand une réservation est confirmée ou annulée,
--      pour le propriétaire du logement ET pour l'équipe concernée ;
--   2. bookings_queue() : la file des réservations pour l'équipe, prochaines arrivées en tête ;
--   3. owner_bookings() : ses propres réservations pour un propriétaire, avec les coordonnées
--      du voyageur MASQUÉES tant que le séjour n'est pas payé.
--
-- Pourquoi ce masquage : un simple blocage de dates, non payé, n'est pas une relation
-- commerciale. Faire circuler le nom et le téléphone de quelqu'un qui n'a encore rien payé,
-- c'est diffuser une donnée personnelle sans raison. Le jour où la déclaration CIL sera
-- examinée, « nous ne communiquons les coordonnées qu'une fois le séjour payé » est une
-- phrase qui se défend ; « tout propriétaire voit tout le monde » ne se défend pas.
--
-- Note sur le choix de ne PAS faire valider les réservations par un humain : c'est la décision
-- déjà prise pour le paiement (« automatique quand c'est possible »). Un voyageur qui a payé
-- ne doit pas attendre qu'on se réveille. Ce fichier n'ajoute donc pas d'étape de validation :
-- il ajoute la VISIBILITÉ qui manquait.

-- =====================================================================
-- 0. Garde : 0011 s'appuie sur 0009 et 0010
-- =====================================================================
-- Appliquée seule, 0011 échouerait plus loin sur une erreur technique illisible.
-- Ce contrôle s'arrête avant d'avoir rien modifié, avec un message qui dit quoi faire.
do $$
begin
  if to_regclass('public.payment_attempts') is null then
    raise exception 'La migration 0009 n''est pas appliquée. Appliquez 0009 puis 0010 d''abord. Rien n''a été modifié.';
  end if;
  if to_regclass('public.refund_rules') is null then
    raise exception 'La migration 0010 n''est pas appliquée. Appliquez 0010 d''abord. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Les notifications ont besoin d'une date
-- =====================================================================
-- La table existe depuis 0001 mais sans date de création : impossible d'afficher
-- « les plus récentes en premier ». On l'ajoute sans toucher aux lignes existantes.
alter table notifications add column if not exists created_at timestamptz not null default now();
create index if not exists notifications_user_idx on notifications (user_id, created_at desc);

-- =====================================================================
-- 2. Le signal : une réservation confirmée ou annulée prévient les bonnes personnes
-- =====================================================================
-- SECURITY DEFINER obligatoire : la table notifications n'a aucune règle d'écriture
-- (0001 n'autorise que la lecture de ses propres notifications). Sans cela, la confirmation
-- de paiement échouerait au moment d'écrire la notification, et le paiement serait perdu.
create or replace function notify_booking_change()
returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  prop record;
  genre text;
  charge boolean;
begin
  -- On ne réagit qu'aux deux changements qui méritent qu'on dérange quelqu'un.
  if new.status = 'confirmee' and (tg_op = 'INSERT' or old.status is distinct from 'confirmee') then
    genre := 'booking.confirmee';
  elsif new.status = 'annulee' and (tg_op = 'INSERT' or old.status is distinct from 'annulee') then
    genre := 'booking.annulee';
  else
    return new;
  end if;

  select p.id, p.owner_id, p.title, p.city, p.district, p.offer into prop
    from properties p where p.id = new.property_id;
  if not found then return new; end if;

  -- « Sous gestion » : YIRI s'occupe du séjour (offres Sérénité et Partenariat).
  -- Le propriétaire est prévenu dans tous les cas ; l'équipe, elle, n'a de geste à faire
  -- que sur ces deux offres-là, et c'est ce que dit « a_traiter ».
  charge := prop.offer in ('gestion', 'partenariat');

  -- Le propriétaire du logement.
  insert into notifications (user_id, type, payload)
  values (prop.owner_id, genre,
          jsonb_build_object('reservation', new.id, 'logement', prop.title,
                             'ville', prop.city, 'arrivee', lower(new.stay),
                             'depart', upper(new.stay), 'total_xof', new.total_xof,
                             'sous_gestion', charge));

  -- L'équipe habilitée aux réservations, plus les administrateurs. L'équipe est petite :
  -- une ligne par personne reste négligeable, et chacun garde SA liste, lue par SA propre
  -- règle de sécurité. Un « distinct » évite de prévenir deux fois un administrateur qui
  -- détient aussi la permission, et le propriétaire ne reçoit pas deux fois le même message.
  insert into notifications (user_id, type, payload)
  select distinct x.user_id, genre || '.equipe',
         jsonb_build_object('reservation', new.id, 'logement', prop.title,
                            'ville', prop.city, 'arrivee', lower(new.stay),
                            'depart', upper(new.stay), 'total_xof', new.total_xof,
                            'sous_gestion', charge, 'a_traiter', charge)
    from (
      select tp.user_id from team_permissions tp where tp.perm in ('reservations', 'paiements')
      union
      select ur.user_id from user_roles ur where ur.role = 'admin'
    ) x
   where x.user_id <> prop.owner_id;

  return new;
end $$;
revoke all on function notify_booking_change() from public, anon, authenticated;

drop trigger if exists bookings_notify on bookings;
create trigger bookings_notify
  after insert or update of status on bookings
  for each row execute function notify_booking_change();

-- =====================================================================
-- 3. Mes notifications (toute personne connectée)
-- =====================================================================
-- La table est déjà lisible ligne à ligne par son propriétaire (0001). Cette fonction
-- existe pour que l'interface n'ait qu'un seul appel à faire, et pour borner le volume.
create or replace function my_notifications(p_limit int default 30)
returns table (id uuid, type text, payload jsonb, created_at timestamptz, read_at timestamptz)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select n.id, n.type, n.payload, n.created_at, n.read_at
      from notifications n
     where n.user_id = uid
     order by n.created_at desc
     limit greatest(1, least(coalesce(p_limit, 30), 100));
end $$;
revoke all on function my_notifications(int) from public, anon;
grant execute on function my_notifications(int) to authenticated;

create or replace function mark_notifications_read()
returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user(); n int;
begin
  update notifications set read_at = now() where user_id = uid and read_at is null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function mark_notifications_read() from public, anon;
grant execute on function mark_notifications_read() to authenticated;

-- =====================================================================
-- 4. La file des réservations, pour l'équipe
-- =====================================================================
-- Permission « reservations » OU « paiements » : celui qui suit l'argent a besoin de voir
-- à quelle réservation il se rapporte, sinon il ne peut rien rapprocher.
-- L'équipe voit les coordonnées complètes : c'est elle qui répond au téléphone quand un
-- voyageur trouve porte close.
create or replace function bookings_queue(p_limit int default 100)
returns table (
  id uuid, property_id uuid, title text, city text, district text,
  offer text, sous_gestion boolean,
  arrivee date, depart date, nuits int, guests int,
  total_xof int, status text, created_at timestamptz, hold_expires_at timestamptz,
  guest_id uuid, guest_name text, guest_phone text, guest_email text,
  paye boolean, paye_le timestamptz, reference text, moyen text
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_any_perm('reservations', 'paiements') then
    raise exception 'Action réservée à l''équipe habilitée (réservations).' using errcode = '42501';
  end if;
  return query
    select b.id, p.id, p.title, p.city::text, p.district,
           p.offer::text, (p.offer in ('gestion', 'partenariat')),
           lower(b.stay), upper(b.stay), (upper(b.stay) - lower(b.stay))::int, b.guests,
           b.total_xof, b.status::text, b.created_at, b.hold_expires_at,
           b.guest_id, pr.full_name, pr.phone, coalesce(pr.email, u.email::text),
           (t.id is not null), t.updated_at, t.provider_reference, (m.after ->> 'moyen')
      from bookings b
      join properties p on p.id = b.property_id
      join profiles pr on pr.id = b.guest_id
      left join auth.users u on u.id = b.guest_id
      -- Un seul encaissement réussi possible par réservation (index unique de 0006).
      left join payment_transactions t
             on t.booking_id = b.id and t.purpose = 'booking' and t.status = 'reussi'
      -- Le moyen de paiement (Orange Money, Moov…) n'est pas une colonne : 0009 l'écrit dans
      -- le journal d'audit. On va le chercher là plutôt que d'ajouter une colonne et de
      -- redéfinir une fonction déjà validée.
      left join lateral (
        select l.after from audit_logs l
         where l.action = 'payment.method' and l.entity_type = 'reservation'
           and l.entity_id = b.id::text
         order by l.created_at desc limit 1
      ) m on true
     order by
       -- D'abord ce qui est vivant, et dedans la prochaine arrivée en tête : c'est la question
       -- qu'on se pose vraiment en ouvrant cet écran — « qui arrive bientôt ? ».
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then 0 else 1 end),
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then lower(b.stay) end) asc nulls last,
       b.created_at desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function bookings_queue(int) from public, anon;
grant execute on function bookings_queue(int) to authenticated;

-- =====================================================================
-- 5. Ses réservations, pour un propriétaire
-- =====================================================================
-- Deux différences volontaires avec la file de l'équipe :
--
--   * le filtre est « mes logements », pas une permission. Aucun rôle n'est requis : si le
--     logement est à vous, les réservations dessus vous regardent ;
--   * les coordonnées du voyageur n'apparaissent QUE lorsque le séjour est payé
--     (confirmé, en cours ou terminé). Avant, le propriétaire voit qu'il y a une demande,
--     les dates et le montant — ce qui suffit à décider — mais pas qui c'est.
--     Une réservation non payée finit souvent expirée : il n'y a aucune raison d'avoir
--     fait circuler un nom et un numéro pour rien.
--
-- L'adresse électronique n'est jamais renvoyée ici, même payée : le propriétaire a besoin
-- d'un numéro pour accueillir quelqu'un, pas d'une adresse pour lui écrire plus tard.
create or replace function owner_bookings(p_limit int default 100)
returns table (
  id uuid, property_id uuid, title text, city text, district text,
  offer text, sous_gestion boolean,
  arrivee date, depart date, nuits int, guests int,
  total_xof int, status text, created_at timestamptz,
  guest_name text, guest_phone text, coordonnees_visibles boolean,
  paye boolean, paye_le timestamptz
)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select b.id, p.id, p.title, p.city::text, p.district,
           p.offer::text, (p.offer in ('gestion', 'partenariat')),
           lower(b.stay), upper(b.stay), (upper(b.stay) - lower(b.stay))::int, b.guests,
           b.total_xof, b.status::text, b.created_at,
           case when b.status in ('confirmee', 'en_cours', 'terminee') then pr.full_name end,
           case when b.status in ('confirmee', 'en_cours', 'terminee') then pr.phone end,
           (b.status in ('confirmee', 'en_cours', 'terminee')),
           (t.id is not null), t.updated_at
      from bookings b
      join properties p on p.id = b.property_id
      join profiles pr on pr.id = b.guest_id
      left join payment_transactions t
             on t.booking_id = b.id and t.purpose = 'booking' and t.status = 'reussi'
     where p.owner_id = uid
     order by
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then 0 else 1 end),
       (case when b.status in ('en_attente_paiement', 'confirmee', 'en_cours') then lower(b.stay) end) asc nulls last,
       b.created_at desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function owner_bookings(int) from public, anon;
grant execute on function owner_bookings(int) to authenticated;
