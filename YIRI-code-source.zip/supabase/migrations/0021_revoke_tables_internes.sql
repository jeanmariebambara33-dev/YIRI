-- YIRI — 0021 : retirer deux droits de lecture oubliés.
--
-- Constat de l'audit du 14 octobre. Sept tables du schéma public ont la sécurité par ligne
-- activée SANS aucune politique : c'est voulu, elles ne sont lues que par des fonctions
-- SECURITY DEFINER. Cinq d'entre elles avaient aussi leur droit de lecture explicitement
-- retiré à « anon » et « authenticated ». Deux ne l'avaient pas : payment_events et rate_events.
--
-- CE N'EST PAS UNE FUITE, et il faut le dire précisément. La vérification a été faite : des
-- lignes ont été insérées dans ces deux tables, puis lues en prenant le rôle « anon » puis
-- « authenticated ». Résultat : zéro ligne visible. PostgreSQL refuse tout par défaut quand la
-- sécurité par ligne est active et qu'aucune politique ne s'applique.
--
-- Ce qui est corrigé est donc un risque FUTUR, pas un problème présent : le jour où quelqu'un
-- ajouterait une politique permissive sur l'une de ces tables — pour déboguer, par exemple — le
-- droit oublié rendrait les données lisibles sans que personne ne s'en aperçoive. Les deux
-- barrières doivent être fermées, pas une seule.
--
-- payment_events contient les messages bruts du prestataire de paiement. rate_events sert à
-- limiter les abus et porte des empreintes d'usage. Ni l'une ni l'autre n'a de raison d'être
-- lisible depuis un navigateur, aujourd'hui ou demain.
--
-- Migration purement additive : aucune donnée touchée, aucune fonction redéfinie, aucune
-- politique créée ni supprimée. Rejouable sans effet.

do $$
begin
  if to_regclass('public.payment_events') is null then
    raise exception 'La migration 0001 n''est pas appliquée. Rien n''a été modifié.';
  end if;
end $$;

revoke all on payment_events from anon, authenticated;
revoke all on rate_events   from anon, authenticated;

-- Le commentaire reste dans la base : il explique le choix à qui ouvrira la table un jour.
comment on table payment_events is
  'Messages bruts du prestataire de paiement. Sécurité par ligne active SANS politique, et droits retirés : lisible uniquement par les fonctions serveur. Ne jamais y ajouter de politique permissive.';
comment on table rate_events is
  'Compteurs de limitation d''abus. Sécurité par ligne active SANS politique, et droits retirés : lisible uniquement par les fonctions serveur.';
