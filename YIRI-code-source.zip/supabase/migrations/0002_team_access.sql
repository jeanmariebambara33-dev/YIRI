-- YIRI — Accès équipe et délégation d'autorisations.
-- Principe : seul un administrateur (role 'admin') donne ou retire des accès. Un membre n'a que les
-- autorisations explicitement cochées. Un visiteur ou un propriétaire n'a aucune ligne ici : il ne voit rien.

create type team_perm as enum ('validation', 'reservations', 'partenariat', 'demandes', 'paiements', 'audit');

create table team_permissions (
  user_id uuid not null references profiles(id) on delete cascade,
  perm team_perm not null,
  granted_by uuid not null references profiles(id),
  created_at timestamptz not null default now(),
  primary key (user_id, perm)
);

-- Vrai pour un administrateur (accès complet) ou pour un membre à qui cette autorisation a été donnée.
create or replace function has_perm(p team_perm) returns boolean
language sql stable security definer set search_path = public as $$
  select has_role('admin')
      or exists (select 1 from team_permissions where user_id = auth.uid() and perm = p);
$$;

alter table team_permissions enable row level security;

-- Lecture : sa propre ligne, ou tout pour un administrateur.
create policy team_perm_read on team_permissions for select
  using (user_id = auth.uid() or has_role('admin'));
-- Écriture : réservée aux administrateurs ; on ne peut pas s'attribuer des droits à soi-même.
create policy team_perm_insert on team_permissions for insert
  with check (has_role('admin') and granted_by = auth.uid() and user_id <> auth.uid());
create policy team_perm_delete on team_permissions for delete
  using (has_role('admin'));

-- Journal : chaque octroi ou retrait est tracé.
create or replace function log_team_perm() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (auth.uid(),
          case tg_op when 'INSERT' then 'team.perm_granted' else 'team.perm_revoked' end,
          'team_permissions',
          coalesce(new.user_id, old.user_id)::text,
          jsonb_build_object('perm', coalesce(new.perm, old.perm)));
  return coalesce(new, old);
end $$;
create trigger trg_team_perm_log after insert or delete on team_permissions
  for each row execute function log_team_perm();
