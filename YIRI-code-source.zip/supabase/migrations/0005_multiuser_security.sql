-- YIRI — 0005 : socle multi-utilisateur (données manquantes + sécurité).
-- Principes :
--  * les droits de l'équipe viennent UNIQUEMENT des autorisations cochées (has_perm / has_any_perm) ;
--  * un propriétaire ne change jamais le statut de validation de son annonce ;
--  * la confirmation des paiements reste manuelle (aucune confirmation automatique ici) ;
--  * ce fichier est additif : 0001 à 0004 ne sont pas modifiées.

-- =====================================================================
-- 1. Aides pour les droits
-- =====================================================================
create or replace function has_any_perm(variadic ps team_perm[]) returns boolean
language sql stable security definer set search_path = public as $$
  select has_role('admin')
      or exists (select 1 from team_permissions where user_id = auth.uid() and perm = any (ps));
$$;

-- Transitions de statut d'annonce autorisées (miroir de LISTING_TRANSITIONS dans src/lib/domain.ts).
create or replace function listing_transition_ok(a listing_status, b listing_status) returns boolean
language sql immutable as $$
  select (a, b) in (
    ('brouillon','soumise'), ('brouillon','archivee'),
    ('soumise','a_corriger'), ('soumise','approuvee'), ('soumise','refusee'),
    ('a_corriger','soumise'), ('a_corriger','archivee'),
    ('approuvee','publiee'), ('approuvee','suspendue'), ('approuvee','archivee'),
    ('refusee','archivee'),
    ('publiee','suspendue'), ('publiee','expiree'), ('publiee','archivee'),
    ('suspendue','publiee'), ('suspendue','archivee'),
    ('expiree','publiee'), ('expiree','archivee')
  );
$$;

-- =====================================================================
-- 2. Nouvelles données
-- =====================================================================
-- Champs d'annonce manquants
alter table properties
  add column if not exists neighborhood text check (neighborhood is null or char_length(neighborhood) <= 120),
  add column if not exists arrival_instructions text check (arrival_instructions is null or char_length(arrival_instructions) <= 600),
  add column if not exists highlights text[] not null default '{}' check (cardinality(highlights) <= 12);

-- Contact du propriétaire (offre Visibilité) : jamais lisible par le public.
-- La révélation à un voyageur passera par une fonction serveur (migration 0006).
create table property_contacts (
  property_id uuid primary key references properties(id) on delete cascade,
  contact_name text not null check (char_length(btrim(contact_name)) between 2 and 60),
  phone text not null check (phone ~ '^[+0-9][0-9 ]{7,19}$'),
  whatsapp boolean not null default false,
  updated_at timestamptz not null default now()
);

-- Compteur de consultations du contact (une ligne par consultation, écrite par le serveur).
create table contact_views (
  id bigint generated always as identity primary key,
  property_id uuid not null references properties(id) on delete cascade,
  viewer_id uuid references profiles(id),
  viewed_at timestamptz not null default now()
);
create index contact_views_property_idx on contact_views (property_id, viewed_at);

-- Demandes de contact des propriétaires (formulaire « Poser une question » / choix d'une solution).
create table owner_leads (
  id uuid primary key default gen_random_uuid(),
  pack text not null check (pack in ('visibilite','serenite','partenariat','indecis')),
  property_kind text not null check (char_length(property_kind) between 2 and 40),
  city text not null check (char_length(btrim(city)) between 2 and 60),
  property_count int not null default 1 check (property_count between 1 and 200),
  level text not null check (level in ('autonomie','reservations','delegation')),
  name text not null check (char_length(btrim(name)) between 2 and 80),
  phone text not null check (phone ~ '^[+0-9][0-9 ]{7,19}$'),
  message text check (message is null or char_length(message) <= 600),
  consent boolean not null check (consent),
  status text not null default 'nouvelle' check (status in ('nouvelle','contactee')),
  created_by uuid default auth.uid() references profiles(id),
  created_at timestamptz not null default now()
);

-- Déclarations « J'ai payé » : un simple signalement, JAMAIS une preuve de paiement.
-- Seule l'équipe (autorisation « paiements ») confirme, côté serveur, après contrôle du montant.
create table payment_notices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references profiles(id),
  object text not null check (object in ('abonnement','reservation')),
  subscription_id uuid references subscriptions(id),
  booking_id uuid references bookings(id),
  declared_amount_xof int not null check (declared_amount_xof > 0),
  reference text check (reference is null or char_length(reference) <= 40),
  message text check (message is null or char_length(message) <= 400),
  status text not null default 'nouveau' check (status in ('nouveau','traite')),
  handled_by uuid references profiles(id),
  handled_at timestamptz,
  created_at timestamptz not null default now(),
  check (
    (object = 'abonnement'  and subscription_id is not null and booking_id is null) or
    (object = 'reservation' and booking_id is not null and subscription_id is null)
  )
);
create index payment_notices_status_idx on payment_notices (status, created_at);

-- Limitation d'abus : compteur d'événements, écrit uniquement par des fonctions serveur.
create table rate_events (
  id bigint generated always as identity primary key,
  key text not null,
  at timestamptz not null default now()
);
create index rate_events_key_idx on rate_events (key, at);

alter table property_contacts enable row level security;
alter table contact_views enable row level security;
alter table owner_leads enable row level security;
alter table payment_notices enable row level security;
alter table rate_events enable row level security; -- aucune policy : fermé aux clients

-- =====================================================================
-- 3. Limitation d'abus (formulaires ouverts)
-- =====================================================================
create or replace function enforce_rate_limit(p_key text, p_max int, p_window interval) returns void
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  delete from rate_events where at < now() - interval '2 days';
  select count(*) into n from rate_events where key = p_key and at > now() - p_window;
  if n >= p_max then
    raise exception 'Trop de demandes. Réessayez plus tard.' using errcode = 'P0001';
  end if;
  insert into rate_events (key) values (p_key);
end $$;
revoke execute on function enforce_rate_limit(text, int, interval) from public, anon, authenticated;

create or replace function throttle_owner_leads() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform enforce_rate_limit('lead:' || regexp_replace(new.phone, '\s', '', 'g'), 3, interval '1 hour');
  perform enforce_rate_limit('lead:*', 100, interval '1 hour');
  return new;
end $$;
create trigger owner_leads_throttle before insert on owner_leads
  for each row execute function throttle_owner_leads();

create or replace function throttle_applications() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform enforce_rate_limit('app:' || regexp_replace(new.contact_phone, '\s', '', 'g'), 3, interval '1 day');
  perform enforce_rate_limit('app:*', 100, interval '1 hour');
  return new;
end $$;
create trigger partnership_applications_throttle before insert on partnership_applications
  for each row execute function throttle_applications();

create or replace function throttle_campaign_leads() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform enforce_rate_limit('camp:' || regexp_replace(new.contact, '\s', '', 'g'), 3, interval '1 hour');
  perform enforce_rate_limit('camp:*', 100, interval '1 hour');
  return new;
end $$;
create trigger campaign_leads_throttle before insert on campaign_leads
  for each row execute function throttle_campaign_leads();

create or replace function throttle_payment_notices() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform enforce_rate_limit('notice:' || new.user_id::text, 10, interval '1 hour');
  return new;
end $$;
create trigger payment_notices_throttle before insert on payment_notices
  for each row execute function throttle_payment_notices();

-- =====================================================================
-- 4. Annonces : garde de validation et re-validation des modifications importantes
-- =====================================================================
-- Règles explicites (aussi résumées dans AUDIT/README) :
--  MAJEUR → l'annonce publiée repasse en « soumise » (nouvelle validation) :
--    prix, adresse privée, ville, quartier, capacité, chambres, lits, séjour minimum,
--    règles de la maison, politique d'annulation, ajout/suppression de photo, changement du contact.
--  MINEUR → reste publiée : titre, description, équipements, points forts, description du quartier,
--    instructions d'arrivée.
--  Le propriétaire ne modifie jamais : statut de validation (hors dépôt/archivage), propriétaire, offre,
--    note de l'équipe, drapeau démo. L'équipe ne valide jamais sa propre annonce.
create or replace function properties_guard() returns trigger language plpgsql as $$
declare
  me uuid := auth.uid();
  major text[] := '{}';
begin
  -- Contexte serveur (migrations, clé de service, fonctions SECURITY DEFINER) : pas de garde ici.
  if current_user not in ('authenticated', 'anon') then
    return new;
  end if;

  if tg_op = 'INSERT' then
    if new.owner_id is distinct from me then
      raise exception 'Une annonce ne peut être créée que pour son propre compte.';
    end if;
    if new.offer <> 'annonce' or new.is_demo or new.review_note is not null or new.status not in ('brouillon','soumise') then
      raise exception 'Création refusée : offre, statut ou champs réservés à l''équipe.';
    end if;
    return new;
  end if;

  new.updated_at := now();

  if old.owner_id = me then
    -- Règles du propriétaire (valables même si la personne est aussi membre de l'équipe : pas d'auto-validation).
    if new.id <> old.id or new.owner_id <> old.owner_id or new.offer <> old.offer
       or new.is_demo <> old.is_demo or new.created_at <> old.created_at
       or new.review_note is distinct from old.review_note then
      raise exception 'Champ réservé à l''équipe YIRI.';
    end if;

    if new.status <> old.status then
      if not (
        (old.status in ('brouillon','a_corriger') and new.status = 'soumise') or
        (old.status in ('brouillon','a_corriger','approuvee','publiee','suspendue','refusee') and new.status = 'archivee')
      ) then
        raise exception 'Le statut de validation ne peut pas être modifié par le propriétaire.';
      end if;
    end if;

    if old.status in ('refusee','suspendue','expiree','archivee')
       and (to_jsonb(new) - 'status' - 'updated_at') <> (to_jsonb(old) - 'status' - 'updated_at') then
      raise exception 'Cette annonce n''est plus modifiable dans son état actuel.';
    end if;

    if new.nightly_price_xof <> old.nightly_price_xof then major := array_append(major, 'prix'); end if;
    if new.private_address is distinct from old.private_address or new.city <> old.city
       or new.district <> old.district then major := array_append(major, 'adresse'); end if;
    if new.capacity <> old.capacity or new.bedrooms <> old.bedrooms or new.beds <> old.beds
       or new.min_nights <> old.min_nights then major := array_append(major, 'capacité et caractéristiques'); end if;
    if new.house_rules is distinct from old.house_rules
       or new.cancellation_policy is distinct from old.cancellation_policy then major := array_append(major, 'règles et annulation'); end if;

    if new.status = old.status and old.status in ('publiee','approuvee') and cardinality(major) > 0 then
      new.status := 'soumise';
      new.review_note := 'Modification à valider : ' || array_to_string(major, ', ');
    end if;
    return new;
  end if;

  if has_perm('validation') then
    -- L'équipe change le statut et la note, pas le contenu de l'annonce.
    if (to_jsonb(new) - 'status' - 'review_note' - 'updated_at') <> (to_jsonb(old) - 'status' - 'review_note' - 'updated_at') then
      raise exception 'L''équipe ne modifie pas le contenu d''une annonce : demandez une correction au propriétaire.';
    end if;
    if new.status <> old.status and not listing_transition_ok(old.status, new.status) then
      raise exception 'Changement de statut non autorisé (% vers %).', old.status, new.status;
    end if;
    if new.status in ('a_corriger','refusee') and new.status <> old.status
       and char_length(coalesce(btrim(new.review_note), '')) < 5 then
      raise exception 'Indiquez un motif clair pour le propriétaire.';
    end if;
    return new;
  end if;

  raise exception 'Action non autorisée.';
end $$;

create trigger properties_guard_trg before insert or update on properties
  for each row execute function properties_guard();

-- Remise en validation quand les photos ou le contact d'une annonce publiée sont modifiés par le propriétaire.
create or replace function flag_major_change(p_property uuid, p_what text) returns void
language plpgsql security definer set search_path = public as $$
begin
  update properties
     set status = 'soumise', review_note = 'Modification à valider : ' || p_what
   where id = p_property and status in ('publiee','approuvee') and owner_id = auth.uid();
end $$;
revoke execute on function flag_major_change(uuid, text) from public, anon, authenticated;

create or replace function photos_flag_major() returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform flag_major_change(coalesce(new.property_id, old.property_id), 'photos');
  return coalesce(new, old);
end $$;
create trigger property_photos_flag after insert or delete on property_photos
  for each row execute function photos_flag_major();

create or replace function contacts_flag_major() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and new.phone = old.phone and new.contact_name = old.contact_name then
    return new;
  end if;
  perform flag_major_change(coalesce(new.property_id, old.property_id), 'contact');
  return coalesce(new, old);
end $$;
create trigger property_contacts_flag after insert or update or delete on property_contacts
  for each row execute function contacts_flag_major();

-- Seule l'équipe (autorisation « validation ») vérifie les droits d'une photo ; jamais le propriétaire.
create or replace function photos_guard() returns trigger language plpgsql as $$
begin
  if current_user not in ('authenticated', 'anon') then return new; end if;
  if new.property_id <> old.property_id or new.storage_path <> old.storage_path then
    raise exception 'Une photo ne peut pas changer de logement ni de fichier.';
  end if;
  if new.rights_checked is distinct from old.rights_checked then
    if not has_perm('validation')
       or exists (select 1 from properties p where p.id = old.property_id and p.owner_id = auth.uid()) then
      raise exception 'La vérification des droits d''une photo est réservée à l''équipe.';
    end if;
  end if;
  return new;
end $$;
create trigger property_photos_guard before update on property_photos
  for each row execute function photos_guard();

-- Avis de paiement : seul le statut change, et seulement par l'équipe « paiements ».
create or replace function payment_notices_guard() returns trigger language plpgsql as $$
begin
  if current_user not in ('authenticated', 'anon') then return new; end if;
  if (to_jsonb(new) - 'status' - 'handled_by' - 'handled_at') <> (to_jsonb(old) - 'status' - 'handled_by' - 'handled_at') then
    raise exception 'Un avis de paiement ne se modifie pas.';
  end if;
  if old.status <> 'nouveau' or new.status <> 'traite' then
    raise exception 'Un avis ne peut passer que de « nouveau » à « traité ».';
  end if;
  new.handled_by := auth.uid();
  new.handled_at := now();
  return new;
end $$;
create trigger payment_notices_guard_trg before update on payment_notices
  for each row execute function payment_notices_guard();

-- =====================================================================
-- 5. Dates : aucun chevauchement entre dates bloquées et réservations
-- =====================================================================
create or replace function release_expired_holds(p_property uuid, p_except uuid default null) returns void
language sql security definer set search_path = public as $$
  update bookings set status = 'expiree'
   where property_id = p_property and status = 'en_attente_paiement'
     and hold_expires_at is not null and hold_expires_at < now()
     and id is distinct from p_except;
$$;
revoke execute on function release_expired_holds(uuid, uuid) from public, anon, authenticated;

create or replace function check_block_vs_booking() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform 1 from properties where id = new.property_id for update; -- sérialise avec les réservations
  perform release_expired_holds(new.property_id);
  if exists (
    select 1 from bookings b
     where b.property_id = new.property_id
       and b.status in ('en_attente_paiement','confirmee','en_cours')
       and b.stay && new.stay
  ) then
    raise exception 'Ces dates chevauchent une réservation en attente ou confirmée.' using errcode = '23P01';
  end if;
  return new;
end $$;
create trigger availability_blocks_no_overlap before insert or update of stay, property_id on availability_blocks
  for each row execute function check_block_vs_booking();

create or replace function check_booking_vs_block() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('en_attente_paiement','confirmee','en_cours') then
    perform 1 from properties where id = new.property_id for update;
    perform release_expired_holds(new.property_id, new.id);
    if exists (select 1 from availability_blocks a where a.property_id = new.property_id and a.stay && new.stay) then
      raise exception 'Ces dates sont bloquées par le propriétaire.' using errcode = '23P01';
    end if;
  end if;
  return new;
end $$;
create trigger bookings_no_block_overlap before insert or update of stay, status, property_id on bookings
  for each row execute function check_booking_vs_block();

-- Disponibilité publique : uniquement des plages de dates, sans aucune donnée personnelle.
-- Le départ (end_date) est exclu : le logement est libre ce jour-là.
create or replace function public_booked_ranges(p_property uuid)
returns table (start_date date, end_date date)
language sql stable security definer set search_path = public as $$
  select lower(b.stay), upper(b.stay)
    from bookings b
   where b.property_id = p_property
     and exists (select 1 from public_listings l where l.id = p_property)
     and (b.status in ('confirmee','en_cours')
          or (b.status = 'en_attente_paiement' and (b.hold_expires_at is null or b.hold_expires_at > now())))
  union all
  select lower(a.stay), upper(a.stay)
    from availability_blocks a
   where a.property_id = p_property
     and exists (select 1 from public_listings l where l.id = p_property)
  order by 1;
$$;
grant execute on function public_booked_ranges(uuid) to anon, authenticated;

-- Vue publique : ajoute le quartier et les points forts (l'adresse privée et le contact restent cachés).
create or replace view public_listings with (security_invoker = false) as
select p.id, p.offer, p.title, p.description, p.city, p.district, p.capacity, p.bedrooms, p.beds,
       p.nightly_price_xof, p.min_nights, p.house_rules, p.cancellation_policy,
       p.neighborhood, p.highlights
from properties p
where p.status = 'publiee'
  and p.is_demo = false
  and (
    (p.offer = 'annonce' and exists (
      select 1 from subscriptions s
      where s.property_id = p.id and s.status = 'actif' and current_date >= s.starts_at and current_date < s.ends_at))
    or (p.offer in ('gestion','partenariat') and exists (
      select 1 from management_agreements m
      where m.property_id = p.id and m.signed and m.operational_check_done))
  );
grant select on public_listings to anon, authenticated;

create or replace view public_listing_photos with (security_invoker = false) as
select ph.property_id, ph.storage_path, ph.position, ph.alt_text
  from property_photos ph
  join public_listings l on l.id = ph.property_id;
grant select on public_listing_photos to anon, authenticated;

-- =====================================================================
-- 6. Droits : les policies suivent les autorisations déléguées (has_perm)
-- =====================================================================
drop policy if exists profiles_self on profiles;
drop policy if exists owner_profiles_own on owner_profiles;
drop policy if exists properties_owner_read on properties;
drop policy if exists properties_owner_insert on properties;
drop policy if exists properties_owner_update on properties;
drop policy if exists properties_staff_update on properties;
drop policy if exists photos_owner on property_photos;
alter table amenities enable row level security;
drop policy if exists amenities_ref_read on amenities;
create policy amenities_ref_read on amenities for select to anon, authenticated using (true);
drop policy if exists amenities_owner on property_amenities;
drop policy if exists blocks_owner on availability_blocks;
drop policy if exists subs_owner_read on subscriptions;
drop policy if exists agreements_read on management_agreements;
drop policy if exists applications_insert on partnership_applications;
drop policy if exists applications_read on partnership_applications;
drop policy if exists applications_staff on partnership_applications;
drop policy if exists bookings_read on bookings;
drop policy if exists tx_staff on payment_transactions;
drop policy if exists ledger_staff on financial_ledger;
drop policy if exists expenses_read on expenses;
drop policy if exists statements_read on owner_statements;
drop policy if exists payouts_read on payouts;
drop policy if exists support_own on support_requests;
drop policy if exists audit_admin on audit_logs;
drop policy if exists leads_insert on campaign_leads;
drop policy if exists leads_staff on campaign_leads;

create policy profiles_read on profiles for select
  using (id = auth.uid() or has_any_perm('validation','reservations','paiements','demandes'));
create policy owner_profiles_read on owner_profiles for select
  using (user_id = auth.uid() or has_perm('validation'));

-- Annonces
create policy properties_read on properties for select
  using (owner_id = auth.uid() or has_any_perm('validation','reservations','paiements'));
create policy properties_owner_insert on properties for insert
  with check (owner_id = auth.uid() and has_role('proprietaire'));
create policy properties_owner_update on properties for update
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy properties_staff_update on properties for update
  using (has_perm('validation')) with check (has_perm('validation'));
-- (aucune policy de suppression : une annonce s'archive, elle ne se supprime pas depuis le navigateur)

create policy photos_read on property_photos for select
  using (exists (select 1 from properties p where p.id = property_id and (p.owner_id = auth.uid() or has_perm('validation'))));
create policy photos_owner_insert on property_photos for insert
  with check (
    rights_checked = false
    and exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid())
    and storage_path like (auth.uid()::text || '/' || property_id::text || '/%')
    and storage_path !~ '\.\.'
  );
create policy photos_owner_update on property_photos for update
  using (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()))
  with check (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));
create policy photos_staff_update on property_photos for update
  using (has_perm('validation')) with check (has_perm('validation'));
create policy photos_owner_delete on property_photos for delete
  using (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));

create policy amenities_read on property_amenities for select
  using (exists (select 1 from properties p where p.id = property_id and (p.owner_id = auth.uid() or has_perm('validation'))));
create policy amenities_owner_write on property_amenities for insert
  with check (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));
create policy amenities_owner_delete on property_amenities for delete
  using (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));

create policy blocks_read on availability_blocks for select
  using (exists (select 1 from properties p where p.id = property_id
                 and ((p.owner_id = auth.uid() and p.offer = 'annonce') or has_any_perm('validation','reservations'))));
create policy blocks_write on availability_blocks for insert
  with check (exists (select 1 from properties p where p.id = property_id
                      and ((p.owner_id = auth.uid() and p.offer = 'annonce') or has_perm('reservations'))));
create policy blocks_update on availability_blocks for update
  using (exists (select 1 from properties p where p.id = property_id
                 and ((p.owner_id = auth.uid() and p.offer = 'annonce') or has_perm('reservations'))))
  with check (exists (select 1 from properties p where p.id = property_id
                      and ((p.owner_id = auth.uid() and p.offer = 'annonce') or has_perm('reservations'))));
create policy blocks_delete on availability_blocks for delete
  using (exists (select 1 from properties p where p.id = property_id
                 and ((p.owner_id = auth.uid() and p.offer = 'annonce') or has_perm('reservations'))));

-- Contact du propriétaire : lisible par lui et par la validation, jamais par le public.
create policy contacts_read on property_contacts for select
  using (exists (select 1 from properties p where p.id = property_id and (p.owner_id = auth.uid() or has_perm('validation'))));
create policy contacts_owner_insert on property_contacts for insert
  with check (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid() and p.offer = 'annonce'));
create policy contacts_owner_update on property_contacts for update
  using (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()))
  with check (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));
create policy contacts_owner_delete on property_contacts for delete
  using (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));

-- Compteur : le propriétaire voit le nombre de consultations de ses annonces, pas qui a consulté.
create policy contact_views_read on contact_views for select
  using (exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid())
         or has_perm('validation'));
revoke all on contact_views from anon, authenticated;
grant select (id, property_id, viewed_at) on contact_views to authenticated;

-- Abonnements, contrats
create policy subs_read on subscriptions for select
  using (owner_id = auth.uid() or has_any_perm('validation','paiements'));
create policy agreements_read on management_agreements for select
  using (has_perm('validation') or exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));

-- Candidatures Partenariat : formulaire ouvert, limité, et seuls le statut/la décision sont modifiables par l'équipe.
create policy applications_insert on partnership_applications for insert
  with check (consent and status = 'recue' and decision_reason is null
              and (applicant_id is null or applicant_id = auth.uid()));
create policy applications_read on partnership_applications for select
  using (applicant_id = auth.uid() or has_perm('partenariat'));
create policy applications_staff on partnership_applications for update
  using (has_perm('partenariat')) with check (has_perm('partenariat'));
revoke update on partnership_applications from anon, authenticated;
grant update (status, decision_reason) on partnership_applications to authenticated;

-- Demandes de propriétaires
create policy owner_leads_insert on owner_leads for insert
  with check (consent and status = 'nouvelle' and (created_by is null or created_by = auth.uid()));
create policy owner_leads_read on owner_leads for select using (has_perm('demandes'));
create policy owner_leads_update on owner_leads for update
  using (has_perm('demandes')) with check (has_perm('demandes'));
revoke update on owner_leads from anon, authenticated;
grant update (status) on owner_leads to authenticated;

-- Avis de paiement
create policy payment_notices_insert on payment_notices for insert to authenticated
  with check (
    user_id = auth.uid() and status = 'nouveau' and handled_by is null and handled_at is null
    and (
      (booking_id is not null and exists (select 1 from bookings b where b.id = booking_id and b.guest_id = auth.uid()))
      or (subscription_id is not null and exists (select 1 from subscriptions s where s.id = subscription_id and s.owner_id = auth.uid()))
    )
  );
create policy payment_notices_read on payment_notices for select
  using (user_id = auth.uid() or has_perm('paiements'));
create policy payment_notices_update on payment_notices for update
  using (has_perm('paiements')) with check (has_perm('paiements'));
revoke update on payment_notices from anon, authenticated;
grant update (status) on payment_notices to authenticated;

-- Réservations et paiements
create policy bookings_read on bookings for select using (
  guest_id = auth.uid()
  or has_any_perm('reservations','paiements')
  or exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));
create policy tx_read on payment_transactions for select using (
  has_perm('paiements')
  or exists (select 1 from bookings b where b.id = booking_id and b.guest_id = auth.uid())
  or exists (select 1 from subscriptions s where s.id = subscription_id and s.owner_id = auth.uid()));
create policy ledger_read on financial_ledger for select using (has_perm('paiements'));
create policy expenses_read on expenses for select using (
  has_any_perm('validation','paiements')
  or exists (select 1 from properties p where p.id = property_id and p.owner_id = auth.uid()));
create policy statements_read on owner_statements for select using (owner_id = auth.uid() or has_perm('paiements'));
create policy payouts_read on payouts for select using (owner_id = auth.uid() or has_perm('paiements'));

create policy support_own on support_requests for all
  using (user_id = auth.uid() or has_perm('demandes'))
  with check (user_id = auth.uid() or has_perm('demandes'));
create policy audit_read on audit_logs for select using (has_perm('audit'));
create policy leads_insert on campaign_leads for insert with check (consent and status = 'nouveau');
create policy leads_read on campaign_leads for select using (has_perm('demandes'));

-- =====================================================================
-- 7. Création automatique du profil à l'inscription (Supabase Auth)
-- =====================================================================
-- Le rôle donné est toujours « voyageur » : jamais lu depuis les données saisies par l'utilisateur.
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name, email, phone)
  values (
    new.id,
    coalesce(nullif(btrim(new.raw_user_meta_data ->> 'full_name'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'Utilisateur'),
    new.email,
    nullif(btrim(new.raw_user_meta_data ->> 'phone'), '')
  )
  on conflict (id) do nothing;
  insert into user_roles (user_id, role) values (new.id, 'voyageur') on conflict do nothing;
  return new;
end $$;
revoke execute on function handle_new_user() from public, anon, authenticated;

do $$
begin
  if to_regclass('auth.users') is not null then
    drop trigger if exists on_auth_user_created on auth.users;
    create trigger on_auth_user_created after insert on auth.users
      for each row execute function public.handle_new_user();
  end if;
end $$;

-- =====================================================================
-- 8. Stockage des photos (Supabase Storage) — appliqué seulement si le schéma storage existe
-- =====================================================================
-- Fichiers rangés dans  <id propriétaire>/<id logement>/<fichier> ; bucket PRIVÉ ; images uniquement, 5 Mo max.
-- Le public ne lit que les photos de logements publiés (via liens signés) ; un propriétaire n'écrit que chez lui.
do $$
begin
  if to_regclass('storage.objects') is null then
    raise notice 'Schéma storage absent : règles de stockage non appliquées (à vérifier sur un vrai projet Supabase).';
    return;
  end if;

  insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('property-photos', 'property-photos', false, 5242880, array['image/jpeg','image/png','image/webp'])
  on conflict (id) do update
    set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

  drop policy if exists yiri_photos_read_public on storage.objects;
  drop policy if exists yiri_photos_read_owner on storage.objects;
  drop policy if exists yiri_photos_read_staff on storage.objects;
  drop policy if exists yiri_photos_insert_owner on storage.objects;
  drop policy if exists yiri_photos_update_owner on storage.objects;
  drop policy if exists yiri_photos_delete_owner on storage.objects;

  create policy yiri_photos_read_public on storage.objects for select to anon, authenticated
    using (bucket_id = 'property-photos'
           and exists (select 1 from public.public_listing_photos pp where pp.storage_path = name));
  create policy yiri_photos_read_owner on storage.objects for select to authenticated
    using (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text);
  create policy yiri_photos_read_staff on storage.objects for select to authenticated
    using (bucket_id = 'property-photos' and public.has_perm('validation'));
  create policy yiri_photos_insert_owner on storage.objects for insert to authenticated
    with check (bucket_id = 'property-photos'
                and (storage.foldername(name))[1] = auth.uid()::text
                and public.has_role('proprietaire')
                and exists (select 1 from public.properties p
                            where p.id::text = (storage.foldername(name))[2] and p.owner_id = auth.uid()));
  create policy yiri_photos_update_owner on storage.objects for update to authenticated
    using (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text)
    with check (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text);
  create policy yiri_photos_delete_owner on storage.objects for delete to authenticated
    using (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text);
end $$;
