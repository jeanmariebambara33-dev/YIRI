// Tests de bout en bout des trois écrans ajoutés par la migration 0011 :
//   * l'onglet « Réservations » de l'équipe (prochaines arrivées en tête, logements sous gestion) ;
//   * les paiements en ligne dans l'onglet « Paiements », y compris le cas « écart de montant » ;
//   * le bloc « Réservations sur mes logements » de l'espace propriétaire, avec les coordonnées
//     du voyageur MASQUÉES tant que le séjour n'est pas payé.
//
// Le serveur est remplacé par une imitation qui applique les MÊMES règles que la base :
// filtre par propriétaire, masquage avant paiement, refus si la permission manque.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const DB = {
  // Deux propriétaires. L'utilisateur connecté est « v-1 », propriétaire du logement p-1.
  // p-2 appartient à quelqu'un d'autre : il ne doit JAMAIS apparaître dans son espace.
  props: [
    { id: "p-1", owner_id: "v-1", offer: "annonce", title: "Studio Gounghin", city: "Ouagadougou", district: "Gounghin" },
    { id: "p-2", owner_id: "autre", offer: "gestion", title: "Villa Accart", city: "Bobo-Dioulasso", district: "Accart" },
  ],
  bookings: [
    // Dans 3 jours, PAYÉE : arrivée proche, coordonnées visibles chez le propriétaire.
    { id: "b-1", prop: "p-1", guest: "g-1", d1: 3, d2: 6, total: 60000, status: "confirmee", paye: true, ref: "YIRI-0001", moyen: "orange_money" },
    // Dans 2 jours, NON payée : dates bloquées, coordonnées masquées.
    { id: "b-2", prop: "p-1", guest: "g-2", d1: 2, d2: 4, total: 40000, status: "en_attente_paiement", paye: false, ref: null, moyen: null },
    // Dans 40 jours, payée : « plus tard ».
    { id: "b-3", prop: "p-1", guest: "g-3", d1: 40, d2: 43, total: 90000, status: "confirmee", paye: true, ref: "YIRI-0003", moyen: "moov" },
    // Sur le logement SOUS GESTION d'un autre propriétaire, arrivée dans 5 jours.
    { id: "b-4", prop: "p-2", guest: "g-4", d1: 5, d2: 7, total: 70000, status: "confirmee", paye: true, ref: "YIRI-0004", moyen: "orange_money" },
    // Terminée, il y a longtemps.
    { id: "b-5", prop: "p-1", guest: "g-1", d1: -30, d2: -27, total: 50000, status: "terminee", paye: true, ref: "YIRI-0005", moyen: "orange_money" },
    // Mes propres séjours en tant que VOYAGEUR : un payé (contact YIRI visible), un pas encore.
    { id: "b-6", prop: "p-2", guest: "moi", d1: 8, d2: 11, total: 80000, status: "confirmee", paye: true, ref: "YIRI-0006", moyen: "moov", tel: "70000042" },
    { id: "b-7", prop: "p-2", guest: "moi", d1: 60, d2: 62, total: 55000, status: "en_attente_paiement", paye: false, ref: null, moyen: null, tel: "70000042" },
  ],
  gens: {
    "g-1": { nom: "Awa Sawadogo", tel: "70000001", mail: "awa@test.local" },
    "g-2": { nom: "Boukary Zongo", tel: "70000002", mail: "boukary@test.local" },
    "g-3": { nom: "Clarisse Kabore", tel: "70000003", mail: "clarisse@test.local" },
    "g-4": { nom: "Daouda Ouedraogo", tel: "70000004", mail: "daouda@test.local" },
    "moi": { nom: "Moussa Compaore", tel: "70000042", mail: "moussa@test.local" },
  },
  tentatives: [
    { reference: "YIRI-0001", object: "reservation", target_id: "b-1", amount_xof: 60000, provider: "saspay", created_at: new Date().toISOString(), settled_at: new Date().toISOString(), outcome: "paye", tx_status: "reussi" },
    { reference: "YIRI-0009", object: "reservation", target_id: "b-9", amount_xof: 35000, provider: "saspay", created_at: new Date().toISOString(), settled_at: new Date().toISOString(), outcome: "ecart", tx_status: "en_attente" },
    { reference: "YIRI-0010", object: "reservation", target_id: "b-10", amount_xof: 20000, provider: "saspay", created_at: new Date().toISOString(), settled_at: null, outcome: "echec", tx_status: "echoue" },
  ],
  roles: [{ role: "voyageur" }],
  perms: [],
};
window.__db = DB;
const UID = "v-1";
const err = (code, message) => ({ data: null, error: { code, message } });
const okRes = (data) => ({ data, error: null });
const estAdmin = () => DB.roles.some((r) => r.role === "admin");
const peut = (p) => estAdmin() || DB.perms.some((x) => x.perm === p);
const PAYES = ["confirmee", "en_cours", "terminee"];

function ligne(b, pourEquipe) {
  const p = DB.props.find((x) => x.id === b.prop);
  const g = DB.gens[b.guest];
  const visible = PAYES.includes(b.status);
  const base = {
    id: b.id, property_id: p.id, title: p.title, city: p.city, district: p.district,
    offer: p.offer, sous_gestion: p.offer === "gestion" || p.offer === "partenariat",
    arrivee: J(b.d1), depart: J(b.d2), nuits: b.d2 - b.d1, guests: 2,
    total_xof: b.total, status: b.status, created_at: new Date().toISOString(),
    paye: b.paye, paye_le: b.paye ? new Date().toISOString() : null,
  };
  if (pourEquipe) {
    // L'équipe voit tout, payé ou non : c'est elle qui décroche le téléphone.
    return Object.assign(base, {
      hold_expires_at: b.status === "en_attente_paiement" ? new Date(Date.now() + 900000).toISOString() : null,
      guest_id: b.guest, guest_name: g.nom, guest_phone: g.tel, guest_email: g.mail,
      reference: b.ref, moyen: b.moyen,
    });
  }
  // Le propriétaire : masquage tant que ce n'est pas payé, exactement comme en base.
  return Object.assign(base, {
    guest_name: visible ? g.nom : null,
    guest_phone: visible ? g.tel : null,
    coordonnees_visibles: visible,
  });
}

const ORDRE = ["en_attente_paiement", "confirmee", "en_cours"];
function trier(rows) {
  return rows.slice().sort((x, y) => {
    const vx = ORDRE.includes(x.status) ? 0 : 1, vy = ORDRE.includes(y.status) ? 0 : 1;
    if (vx !== vy) return vx - vy;
    if (vx === 0) return x.arrivee < y.arrivee ? -1 : x.arrivee > y.arrivee ? 1 : 0;
    return 0;
  });
}

function builder(table) {
  const run = () => {
    if (table === "public_listings") return okRes([]);
    if (table === "public_listing_photos") return okRes([]);
    if (table === "properties") return okRes(DB.props.filter((p) => p.owner_id === UID).map((p) => ({
      id: p.id, title: p.title, description: "desc", city: p.city, district: p.district,
      private_address: "adresse", capacity: 2, bedrooms: 1, beds: 1, nightly_price_xof: 20000,
      min_nights: 1, status: "publiee", review_note: null, created_at: new Date().toISOString(),
    })));
    if (table === "payment_notices") {
      if (!peut("paiements")) return err("42501", "permission denied for table payment_notices");
      return okRes([]);
    }
    if (table === "bookings") return okRes(DB.bookings
      .filter((b) => b.guest === "moi")
      .map((b) => ({ id: b.id, property_id: b.prop, stay: "[" + J(b.d1) + "," + J(b.d2) + ")",
                     guests: 2, nightly_price_xof: 20000, accommodation_xof: b.total, total_xof: b.total,
                     status: b.status, hold_expires_at: null, created_at: new Date().toISOString(),
                     guest_phone: b.tel || null })));
    if (table === "profiles") return okRes([{ full_name: "Moussa Compaore", phone: null }]);
    if (table === "user_roles") return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    if (table === "team_permissions") return okRes(DB.perms.map((x) => ({ user_id: UID, perm: x.perm })));
    if (table === "audit_logs") return okRes([]);
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; }, insert() { return self; }, upsert() { return self; }, update() { return self; },
    delete() { return self; }, eq() { return self; }, in() { return self; },
    order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: "jeton", user: { id: UID, email: "moussa@test.local" } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem("fs") ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    if (fn === "public_booked_ranges") return Promise.resolve(okRes([]));
    if (fn === "my_owner_identity") return Promise.resolve(okRes([{ state: "verifie", id_type: "cnib", id_number_masked: "****1234", files_sent: 0, decision_note: null, files_deleted: true }]));

    if (fn === "bookings_queue") {
      if (!peut("reservations") && !peut("paiements")) {
        return Promise.resolve(err("42501", "Action réservée à l'équipe habilitée (réservations)."));
      }
      return Promise.resolve(okRes(trier(DB.bookings.map((b) => ligne(b, true)))));
    }

    if (fn === "owner_bookings") {
      const miens = DB.bookings.filter((b) => (DB.props.find((p) => p.id === b.prop) || {}).owner_id === UID);
      return Promise.resolve(okRes(trier(miens.map((b) => ligne(b, false)))));
    }

    if (fn === "payment_attempts_recent") {
      if (!peut("paiements")) return Promise.resolve(err("42501", "Action réservée à l'équipe habilitée (paiements)."));
      return Promise.resolve(okRes(DB.tentatives.slice()));
    }

    if (fn === "my_notifications") return Promise.resolve(okRes([]));
    if (fn === "identity_queue" || fn === "identity_files_pending") return Promise.resolve(okRes([]));
    if (fn === "refunds_queue") return Promise.resolve(okRes([]));
    if (fn === "my_refunds") return Promise.resolve(okRes([]));
    if (fn === "refund_quote") return Promise.resolve(okRes([{ gross_xof: 80000, rate_pct: 100, fees_xof: 0, net_xof: 80000, tier: "loin", days_before: 8, cancellable: true, reason: null }]));
    if (fn === "refund_rules_public") return Promise.resolve(okRes([{ far_days: 7, far_pct: 100, mid_days: 2, mid_pct: 50, near_pct: 0, started_pct: 0 }]));
    return Promise.resolve(okRes(null));
  },
  storage: { from() { return {
    async createSignedUrl() { return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1400 } });
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
// Un rechargement rejouerait addInitScript et remettrait la fausse base à zéro :
// après le premier chargement, on navigue uniquement par le routeur de l'application.
const aller = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(700); };
const rafraichir = async (h) => { await aller("#accueil"); await aller(h); };
// Les rôles et autorisations sont lus à la connexion : les changer exige de se reconnecter.
const reconnexion = async () => {
  await aller("#compte");
  await p.getByRole("button", { name: "Se déconnecter" }).click();
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "moussa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(800);
};
// Les montants sont écrits avec des espaces insécables : on les ramène à des espaces
// ordinaires avant toute recherche de texte, sinon /40 000/ ne trouve rien.
const nb = (s) => s.replace(/[\u00a0\u202f\u2009]/g, " ");

await p.goto(URL + "#compte");
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "moussa@test.local");
await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(800);
ok("la connexion aboutit", !/Se connecter pour/.test(await texte()));

// =====================================================================
// 1. Espace propriétaire : je vois les réservations sur MES logements
// =====================================================================
await aller("#espace");
await p.waitForSelector("h1");
let t = nb(await texte());
ok("le bloc des réservations apparaît dans l'espace propriétaire", /Réservations sur mes logements/.test(t));
ok("la réservation payée de mon logement est là", /Awa Sawadogo/.test(t));
ok("son téléphone aussi, puisque le séjour est payé", /70000001/.test(t));
ok("AVANT paiement, le nom du voyageur n'apparaît PAS", !/Boukary Zongo/.test(t));
ok("ni son téléphone", !/70000002/.test(t));
ok("et la raison est expliquée, pas laissée vide",
  /coordonnées du voyageur apparaîtront ici dès que le séjour sera payé/.test(t));
ok("le logement d'un AUTRE propriétaire n'apparaît jamais", !/Villa Accart/.test(t));
ok("ni le voyageur de ce logement", !/Daouda Ouedraogo/.test(t));
ok("le montant du séjour non payé est tout de même affiché", /40 000/.test(t));
ok("l'historique est replié, pas mélangé aux arrivées", /Historique \(1\)/.test(t));
ok("le séjour terminé n'est donc pas visible d'emblée", !/50 000/.test(t));

// Le voyageur non payé étant anonyme à l'écran, on vérifie l'ordre sur les montants,
// qui identifient chaque séjour de façon unique : 40 000 (2 j), 60 000 (3 j), 90 000 (40 j).
const ordre = await p.evaluate(() => {
  const txt = document.body.innerText.replace(/[\u00a0\u202f\u2009]/g, " ");
  return [txt.indexOf("40 000"), txt.indexOf("60 000"), txt.indexOf("90 000")];
});
ok("les prochaines arrivées sont en tête, la plus lointaine en dernier",
  ordre.every((x) => x >= 0) && ordre[0] < ordre[1] && ordre[1] < ordre[2]);

await p.locator("summary", { hasText: "Historique" }).click();
await p.waitForTimeout(300);
t = nb(await texte());
ok("l'historique s'ouvre et montre le séjour terminé", /50 000/.test(t));

// =====================================================================
// 2. L'équipe sans la bonne autorisation ne voit pas l'onglet
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "validation" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
t = await texte();
ok("avec la seule autorisation « validation », l'onglet Réservations est absent",
  !/Réservations/.test(t));
ok("et l'onglet Pièces d'identité est bien là", /Pièces d'identité/.test(t));

// =====================================================================
// 3. L'équipe « réservations » : la file, prochaines arrivées en tête
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "reservations" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
await p.getByRole("button", { name: "Réservations" }).click();
await p.waitForTimeout(700);
t = nb(await texte());
ok("l'onglet Réservations s'ouvre", /Arrivées dans les 7 jours/.test(t));
ok("il annonce les deux arrivées proches", /Arrivées dans les 7 jours \(2\)/.test(t));
ok("l'équipe voit les logements de TOUS les propriétaires", /Villa Accart/.test(t));
ok("le logement sous gestion est signalé comme tel", /Sous gestion/.test(t));
ok("et l'alerte dit que c'est YIRI qui accueille",
  /1 arrivée dans les 7 jours sur un logement sous gestion/.test(t));
ok("l'équipe voit le téléphone même avant paiement", /70000002/.test(t));
ok("le moyen de paiement est affiché", /orange_money/.test(t));
ok("la référence du prestataire est affichée", /YIRI-0001/.test(t));
ok("un séjour non payé est annoncé comme tel", /pas encore reçu/.test(t));
ok("et la libération automatique des dates est expliquée",
  /dates sont bloquées jusqu'au .* puis libérées automatiquement/.test(t));
ok("les séjours non payés ont leur propre section", /En attente de paiement \(2\)/.test(t));
ok("et l'urgence d'un impayé qui arrive bientôt est dite",
  /1 de ces séjours commence dans moins de 7 jours/.test(t));
ok("la section « plus tard » existe", /Plus tard \(2\)/.test(t));
ok("et la section des réservations closes aussi", /Terminées, annulées et expirées \(1\)/.test(t));

const ordreEquipe = await p.evaluate(() => {
  const txt = document.body.innerText;
  return { awa: txt.indexOf("Awa"), daouda: txt.indexOf("Daouda"),
           boukary: txt.indexOf("Boukary"), clarisse: txt.indexOf("Clarisse") };
});
ok("dans les arrivées proches, la plus proche d'abord : 3 j puis 5 j",
  ordreEquipe.awa >= 0 && ordreEquipe.daouda > ordreEquipe.awa);
ok("l'impayé vient après les arrivées proches, dans sa propre section",
  ordreEquipe.boukary > ordreEquipe.daouda);
ok("et le séjour lointain en dernier", ordreEquipe.clarisse > ordreEquipe.boukary);

ok("sans l'autorisation « paiements », l'onglet Paiements reste fermé", !/Derniers traités/.test(t));

// =====================================================================
// 4. L'équipe « paiements » : les paiements en ligne deviennent visibles
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "paiements" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
ok("l'autorisation « paiements » ouvre aussi l'onglet Réservations",
  /Réservations/.test(await texte()));
await p.getByRole("button", { name: "Paiements", exact: true }).click();
await p.waitForTimeout(700);
t = nb(await texte());
ok("la section des paiements en ligne apparaît", /Paiements en ligne/.test(t));
ok("un paiement réussi est listé", /YIRI-0001/.test(t));
ok("un paiement échoué aussi", /YIRI-0010/.test(t));
ok("l'écart de montant est signalé en haut", /1 paiement en ligne avec un écart de montant/.test(t));
ok("et expliqué sur la ligne concernée",
  /Le montant encaissé ne correspond pas à celui calculé par la base/.test(t));
ok("il est dit clairement que rien n'a été encaissé", /Rien n'a été validé/.test(t));
ok("l'écran précise qu'on ne peut rien valider à la main",
  /Personne ne peut le valider depuis cet écran/.test(t));

// Aucun bouton ne doit permettre de « confirmer » un paiement en ligne.
const boutonsEcart = await p.locator("button", { hasText: /Confirmer/ }).count();
ok("aucun bouton de confirmation n'est proposé sur un paiement en ligne", boutonsEcart === 0);

// =====================================================================
// 5. Un administrateur voit tout
// =====================================================================
await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }, { role: "admin" }]; window.__db.perms = []; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
await p.getByRole("button", { name: "Réservations" }).click();
await p.waitForTimeout(700);
t = nb(await texte());
ok("l'administrateur accède à la file sans autorisation nominative", /Arrivées dans les 7 jours/.test(t));

// =====================================================================
// 6. Un refus du serveur est affiché, pas avalé
// =====================================================================
await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }]; window.__db.perms = [{ perm: "reservations" }]; });
await reconnexion();
await p.evaluate(() => {
  // On simule un serveur qui refuse APRÈS l'affichage de l'onglet : l'interface ne doit pas
  // rester sur « Chargement… » ni afficher une liste vide trompeuse.
  window.__db.perms = [];
});
await rafraichir("#equipe");
await p.getByRole("button", { name: "Réservations" }).click();
await p.waitForTimeout(700);
t = await texte();
ok("un refus du serveur est montré à l'écran", /Action réservée à l'équipe habilitée/.test(t));
ok("et l'écran ne reste pas bloqué sur « Chargement »", !/^Chargement…$/m.test(t));

// =====================================================================
// 7. Le voyageur qui a payé peut enfin joindre YIRI pour les clés
// =====================================================================
await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }]; window.__db.perms = []; });
await reconnexion();
await aller("#mes-sejours");
await p.waitForSelector("h1");
t = nb(await texte());
ok("le séjour payé propose d'écrire à YIRI", /Écrire à YIRI sur WhatsApp/.test(t));
ok("et explique que c'est pour les clés", /Votre séjour est payé. Pour les clés, écrivez-nous/.test(t));
ok("le numéro que le voyageur a donné lui est rappelé", /70000042/.test(t));
ok("un numéro d'appel est aussi proposé", /Appeler le \+226/.test(t));

// Un seul bouton porte un message pré-rempli : celui du séjour payé. Le pied de page du site
// affiche DÉJÀ un lien WhatsApp nu sur toutes les pages, et ce n'est pas ce qu'on teste ici.
const liens = await p.evaluate(() => Array.from(document.querySelectorAll("a[href*='wa.me']"))
  .map((a) => a.getAttribute("href")));
const prerempli = liens.filter((h) => h.includes("?text="));
ok("un seul lien WhatsApp pré-rempli, celui du séjour payé", prerempli.length === 1);
ok("il pointe vers le numéro YIRI", prerempli[0].includes("22606443315"));
ok("le message est pré-rempli avec les dates du séjour",
  decodeURIComponent(prerempli[0]).includes("ma réservation du "));
ok("il s'ouvre dans un nouvel onglet, sans fuite de référent",
  await p.evaluate(() => { const a = document.querySelector("a[href*='?text=']");
    return a.getAttribute("target") === "_blank" && (a.getAttribute("rel") || "").includes("noopener"); }));

// Le séjour NON payé ne doit rien proposer : c'est là qu'est la distinction.
const cartes = await p.evaluate(() => Array.from(document.querySelectorAll("a[href*='?text=']"))
  .map((a) => a.closest("div.rounded-2xl")?.innerText || ""));
ok("le séjour en attente de paiement n'affiche aucun bloc « clés »",
  cartes.every((c) => !/En attente de paiement/.test(c)));
ok("le bloc « clés » n'apparaît qu'une fois, pour le séjour confirmé",
  (nb(await texte()).match(/Pour les clés, écrivez-nous/g) || []).length === 1);

// La fiche du logement ne doit pas proposer d'écrire à YIRI pour ce logement-là.
await aller("#offre-p-2");
await p.waitForTimeout(700);
t = nb(await texte());
ok("la fiche du logement ne propose pas d'écrire à YIRI pour les clés",
  !/Pour les clés, écrivez-nous/.test(t));
ok("et ne contient aucun lien WhatsApp pré-rempli",
  await p.evaluate(() => document.querySelectorAll("a[href*='?text=']").length === 0));

// =====================================================================
// 8. L'équipe joint le voyageur en un geste
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "reservations" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
await p.getByRole("button", { name: "Réservations" }).click();
await p.waitForTimeout(700);
const contacts = await p.evaluate(() => ({
  wa: Array.from(document.querySelectorAll("a[href*='wa.me']")).map((a) => a.getAttribute("href")),
  tel: Array.from(document.querySelectorAll("a[href^='tel:']")).map((a) => a.getAttribute("href")),
}));
ok("chaque réservation offre un lien WhatsApp vers le voyageur", contacts.wa.length >= 4);
ok("le lien porte le numéro du voyageur",
  contacts.wa.some((h) => h.includes("70000002")) && contacts.wa.some((h) => h.includes("70000001")));
ok("un lien d'appel direct est aussi proposé", contacts.tel.some((h) => h.includes("70000001")));

ok("aucune erreur JavaScript pendant tout le parcours", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DE RÉSERVATIONS PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
