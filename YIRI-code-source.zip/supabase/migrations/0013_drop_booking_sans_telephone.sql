-- YIRI — 0013 : fermer la réservation sans téléphone.
--
-- La 0012 avait gardé exprès l'ancienne version de create_booking à quatre arguments, parce que
-- le site alors en ligne l'appelait encore : la retirer aurait cassé le bouton « Réserver » en
-- production entre l'exécution de la migration et le redéploiement.
--
-- Ce n'est plus le cas : le site déployé appelle la version à cinq arguments, et l'ancien
-- déploiement n'existe plus. On peut donc fermer cette porte, et le téléphone devient
-- obligatoire au niveau de la BASE, pas seulement de l'interface.
--
-- Après ce fichier, une réservation sans numéro est impossible, quel que soit le client utilisé.

-- =====================================================================
-- 0. Garde : ne rien casser si la 0012 n'est pas là
-- =====================================================================
-- Sans ce contrôle, supprimer l'ancienne version alors que la nouvelle n'existe pas rendrait
-- toute réservation impossible. On vérifie donc AVANT de supprimer.
do $$
begin
  if to_regprocedure('public.create_booking(uuid,date,date,int,text)') is null then
    raise exception 'La migration 0012 n''est pas appliquée : la version avec téléphone n''existe pas. Appliquez 0012 d''abord. Rien n''a été modifié.';
  end if;
end $$;

drop function if exists create_booking(uuid, date, date, int);
