// Dates au format ISO "AAAA-MM-JJ". Fuseau de lancement : Africa/Ouagadougou (UTC+0).
// Une nuitée = une date d'arrivée incluse, date de départ exclue (intervalle semi-ouvert).

export type ISODate = string;

const RE = /^\d{4}-\d{2}-\d{2}$/;

export function parseISODate(d: ISODate): number {
  if (!RE.test(d)) throw new Error(`date invalide : ${d}`);
  const t = Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10));
  if (new Date(t).toISOString().slice(0, 10) !== d) throw new Error(`date inexistante : ${d}`);
  return t;
}

export function nightsBetween(checkIn: ISODate, checkOut: ISODate): number {
  return Math.round((parseISODate(checkOut) - parseISODate(checkIn)) / 86_400_000);
}

export function addDays(d: ISODate, days: number): ISODate {
  return new Date(parseISODate(d) + days * 86_400_000).toISOString().slice(0, 10);
}

/** Ajoute des mois calendaires ; le jour est ramené au dernier jour du mois si nécessaire (31/01 + 1 mois = 28 ou 29/02). */
export function addMonths(d: ISODate, months: number): ISODate {
  const y = +d.slice(0, 4);
  const m = +d.slice(5, 7) - 1 + months;
  const day = +d.slice(8, 10);
  const target = new Date(Date.UTC(y, m, 1));
  const last = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(day, last));
  return target.toISOString().slice(0, 10);
}

/** Chevauchement de deux séjours [a, b[ et [c, d[ : un départ le jour d'une arrivée n'est pas un conflit. */
export function rangesOverlap(aStart: ISODate, aEnd: ISODate, bStart: ISODate, bEnd: ISODate): boolean {
  return parseISODate(aStart) < parseISODate(bEnd) && parseISODate(bStart) < parseISODate(aEnd);
}

export function todayISO(): ISODate {
  return new Date().toISOString().slice(0, 10);
}

const MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
export function formatDateFR(d: ISODate): string {
  return `${+d.slice(8, 10)} ${MOIS[+d.slice(5, 7) - 1]} ${d.slice(0, 4)}`;
}
