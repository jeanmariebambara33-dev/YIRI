import * as React from "react";
import { PLACES_SORTED, OTHER_PLACE } from "./data/cities";
import { Field, inputCls } from "./ui";

/** Choix d'une localité du Burkina Faso : liste + saisie libre pour toute autre localité. */
export function CityField({ id, value, onChange, label = "Ville / localité" }: { id: string; value: string; onChange: (v: string) => void; label?: string }) {
  const known = PLACES_SORTED.includes(value);
  const [other, setOther] = React.useState(!known && value !== "");
  return (
    <Field label={label} htmlFor={id}>
      <div className="flex flex-col gap-2">
        <select id={id} className={inputCls} value={other ? OTHER_PLACE : value}
          onChange={(e) => { if (e.target.value === OTHER_PLACE) { setOther(true); onChange(""); } else { setOther(false); onChange(e.target.value); } }}>
          {PLACES_SORTED.map((c) => <option key={c}>{c}</option>)}
          <option>{OTHER_PLACE}</option>
        </select>
        {other && <input id={`${id}-other`} className={inputCls} placeholder="Nom de la localité" maxLength={60} value={value} onChange={(e) => onChange(e.target.value)} />}
      </div>
    </Field>
  );
}
