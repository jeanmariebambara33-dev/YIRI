// Le générateur de clés produit-il des clés UTILISABLES par la fonction d'envoi ?
//
// Un générateur qui affiche deux belles chaînes inutilisables ferait perdre une soirée pour rien :
// on s'en apercevrait seulement au premier envoi, en production. Ce test ouvre donc le vrai
// fichier dans un vrai navigateur, clique sur le vrai bouton, récupère les clés affichées, et
// les donne à la vraie fonction d'envoi pour signer un jeton VAPID.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
import { webcrypto } from "node:crypto";

globalThis.Deno = { env: { get: () => undefined }, serve: () => {} };
const { importerCleSignature, enteteVapid, b64urlVersOctets } = await import("../supabase/functions/push-envoyer/index.ts");

let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ permissions: ["clipboard-read", "clipboard-write"] });
// Coupé du réseau : le fichier doit fonctionner hors ligne, c'est sa raison d'être.
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));

await p.goto("file:///home/claude/yiri/outils/cles-vapid.html");
await p.waitForSelector("h1");

ok("rien n'est affiché avant le clic", await p.locator("#sortie").isHidden());
await p.getByRole("button", { name: "Fabriquer mes clés" }).click();
await p.waitForTimeout(500);
ok("les clés apparaissent après le clic", await p.locator("#sortie").isVisible());

const pub = (await p.locator("#pub").innerText()).trim();
const priv = (await p.locator("#priv").innerText()).trim();

ok("la clé publique fait 65 octets non compressés", b64urlVersOctets(pub).length === 65 && b64urlVersOctets(pub)[0] === 4);
ok("la clé privée fait 32 octets", b64urlVersOctets(priv).length === 32);
ok("les deux sont en base64url, sans caractère à échapper", !/[+/=]/.test(pub + priv));
ok("la clé publique est bien celle que les navigateurs attendent (87 caractères)", pub.length === 87);

// Le vrai test : ces clés signent-elles un jeton que le service de notification acceptera ?
let cle = null;
try { cle = await importerCleSignature(pub, priv); } catch (e) { console.log("   import :", e.message); }
ok("la fonction d'envoi accepte ces clés", cle !== null);

let verifiee = false;
if (cle) {
  const entete = await enteteVapid("https://fcm.googleapis.com/fcm/send/x", pub, cle, "https://yiri.bf", 1760000000000);
  const jeton = entete.slice("vapid t=".length).split(",")[0].trim();
  const [h, c, s] = jeton.split(".");
  // On vérifie la signature avec la clé PUBLIQUE affichée : c'est exactement ce que fera Google.
  const pubImportee = await webcrypto.subtle.importKey(
    "raw", b64urlVersOctets(pub), { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"],
  );
  verifiee = await webcrypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" }, pubImportee,
    b64urlVersOctets(s), new TextEncoder().encode(`${h}.${c}`),
  );
}
ok("et le jeton signé est vérifiable avec la clé publique affichée — les deux clés vont bien ensemble", verifiee);

// Deux fabrications doivent donner deux paires différentes.
await p.getByRole("button", { name: /Refabriquer/ }).click();
await p.waitForTimeout(400);
ok("refabriquer donne une autre paire", (await p.locator("#pub").innerText()).trim() !== pub);

// Rien ne doit sortir de la machine, et rien ne doit rester.
const html = await p.content();
ok("la clé privée n'est écrite dans aucun stockage",
  await p.evaluate(() => {
    try { return localStorage.length === 0 && sessionStorage.length === 0; } catch { return true; }
  }));
ok("le fichier ne charge aucune ressource extérieure", !/https?:\/\/(?!www\.w3\.org)/.test(html.replace(/https:\/\/yiri\.bf/g, "")));
// innerText rend le texte TEL QU'IL S'AFFICHE : l'étiquette est en capitales par la feuille
// de style, d'où la comparaison insensible à la casse.
ok("il est dit clairement laquelle ne doit jamais être montrée",
  /à ne montrer à personne/i.test(await p.locator("body").innerText()));
const corpsTexte = await p.locator("body").innerText();
ok("et où va chacune des deux", /VAPID_PRIVATE_KEY/.test(corpsTexte));
// La clé publique ne doit plus être annoncée comme un secret à coller : c'était la source de
// confusion — elle n'a qu'UNE destination, l'éditeur SQL.
ok("la clé publique n'est plus présentée comme un secret à coller",
  !/VAPID_PUBLIC_KEY/.test(corpsTexte));
ok("sa destination unique est nommée", /SQL Editor/.test(corpsTexte));
ok("aucune erreur JavaScript", errs.length === 0);

await b.close();
console.log(fails === 0 ? "\nLE GENERATEUR DE CLES PRODUIT DES CLES UTILISABLES" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
