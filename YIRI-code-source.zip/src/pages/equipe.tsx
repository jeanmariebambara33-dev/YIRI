import * as React from "react";
import { Button, Field, inputCls, Pill, Money } from "../ui";
import { useSession } from "../session";
import * as api from "../lib/api";
import type { QueueEntry, OpenedIdentity, TeamListing, Notice, Member, Perm } from "../lib/api";
import { AlertesAppareil } from "../push";

// Tableau de bord de l'ÉQUIPE YIRI, relié à la vraie base.
// Règle : l'interface ne décide de rien. Chaque bouton appelle une fonction serveur qui revérifie
// l'autorisation (has_perm) et refuse si elle manque. Masquer un onglet n'est qu'un confort d'affichage.

type Tab = "identites" | "annonces" | "reservations" | "abonnements" | "demandes" | "paiements" | "remboursements" | "nettoyage" | "revenus" | "signalements" | "journal" | "equipe";

function Alert({ tone, children }: { tone: "bad" | "good" | "warn"; children: React.ReactNode }) {
  const cls = tone === "bad" ? "border-danger/40 bg-danger/10 text-danger"
    : tone === "good" ? "border-good/40 bg-good/10 text-good" : "border-warn/40 bg-warn/10 text-warn";
  return <p role={tone === "bad" ? "alert" : "status"} className={`rounded-xl border px-3.5 py-2.5 text-sm font-medium ${cls}`}>{children}</p>;
}

function Box({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border border-line bg-surface p-4">{children}</div>;
}

function useAsync<T>(fn: () => Promise<T>, deps: React.DependencyList) {
  const [data, setData] = React.useState<T | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    let alive = true;
    fn().then((d) => { if (alive) { setData(d); setError(null); } })
        .catch((e) => { if (alive) setError(e instanceof Error ? e.message : "Lecture impossible."); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, error, reload: () => setTick((t) => t + 1) };
}

// ---------------------------------------------------------------------------
// 1. Pièces d'identité
// ---------------------------------------------------------------------------
function IdentityPhoto({ path }: { path: string }) {
  const [url, setUrl] = React.useState<string | null>(null);
  const [failed, setFailed] = React.useState(false);
  React.useEffect(() => {
    let alive = true;
    api.identityFileUrl(path).then((u) => { if (alive) { setUrl(u); setFailed(!u); } }).catch(() => { if (alive) setFailed(true); });
    return () => { alive = false; };
  }, [path]);
  const name = path.split("/").pop() ?? "";
  if (failed) return <div className="grid aspect-3/2 place-items-center rounded-xl bg-sunk text-xs text-muted">{name} : aperçu indisponible</div>;
  if (!url) return <div className="aspect-3/2 animate-pulse rounded-xl bg-sunk" />;
  return <figure><img src={url} alt={name} className="aspect-3/2 w-full rounded-xl object-contain bg-sunk" /><figcaption className="mt-1 text-xs text-muted">{name}</figcaption></figure>;
}

function IdentityReview({ entry, onDone }: { entry: QueueEntry; onDone: () => void }) {
  const [opened, setOpened] = React.useState<OpenedIdentity | null>(null);
  const [paths, setPaths] = React.useState<string[]>([]);
  const [note, setNote] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const guard = async (fn: () => Promise<void>) => {
    setBusy(true); setError(null);
    try { await fn(); } catch (e) { setError(e instanceof Error ? e.message : "Opération impossible."); }
    finally { setBusy(false); }
  };

  const open = () => void guard(async () => {
    const o = await api.openIdentity(entry.user_id);
    setOpened(o);
    setPaths(await api.identityFiles(entry.user_id));
  });

  return (
    <Box>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{entry.full_name}</p>
          <p className="truncate text-sm text-muted">{entry.email} · {entry.id_type} · {entry.files_sent} document(s)</p>
          <p className="text-xs text-muted">Envoyé le {new Date(entry.submitted_at).toLocaleDateString("fr-FR")}</p>
        </div>
        <Pill tone={entry.state === "a_renvoyer" ? "warn" : "info"}>{entry.state === "a_renvoyer" ? "À renvoyer" : "En attente"}</Pill>
      </div>

      {error && <div className="mt-3"><Alert tone="bad">{error}</Alert></div>}

      {!opened ? (
        <div className="mt-3 flex flex-col gap-2">
          <Button variant="secondary" onClick={open} disabled={busy}>Ouvrir le dossier</Button>
          <p className="text-xs text-muted">L'ouverture est enregistrée au journal, avec votre nom et l'heure. Elle donne 15 minutes pour consulter les documents.</p>
        </div>
      ) : (
        <div className="mt-4 flex flex-col gap-4">
          <div className="rounded-xl bg-sunk px-3.5 py-2.5 text-sm">
            <span className="text-muted">Numéro de la pièce : </span>
            <span className="font-mono font-semibold text-ink">{opened.id_number}</span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {paths.map((p) => <IdentityPhoto key={p} path={p} />)}
            {paths.length === 0 && <p className="text-sm text-muted">Aucun document trouvé.</p>}
          </div>
          <Field label="Motif, si vous refusez ou demandez un renvoi" htmlFor={`note-${entry.user_id}`}>
            <input id={`note-${entry.user_id}`} className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Photo illisible, document expiré…" />
          </Field>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => void guard(async () => { await api.grantOwner(entry.user_id); onDone(); })} disabled={busy}>
              Valider et accorder le rôle propriétaire
            </Button>
            <Button variant="secondary" onClick={() => void guard(async () => { await api.rejectIdentity(entry.user_id, note, true); onDone(); })} disabled={busy}>
              Demander un nouveau document
            </Button>
            <Button variant="danger" onClick={() => void guard(async () => { await api.rejectIdentity(entry.user_id, note, false); onDone(); })} disabled={busy}>
              Refuser
            </Button>
          </div>
          <p className="text-xs text-muted">Après votre décision, les images devront être supprimées. L'onglet « Nettoyage » liste ce qui reste.</p>
        </div>
      )}
    </Box>
  );
}

function IdentitiesTab() {
  const { data, error, reload } = useAsync(() => api.identityQueue(), []);
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;
  if (data.length === 0) return <p className="text-muted">Aucune pièce d'identité en attente.</p>;
  return <div className="flex flex-col gap-3">{data.map((e) => <IdentityReview key={e.user_id} entry={e} onDone={reload} />)}</div>;
}

// ---------------------------------------------------------------------------
// 2. Annonces
// ---------------------------------------------------------------------------
const LABEL: Record<string, string> = {
  brouillon: "Brouillon", soumise: "À examiner", a_corriger: "À corriger", approuvee: "Approuvée",
  publiee: "En ligne", refusee: "Refusée", suspendue: "Suspendue", expiree: "Expirée", archivee: "Archivée",
};

function ListingReview({ l, onDone }: { l: TeamListing; onDone: () => void }) {
  const [note, setNote] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [problem, setProblem] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(false);

  const act = (status: string, needNote: boolean) => void (async () => {
    if (needNote && note.trim().length < 5) { setError("Indiquez un motif d'au moins 5 caractères pour le propriétaire."); return; }
    setBusy(true); setError(null);
    try { await api.setListingStatus(l.id, status, note.trim() || undefined); onDone(); }
    catch (e) { setError(e instanceof Error ? e.message : "Opération impossible."); }
    finally { setBusy(false); }
  })();

  const check = () => void (async () => {
    setBusy(true); setError(null);
    try { setProblem(await api.publishProblem(l.id) ?? "Rien ne manque : l'annonce peut être mise en ligne."); }
    catch (e) { setError(e instanceof Error ? e.message : "Vérification impossible."); }
    finally { setBusy(false); }
  })();

  return (
    <Box>
      <button onClick={() => setOpen(!open)} className="flex w-full flex-wrap items-center justify-between gap-3 text-left cursor-pointer">
        <div className="min-w-0">
          <p className="truncate font-semibold text-ink">{l.title}</p>
          <p className="text-sm text-muted">{l.district}, {l.city} · <Money value={l.nightly_price_xof} /> · {l.capacity} voyageur(s)</p>
        </div>
        <Pill tone={l.status === "soumise" ? "info" : l.status === "publiee" ? "good" : "neutral"}>{LABEL[l.status] ?? l.status}</Pill>
      </button>

      {open && (
        <div className="mt-4 flex flex-col gap-3 border-t border-line pt-4">
          <p className="whitespace-pre-wrap text-sm text-ink">{l.description}</p>
          {l.private_address && <p className="text-sm text-muted">Adresse : {l.private_address}</p>}
          {l.review_note && <Alert tone="warn">Note en cours : {l.review_note}</Alert>}
          {error && <Alert tone="bad">{error}</Alert>}
          {problem && <Alert tone={problem.startsWith("Rien") ? "good" : "warn"}>{problem}</Alert>}

          {(l.status === "soumise" || l.status === "approuvee" || l.status === "publiee") && (
            <>
              <Field label="Motif, pour une correction ou un refus" htmlFor={`ln-${l.id}`}>
                <input id={`ln-${l.id}`} className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Photos floues, prix incohérent…" />
              </Field>
              <div className="flex flex-wrap gap-2">
                {l.status === "soumise" && <>
                  <Button onClick={() => act("approuvee", false)} disabled={busy}>Approuver</Button>
                  <Button variant="secondary" onClick={() => act("a_corriger", true)} disabled={busy}>Demander une correction</Button>
                  <Button variant="danger" onClick={() => act("refusee", true)} disabled={busy}>Refuser</Button>
                </>}
                {l.status === "approuvee" && <>
                  <Button variant="secondary" onClick={check} disabled={busy}>Que manque-t-il pour publier ?</Button>
                  <Button onClick={() => act("publiee", false)} disabled={busy}>Mettre en ligne</Button>
                </>}
                {l.status === "publiee" && <Button variant="danger" onClick={() => act("suspendue", true)} disabled={busy}>Suspendre</Button>}
              </div>
            </>
          )}
          <p className="text-xs text-muted">Une annonce ne se met en ligne qu'avec un abonnement payé et confirmé, un contact et une photo vérifiée. Le serveur le revérifie.</p>
        </div>
      )}
    </Box>
  );
}

function ListingsTab() {
  const { data, error, reload } = useAsync(() => api.listingsForTeam(), []);
  const [filter, setFilter] = React.useState<string>("soumise");
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;
  const counts: Record<string, number> = {};
  for (const l of data) counts[l.status] = (counts[l.status] ?? 0) + 1;
  const shown = data.filter((l) => l.status === filter);
  const tabs = ["soumise", "approuvee", "publiee", "a_corriger", "brouillon"];
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap gap-1.5">
        {tabs.map((t) => (
          <button key={t} onClick={() => setFilter(t)} aria-pressed={filter === t}
                  className={`rounded-full px-3 py-1 text-sm font-semibold cursor-pointer ${filter === t ? "bg-brand text-on-brand" : "bg-sunk text-ink hover:bg-line"}`}>
            {LABEL[t]} ({counts[t] ?? 0})
          </button>
        ))}
      </div>
      {shown.length === 0 ? <p className="text-muted">Aucune annonce dans cet état.</p>
        : shown.map((l) => <ListingReview key={l.id} l={l} onDone={reload} />)}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 3. Paiements
// ---------------------------------------------------------------------------
function NoticeRow({ n, onDone }: { n: Notice; onDone: () => void }) {
  const [amount, setAmount] = React.useState("");
  const [note, setNote] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [done, setDone] = React.useState<string | null>(null);
  const target = n.object === "abonnement" ? n.subscription_id : n.booking_id;

  const confirm = () => void (async () => {
    const v = Number(amount);
    if (!Number.isFinite(v) || v <= 0) { setError("Saisissez le montant réellement reçu."); return; }
    if (!target) { setError("Avis incomplet : aucune cible."); return; }
    setBusy(true); setError(null);
    try {
      await api.confirmPayment(n.object, target, v);
      await api.markNoticeHandled(n.id);
      setDone("Paiement confirmé."); onDone();
    } catch (e) { setError(e instanceof Error ? e.message : "Confirmation impossible."); }
    finally { setBusy(false); }
  })();

  const refuse = () => void (async () => {
    if (note.trim().length < 5) { setError("Indiquez pourquoi le paiement n'a pas été reçu."); return; }
    if (!target) { setError("Avis incomplet : aucune cible."); return; }
    setBusy(true); setError(null);
    try {
      await api.rejectPayment(n.object, target, note.trim());
      await api.markNoticeHandled(n.id);
      setDone("Paiement marqué comme non reçu."); onDone();
    } catch (e) { setError(e instanceof Error ? e.message : "Refus impossible."); }
    finally { setBusy(false); }
  })();

  return (
    <Box>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{n.object === "abonnement" ? "Abonnement" : "Réservation"} · montant déclaré <Money value={n.declared_amount_xof} /></p>
          <p className="text-sm text-muted">Reçu le {new Date(n.created_at).toLocaleString("fr-FR")}{n.reference ? ` · référence ${n.reference}` : ""}</p>
          {n.message && <p className="mt-1 text-sm text-ink">« {n.message} »</p>}
        </div>
        <Pill tone={n.status === "nouveau" ? "warn" : "neutral"}>{n.status === "nouveau" ? "À traiter" : "Traité"}</Pill>
      </div>

      {error && <div className="mt-3"><Alert tone="bad">{error}</Alert></div>}
      {done && <div className="mt-3"><Alert tone="good">{done}</Alert></div>}

      {n.status === "nouveau" && !done && (
        <div className="mt-4 flex flex-col gap-3">
          <Alert tone="warn">Le montant déclaré n'est qu'une déclaration. Saisissez le montant que vous avez réellement reçu : le serveur le compare au prix qu'il recalcule lui-même.</Alert>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Montant réellement reçu (FCFA)" htmlFor={`a-${n.id}`}>
              <input id={`a-${n.id}`} type="number" min={1} className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} />
            </Field>
            <Field label="Motif, si le paiement n'a pas été reçu" htmlFor={`n-${n.id}`}>
              <input id={`n-${n.id}`} className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Aucun versement trouvé" />
            </Field>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={confirm} disabled={busy}>Confirmer la réception</Button>
            <Button variant="danger" onClick={refuse} disabled={busy}>Non reçu</Button>
          </div>
        </div>
      )}
    </Box>
  );
}

// ---------------------------------------------------------------------------
// 3bis. Réservations (migration 0011)
//
// Cet écran n'existait pas, et c'est ce qui rendait le site aveugle : un voyageur pouvait
// réserver, payer, et personne du côté YIRI ne l'apprenait. On ouvre donc sur la question
// qu'on se pose vraiment en arrivant : QUI ARRIVE BIENTÔT.
// ---------------------------------------------------------------------------
const B_LABEL: Record<string, [string, "neutral" | "good" | "warn" | "bad" | "info" | "accent"]> = {
  en_attente_confirmation: ["À confirmer", "warn"],
  en_attente_paiement: ["En attente de paiement", "warn"],
  confirmee: ["Confirmée", "good"],
  en_cours: ["Séjour en cours", "info"],
  terminee: ["Terminée", "neutral"],
  refusee: ["Refusée", "bad"],
  annulee: ["Annulée", "bad"],
  expiree: ["Expirée", "neutral"],
  litige: ["Litige", "bad"],
};

function jour(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

function BookingCard({ b }: { b: api.TeamBooking }) {
  const [lab, tone] = B_LABEL[b.status] ?? [b.status, "neutral" as const];
  const bientot = api.arriveBientot(b.arrivee) && (b.status === "confirmee" || b.status === "en_cours");
  return (
    <div className={`rounded-2xl border bg-surface p-4 ${bientot ? "border-good/50" : "border-line"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{b.title}</p>
          <p className="text-sm text-muted">{b.district}, {b.city} · {b.guests} voyageur{b.guests > 1 ? "s" : ""}</p>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {b.sous_gestion && <Pill tone="accent">Sous gestion</Pill>}
          <Pill tone={tone}>{lab}</Pill>
        </div>
      </div>

      <div className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
        <p className="text-ink"><span className="text-muted">Séjour : </span>{jour(b.arrivee)} → {jour(b.depart)} ({b.nuits} nuit{b.nuits > 1 ? "s" : ""})</p>
        <p className="text-ink"><span className="text-muted">Montant : </span><Money value={b.total_xof} /></p>
        <p className="text-ink"><span className="text-muted">Voyageur : </span>{b.guest_name ?? "inconnu"}</p>
        <p className="text-ink"><span className="text-muted">Téléphone : </span>{b.guest_phone ?? "non renseigné"}</p>
        {b.guest_email && <p className="truncate text-ink"><span className="text-muted">Courriel : </span>{b.guest_email}</p>}
        <p className="text-ink">
          <span className="text-muted">Paiement : </span>
          {b.paye
            ? <>reçu{b.moyen ? ` (${b.moyen})` : ""}{b.paye_le ? ` le ${new Date(b.paye_le).toLocaleDateString("fr-FR")}` : ""}</>
            : "pas encore reçu"}
        </p>
      </div>

      {/* Joindre le voyageur en un geste : c'est tout l'intérêt d'avoir son numéro.
          Les réservations créées avant la migration 0012 n'en ont pas, et le disent. */}
      {b.guest_phone ? (
        <div className="mt-3 flex flex-wrap gap-2">
          <a href={`https://wa.me/${b.guest_phone.replace(/[^0-9]/g, "")}`}
             target="_blank" rel="noopener noreferrer"
             className="rounded-full bg-ink px-3.5 py-1.5 text-sm font-semibold text-bg no-underline hover:opacity-90">
            WhatsApp
          </a>
          <a href={`tel:${b.guest_phone.replace(/[^0-9+]/g, "")}`}
             className="rounded-full bg-sunk px-3.5 py-1.5 text-sm font-semibold text-ink no-underline hover:bg-line">
            Appeler
          </a>
          {b.guest_email && (
            <a href={`mailto:${b.guest_email}`}
               className="rounded-full bg-sunk px-3.5 py-1.5 text-sm font-semibold text-ink no-underline hover:bg-line">
              Courriel
            </a>
          )}
        </div>
      ) : (
        <p className="mt-3 text-sm text-warn">
          Aucun numéro : réservation faite avant que le téléphone soit demandé. Passez par le courriel.
        </p>
      )}

      {b.paye && b.reference && <p className="mt-2 font-mono text-xs text-muted">{b.reference}</p>}

      {/* Un blocage non payé libère les dates tout seul : le dire évite qu'on « fasse quelque chose ». */}
      {b.status === "en_attente_paiement" && b.hold_expires_at && (
        <p className="mt-2 text-sm text-muted">
          Les dates sont bloquées jusqu'au {new Date(b.hold_expires_at).toLocaleString("fr-FR")}, puis libérées automatiquement.
        </p>
      )}
    </div>
  );
}

function BookingsTab() {
  const { data, error } = useAsync(() => api.bookingsQueue(), []);
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;

  // Quatre groupes, parce qu'on vient ici avec deux questions distinctes : « qui arrive bientôt »
  // et « qu'est-ce qui est coincé sans paiement ». Mélanger les deux noierait la seconde :
  // une arrivée dans deux jours non payée est justement ce qu'il faut voir en premier.
  const payee = (b: api.TeamBooking) => b.status === "confirmee" || b.status === "en_cours";
  const bientot = data.filter((b) => payee(b) && api.arriveBientot(b.arrivee));
  const impayees = data.filter((b) => b.status === "en_attente_paiement" || b.status === "en_attente_confirmation");
  const aVenir = data.filter((b) => payee(b) && !api.arriveBientot(b.arrivee));
  const passees = data.filter((b) => !payee(b) && !impayees.includes(b));
  const gestion = bientot.filter((b) => b.sous_gestion);
  const impayeesProches = impayees.filter((b) => api.arriveBientot(b.arrivee));

  return (
    <div className="flex flex-col gap-4">
      {data.length === 0 && (
        <div className="rounded-2xl border border-dashed border-line-strong p-10 text-center">
          <p className="text-muted">Aucune réservation pour l'instant.</p>
        </div>
      )}

      {gestion.length > 0 && (
        <Alert tone="warn">
          {gestion.length} arrivée{gestion.length > 1 ? "s" : ""} dans les 7 jours sur un logement sous gestion :
          c'est YIRI qui accueille, prépare les clés et le ménage.
        </Alert>
      )}

      {bientot.length > 0 && <>
        <h2 className="font-display font-bold text-ink">Arrivées dans les 7 jours ({bientot.length})</h2>
        {bientot.map((b) => <BookingCard key={b.id} b={b} />)}
      </>}

      {impayees.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">En attente de paiement ({impayees.length})</h2>
        {impayeesProches.length > 0 && (
          <Alert tone="warn">
            {impayeesProches.length} de ces séjours commence{impayeesProches.length > 1 ? "nt" : ""} dans moins de 7 jours
            et n'{impayeesProches.length > 1 ? "ont" : "a"} pas été payé{impayeesProches.length > 1 ? "s" : ""}.
            Les dates seront libérées automatiquement à la fin du blocage.
          </Alert>
        )}
        {impayees.map((b) => <BookingCard key={b.id} b={b} />)}
      </>}

      {aVenir.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">Plus tard ({aVenir.length})</h2>
        {aVenir.map((b) => <BookingCard key={b.id} b={b} />)}
      </>}

      {passees.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">Terminées, annulées et expirées ({passees.length})</h2>
        {passees.slice(0, 20).map((b) => <BookingCard key={b.id} b={b} />)}
      </>}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 3quater. Demandes et candidatures
//
// Ces deux canaux arrivaient en base sans que PERSONNE ne puisse les lire : les fonctions
// existaient dans l'API, aucun écran ne les appelait. Les autorisations « demandes » et
// « partenariat » pouvaient être accordées à quelqu'un sans rien lui ouvrir.
//
// L'écran ouvre sur ce qui n'a pas encore été traité, parce que c'est la seule question
// qu'on se pose en arrivant : qui attend un rappel.
// ---------------------------------------------------------------------------
const PACK_FR: Record<string, string> = {
  visibilite: "YIRI Annonce", serenite: "YIRI Sérénité",
  partenariat: "YIRI Partenariat", indecis: "Encore indécis",
};
const NIVEAU_FR: Record<string, string> = {
  autonomie: "veut gérer seul", reservations: "veut de l'aide sur les réservations",
  delegation: "veut tout déléguer",
};
const APP_STATUT: Record<string, [string, "neutral" | "good" | "warn" | "bad" | "info" | "accent"]> = {
  recue: ["Reçue", "warn"],
  preselection: ["En présélection", "info"],
  visite: ["Visite planifiée", "info"],
  acceptee: ["Acceptée", "good"],
  refusee: ["Refusée", "bad"],
};

function LeadCard({ l, onDone }: { l: api.TeamLead; onDone: () => void }) {
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const traite = l.status === "contactee";
  return (
    <div className={`rounded-2xl border bg-surface p-4 ${traite ? "border-line" : "border-warn/50"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{l.name}</p>
          <p className="text-sm text-muted">{new Date(l.created_at).toLocaleString("fr-FR")}</p>
        </div>
        <Pill tone={traite ? "neutral" : "warn"}>{traite ? "Rappelé" : "À rappeler"}</Pill>
      </div>
      <div className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
        <p className="text-ink"><span className="text-muted">Téléphone : </span>{l.phone}</p>
        <p className="text-ink"><span className="text-muted">Offre visée : </span>{PACK_FR[l.pack] ?? l.pack}</p>
        <p className="text-ink"><span className="text-muted">Bien : </span>{l.property_kind} · {l.city}</p>
        <p className="text-ink"><span className="text-muted">Logements : </span>{l.property_count}</p>
        <p className="text-ink sm:col-span-2"><span className="text-muted">Besoin : </span>{NIVEAU_FR[l.level] ?? l.level}</p>
      </div>
      {l.message && <p className="mt-2 whitespace-pre-wrap rounded-xl bg-sunk px-3 py-2 text-sm text-ink">{l.message}</p>}
      {error && <div className="mt-3"><Alert tone="bad">{error}</Alert></div>}
      <div className="mt-3 flex flex-wrap gap-2">
        <a href={`https://wa.me/${l.phone.replace(/[^0-9]/g, "")}`} target="_blank" rel="noopener noreferrer"
           className="rounded-full bg-ink px-3.5 py-1.5 text-sm font-semibold text-bg no-underline hover:opacity-90">WhatsApp</a>
        <a href={`tel:${l.phone.replace(/[^0-9+]/g, "")}`}
           className="rounded-full bg-sunk px-3.5 py-1.5 text-sm font-semibold text-ink no-underline hover:bg-line">Appeler</a>
        {!traite && (
          <Button size="sm" variant="secondary" disabled={busy}
                  onClick={() => void (async () => {
                    setBusy(true); setError(null);
                    try { await api.markLeadContacted(l.id); onDone(); }
                    catch (e) { setError(e instanceof Error ? e.message : "Enregistrement impossible."); }
                    finally { setBusy(false); }
                  })()}>
            {busy ? "Patientez…" : "Marquer rappelé"}
          </Button>
        )}
      </div>
    </div>
  );
}

function ApplicationCard({ a, onDone }: { a: api.TeamApplication; onDone: () => void }) {
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [motif, setMotif] = React.useState("");
  const [lab, tone] = APP_STATUT[a.status] ?? [a.status, "neutral" as const];

  const decider = (statut: string) => void (async () => {
    setBusy(true); setError(null);
    try { await api.setApplicationStatus(a.id, statut, motif); setMotif(""); onDone(); }
    catch (e) { setError(e instanceof Error ? e.message : "Enregistrement impossible."); }
    finally { setBusy(false); }
  })();

  return (
    <div className={`rounded-2xl border bg-surface p-4 ${a.status === "recue" ? "border-warn/50" : "border-line"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{a.contact_name}</p>
          <p className="text-sm text-muted">{new Date(a.created_at).toLocaleString("fr-FR")}</p>
        </div>
        <Pill tone={tone}>{lab}</Pill>
      </div>
      <div className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
        <p className="text-ink"><span className="text-muted">Téléphone : </span>{a.contact_phone}</p>
        <p className="text-ink"><span className="text-muted">Bien : </span>{a.property_kind} · {a.rooms} chambre(s)</p>
        <p className="text-ink sm:col-span-2"><span className="text-muted">Où : </span>{a.district}, {a.city}</p>
      </div>
      <p className="mt-2 whitespace-pre-wrap rounded-xl bg-sunk px-3 py-2 text-sm text-ink">
        <span className="text-muted">État du bien : </span>{a.condition_notes}
      </p>
      {a.estimated_works && (
        <p className="mt-2 whitespace-pre-wrap text-sm text-muted">Travaux à prévoir : {a.estimated_works}</p>
      )}
      {a.decision_reason && <p className="mt-2 text-sm text-muted">Décision : {a.decision_reason}</p>}
      {error && <div className="mt-3"><Alert tone="bad">{error}</Alert></div>}

      <div className="mt-3 flex flex-wrap gap-2">
        <a href={`https://wa.me/${a.contact_phone.replace(/[^0-9]/g, "")}`} target="_blank" rel="noopener noreferrer"
           className="rounded-full bg-ink px-3.5 py-1.5 text-sm font-semibold text-bg no-underline hover:opacity-90">WhatsApp</a>
        {a.status === "recue" && (
          <>
            <Button size="sm" disabled={busy} onClick={() => decider("preselection")}>Présélectionner</Button>
            <Button size="sm" variant="danger" disabled={busy || motif.trim().length < 5} onClick={() => decider("refusee")}>Refuser</Button>
          </>
        )}
        {a.status === "preselection" && (
          <Button size="sm" disabled={busy} onClick={() => decider("visite")}>Visite planifiée</Button>
        )}
        {a.status === "visite" && (
          <>
            <Button size="sm" disabled={busy} onClick={() => decider("acceptee")}>Accepter</Button>
            <Button size="sm" variant="danger" disabled={busy || motif.trim().length < 5} onClick={() => decider("refusee")}>Refuser</Button>
          </>
        )}
      </div>
      {["recue", "visite"].includes(a.status) && (
        <div className="mt-3">
          <Field label="Motif (obligatoire pour refuser)" htmlFor={`m-${a.id}`}>
            <input id={`m-${a.id}`} className={inputCls} value={motif} onChange={(e) => setMotif(e.target.value)}
                   placeholder="Bien trop éloigné de nos zones" />
          </Field>
        </div>
      )}
    </div>
  );
}

function RequestsTab() {
  const s = useSession();
  const [leads, setLeads] = React.useState<api.TeamLead[] | null>(null);
  const [apps, setApps] = React.useState<api.TeamApplication[] | null>(null);
  const [errL, setErrL] = React.useState<string | null>(null);
  const [errA, setErrA] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  // Les deux canaux sont lus séparément : l'un peut être refusé sans masquer l'autre,
  // parce que « demandes » et « partenariat » sont deux autorisations distinctes.
  React.useEffect(() => {
    let alive = true;
    if (s.can("demandes")) {
      api.leadsForTeam().then((r) => { if (alive) setLeads(r); })
        .catch((e) => { if (alive) { setErrL(e instanceof Error ? e.message : "Lecture impossible."); setLeads([]); } });
    } else setLeads([]);
    if (s.can("partenariat")) {
      api.applicationsForTeam().then((r) => { if (alive) setApps(r); })
        .catch((e) => { if (alive) { setErrA(e instanceof Error ? e.message : "Lecture impossible."); setApps([]); } });
    } else setApps([]);
    return () => { alive = false; };
  }, [tick, s]);

  if (leads === null || apps === null) return <p className="text-muted">Chargement…</p>;

  const aRappeler = leads.filter((l) => l.status === "nouvelle");
  const rappeles = leads.filter((l) => l.status !== "nouvelle");
  const nouvelles = apps.filter((a) => a.status === "recue");
  const enCours = apps.filter((a) => ["preselection", "visite"].includes(a.status));
  const closes = apps.filter((a) => ["acceptee", "refusee"].includes(a.status));

  return (
    <div className="flex flex-col gap-4">
      {aRappeler.length + nouvelles.length > 0 && (
        <Alert tone="warn">
          {aRappeler.length + nouvelles.length} personne{aRappeler.length + nouvelles.length > 1 ? "s attendent" : " attend"} une réponse de votre part.
        </Alert>
      )}

      {s.can("demandes") && <>
        <h2 className="font-display font-bold text-ink">À rappeler ({aRappeler.length})</h2>
        {errL && <Alert tone="bad">{errL}</Alert>}
        {aRappeler.length === 0 && !errL && <p className="text-muted">Aucune demande en attente.</p>}
        {aRappeler.map((l) => <LeadCard key={l.id} l={l} onDone={() => setTick((t) => t + 1)} />)}
        {rappeles.length > 0 && (
          <details>
            <summary className="cursor-pointer text-sm font-semibold text-ink">Déjà rappelés ({rappeles.length})</summary>
            <div className="mt-3 flex flex-col gap-3">
              {rappeles.slice(0, 20).map((l) => <LeadCard key={l.id} l={l} onDone={() => setTick((t) => t + 1)} />)}
            </div>
          </details>
        )}
      </>}

      {s.can("partenariat") && <>
        <h2 className="mt-2 font-display font-bold text-ink">Candidatures Partenariat ({nouvelles.length})</h2>
        {errA && <Alert tone="bad">{errA}</Alert>}
        {nouvelles.length === 0 && !errA && <p className="text-muted">Aucune nouvelle candidature.</p>}
        {nouvelles.map((a) => <ApplicationCard key={a.id} a={a} onDone={() => setTick((t) => t + 1)} />)}
        {enCours.length > 0 && <>
          <h3 className="mt-2 font-display font-semibold text-ink">En cours d'étude ({enCours.length})</h3>
          {enCours.map((a) => <ApplicationCard key={a.id} a={a} onDone={() => setTick((t) => t + 1)} />)}
        </>}
        {closes.length > 0 && (
          <details>
            <summary className="cursor-pointer text-sm font-semibold text-ink">Dossiers clos ({closes.length})</summary>
            <div className="mt-3 flex flex-col gap-3">
              {closes.slice(0, 20).map((a) => <ApplicationCard key={a.id} a={a} onDone={() => setTick((t) => t + 1)} />)}
            </div>
          </details>
        )}
      </>}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 3ter. Abonnements YIRI Annonce (migrations 0014 à 0016)
//
// Un abonnement par PROFIL, plus par logement. La question qu'on vient se poser ici est
// « qui va expirer, et quand » : la file est donc triée par date de fin, les plus proches
// en tête. L'accès offert se donne au compte et couvre tous ses logements, présents et à venir.
// ---------------------------------------------------------------------------
const S_LABEL: Record<string, [string, "neutral" | "good" | "warn" | "bad" | "info" | "accent"]> = {
  en_attente_paiement: ["En attente de paiement", "warn"],
  actif: ["Actif", "good"],
  expire: ["Expiré", "bad"],
  annule: ["Annulé", "neutral"],
  rembourse: ["Remboursé", "neutral"],
};

function OffrirAcces({ s, onDone }: { s: api.TeamSubscription; onDone: () => void }) {
  const [ouvert, setOuvert] = React.useState(false);
  const [jours, setJours] = React.useState(90);
  const [motif, setMotif] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const offrir = () => void (async () => {
    setBusy(true); setError(null);
    try { await api.grantOwnerPass(s.owner_id, jours, motif); setOuvert(false); setMotif(""); onDone(); }
    catch (e) { setError(e instanceof Error ? e.message : "Octroi impossible."); }
    finally { setBusy(false); }
  })();

  const retirer = () => void (async () => {
    setBusy(true); setError(null);
    try { await api.revokeOwnerPass(s.owner_id, motif || "Retrait décidé par l'équipe"); setOuvert(false); setMotif(""); onDone(); }
    catch (e) { setError(e instanceof Error ? e.message : "Retrait impossible."); }
    finally { setBusy(false); }
  })();

  if (!ouvert) {
    return (
      <Button size="sm" variant="secondary" onClick={() => setOuvert(true)}>
        {s.acces_offert ? "Modifier l'accès offert" : "Offrir un accès"}
      </Button>
    );
  }
  return (
    <div className="mt-3 rounded-xl bg-sunk p-3">
      {error && <Alert tone="bad">{error}</Alert>}
      <p className="text-sm text-muted">
        L'accès offert couvre <strong>tous les logements</strong> de ce propriétaire, y compris
        ceux qu'il publiera ensuite. Il n'est pas facturé : rien n'entre dans le chiffre d'affaires.
      </p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <Field label="Durée en jours" htmlFor={`j-${s.owner_id}`}>
          <input id={`j-${s.owner_id}`} type="number" min={1} max={1095} className={inputCls}
                 value={jours} onChange={(e) => setJours(+e.target.value)} />
        </Field>
        <Field label="Motif (obligatoire)" htmlFor={`m-${s.owner_id}`}>
          <input id={`m-${s.owner_id}`} className={inputCls} value={motif}
                 placeholder="Partenariat de lancement" onChange={(e) => setMotif(e.target.value)} />
        </Field>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button size="sm" disabled={busy || motif.trim().length < 3} onClick={offrir}>
          {busy ? "Patientez…" : "Accorder"}
        </Button>
        {s.acces_offert && (
          <Button size="sm" variant="danger" disabled={busy || motif.trim().length < 3} onClick={retirer}>
            Retirer l'accès
          </Button>
        )}
        <Button size="sm" variant="ghost" onClick={() => setOuvert(false)}>Annuler</Button>
      </div>
    </div>
  );
}

function SubscriptionsTab() {
  const [data, setData] = React.useState<api.TeamSubscription[] | null>(null);
  const [passes, setPasses] = React.useState<api.FreePass[]>([]);
  const [error, setError] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    let alive = true;
    api.subscriptionsQueue().then((r) => { if (alive) setData(r); })
      .catch((e) => { if (alive) { setError(e instanceof Error ? e.message : "Lecture impossible."); setData([]); } });
    // Les accès offerts sont un complément : leur absence ne doit pas masquer les abonnements.
    api.freePasses().then((r) => { if (alive) setPasses(r); }).catch(() => { if (alive) setPasses([]); });
    return () => { alive = false; };
  }, [tick]);

  if (error) return <Alert tone="bad">{error}</Alert>;
  if (data === null) return <p className="text-muted">Chargement…</p>;

  const expirent = data.filter((s) => s.status === "actif" && (s.jours_restants ?? 99) <= 7);
  const attente = data.filter((s) => s.status === "en_attente_paiement");
  const actifs = data.filter((s) => s.status === "actif" && !expirent.includes(s));
  const finis = data.filter((s) => !["actif", "en_attente_paiement"].includes(s.status));
  const offerts = passes.filter((p) => !p.revoke_at && p.jours_restants > 0);

  const Carte = ({ s }: { s: api.TeamSubscription }) => {
    const [lab, tone] = S_LABEL[s.status] ?? [s.status, "neutral" as const];
    return (
      <div className={`rounded-2xl border bg-surface p-4 ${s.status === "actif" && (s.jours_restants ?? 99) <= 7 ? "border-warn/50" : "border-line"}`}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="font-semibold text-ink">{s.proprietaire}</p>
            <p className="truncate text-sm text-muted">{s.email ?? "adresse inconnue"}</p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {s.acces_offert && <Pill tone="accent">Accès offert</Pill>}
            <Pill tone={tone}>{lab}</Pill>
          </div>
        </div>
        <div className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
          <p className="text-ink"><span className="text-muted">Forfait : </span>{s.plan === "mensuel" ? "Mensuel" : "Annuel"} · <Money value={s.amount_xof} /></p>
          <p className="text-ink">
            <span className="text-muted">Échéance : </span>
            {s.ends_at ? new Date(s.ends_at).toLocaleDateString("fr-FR") : "—"}
            {s.jours_restants !== null && s.status === "actif" && <> · {s.jours_restants} j</>}
          </p>
          <p className="text-ink"><span className="text-muted">Logements : </span>{s.annonces}</p>
          <p className="text-ink"><span className="text-muted">En ligne : </span>{s.publiees}</p>
        </div>
        {!s.peut_publier && s.annonces > 0 && (
          <p className="mt-2 text-sm text-danger">
            Ce propriétaire ne peut rien publier : ses {s.annonces} annonce{s.annonces > 1 ? "s sont masquées" : " est masquée"}.
          </p>
        )}
        <div className="mt-3"><OffrirAcces s={s} onDone={() => setTick((t) => t + 1)} /></div>
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-muted">
        Un abonnement par propriétaire, pas par logement : il publie autant de logements qu'il veut.
        Chaque annonce reste validée individuellement par l'équipe.
      </p>

      {data.length === 0 && (
        <div className="rounded-2xl border border-dashed border-line-strong p-10 text-center">
          <p className="text-muted">Aucun abonnement pour l'instant.</p>
        </div>
      )}

      {expirent.length > 0 && <>
        <Alert tone="warn">
          {expirent.length} abonnement{expirent.length > 1 ? "s expirent" : " expire"} dans les 7 jours.
          Les relances partent automatiquement ; vous n'avez rien à envoyer.
        </Alert>
        <h2 className="font-display font-bold text-ink">Expire bientôt ({expirent.length})</h2>
        {expirent.map((s) => <Carte key={s.id} s={s} />)}
      </>}

      {attente.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">En attente de paiement ({attente.length})</h2>
        {attente.map((s) => <Carte key={s.id} s={s} />)}
      </>}

      {actifs.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">Actifs ({actifs.length})</h2>
        {actifs.map((s) => <Carte key={s.id} s={s} />)}
      </>}

      {finis.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">Expirés et annulés ({finis.length})</h2>
        {finis.slice(0, 20).map((s) => <Carte key={s.id} s={s} />)}
      </>}

      {offerts.length > 0 && <>
        <h2 className="mt-2 font-display font-bold text-ink">Accès offerts en cours ({offerts.length})</h2>
        {offerts.map((p) => (
          <div key={p.id} className="rounded-2xl border border-accent/40 bg-surface p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="font-semibold text-ink">{p.proprietaire}</p>
                <p className="text-sm text-muted">{p.reason}</p>
              </div>
              <Pill tone="accent">{p.jours_restants} jour{p.jours_restants > 1 ? "s" : ""}</Pill>
            </div>
            <p className="mt-2 text-sm text-ink">
              <span className="text-muted">Jusqu'au </span>{new Date(p.ends_on).toLocaleDateString("fr-FR")}
              <span className="text-muted"> · couvre </span>{p.annonces} logement{p.annonces > 1 ? "s" : ""}
            </p>
          </div>
        ))}
      </>}
    </div>
  );
}

/** Issue d'une tentative de paiement en ligne. « ecart » est le cas qui doit sauter aux yeux :
 *  le prestataire a encaissé un montant différent de celui que la base avait calculé, donc
 *  RIEN n'a été validé et la réservation est restée en attente. */
const A_LABEL: Record<string, [string, "neutral" | "good" | "warn" | "bad" | "info" | "accent"]> = {
  paye: ["Payé", "good"],
  echec: ["Échec", "bad"],
  annule: ["Abandonné", "neutral"],
  ecart: ["ÉCART DE MONTANT", "bad"],
};

function AttemptRow({ a }: { a: api.PaymentAttempt }) {
  const [lab, tone] = a.outcome ? (A_LABEL[a.outcome] ?? [a.outcome, "neutral" as const]) : ["En cours", "warn" as const];
  return (
    <div className={`rounded-2xl border bg-surface p-3.5 ${a.outcome === "ecart" ? "border-danger/50" : "border-line"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink"><Money value={a.amount_xof} /> · {a.object === "reservation" ? "réservation" : "abonnement"}</p>
          <p className="font-mono text-xs text-muted">{a.reference}</p>
          <p className="text-sm text-muted">
            {new Date(a.created_at).toLocaleString("fr-FR")} · {a.provider}
            {a.settled_at ? ` · réglé le ${new Date(a.settled_at).toLocaleString("fr-FR")}` : ""}
          </p>
        </div>
        <Pill tone={tone}>{lab}</Pill>
      </div>
      {a.outcome === "ecart" && (
        <Alert tone="bad">
          Le montant encaissé ne correspond pas à celui calculé par la base. Rien n'a été validé :
          la réservation est toujours en attente. À rapprocher dans le tableau de bord du prestataire.
        </Alert>
      )}
    </div>
  );
}

function PaymentsTab() {
  const { data, error, reload } = useAsync(() => api.notices(), []);
  // Les paiements en ligne sont lus à part : l'un des deux peut échouer sans emporter l'autre.
  const enLigne = useAsync(() => api.paymentAttempts(), []);
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;
  const todo = data.filter((n) => n.status === "nouveau");
  const done = data.filter((n) => n.status !== "nouveau").slice(0, 10);
  const tentatives = enLigne.data ?? [];
  const ecarts = tentatives.filter((a) => a.outcome === "ecart");
  const recentes = tentatives.slice(0, 15);
  return (
    <div className="flex flex-col gap-3">
      {ecarts.length > 0 && (
        <Alert tone="bad">
          {ecarts.length} paiement{ecarts.length > 1 ? "s" : ""} en ligne avec un écart de montant. Rien n'a été encaissé : à vérifier.
        </Alert>
      )}

      <h3 className="font-display font-bold text-ink">Paiements hors ligne à traiter ({todo.length})</h3>
      {todo.length === 0 ? <p className="text-muted">Aucun paiement déclaré en attente.</p> : todo.map((n) => <NoticeRow key={n.id} n={n} onDone={reload} />)}
      {done.length > 0 && <>
        <h3 className="mt-4 font-display font-bold text-ink">Derniers traités</h3>
        {done.map((n) => <NoticeRow key={n.id} n={n} onDone={reload} />)}
      </>}

      <h3 className="mt-5 font-display font-bold text-ink">Paiements en ligne</h3>
      <p className="text-sm text-muted">
        Lecture seule : un paiement en ligne se confirme tout seul, par le message signé du prestataire.
        Personne ne peut le valider depuis cet écran, et c'est voulu.
      </p>
      {enLigne.error && <Alert tone="bad">{enLigne.error}</Alert>}
      {!enLigne.error && enLigne.data === null && <p className="text-muted">Chargement…</p>}
      {enLigne.data !== null && recentes.length === 0 && <p className="text-muted">Aucun paiement en ligne pour l'instant.</p>}
      {recentes.map((a) => <AttemptRow key={a.reference} a={a} />)}
    </div>
  );
}

// ---------------------------------------------------------------------------
// 4. Nettoyage des pièces d'identité
// ---------------------------------------------------------------------------
function CleanupTab() {
  const { data, error, reload } = useAsync(() => api.identityFilesPending(), []);
  const [busy, setBusy] = React.useState<string | null>(null);
  const [err2, setErr2] = React.useState<string | null>(null);
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;
  return (
    <div className="flex flex-col gap-3">
      <Alert tone="warn">Une pièce d'identité ne se garde pas. Dès qu'une décision est prise, les images doivent être supprimées. Seul le numéro est conservé.</Alert>
      {err2 && <Alert tone="bad">{err2}</Alert>}
      {data.length === 0 ? <p className="text-muted">Aucune image à supprimer. Tout est propre.</p> : data.map((d) => (
        <Box key={d.user_id}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-ink">Dossier {d.state === "verifie" ? "validé" : "refusé"}</p>
              <p className="text-sm text-muted">{d.files_left} image(s) encore stockée(s) · décidé le {new Date(d.decided_at).toLocaleDateString("fr-FR")}</p>
            </div>
            <Button variant="danger" disabled={busy === d.user_id}
                    onClick={() => void (async () => {
                      setBusy(d.user_id); setErr2(null);
                      try { await api.purgeIdentityFiles(d.user_id); reload(); }
                      catch (e) { setErr2(e instanceof Error ? e.message : "Suppression impossible."); }
                      finally { setBusy(null); }
                    })()}>
              Supprimer les images
            </Button>
          </div>
        </Box>
      ))}
    </div>
  );
}


// ---------------------------------------------------------------------------
// 5. Équipe et autorisations — administrateurs seulement
// ---------------------------------------------------------------------------
function MemberCard({ m, moi, onChange }: { m: Member; moi: string; onChange: () => void }) {
  const [busy, setBusy] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const soiMeme = m.id === moi;

  const basculer = (perm: Perm, donner: boolean) => void (async () => {
    setBusy(perm); setError(null);
    try {
      if (donner) await api.grantPerm(m.id, perm, moi);
      else await api.revokePerm(m.id, perm);
      onChange();
    } catch (e) { setError(e instanceof Error ? e.message : "Opération impossible."); }
    finally { setBusy(null); }
  })();

  return (
    <Box>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{m.full_name}{soiMeme ? " (vous)" : ""}</p>
          <p className="truncate text-sm text-muted">{m.email ?? "adresse inconnue"}</p>
        </div>
        {m.isAdmin && <Pill tone="accent">Administrateur</Pill>}
      </div>

      {error && <div className="mt-3"><Alert tone="bad">{error}</Alert></div>}

      {m.isAdmin ? (
        <p className="mt-3 text-sm text-muted">
          Un administrateur a déjà tous les accès. Son rôle ne se change pas depuis l'application :
          il s'accorde et se retire uniquement en base de données.
        </p>
      ) : (
        <>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {api.PERMS.map(([perm, nom, quoi]) => {
              const a = m.perms.includes(perm);
              return (
                <label key={perm} className={`flex items-start gap-2.5 rounded-xl border p-2.5 ${a ? "border-good/40 bg-good/5" : "border-line"} ${soiMeme ? "opacity-60" : "cursor-pointer"}`}>
                  <input type="checkbox" checked={a} disabled={soiMeme || busy === perm} className="mt-0.5"
                         onChange={(e) => basculer(perm, e.target.checked)} />
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold text-ink">{nom}</span>
                    <span className="block text-xs text-muted">{quoi}</span>
                  </span>
                </label>
              );
            })}
          </div>
          {soiMeme && <p className="mt-2 text-xs text-muted">Vous ne pouvez pas modifier vos propres autorisations. La base le refuse aussi.</p>}
        </>
      )}
    </Box>
  );
}

// ---------------------------------------------------------------------------
// JOURNAL — l'écran de l'autorisation « audit ».
// Cette autorisation existait sans rien ouvrir : la base laissait lire audit_logs, mais
// aucun écran ne l'affichait. Lecture seule, sans aucune action possible : c'est le propre
// d'un journal. La base elle-même interdit d'y toucher, même à un administrateur.
// ---------------------------------------------------------------------------
function JournalTab() {
  const { data, error, reload } = useAsync(() => api.auditEntries(200), []);
  const [filtre, setFiltre] = React.useState("");

  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;

  const f = filtre.trim().toLowerCase();
  const lignes = f
    ? data.filter((e) =>
        (e.action + " " + e.entity_type + " " + e.entity_id + " " + (e.actor_name ?? "") + " " +
         api.auditActionLabel(e.action) + " " + (e.reason ?? "")).toLowerCase().includes(f))
    : data;

  return (
    <div className="flex flex-col gap-4">
      <Alert tone="warn">
        Ce journal est en lecture seule. Rien ne peut y être modifié ni effacé, pas même par un
        administrateur : la base le refuse. Il sert à rendre compte de qui a fait quoi, et quand.
      </Alert>

      <div className="flex flex-wrap items-end gap-2">
        <div className="min-w-[240px] flex-1">
          <Field label="Chercher" htmlFor="j-q">
            <input id="j-q" className={inputCls} value={filtre} onChange={(e) => setFiltre(e.target.value)}
                   placeholder="une action, un nom, un identifiant…" />
          </Field>
        </div>
        <Button variant="ghost" onClick={() => reload()}>Actualiser</Button>
      </div>

      <p className="text-sm text-muted">
        {lignes.length} ligne{lignes.length > 1 ? "s" : ""}
        {f ? ` sur ${data.length}` : " (les 200 plus récentes)"}.
      </p>

      {lignes.length === 0 && <p className="text-muted">Aucune ligne ne correspond.</p>}

      <div className="flex flex-col gap-2">
        {lignes.map((e) => (
          <div key={e.id} className="rounded-xl border border-line bg-surface p-3">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="font-semibold text-ink">{api.auditActionLabel(e.action)}</p>
              <p className="text-xs text-muted">{new Date(e.created_at).toLocaleString("fr-FR")}</p>
            </div>
            <p className="mt-1 text-sm text-muted">
              Par {e.actor_name ?? (e.actor_id ? "un compte (nom non accessible avec vos autorisations)" : "le système")}
              {" · "}{e.entity_type} <span className="font-mono text-xs">{e.entity_id}</span>
              {" · "}<span className="font-mono text-xs">{e.action}</span>
            </p>
            {e.reason && <p className="mt-1 text-sm text-ink">Motif : {e.reason}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

function TeamTab({ moi }: { moi: string }) {
  const { data, error, reload } = useAsync(() => api.teamMembers(), []);
  const journal = useAsync(() => api.teamLog(), [data]);
  const [email, setEmail] = React.useState("");
  const [trouve, setTrouve] = React.useState<Member | null>(null);
  const [cherche, setCherche] = React.useState(false);
  const [msg, setMsg] = React.useState<string | null>(null);

  const chercher = (e: React.FormEvent) => {
    e.preventDefault();
    setCherche(true); setMsg(null); setTrouve(null);
    void api.findByEmail(email)
      .then((m) => { if (m) setTrouve(m); else setMsg("Aucun compte avec cette adresse. La personne doit d'abord créer son compte sur YIRI."); })
      .catch((err) => setMsg(err instanceof Error ? err.message : "Recherche impossible."))
      .finally(() => setCherche(false));
  };

  if (error) return <Alert tone="bad">{error}</Alert>;

  return (
    <div className="flex flex-col gap-4">
      <Alert tone="warn">
        Donnez à chacun le minimum dont il a besoin. Une personne chargée des pièces d'identité n'a pas besoin
        d'accéder aux paiements. Chaque octroi et chaque retrait est inscrit au journal.
      </Alert>

      <Box>
        <h3 className="font-display font-bold text-ink">Ajouter quelqu'un</h3>
        <p className="mt-1 text-sm text-muted">La personne doit déjà avoir un compte YIRI. Cherchez-la par son adresse e-mail.</p>
        <form onSubmit={chercher} className="mt-3 flex flex-wrap items-end gap-2">
          <div className="min-w-[240px] flex-1">
            <Field label="Adresse e-mail" htmlFor="t-mail">
              <input id="t-mail" type="email" className={inputCls} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="collegue@exemple.com" />
            </Field>
          </div>
          <Button type="submit" disabled={cherche || !email.trim()}>{cherche ? "Recherche…" : "Chercher"}</Button>
        </form>
        {msg && <div className="mt-3"><Alert tone="warn">{msg}</Alert></div>}
      </Box>

      {trouve && <MemberCard m={trouve} moi={moi} onChange={() => { reload(); void api.findByEmail(email).then(setTrouve).catch(() => {}); }} />}

      <h3 className="mt-2 font-display font-bold text-ink">Équipe actuelle ({(data ?? []).length})</h3>
      {!data && <p className="text-muted">Chargement…</p>}
      {data && data.length === 0 && <p className="text-muted">Personne n'a encore d'autorisation.</p>}
      {(data ?? []).map((m) => <MemberCard key={m.id} m={m} moi={moi} onChange={reload} />)}

      {(journal.data ?? []).length > 0 && (
        <>
          <h3 className="mt-2 font-display font-bold text-ink">Derniers changements</h3>
          <Box>
            <ul className="flex flex-col gap-1.5 text-sm">
              {(journal.data ?? []).map((l, i) => {
                const perm = (l.after as { perm?: string } | null)?.perm ?? "?";
                const nom = (data ?? []).find((m) => m.id === l.entity_id)?.full_name ?? l.entity_id.slice(0, 8);
                return (
                  <li key={i} className="flex flex-wrap items-center gap-2 text-muted">
                    <Pill tone={l.action === "team.perm_granted" ? "good" : "bad"}>
                      {l.action === "team.perm_granted" ? "accordé" : "retiré"}
                    </Pill>
                    <span className="font-semibold text-ink">{perm}</span>
                    <span>à {nom}</span>
                    <span>· {new Date(l.created_at).toLocaleString("fr-FR")}</span>
                  </li>
                );
              })}
            </ul>
          </Box>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Remboursements
// Le cas normal ne passe pas ici : il part automatiquement. Cette file sert aux
// remboursements qu'un garde-fou a retenus — compte du payeur inconnu, ou plafond
// journalier atteint — et au suivi de ceux qui sont partis.
// ---------------------------------------------------------------------------
const RS: Record<string, [string, "warn" | "good" | "bad" | "neutral"]> = {
  demande: ["À vérifier", "warn"],
  approuve: ["Prêt à partir", "neutral"],
  en_cours: ["Envoyé", "warn"],
  reussi: ["Remboursé", "good"],
  echoue: ["Échec", "bad"],
};

/** Les annulations sur séjour payé qui n'ont encore donné lieu à aucune décision.
 *
 *  C'est l'écran qui remplace l'automatisme retiré par la migration 0019. Sans lui, une
 *  annulation sur un séjour payé ne serait vue par personne : ce serait pire que l'ancien
 *  système, pas mieux. Le montant est saisi par la personne, jamais proposé coché d'avance —
 *  le barème est affiché à côté comme un avis, pas comme une case à valider. */
function AnnulationsAExaminer() {
  const { data, error, reload } = useAsync(() => api.cancellationsToReview(), []);
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;
  if (data.length === 0) return null;

  return (
    <div className="flex flex-col gap-3">
      <Alert tone="warn">
        {data.length} annulation{data.length > 1 ? "s" : ""} sur un séjour déjà payé
        attend{data.length > 1 ? "ent" : ""} votre décision. Le voyageur ne reçoit rien tant que
        personne n'a tranché.
      </Alert>
      {data.map((c) => <AnnulationCard key={c.booking_id} c={c} onDone={reload} />)}
    </div>
  );
}

function AnnulationCard({ c, onDone }: { c: api.CancellationToReview; onDone: () => void }) {
  const [ouvert, setOuvert] = React.useState(false);
  const [montant, setMontant] = React.useState("");
  const [motif, setMotif] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);

  const n = Math.round(Number(montant.replace(/[^0-9]/g, "")) || 0);
  const valide = n > 0 && n <= c.encaisse_xof && motif.trim().length >= 5;

  const enregistrer = () => void (async () => {
    setBusy(true); setErr(null);
    try { await api.createRefund(c.booking_id, n, motif); onDone(); }
    catch (e) { setErr(e instanceof Error ? e.message : "Enregistrement impossible."); setBusy(false); }
  })();

  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{c.titre}</p>
          <p className="text-sm text-muted">
            {c.ville} · séjour {jour(c.arrivee)} → {jour(c.depart)} · annulée le {new Date(c.annulee_le).toLocaleDateString("fr-FR")}
          </p>
        </div>
        <Pill tone="warn">À décider</Pill>
      </div>

      <div className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
        <p className="text-ink"><span className="text-muted">Voyageur : </span>{c.guest_name ?? "—"}</p>
        <p className="text-ink"><span className="text-muted">Téléphone : </span>{c.guest_phone ?? "—"}</p>
        <p className="text-ink"><span className="text-muted">Encaissé : </span><Money value={c.encaisse_xof} /></p>
        <p className="text-ink">
          <span className="text-muted">Le barème prévoyait : </span><Money value={c.bareme_net_xof} />
          {c.palier ? ` (${c.palier}, ${c.taux_pct} %)` : ""}
        </p>
      </div>
      {c.motif && <p className="mt-2 text-sm text-ink"><span className="text-muted">Motif du voyageur : </span>{c.motif}</p>}

      {!ouvert ? (
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" onClick={() => { setMontant(String(c.bareme_net_xof)); setOuvert(true); }}>
            Enregistrer un remboursement
          </Button>
          {c.guest_phone && (
            <Button size="sm" variant="ghost" onClick={() => window.open(`https://wa.me/${c.guest_phone!.replace(/[^0-9]/g, "")}`, "_blank")}>
              WhatsApp
            </Button>
          )}
        </div>
      ) : (
        <div className="mt-3 flex flex-col gap-3 border-t border-line pt-3">
          {err && <Alert tone="bad">{err}</Alert>}
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Montant à rembourser (FCFA)" htmlFor={`r-m-${c.booking_id}`}
                   hint={`Au maximum ${c.encaisse_xof.toLocaleString("fr-FR")} FCFA, ce qui a été encaissé.`}>
              <input id={`r-m-${c.booking_id}`} inputMode="numeric" className={inputCls}
                     value={montant} onChange={(e) => setMontant(e.target.value)} />
            </Field>
            <Field label="Motif" htmlFor={`r-r-${c.booking_id}`} hint="Il reste au journal et justifie le versement.">
              <input id={`r-r-${c.booking_id}`} className={inputCls} value={motif}
                     onChange={(e) => setMotif(e.target.value)} placeholder="Annulation à plus de 30 jours" />
            </Field>
          </div>
          <p className="text-xs text-muted">
            Le versement lui-même reste à faire à la main : le prestataire ne permet pas encore de
            l'automatiser. Cet écran enregistre la décision et prévient le voyageur.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" disabled={!valide || busy} onClick={enregistrer}>
              {busy ? "Enregistrement…" : "Enregistrer"}
            </Button>
            <Button size="sm" variant="ghost" disabled={busy} onClick={() => setOuvert(false)}>Annuler</Button>
          </div>
        </div>
      )}
    </div>
  );
}

/** Les relevés de revenus, côté équipe.
 *
 *  Deux listes : les propriétaires qui ont des séjours payés non encore clôturés, et les relevés
 *  déjà faits. La clôture montre d'abord un APERÇU — on regarde ce qu'on va devoir avant de
 *  l'engager, et le montant ne peut plus être changé après. */
function RevenusTab() {
  const aRegler = useAsync(() => api.ownersToSettle(), []);
  const releves = useAsync(() => api.statementsQueue(), [aRegler.data]);

  if (aRegler.error) return <Alert tone="bad">{aRegler.error}</Alert>;
  if (!aRegler.data || !releves.data) return <p className="text-muted">Chargement…</p>;

  const du = releves.data.reduce((s, r) => s + Math.max(0, r.amount_due_xof - r.amount_paid_xof), 0);

  return (
    <div className="flex flex-col gap-4">
      {du > 0 && (
        <Alert tone="warn">
          Reste à verser aux propriétaires : <strong><Money value={du} /></strong>.
          Les virements se font à la main, puis s'enregistrent ici.
        </Alert>
      )}

      <h2 className="font-display font-bold text-ink">À clôturer ({aRegler.data.length})</h2>
      {aRegler.data.length === 0 && <p className="text-muted">Aucun séjour payé en attente de clôture.</p>}
      {aRegler.data.map((o) => (
        <ClotureCard key={o.owner_id} o={o} onDone={() => { aRegler.reload(); releves.reload(); }} />
      ))}

      <h2 className="mt-2 font-display font-bold text-ink">Relevés ({releves.data.length})</h2>
      {releves.data.length === 0 && <p className="text-muted">Aucun relevé.</p>}
      {releves.data.map((r) => <ReleveCard key={r.id} r={r} onDone={() => releves.reload()} />)}
    </div>
  );
}

function ClotureCard({ o, onDone }: { o: api.OwnerToSettle; onDone: () => void }) {
  // Par défaut : le mois civil qui précède le dernier départ. C'est le découpage naturel, et
  // l'équipe peut le changer avant de regarder l'aperçu.
  const fin = o.dernier_depart;
  const debutDefaut = new Date(fin + "T00:00:00");
  debutDefaut.setDate(1);
  const [debut, setDebut] = React.useState(debutDefaut.toISOString().slice(0, 10));
  const [finP, setFinP] = React.useState(fin);
  const [depenses, setDepenses] = React.useState("0");
  const [apercu, setApercu] = React.useState<api.StatementPreview | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);

  const regarder = () => void (async () => {
    setBusy(true); setErr(null);
    try { setApercu(await api.statementPreview(o.owner_id, debut, finP)); }
    catch (e) { setErr(e instanceof Error ? e.message : "Aperçu impossible."); }
    finally { setBusy(false); }
  })();

  const cloturer = () => void (async () => {
    setBusy(true); setErr(null);
    try { await api.closeStatement(o.owner_id, debut, finP, Number(depenses.replace(/[^0-9]/g, "")) || 0); onDone(); }
    catch (e) { setErr(e instanceof Error ? e.message : "Clôture impossible."); setBusy(false); }
  })();

  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-semibold text-ink">{o.proprietaire ?? "—"}</p>
          <p className="text-sm text-muted">
            {o.logements} logement{o.logements > 1 ? "s" : ""} · {o.sejours_non_clotures} séjour{o.sejours_non_clotures > 1 ? "s" : ""} payé{o.sejours_non_clotures > 1 ? "s" : ""} non clôturé{o.sejours_non_clotures > 1 ? "s" : ""} · dernier départ le {jour(o.dernier_depart)}
          </p>
        </div>
        {o.telephone && (
          <Button size="sm" variant="ghost" onClick={() => window.open(`https://wa.me/${o.telephone!.replace(/[^0-9]/g, "")}`, "_blank")}>WhatsApp</Button>
        )}
      </div>

      {err && <Alert tone="bad">{err}</Alert>}

      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        <Field label="Du" htmlFor={`d-${o.owner_id}`}>
          <input id={`d-${o.owner_id}`} type="date" className={inputCls} value={debut} onChange={(e) => { setDebut(e.target.value); setApercu(null); }} />
        </Field>
        <Field label="Au" htmlFor={`f-${o.owner_id}`}>
          <input id={`f-${o.owner_id}`} type="date" className={inputCls} value={finP} onChange={(e) => { setFinP(e.target.value); setApercu(null); }} />
        </Field>
        <Field label="Dépenses avancées (FCFA)" htmlFor={`e-${o.owner_id}`} hint="Retenues sur sa part.">
          <input id={`e-${o.owner_id}`} inputMode="numeric" className={inputCls} value={depenses} onChange={(e) => setDepenses(e.target.value)} />
        </Field>
      </div>

      {!apercu ? (
        <Button size="sm" className="mt-3" disabled={busy} onClick={regarder}>
          {busy ? "Calcul…" : "Voir ce que donnerait la clôture"}
        </Button>
      ) : (
        <>
          <dl className="mt-3 rounded-xl bg-sunk p-3 text-sm">
            <div className="flex justify-between py-0.5"><dt className="text-muted">Séjours payés</dt><dd className="font-medium text-ink">{apercu.sejours} sur {apercu.logements} logement{apercu.logements > 1 ? "s" : ""}</dd></div>
            <div className="flex justify-between py-0.5"><dt className="text-muted">Encaissé</dt><dd className="font-medium text-ink"><Money value={apercu.encaisse_xof} /></dd></div>
            {apercu.remboursements_xof > 0 && <div className="flex justify-between py-0.5"><dt className="text-muted">Remboursements déduits</dt><dd className="font-medium text-ink">− <Money value={apercu.remboursements_xof} /></dd></div>}
            <div className="flex justify-between border-t border-line py-1 pt-1.5"><dt className="font-semibold text-ink">Revenu partageable</dt><dd className="font-semibold text-ink"><Money value={apercu.rlp_xof} /></dd></div>
            <div className="flex justify-between py-0.5"><dt className="text-muted">Part du propriétaire</dt><dd className="font-medium text-ink"><Money value={apercu.part_proprietaire_xof} /></dd></div>
            <div className="flex justify-between py-0.5"><dt className="text-muted">Commission YIRI</dt><dd className="font-medium text-ink"><Money value={apercu.commission_yiri_xof} /></dd></div>
            <div className="flex justify-between py-0.5"><dt className="text-muted">Frais du prestataire (à la charge de YIRI)</dt><dd className="font-medium text-ink"><Money value={apercu.frais_xof} /></dd></div>
          </dl>
          <p className="mt-2 text-xs text-muted">
            Le pourcentage vient du contrat de chaque logement, pas d'une règle unique. La clôture
            est définitive : le montant ne pourra plus être changé.
          </p>
          {apercu.deja_cloture && <Alert tone="warn">Cette période est déjà clôturée.</Alert>}
          <div className="mt-2 flex flex-wrap gap-2">
            <Button size="sm" disabled={busy || apercu.deja_cloture || apercu.sejours === 0} onClick={cloturer}>
              {busy ? "Clôture…" : "Clôturer cette période"}
            </Button>
            <Button size="sm" variant="ghost" disabled={busy} onClick={() => setApercu(null)}>Changer les dates</Button>
          </div>
        </>
      )}
    </div>
  );
}

function ReleveCard({ r, onDone }: { r: api.TeamStatement; onDone: () => void }) {
  const reste = Math.max(0, r.amount_due_xof - r.amount_paid_xof);
  const [ouvert, setOuvert] = React.useState(false);
  const [montant, setMontant] = React.useState(String(reste));
  const [dest, setDest] = React.useState("");
  const [ref, setRef] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);

  const n = Math.round(Number(montant.replace(/[^0-9]/g, "")) || 0);
  const valide = n > 0 && n <= reste && dest.trim() !== "" && ref.trim() !== "";

  const enregistrer = () => void (async () => {
    setBusy(true); setErr(null);
    try { await api.registerPayout(r.id, n, dest, ref); onDone(); }
    catch (e) { setErr(e instanceof Error ? e.message : "Enregistrement impossible."); setBusy(false); }
  })();

  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-semibold text-ink">{r.proprietaire ?? "—"}</p>
          <p className="text-sm text-muted">{jour(r.period_start)} → {jour(r.period_end)}</p>
        </div>
        <Pill tone={r.status === "verse" ? "good" : "warn"}>{r.status === "verse" ? "Réglé" : "À régler"}</Pill>
      </div>

      <div className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
        <p className="text-ink"><span className="text-muted">Revenu partageable : </span><Money value={r.rlp_xof} /></p>
        <p className="text-ink"><span className="text-muted">Commission YIRI : </span><Money value={r.yiri_commission_xof} /></p>
        <p className="text-ink"><span className="text-muted">Part du propriétaire : </span><Money value={r.owner_share_xof} /></p>
        <p className="text-ink"><span className="text-muted">Reste à verser : </span><strong><Money value={reste} /></strong></p>
      </div>

      {err && <Alert tone="bad">{err}</Alert>}

      {reste > 0 && (!ouvert ? (
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" onClick={() => setOuvert(true)}>Enregistrer un versement</Button>
          {r.telephone && <Button size="sm" variant="ghost" onClick={() => window.open(`https://wa.me/${r.telephone!.replace(/[^0-9]/g, "")}`, "_blank")}>WhatsApp</Button>}
        </div>
      ) : (
        <div className="mt-3 flex flex-col gap-3 border-t border-line pt-3">
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Montant versé (FCFA)" htmlFor={`m-${r.id}`}>
              <input id={`m-${r.id}`} inputMode="numeric" className={inputCls} value={montant} onChange={(e) => setMontant(e.target.value)} />
            </Field>
            <Field label="Destination" htmlFor={`de-${r.id}`} hint="Les 4 derniers chiffres suffisent.">
              <input id={`de-${r.id}`} className={inputCls} value={dest} onChange={(e) => setDest(e.target.value)} placeholder="**4567" />
            </Field>
            <Field label="Référence du virement" htmlFor={`re-${r.id}`} hint="Obligatoire : elle trace le paiement.">
              <input id={`re-${r.id}`} className={inputCls} value={ref} onChange={(e) => setRef(e.target.value)} placeholder="OM-20261014-001" />
            </Field>
          </div>
          <p className="text-xs text-muted">
            À enregistrer UNE FOIS LE VIREMENT FAIT. Cet écran ne transfère pas d'argent : il garde
            la trace de ce qui a été payé, et prévient le propriétaire.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" disabled={!valide || busy} onClick={enregistrer}>{busy ? "Enregistrement…" : "Enregistrer"}</Button>
            <Button size="sm" variant="ghost" disabled={busy} onClick={() => setOuvert(false)}>Annuler</Button>
          </div>
        </div>
      ))}
    </div>
  );
}

/** Les signalements, côté équipe. */
function SignalementsTab() {
  const { data, error, reload } = useAsync(() => api.supportQueue(), []);
  if (error) return <Alert tone="bad">{error}</Alert>;
  if (!data) return <p className="text-muted">Chargement…</p>;

  const ouverts = data.filter((s) => ["ouvert", "en_cours"].includes(s.status));
  const traites = data.filter((s) => !["ouvert", "en_cours"].includes(s.status));

  return (
    <div className="flex flex-col gap-4">
      {ouverts.length > 0 && (
        <Alert tone="warn">
          {ouverts.length} signalement{ouverts.length > 1 ? "s" : ""} en attente. Un problème
          d'accès au logement ne peut pas attendre le lendemain.
        </Alert>
      )}
      <h2 className="font-display font-bold text-ink">En attente ({ouverts.length})</h2>
      {ouverts.length === 0 && <p className="text-muted">Aucun signalement en attente.</p>}
      {ouverts.map((s) => <SignalementCard key={s.id} s={s} onDone={reload} />)}

      {traites.length > 0 && (
        <details className="mt-2">
          <summary className="cursor-pointer text-sm font-semibold text-ink">Traités ({traites.length})</summary>
          <div className="mt-3 flex flex-col gap-3">
            {traites.slice(0, 30).map((s) => <SignalementCard key={s.id} s={s} onDone={reload} />)}
          </div>
        </details>
      )}
    </div>
  );
}

function SignalementCard({ s, onDone }: { s: api.TeamSupportRequest; onDone: () => void }) {
  const [reponse, setReponse] = React.useState(s.resolution ?? "");
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);
  const [lab, tone] = api.SUPPORT_STATUS_FR[s.status] ?? [s.status, "neutral" as const];

  const changer = (statut: string) => void (async () => {
    setBusy(true); setErr(null);
    try { await api.setSupportStatus(s.id, statut, reponse); onDone(); }
    catch (e) { setErr(e instanceof Error ? e.message : "Enregistrement impossible."); setBusy(false); }
  })();

  const clos = ["resolu", "clos"].includes(s.status);

  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-ink">{api.supportCategoryLabel(s.category)}</p>
          <p className="text-sm text-muted">
            {s.demandeur ?? "—"} · {s.role_demandeur === "proprietaire" ? "propriétaire" : "voyageur"}
            {s.titre ? ` · ${s.titre}` : ""}{s.ville ? `, ${s.ville}` : ""} · {new Date(s.created_at).toLocaleDateString("fr-FR")}
          </p>
        </div>
        <Pill tone={tone}>{lab}</Pill>
      </div>

      <p className="mt-2 rounded-xl bg-sunk p-3 text-sm text-ink">{s.message}</p>

      {err && <Alert tone="bad">{err}</Alert>}

      {!clos ? (
        <div className="mt-3 flex flex-col gap-2">
          <Field label="Ce qui a été fait" htmlFor={`r-${s.id}`} hint="La personne le lira. Obligatoire pour clore.">
            <input id={`r-${s.id}`} className={inputCls} value={reponse} onChange={(e) => setReponse(e.target.value)}
                   placeholder="Serrure remplacée le jour même." />
          </Field>
          <div className="flex flex-wrap gap-2">
            {s.status === "ouvert" && (
              <Button size="sm" variant="secondary" disabled={busy} onClick={() => changer("en_cours")}>Je m'en occupe</Button>
            )}
            <Button size="sm" disabled={busy || reponse.trim().length < 5} onClick={() => changer("resolu")}>
              {busy ? "…" : "Marquer résolu"}
            </Button>
            <Button size="sm" variant="ghost" disabled={busy || reponse.trim().length < 5} onClick={() => changer("clos")}>Clore sans suite</Button>
            {s.telephone && (
              <Button size="sm" variant="ghost" onClick={() => window.open(`https://wa.me/${s.telephone!.replace(/[^0-9]/g, "")}`, "_blank")}>WhatsApp</Button>
            )}
          </div>
        </div>
      ) : (
        s.resolution && <p className="mt-2 text-sm text-ink"><span className="text-muted">Réponse donnée : </span>{s.resolution}</p>
      )}
    </div>
  );
}

function RefundsTab() {
  const s = useSession();
  const [data, setData] = React.useState<api.TeamRefund[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    let alive = true;
    api.refundsQueue().then((r) => { if (alive) setData(r); })
      .catch((e) => { if (alive) { setError(e instanceof Error ? e.message : "Lecture impossible."); setData([]); } });
    return () => { alive = false; };
  }, [tick]);

  const debloquer = (id: string) => void (async () => {
    setBusy(id); setError(null);
    try { await api.approveRefund(id); setTick((t) => t + 1); }
    catch (e) { setError(e instanceof Error ? e.message : "Déblocage impossible."); }
    finally { setBusy(null); }
  })();

  const attente = (data ?? []).filter((r) => r.status === "demande");
  const autres = (data ?? []).filter((r) => r.status !== "demande");

  return (
    <div className="flex flex-col gap-4">
      {error && <Alert tone="bad">{error}</Alert>}
      {data === null && <p className="text-muted">Chargement…</p>}

      <AnnulationsAExaminer />

      <h2 className="mt-2 font-display font-bold text-ink">Remboursements enregistrés</h2>
      <p className="text-sm text-muted">
        Un remboursement n'est plus créé par l'annulation du voyageur : c'est vous qui l'enregistrez,
        ci-dessus. N'apparaissent ici en attente que ceux qu'un garde-fou a retenus — destination
        inconnue, ou plafond journalier atteint. Vérifiez avant de débloquer.
      </p>

      {data !== null && attente.length === 0 && autres.length === 0 && (
        <div className="rounded-2xl border border-dashed border-line-strong p-10 text-center">
          <p className="text-muted">Aucun remboursement.</p>
        </div>
      )}

      {attente.length > 0 && (
        <div className="flex flex-col gap-3">
          <h2 className="font-display font-bold text-ink">À vérifier ({attente.length})</h2>
          {attente.map((r) => (
            <div key={r.id} className="rounded-2xl border border-warn/40 bg-surface p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold text-ink"><Money value={r.amount_xof} /></p>
                  <p className="text-sm text-muted">Réservation {r.booking_id.slice(0, 8)} · {new Date(r.created_at).toLocaleString("fr-FR")}</p>
                  {r.reason && <p className="mt-1 text-sm text-muted">{r.reason}</p>}
                </div>
                <Pill tone={r.payer_known ? "neutral" : "bad"}>
                  {r.payer_known ? "Destination connue" : "Destination INCONNUE"}
                </Pill>
              </div>
              {!r.payer_known && (
                <Alert tone="bad">
                  Le compte du payeur n'est pas enregistré. Débloquer ne suffira pas à envoyer l'argent :
                  il faudra le verser depuis le tableau de bord du prestataire, vers le compte qui a réellement payé.
                </Alert>
              )}
              <div className="mt-3">
                <Button size="sm" disabled={busy === r.id} onClick={() => debloquer(r.id)}>
                  {busy === r.id ? "Déblocage…" : "Débloquer ce remboursement"}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {autres.length > 0 && (
        <div className="flex flex-col gap-2">
          <h2 className="font-display font-bold text-ink">Suivi</h2>
          {autres.map((r) => {
            const st = RS[r.status] ?? [r.status, "neutral" as const];
            return (
              <div key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-surface p-3">
                <span className="text-sm text-muted">
                  <Money value={r.amount_xof} className="font-medium text-ink" /> · réservation {r.booking_id.slice(0, 8)}
                  {r.provider_reference ? ` · ${r.provider_reference}` : ""}
                  {r.failure_reason ? ` · ${r.failure_reason}` : ""}
                </span>
                <Pill tone={st[1]}>{st[0]}</Pill>
              </div>
            );
          })}
        </div>
      )}

      {s.account?.roles.includes("admin") && <BaremeBlock />}
    </div>
  );
}

/** Le barème, modifiable par l'administrateur seul. La base refuse un barème incohérent
 *  (par exemple un taux « proche » supérieur au taux « loin »), donc rien à revérifier ici. */
function BaremeBlock() {
  const [r, setR] = React.useState<(api.RefundRules & { daily_cap_xof: number }) | null>(null);
  const [ouvert, setOuvert] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [msg, setMsg] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!ouvert || r) return;
    api.refundRules()
      // Le plafond journalier n'est pas exposé au public : il est saisi, pas relu.
      .then((x) => setR(x ? { ...x, daily_cap_xof: 500000 } : null))
      .catch((e) => setError(e instanceof Error ? e.message : "Lecture impossible."));
  }, [ouvert, r]);

  if (!ouvert) {
    return (
      <div className="border-t border-line pt-4">
        <Button variant="ghost" size="sm" onClick={() => setOuvert(true)}>Modifier le barème d'annulation</Button>
      </div>
    );
  }

  const champ = (cle: keyof (api.RefundRules & { daily_cap_xof: number }), label: string, hint?: string) => (
    <Field label={label} htmlFor={`b-${cle}`} hint={hint}>
      <input id={`b-${cle}`} type="number" min={0} className={inputCls}
             value={r ? String(r[cle]) : ""} disabled={!r}
             onChange={(e) => r && setR({ ...r, [cle]: Math.max(0, Math.round(+e.target.value)) })} />
    </Field>
  );

  return (
    <div className="flex flex-col gap-3 border-t border-line pt-4">
      <h2 className="font-display font-bold text-ink">Barème d'annulation</h2>
      {error && <Alert tone="bad">{error}</Alert>}
      {msg && <Alert tone="good">{msg}</Alert>}
      {!r ? <p className="text-muted">Chargement…</p> : (
        <>
          <div className="grid gap-3 sm:grid-cols-2">
            {champ("far_days", "Seuil « loin » (jours)", "Au-delà de ce délai, le taux le plus favorable s'applique.")}
            {champ("far_pct", "Taux « loin » (%)")}
            {champ("mid_days", "Seuil « moyen » (jours)")}
            {champ("mid_pct", "Taux « moyen » (%)")}
            {champ("near_pct", "Taux « proche » (%)", "En dessous du seuil « moyen ».")}
            {champ("started_pct", "Taux après le début du séjour (%)")}
            {champ("daily_cap_xof", "Plafond journalier (FCFA)", "Au-delà de ce total remboursé en une journée, les remboursements attendent une vérification.")}
          </div>
          <p className="text-sm text-muted">
            Les taux doivent décroître : « proche » ne peut pas dépasser « moyen », ni « moyen » dépasser « loin ».
            La base refuse tout barème incohérent.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button disabled={busy} onClick={() => void (async () => {
              setBusy(true); setError(null); setMsg(null);
              try { await api.saveRefundRules(r); setMsg("Barème enregistré."); }
              catch (e) { setError(e instanceof Error ? e.message : "Enregistrement impossible."); }
              finally { setBusy(false); }
            })()}>{busy ? "Enregistrement…" : "Enregistrer le barème"}</Button>
            <Button variant="ghost" disabled={busy} onClick={() => setOuvert(false)}>Fermer</Button>
          </div>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------
export function EquipeYiri({ onLogin }: { onLogin: () => void }) {
  const s = useSession();
  const [tab, setTab] = React.useState<Tab>("identites");

  if (!s.ready) return <p className="py-16 text-center text-muted">Chargement…</p>;
  if (!s.account) {
    return (
      <div className="mx-auto max-w-md py-16">
        <h1 className="font-display text-2xl font-bold text-ink">Espace équipe YIRI</h1>
        <p className="mt-2 text-muted">Connectez-vous avec votre compte YIRI.</p>
        <Button className="mt-5" size="lg" onClick={onLogin}>Se connecter</Button>
      </div>
    );
  }

  const isTeam = s.account.roles.includes("admin") || s.account.perms.length > 0;
  if (!isTeam) {
    return (
      <div className="mx-auto max-w-md py-16">
        <h1 className="font-display text-2xl font-bold text-ink">Accès refusé</h1>
        <p className="mt-2 text-muted">Votre compte n'appartient pas à l'équipe YIRI. Si c'est une erreur, demandez à un administrateur de vous accorder une autorisation.</p>
      </div>
    );
  }

  const tabs: [Tab, string, boolean][] = [
    ["identites", "Pièces d'identité", s.can("validation")],
    ["annonces", "Annonces", s.can("validation")],
    ["reservations", "Réservations", s.can("reservations") || s.can("paiements")],
    ["abonnements", "Abonnements", s.can("validation") || s.can("paiements")],
    ["demandes", "Demandes", s.can("demandes") || s.can("partenariat")],
    ["paiements", "Paiements", s.can("paiements")],
    ["remboursements", "Remboursements", s.can("paiements")],
    ["revenus", "Revenus propriétaires", s.can("paiements")],
    ["signalements", "Signalements", s.can("demandes") || s.can("reservations")],
    ["nettoyage", "Nettoyage", s.can("validation")],
    ["journal", "Journal", s.can("audit")],
    ["equipe", "Équipe et accès", s.account.roles.includes("admin")],
  ];
  const allowed = tabs.filter(([, , ok]) => ok);
  const current = allowed.some(([t]) => t === tab) ? tab : allowed[0]?.[0];

  return (
    <div className="flex flex-col gap-5 py-8">
      <div>
        <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">Espace équipe YIRI</h1>
        <p className="mt-1 text-muted">
          Connecté en tant que {s.account.fullName || s.account.email}
          {s.account.roles.includes("admin") ? " · administrateur" : ` · ${s.account.perms.join(", ")}`}
        </p>
      </div>

      {allowed.length === 0 && <Alert tone="warn">Aucune autorisation ne vous a encore été accordée.</Alert>}

      {/* L'équipe est la première concernée : c'est elle qui doit apprendre qu'une réservation
          a été payée, sans avoir à ouvrir le site. */}
      <AlertesAppareil compact />

      <div className="flex flex-wrap gap-1.5">
        {allowed.map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)} aria-pressed={current === t}
                  className={`rounded-full px-3.5 py-1.5 text-sm font-semibold cursor-pointer ${current === t ? "bg-ink text-bg" : "bg-sunk text-ink hover:bg-line"}`}>
            {label}
          </button>
        ))}
      </div>

      {current === "identites" && <IdentitiesTab />}
      {current === "annonces" && <ListingsTab />}
      {current === "reservations" && <BookingsTab />}
      {current === "abonnements" && <SubscriptionsTab />}
      {current === "demandes" && <RequestsTab />}
      {current === "paiements" && <PaymentsTab />}
      {current === "remboursements" && <RefundsTab />}
      {current === "revenus" && <RevenusTab />}
      {current === "signalements" && <SignalementsTab />}
      {current === "nettoyage" && <CleanupTab />}
      {current === "journal" && <JournalTab />}
      {current === "equipe" && <TeamTab moi={s.account.id} />}
    </div>
  );
}
