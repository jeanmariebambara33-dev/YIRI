-- YIRI — planification de l'expiration des blocages de réservation (toutes les minutes).
-- À exécuter UNE FOIS dans l'éditeur SQL du projet de préproduction, après avoir activé l'extension pg_cron
-- (tableau de bord → Database → Extensions → pg_cron). La migration 0006 le fait déjà si pg_cron était actif au moment
-- de son application ; ce script sert si l'extension a été activée APRÈS, et peut être relancé sans danger.
select cron.unschedule('yiri-expire-holds') where exists (select 1 from cron.job where jobname = 'yiri-expire-holds');
select cron.schedule('yiri-expire-holds', '* * * * *', 'select public.expire_booking_holds()');
-- Vérification : une ligne attendue, active = true
select jobname, schedule, active from cron.job where jobname = 'yiri-expire-holds';
-- Historique des exécutions (après quelques minutes) : status = 'succeeded'
-- select status, return_message, start_time from cron.job_run_details order by start_time desc limit 5;
