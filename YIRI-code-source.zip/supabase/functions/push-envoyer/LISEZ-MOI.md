# Les alertes sur le téléphone — ce que tu dois faire, dans l'ordre

Six étapes. Rien à payer, aucun compte à créer. Les clés, c'est toi qui les fabriques : je ne
les vois pas, et elles n'ont pas à sortir de ton ordinateur.

---

## 1. Fabriquer les clés

Ouvre le fichier **`cles-vapid.html`** (double-clic ; il s'ouvre dans ton navigateur) et clique
sur **Fabriquer mes clés**.

Le fichier ne charge rien et n'envoie rien : tu peux couper internet avant de cliquer. Deux clés
s'affichent :

- la **clé publique** — faite pour être lue par tous les téléphones, aucun risque ;
- la **clé privée** — à ne montrer à personne, jamais. Pas à moi.

Garde l'onglet ouvert le temps des étapes 2 et 3 : il ne conserve rien, et rouvrir le fichier
fabriquerait une autre paire, qui ne marcherait pas avec celle déjà installée.

---

## 2. La migration, dans l'éditeur SQL

Colle **`0017_notifications_push.sql`** en entier dans Supabase → **SQL Editor** → **Run**.

Puis, dans la même fenêtre, remplace `TA_CLE_PUBLIQUE` par la clé **publique** et exécute :

```sql
insert into public_settings (key, value)
values ('push_vapid_public', 'TA_CLE_PUBLIQUE')
on conflict (key) do update set value = excluded.value, updated_at = now();
```

Pour vérifier d'un coup d'œil que c'est bien passé :

```sql
select left(value, 12) || '…' as cle_posee, length(value) as longueur
  from public_settings where key = 'push_vapid_public';
```

`longueur` doit afficher **87**. Si elle affiche autre chose, la clé a été tronquée au collage :
recolle-la.

---

## 3. Les deux secrets

Supabase → **Edge Functions** → **Secrets**. Trois noms à ajouter :

| Nom | Valeur |
|---|---|
| `VAPID_PRIVATE_KEY` | la clé **privée** |
| `PUSH_TRIGGER_SECRET` | une phrase que tu inventes, longue et sans espaces — elle sert de mot de passe au déclencheur de l'étape 5 |

La clé **publique** n'est pas ici : elle est déjà en base, à l'étape 2, et la fonction la lira
là. Une seule copie, donc aucun risque qu'elle finisse différente à deux endroits — ce qui
aurait fait échouer tous les envois sans message clair.

Pour `PUSH_TRIGGER_SECRET`, n'importe quelle suite longue convient, par exemple
`yiri-push-2026-un-truc-que-personne-ne-devine`. Garde-la sous la main pour l'étape 5.

Tu peux maintenant fermer l'onglet des clés.

---

## 4. Déployer la fonction

```
supabase functions deploy push-envoyer --no-verify-jwt
```

`--no-verify-jwt` est **nécessaire** : cette fonction est appelée par la base, qui n'a pas de
compte utilisateur. Sa preuve d'identité est l'en-tête secret de l'étape 3, vérifié avant toute
autre chose.

---

## 5. Le déclencheur : que l'envoi parte tout seul

Supabase → **Database** → **Webhooks** → **Create a new hook**.

| Champ | Valeur |
|---|---|
| Name | `yiri-push` |
| Table | `notifications` |
| Events | **Insert** uniquement |
| Type | HTTP Request |
| Method | `POST` |
| URL | `https://kzzrowymwwxoydklnkfb.supabase.co/functions/v1/push-envoyer` |
| HTTP Headers | nom `x-yiri-push`, valeur : la phrase de `PUSH_TRIGGER_SECRET` |

À chaque notification écrite par la base, l'envoi part dans la seconde.

Un oubli se répare tout seul : la fonction ne traite pas seulement la notification qui vient
d'arriver, elle vide toute la file en attente. Si un déclenchement est raté, le suivant rattrape.

---

## 6. Vérifier, sur ton propre téléphone

1. Sur ton téléphone, ouvre le site et **ajoute-le à l'écran d'accueil**
   (sur iPhone c'est **obligatoire** : Safari ne pousse rien à un simple onglet).
2. Ouvre YIRI depuis l'icône, connecte-toi, va dans **Mon compte**.
3. Appuie sur **Activer les alertes** et accepte la demande du téléphone.
4. Depuis un ordinateur, dans l'éditeur SQL, envoie-toi une alerte d'essai — remplace l'adresse
   par la tienne :

```sql
insert into notifications (user_id, type, payload)
select id, 'booking.confirmee', '{"titre": "Essai des alertes"}'
  from profiles where id = (select id from auth.users where email = 'ton.adresse@exemple.com');
```

La notification doit arriver sur le téléphone **en quelques secondes**, site fermé. Un appui
dessus doit ouvrir YIRI au bon endroit.

Puis efface l'essai :

```sql
delete from notifications where payload->>'titre' = 'Essai des alertes';
```

---

## Si rien n'arrive

Dans l'ordre, du plus fréquent au plus rare :

1. **Supabase → Edge Functions → push-envoyer → Logs.** Le message dit lequel des deux secrets
   manque, si la clé publique n'est pas posée en base, ou si une clé est mal collée.
2. **Rien du tout dans les logs** → le déclencheur de l'étape 5 ne part pas. Vérifie que l'en-tête
   `x-yiri-push` est bien écrit et que sa valeur est exactement celle du secret.
3. **`401 refusé`** → l'en-tête ne correspond pas au secret.
4. **La fonction répond `{"envoyees": 0}`** → la base n'a rien à envoyer. Soit l'appareil n'est pas
   enregistré (refais l'étape 6), soit la personne n'a pas l'autorisation correspondante : une
   alerte d'équipe ne part qu'à qui a l'autorisation voulue, et c'est voulu.
5. **La notification arrive sur Android mais pas sur iPhone** → le site n'a pas été ajouté à
   l'écran d'accueil sur cet iPhone, ou il a été ouvert depuis un onglet Safari ordinaire.

Pour voir où en est la file sans rien envoyer :

```sql
select type, count(*) filter (where pushed_at is null) as en_attente,
       count(*) filter (where pushed_at is not null) as parties,
       max(push_attempts) as tentatives_max
  from notifications
 where created_at > now() - interval '2 days'
 group by type order by en_attente desc;
```

---

## Ce qui reste vrai quoi que tu fasses

- **La clé privée ne quitte jamais les secrets Supabase.** Si elle fuite, refabrique la paire
  avec `cles-vapid.html`, remplace les deux clés : les téléphones se réenregistrent tout seuls
  à la prochaine ouverture du site.
- **Qui reçoit quoi n'est pas décidé par le téléphone.** Un appareil enregistré ne donne aucun
  droit. Retirer une autorisation à quelqu'un coupe ses alertes à l'envoi suivant, sans toucher
  à son téléphone.
- **Le contenu est chiffré de bout en bout.** Google et Apple transportent les alertes sans
  pouvoir les lire.
- **Personne ne voit les appareils de personne**, pas même un administrateur. C'est une donnée
  de localisation déguisée.
