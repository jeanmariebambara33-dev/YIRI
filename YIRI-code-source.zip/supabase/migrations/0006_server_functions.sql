-- YIRI — 0006 : fonctions serveur (RPC) pour les opérations sensibles.
-- Principes :
--  * l'identité vient UNIQUEMENT de auth.uid() (jamais d'un paramètre) ; refus si non connecté ;
--  * montants, prix, statuts, rôles et permissions ne sont JAMAIS lus depuis le navigateur : tout est recalculé ici ;
--  * chaque fonction « SECURITY DEFINER » fixe son search_path, valide explicitement son appelant (rôle / autorisation
--    déléguée / propriété de l'objet) et n'accorde AUCUN droit d'exécution à « anon » ;
--  * la confirmation des paiements reste MANUELLE (équipe, autorisation « paiements ») : aucune confirmation
--    automatique Chariow, aucun reversement ni remboursement n'est géré ici ;
--  * verrous : toujours dans le même ordre (logement, puis réservation / abonnement) pour éviter les blocages croisés ;
--  * ce fichier est additif : 0001 à 0005 ne sont pas modifiées.

-- =====================================================================
-- 0. Outils internes (non appelables depuis le navigateur)
-- =====================================================================
create or replace function require_user() returns uuid
language plpgsql stable as $$
declare u uuid := auth.uid();
begin
  if u is null then
    raise exception 'Connexion requise.' using errcode = '28000';
  end if;
  return u;
end $$;
revoke all on function require_user() from public, anon, authenticated;

-- Garde-fous de données : un seul paiement « réussi » par cible, un seul avis ouvert par cible.
create unique index if not exists payment_success_booking_uidx
  on payment_transactions (booking_id) where purpose = 'booking' and status = 'reussi';
create unique index if not exists payment_success_subscription_uidx
  on payment_transactions (subscription_id) where purpose = 'subscription' and status = 'reussi';
create unique index if not exists payment_notice_open_booking_uidx
  on payment_notices (booking_id) where status = 'nouveau' and booking_id is not null;
create unique index if not exists payment_notice_open_subscription_uidx
  on payment_notices (subscription_id) where status = 'nouveau' and subscription_id is not null;

-- Prolongation du blocage : au plus UNE fois par réservation, plafonnée, tracée (voir declare_payment).
alter table bookings add column if not exists hold_extensions int not null default 0
  check (hold_extensions between 0 and 1);

create or replace function bookings_hold_guard() returns trigger language plpgsql as $$
begin
  -- Aucune modification du blocage depuis le navigateur (en plus de l'absence de policy d'écriture).
  if tg_op = 'UPDATE' and current_user in ('authenticated', 'anon')
     and (new.hold_expires_at is distinct from old.hold_expires_at or new.hold_extensions <> old.hold_extensions) then
    raise exception 'Le blocage d''une réservation ne se modifie pas directement.';
  end if;
  -- Plafond absolu, pour tous (même les fonctions serveur) : 15 min + une prolongation de 2 h au plus.
  if new.hold_expires_at is not null and new.hold_expires_at > new.created_at + interval '2 hours 15 minutes' then
    raise exception 'Le blocage ne peut pas dépasser 2 h 15 après la création de la réservation.';
  end if;
  return new;
end $$;
create trigger bookings_hold_guard_trg before insert or update of hold_expires_at, hold_extensions on bookings
  for each row execute function bookings_hold_guard();

-- Un avis « J'ai payé » ne se crée plus que par declare_payment() (qui vérifie la cible et prolonge le blocage).
drop policy if exists payment_notices_insert on payment_notices;
revoke insert on payment_notices from anon, authenticated;

-- =====================================================================
-- 1. Réservation sécurisée (prix et dates contrôlés par le serveur, blocage 15 min atomique)
-- =====================================================================
create or replace function create_booking(p_property uuid, p_start date, p_end date, p_guests int)
returns bookings
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  prop properties%rowtype;
  nights int;
  holds int;
  b bookings%rowtype;
begin
  if p_property is null or p_start is null or p_end is null or p_guests is null then
    raise exception 'Informations de réservation incomplètes.';
  end if;
  perform enforce_rate_limit('book:' || uid::text, 20, interval '1 hour');

  -- 1er verrou : le logement (sérialise toutes les réservations et blocages de dates de ce logement).
  select * into prop from properties where id = p_property for update;
  if not found or not exists (select 1 from public_listings l where l.id = p_property) then
    raise exception 'Ce logement n''est pas disponible à la réservation.';
  end if;
  if prop.offer <> 'gestion' then
    raise exception 'Ce logement ne se réserve pas en ligne : contactez directement le propriétaire.';
  end if;
  if prop.owner_id = uid then
    raise exception 'Vous ne pouvez pas réserver votre propre logement.';
  end if;

  if p_start < current_date or p_end <= p_start then
    raise exception 'Dates invalides : l''arrivée doit être future et le départ après l''arrivée.';
  end if;
  if p_start > current_date + 365 then
    raise exception 'Réservation possible jusqu''à un an à l''avance.';
  end if;
  nights := p_end - p_start;
  if nights < prop.min_nights then
    raise exception 'Séjour minimum : % nuit(s).', prop.min_nights;
  end if;
  if nights > 90 then
    raise exception 'Séjour maximum : 90 nuits.';
  end if;
  if p_guests < 1 or p_guests > prop.capacity then
    raise exception 'Nombre de voyageurs invalide (maximum : %).', prop.capacity;
  end if;

  -- Libère les blocages expirés de ce logement, puis limite les blocages simultanés d'un même voyageur.
  perform release_expired_holds(prop.id);
  select count(*) into holds from bookings
   where guest_id = uid and status = 'en_attente_paiement' and hold_expires_at > now();
  if holds >= 3 then
    raise exception 'Vous avez déjà 3 réservations en attente de paiement. Finalisez-les ou attendez leur expiration.';
  end if;

  begin
    insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof,
                          discount_xof, taxes_xof, total_xof, status, hold_expires_at)
    values (prop.id, uid, daterange(p_start, p_end), p_guests, prop.nightly_price_xof,
            nights * prop.nightly_price_xof, 0, 0, nights * prop.nightly_price_xof,
            'en_attente_paiement', now() + interval '15 minutes')
    returning * into b;
  exception when exclusion_violation then
    raise exception 'Ces dates ne sont plus disponibles.' using errcode = '23P01';
  end;
  return b;
end $$;
revoke all on function create_booking(uuid, date, date, int) from public, anon;
grant execute on function create_booking(uuid, date, date, int) to authenticated;

-- =====================================================================
-- 2. Expiration des blocages (tâche planifiée) — ne touche jamais une réservation confirmée
-- =====================================================================
create or replace function expire_booking_holds() returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  -- Les lignes en cours de traitement par une autre transaction (ex. confirmation) sont sautées, jamais bloquées.
  with cand as (
    select b.id from bookings b
     where b.status = 'en_attente_paiement'
       and b.hold_expires_at is not null and b.hold_expires_at < now()
       and not exists (select 1 from payment_transactions t where t.booking_id = b.id and t.status = 'reussi')
     for update skip locked
  )
  update bookings set status = 'expiree' from cand where bookings.id = cand.id;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function expire_booking_holds() from public, anon, authenticated;

-- Libération « paresseuse » (appelée avant toute réservation / blocage de dates d'un logement) : mêmes garanties que la tâche
-- planifiée — jamais une réservation confirmée, jamais une réservation ayant un paiement réussi. (Remplace la version de 0005.)
create or replace function release_expired_holds(p_property uuid, p_except uuid default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  update bookings set status = 'expiree'
   where id in (
     select b.id from bookings b
      where b.property_id = p_property and b.status = 'en_attente_paiement'
        and b.hold_expires_at is not null and b.hold_expires_at < now()
        and b.id is distinct from p_except
        and not exists (select 1 from payment_transactions t where t.booking_id = b.id and t.status = 'reussi')
      for update skip locked);
end $$;
revoke all on function release_expired_holds(uuid, uuid) from public, anon, authenticated;

-- Planification chaque minute si l'extension pg_cron est disponible (sinon : à configurer, voir README).
do $$
begin
  if to_regnamespace('cron') is null then
    raise notice 'pg_cron absent : planifier expire_booking_holds() chaque minute (tâche à configurer sur Supabase).';
  else
    begin
      perform cron.schedule('yiri-expire-holds', '* * * * *', 'select public.expire_booking_holds()');
    exception when others then
      raise notice 'Planification pg_cron impossible (%). À configurer manuellement.', sqlerrm;
    end;
  end if;
end $$;

-- =====================================================================
-- 3. Révélation contrôlée des coordonnées (offre Visibilité)
-- =====================================================================
create or replace function reveal_contact(p_property uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  prop properties%rowtype;
  c property_contacts%rowtype;
begin
  select * into prop from properties where id = p_property;
  if not found or prop.offer <> 'annonce'
     or not exists (select 1 from public_listings l where l.id = p_property) then
    raise exception 'Contact indisponible.';
  end if;
  if prop.owner_id = uid then
    raise exception 'Il s''agit de votre propre annonce.';
  end if;
  select * into c from property_contacts where property_id = p_property;
  if not found then
    raise exception 'Contact indisponible.';
  end if;

  -- Une consultation = un voyageur, une annonce, par tranche de 24 h. Une 2e lecture rapprochée ne coûte rien.
  perform pg_advisory_xact_lock(hashtextextended(uid::text || p_property::text, 0));
  if not exists (select 1 from contact_views
                  where property_id = p_property and viewer_id = uid and viewed_at > now() - interval '24 hours') then
    perform enforce_rate_limit('reveal-h:' || uid::text, 10, interval '1 hour');
    perform enforce_rate_limit('reveal-d:' || uid::text, 30, interval '1 day');
    insert into contact_views (property_id, viewer_id) values (p_property, uid);
  end if;
  return jsonb_build_object('contact_name', c.contact_name, 'phone', c.phone, 'whatsapp', c.whatsapp);
end $$;
revoke all on function reveal_contact(uuid) from public, anon;
grant execute on function reveal_contact(uuid) to authenticated;

-- =====================================================================
-- 4. Déclaration « J'ai payé » (un signalement, jamais une preuve)
-- =====================================================================
create or replace function declare_payment(p_object text, p_id uuid, p_amount int,
                                           p_reference text default null, p_message text default null)
returns payment_notices
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  sb subscriptions%rowtype;
  nt payment_notices%rowtype;
begin
  if p_object not in ('reservation', 'abonnement') or p_id is null then
    raise exception 'Objet de paiement invalide.';
  end if;
  if p_amount is null or p_amount <= 0 or p_amount > 100000000 then
    raise exception 'Montant invalide.';
  end if;

  if p_object = 'reservation' then
    select * into bk from bookings where id = p_id;
    if not found or bk.guest_id <> uid then
      raise exception 'Réservation introuvable.';   -- même message : on ne révèle pas l'existence des réservations d'autrui
    end if;
    perform 1 from properties where id = bk.property_id for update;
    select * into bk from bookings where id = p_id for update;
    if bk.status not in ('en_attente_paiement', 'expiree') then
      raise exception 'Cette réservation n''attend pas de paiement.';
    end if;
    select * into nt from payment_notices where booking_id = bk.id and status = 'nouveau';
    if found then return nt; end if;      -- déjà signalé : idempotent
    insert into payment_notices (user_id, object, booking_id, declared_amount_xof, reference, message)
    values (uid, 'reservation', bk.id, p_amount, left(p_reference, 40), left(p_message, 400))
    returning * into nt;
    -- Prolongation du blocage (15 min → 2 h) pendant que l'équipe vérifie la réception. Conditions cumulatives :
    -- déclaration valide (montant déclaré = montant dû), blocage encore actif, jamais déjà prolongé (1 fois maximum).
    -- Elle ne confirme RIEN et ne ravive jamais une réservation expirée.
    if bk.status = 'en_attente_paiement' and bk.hold_expires_at > now()
       and bk.hold_extensions = 0 and p_amount = bk.total_xof then
      update bookings set hold_expires_at = now() + interval '2 hours', hold_extensions = 1 where id = bk.id;
      insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
      values (uid, 'booking.hold_extended', 'booking', bk.id::text,
              jsonb_build_object('hold_expires_at', bk.hold_expires_at),
              jsonb_build_object('hold_expires_at', now() + interval '2 hours', 'notice_id', nt.id, 'declared_xof', p_amount));
    end if;
  else
    select * into sb from subscriptions where id = p_id;
    if not found or sb.owner_id <> uid then
      raise exception 'Abonnement introuvable.';
    end if;
    select * into sb from subscriptions where id = p_id for update;
    if sb.status <> 'en_attente_paiement' then
      raise exception 'Cet abonnement n''attend pas de paiement.';
    end if;
    select * into nt from payment_notices where subscription_id = sb.id and status = 'nouveau';
    if found then return nt; end if;
    insert into payment_notices (user_id, object, subscription_id, declared_amount_xof, reference, message)
    values (uid, 'abonnement', sb.id, p_amount, left(p_reference, 40), left(p_message, 400))
    returning * into nt;
  end if;
  return nt;
end $$;
revoke all on function declare_payment(text, uuid, int, text, text) from public, anon;
grant execute on function declare_payment(text, uuid, int, text, text) to authenticated;

-- =====================================================================
-- 5. Conditions de publication d'une annonce (partagées par les fonctions et par un garde-fou)
-- =====================================================================
create or replace function _listing_publish_problem(p_property uuid) returns text
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare p properties%rowtype;
begin
  select * into p from properties where id = p_property;
  if not found then return 'Annonce introuvable.'; end if;
  if p.is_demo then return 'Une annonce de démonstration ne se publie pas.'; end if;
  if p.offer = 'annonce' then
    if not exists (select 1 from subscriptions s
                    where s.property_id = p.id and s.status = 'actif'
                      and current_date >= s.starts_at and current_date < s.ends_at) then
      return 'Un abonnement actif (paiement confirmé) est requis.';
    end if;
    if not exists (select 1 from property_contacts c where c.property_id = p.id) then
      return 'Le contact du propriétaire est manquant.';
    end if;
  else
    if not exists (select 1 from management_agreements m
                    where m.property_id = p.id and m.signed and m.operational_check_done) then
      return 'Un contrat signé et la vérification opérationnelle sont requis.';
    end if;
  end if;
  if not exists (select 1 from property_photos ph where ph.property_id = p.id and ph.rights_checked) then
    return 'Au moins une photo aux droits vérifiés est requise.';
  end if;
  return null;
end $$;
revoke all on function _listing_publish_problem(uuid) from public, anon, authenticated;

-- Version appelable : seulement pour le propriétaire de l'annonce ou l'équipe « validation ».
create or replace function listing_publish_problem(p_property uuid) returns text
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is null
     or not (exists (select 1 from properties where id = p_property and owner_id = auth.uid()) or has_perm('validation')) then
    return 'Annonce introuvable.';
  end if;
  return _listing_publish_problem(p_property);
end $$;
revoke all on function listing_publish_problem(uuid) from public, anon;
grant execute on function listing_publish_problem(uuid) to authenticated;

-- Garde-fou : même une modification directe par le navigateur ne peut pas publier une annonce qui ne remplit pas les conditions.
create or replace function properties_publish_guard() returns trigger language plpgsql as $$
declare problem text;
begin
  if current_user not in ('authenticated', 'anon') then return new; end if;
  if new.status = 'publiee' and old.status is distinct from 'publiee' then
    problem := listing_publish_problem(new.id);
    if problem is not null then
      raise exception 'Publication refusée : %', problem;
    end if;
  end if;
  return new;
end $$;
create trigger properties_publish_guard_trg before update of status on properties
  for each row execute function properties_publish_guard();

-- =====================================================================
-- 6. Confirmation MANUELLE d'un paiement par l'équipe (autorisation « paiements »)
-- =====================================================================
create or replace function confirm_payment(p_object text, p_id uuid, p_received_amount_xof int)
returns payment_transactions
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  sb subscriptions%rowtype;
  tx payment_transactions%rowtype;
  prop_id uuid;
  expected int;
  base date;
  st date;
  en date;
  before_status text;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  if p_object not in ('reservation', 'abonnement') or p_id is null then
    raise exception 'Objet de paiement invalide.';
  end if;
  if p_received_amount_xof is null or p_received_amount_xof <= 0 then
    raise exception 'Indiquez le montant réellement reçu.';
  end if;

  if p_object = 'reservation' then
    select property_id into prop_id from bookings where id = p_id;
    if not found then raise exception 'Réservation introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;         -- 1er verrou : le logement
    select * into bk from bookings where id = p_id for update;       -- 2e verrou : la réservation
    if bk.guest_id = uid then
      raise exception 'Vous ne pouvez pas confirmer votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where booking_id = bk.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé.' using errcode = '23505';
    end if;
    if bk.status not in ('en_attente_paiement', 'expiree') then
      raise exception 'Cette réservation ne peut plus être confirmée (statut : %).', bk.status;
    end if;
    expected := bk.total_xof;
    if p_received_amount_xof <> expected then
      raise exception 'Montant reçu (%) différent du montant attendu (%). Rien n''a été confirmé.', p_received_amount_xof, expected;
    end if;
    before_status := bk.status::text;
    begin
      update bookings set status = 'confirmee', hold_expires_at = null where id = bk.id;
    exception when exclusion_violation then
      raise exception 'Les dates ont été reprises depuis l''expiration du blocage : confirmation impossible. Un remboursement éventuel doit être organisé hors plateforme.'
        using errcode = '23P01';
    end;
    select * into tx from payment_transactions
     where booking_id = bk.id and purpose = 'booking' and status in ('cree', 'en_attente')
     order by created_at desc limit 1 for update;
    if found then
      update payment_transactions
         set status = 'reussi', amount_xof = expected, received_amount_xof = p_received_amount_xof,
             confirmed_by = uid, confirmed_at = now(), updated_at = now()
       where id = tx.id returning * into tx;
    else
      insert into payment_transactions (purpose, booking_id, provider, idempotency_key, amount_xof, status,
                                        received_amount_xof, confirmed_by, confirmed_at)
      values ('booking', bk.id, 'chariow', 'manual:booking:' || bk.id::text, expected, 'reussi',
              p_received_amount_xof, uid, now())
      returning * into tx;
    end if;
    insert into financial_ledger (booking_id, transaction_id, entry_type, credit_xof, description)
    values (bk.id, tx.id, 'paiement_voyageur', expected, 'Paiement reçu, confirmé manuellement par l''équipe');
    update payment_notices set status = 'traite', handled_by = uid, handled_at = now()
     where booking_id = bk.id and status = 'nouveau';
    insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
    values (uid, 'payment.confirmed', 'booking', bk.id::text,
            jsonb_build_object('status', before_status),
            jsonb_build_object('status', 'confirmee', 'expected_xof', expected, 'received_xof', p_received_amount_xof,
                               'transaction_id', tx.id));
  else
    select property_id into prop_id from subscriptions where id = p_id;
    if not found then raise exception 'Abonnement introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;
    select * into sb from subscriptions where id = p_id for update;
    if sb.owner_id = uid then
      raise exception 'Vous ne pouvez pas confirmer votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where subscription_id = sb.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé.' using errcode = '23505';
    end if;
    if sb.status <> 'en_attente_paiement' then
      raise exception 'Cet abonnement ne peut plus être activé (statut : %).', sb.status;
    end if;
    expected := case sb.plan when 'mensuel' then 5000 else 30000 end;   -- tarif recalculé, jamais lu du navigateur
    if sb.amount_xof <> expected or p_received_amount_xof <> expected then
      raise exception 'Montant reçu (%) différent du montant attendu (%). Rien n''a été confirmé.', p_received_amount_xof, expected;
    end if;
    -- Un renouvellement commence à la fin de l'abonnement actif (aucune journée perdue).
    select coalesce(max(ends_at), current_date) into base
      from subscriptions where property_id = sb.property_id and status = 'actif' and ends_at > current_date;
    st := greatest(current_date, base);
    en := (st + case sb.plan when 'mensuel' then interval '1 month' else interval '1 year' end)::date;
    update subscriptions set status = 'actif', starts_at = st, ends_at = en where id = sb.id;
    select * into tx from payment_transactions
     where subscription_id = sb.id and purpose = 'subscription' and status in ('cree', 'en_attente')
     order by created_at desc limit 1 for update;
    if found then
      update payment_transactions
         set status = 'reussi', amount_xof = expected, received_amount_xof = p_received_amount_xof,
             confirmed_by = uid, confirmed_at = now(), updated_at = now()
       where id = tx.id returning * into tx;
    else
      insert into payment_transactions (purpose, subscription_id, provider, idempotency_key, amount_xof, status,
                                        received_amount_xof, confirmed_by, confirmed_at)
      values ('subscription', sb.id, 'chariow', 'manual:subscription:' || sb.id::text, expected, 'reussi',
              p_received_amount_xof, uid, now())
      returning * into tx;
    end if;
    insert into financial_ledger (transaction_id, entry_type, credit_xof, description)
    values (tx.id, 'abonnement', expected, 'Abonnement payé, confirmé manuellement par l''équipe');
    update payment_notices set status = 'traite', handled_by = uid, handled_at = now()
     where subscription_id = sb.id and status = 'nouveau';
    -- Une annonce DÉJÀ approuvée par l'équipe « validation » est publiée dès que son abonnement est actif
    -- (aucune décision nouvelle : la validation a déjà eu lieu). Sinon elle reste en l'état.
    if exists (select 1 from properties where id = sb.property_id and status = 'approuvee')
       and _listing_publish_problem(sb.property_id) is null then
      update properties set status = 'publiee', review_note = null where id = sb.property_id;
    end if;
    insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
    values (uid, 'payment.confirmed', 'subscription', sb.id::text,
            jsonb_build_object('status', 'en_attente_paiement'),
            jsonb_build_object('status', 'actif', 'starts_at', st, 'ends_at', en, 'expected_xof', expected,
                               'received_xof', p_received_amount_xof, 'transaction_id', tx.id));
  end if;
  return tx;
end $$;
revoke all on function confirm_payment(text, uuid, int) from public, anon;
grant execute on function confirm_payment(text, uuid, int) to authenticated;

-- « Non reçu » : l'équipe clôt l'avis ; une réservation non payée libère ses dates.
create or replace function reject_payment(p_object text, p_id uuid, p_note text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  sb subscriptions%rowtype;
  prop_id uuid;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  if p_object not in ('reservation', 'abonnement') or p_id is null then
    raise exception 'Objet de paiement invalide.';
  end if;
  if char_length(coalesce(btrim(p_note), '')) < 5 then
    raise exception 'Indiquez un motif (5 caractères minimum).';
  end if;

  if p_object = 'reservation' then
    select property_id into prop_id from bookings where id = p_id;
    if not found then raise exception 'Réservation introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;
    select * into bk from bookings where id = p_id for update;
    if bk.guest_id = uid then
      raise exception 'Vous ne pouvez pas traiter votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where booking_id = bk.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé : impossible de le marquer « non reçu ».';
    end if;
    if bk.status = 'en_attente_paiement' then
      update bookings set status = 'expiree', hold_expires_at = null where id = bk.id;
    end if;
    update payment_transactions set status = 'echoue', updated_at = now()
     where booking_id = bk.id and status in ('cree', 'en_attente');
    update payment_notices set status = 'traite', handled_by = uid, handled_at = now()
     where booking_id = bk.id and status = 'nouveau';
    insert into audit_logs (actor_id, action, entity_type, entity_id, reason)
    values (uid, 'payment.rejected', 'booking', bk.id::text, btrim(p_note));
  else
    select property_id into prop_id from subscriptions where id = p_id;
    if not found then raise exception 'Abonnement introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;
    select * into sb from subscriptions where id = p_id for update;
    if sb.owner_id = uid then
      raise exception 'Vous ne pouvez pas traiter votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where subscription_id = sb.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé : impossible de le marquer « non reçu ».';
    end if;
    update payment_transactions set status = 'echoue', updated_at = now()
     where subscription_id = sb.id and status in ('cree', 'en_attente');
    update payment_notices set status = 'traite', handled_by = uid, handled_at = now()
     where subscription_id = sb.id and status = 'nouveau';
    insert into audit_logs (actor_id, action, entity_type, entity_id, reason)
    values (uid, 'payment.rejected', 'subscription', sb.id::text, btrim(p_note));
  end if;
end $$;
revoke all on function reject_payment(text, uuid, text) from public, anon;
grant execute on function reject_payment(text, uuid, text) to authenticated;

-- =====================================================================
-- 7. Rôle propriétaire : demande par l'utilisateur, attribution par l'équipe
-- =====================================================================
create or replace function request_owner_role(p_proof_type text default null) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  perform enforce_rate_limit('ownerreq:' || uid::text, 5, interval '1 day');
  insert into owner_profiles (user_id, proof_type) values (uid, left(btrim(p_proof_type), 60))
  on conflict (user_id) do update set proof_type = coalesce(excluded.proof_type, owner_profiles.proof_type)
   where owner_profiles.verification_status = 'en_attente';      -- une demande vérifiée ou refusée ne se rouvre pas
end $$;
revoke all on function request_owner_role(text) from public, anon;
grant execute on function request_owner_role(text) to authenticated;

create or replace function grant_owner_role(p_user uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  if not has_any_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  if p_user is null or p_user = uid then
    raise exception 'Vous ne pouvez pas vous attribuer ce rôle vous-même.' using errcode = '42501';
  end if;
  if not exists (select 1 from profiles where id = p_user) then
    raise exception 'Utilisateur introuvable.';
  end if;
  if not exists (select 1 from owner_profiles where user_id = p_user and verification_status <> 'refuse') then
    raise exception 'Aucune demande de statut propriétaire en attente pour cet utilisateur.';
  end if;
  insert into user_roles (user_id, role, granted_by) values (p_user, 'proprietaire', uid) on conflict do nothing;
  update owner_profiles set verification_status = 'verifie' where user_id = p_user;
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'role.owner_granted', 'user', p_user::text, jsonb_build_object('role', 'proprietaire'));
end $$;
revoke all on function grant_owner_role(uuid) from public, anon;
grant execute on function grant_owner_role(uuid) to authenticated;

-- =====================================================================
-- 8. Statut de publication d'une annonce (processus de validation de 0005)
-- =====================================================================
create or replace function set_listing_status(p_property uuid, p_status listing_status, p_note text default null)
returns properties
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  prop properties%rowtype;
  problem text;
  old_status listing_status;
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  select * into prop from properties where id = p_property for update;
  if not found then
    raise exception 'Annonce introuvable.';
  end if;
  if prop.owner_id = uid then
    raise exception 'Vous ne pouvez pas valider ou publier votre propre annonce.' using errcode = '42501';
  end if;
  if prop.status in ('brouillon', 'a_corriger') then
    raise exception 'Cette annonce est en attente d''une action du propriétaire.';
  end if;
  if not listing_transition_ok(prop.status, p_status) then
    raise exception 'Changement de statut non autorisé (% vers %).', prop.status, p_status;
  end if;
  if p_status in ('a_corriger', 'refusee', 'suspendue') and char_length(coalesce(btrim(p_note), '')) < 5 then
    raise exception 'Indiquez un motif clair pour le propriétaire (5 caractères minimum).';
  end if;
  if p_status = 'publiee' then
    problem := _listing_publish_problem(prop.id);
    if problem is not null then
      raise exception 'Publication refusée : %', problem;
    end if;
  end if;

  old_status := prop.status;
  update properties
     set status = p_status,
         review_note = case when p_status in ('a_corriger', 'refusee', 'suspendue') then btrim(p_note)
                            when p_status in ('approuvee', 'publiee') then null
                            else review_note end,
         updated_at = now()
   where id = prop.id returning * into prop;
  insert into audit_logs (actor_id, action, entity_type, entity_id, before, after, reason)
  values (uid, 'listing.status_changed', 'property', prop.id::text,
          jsonb_build_object('status', old_status), jsonb_build_object('status', p_status), nullif(btrim(p_note), ''));
  return prop;
end $$;
revoke all on function set_listing_status(uuid, listing_status, text) from public, anon;
grant execute on function set_listing_status(uuid, listing_status, text) to authenticated;
