// Connexion à Supabase — bibliothèque OFFICIELLE @supabase/supabase-js (v2.117.3).
// Elle est chargée depuis un CDN par la page construite (voir scripts/build-preview.mjs) et expose
// « window.supabase ». C'est la même interface que le paquet npm : le jour où le projet est construit
// sur une machine avec accès à npm, il suffit de remplacer getClient() par
//     import { createClient } from "@supabase/supabase-js";
// sans toucher au reste de l'application.
//
// La clé « anon » est PUBLIQUE par conception : elle ne donne aucun droit par elle-même, toute la
// sécurité est appliquée par la base (RLS + fonctions serveur, migrations 0001 à 0007).
// La clé « service_role » ne doit JAMAIS apparaître dans l'application.

export interface SupabaseConfig { url: string; anonKey: string }

const DEFAULT_CONFIG: SupabaseConfig = {
  url: "https://kzzrowymwwxoydklnkfb.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6enJvd3ltd3d4b3lka2xua2ZiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE1ODczODAsImV4cCI6MjEwNzE2MzM4MH0.Bswxc0KJZ5aO3Px7XauqqUJPhrPJUq4is8qXNXwyPl4",
};

/** Permet de pointer vers un autre projet (production) sans reconstruire : window.YIRI_SUPABASE = {url, anonKey}. */
export function config(): SupabaseConfig {
  const w = globalThis as unknown as { YIRI_SUPABASE?: Partial<SupabaseConfig> };
  return { url: w.YIRI_SUPABASE?.url || DEFAULT_CONFIG.url, anonKey: w.YIRI_SUPABASE?.anonKey || DEFAULT_CONFIG.anonKey };
}

// ---------------------------------------------------------------------------
// Interface minimale de la bibliothèque (les types npm ne sont pas disponibles ici).
// ---------------------------------------------------------------------------
export interface SbError { message: string; status?: number; code?: string }
export interface SbResult<T> { data: T | null; error: SbError | null }
export interface SbUser { id: string; email?: string; email_confirmed_at?: string | null }
export interface SbSession { access_token: string; expires_at?: number; user: SbUser }

export interface Filterable<T> extends PromiseLike<SbResult<T[]>> {
  select(cols?: string): Filterable<T>;
  eq(col: string, v: unknown): Filterable<T>;
  in(col: string, v: unknown[]): Filterable<T>;
  order(col: string, opts?: { ascending?: boolean }): Filterable<T>;
  limit(n: number): Filterable<T>;
  maybeSingle(): PromiseLike<SbResult<T>>;
  single(): PromiseLike<SbResult<T>>;
}
export type Row = Record<string, unknown>;
interface Table {
  select(cols?: string): Filterable<Row>;
  insert(rows: unknown): Filterable<Row>;
  upsert(rows: unknown, opts?: { onConflict?: string }): Filterable<Row>;
  update(patch: unknown): Filterable<Row>;
  delete(): Filterable<Row>;
}
export interface SupabaseClient {
  auth: {
    getSession(): Promise<SbResult<{ session: SbSession | null }>>;
    signUp(c: { email: string; password: string; options?: { data?: Record<string, unknown>; emailRedirectTo?: string } }): Promise<SbResult<{ user: SbUser | null; session: SbSession | null }>>;
    signInWithPassword(c: { email: string; password: string }): Promise<SbResult<{ user: SbUser | null; session: SbSession | null }>>;
    signOut(): Promise<{ error: SbError | null }>;
    resetPasswordForEmail(email: string, opts?: { redirectTo?: string }): Promise<SbResult<unknown>>;
    updateUser(attrs: { password?: string; data?: Record<string, unknown> }): Promise<SbResult<{ user: SbUser | null }>>;
    onAuthStateChange(cb: (event: string, session: SbSession | null) => void): { data: { subscription: { unsubscribe(): void } } };
  };
  from(table: string): Table;
  rpc(fn: string, args?: Record<string, unknown>): PromiseLike<SbResult<unknown>>;
  storage: {
    from(bucket: string): {
      upload(path: string, file: Blob | File, opts?: { upsert?: boolean; contentType?: string }): Promise<SbResult<unknown>>;
      remove(paths: string[]): Promise<SbResult<unknown>>;
      createSignedUrl(path: string, expiresIn: number): Promise<SbResult<{ signedUrl: string }>>;
      list(prefix?: string): Promise<SbResult<{ name: string }[]>>;
    };
  };
}

// ---------------------------------------------------------------------------
// Stockage de session tolérant aux pannes : certains contextes (fichier local, navigation
// privée, cookies bloqués) interdisent localStorage. On retombe alors en mémoire : la session
// dure le temps de l'onglet au lieu d'être perdue avec une erreur.
// ---------------------------------------------------------------------------
const memory = new Map<string, string>();
export let storageIsPersistent = true;
const safeStorage = {
  getItem(k: string) { try { return globalThis.localStorage?.getItem(k) ?? memory.get(k) ?? null; } catch { return memory.get(k) ?? null; } },
  setItem(k: string, v: string) { memory.set(k, v); try { globalThis.localStorage?.setItem(k, v); } catch { storageIsPersistent = false; } },
  removeItem(k: string) { memory.delete(k); try { globalThis.localStorage?.removeItem(k); } catch { /* ignoré */ } },
};

// ---------------------------------------------------------------------------
// Création du client (une seule fois)
// ---------------------------------------------------------------------------
type Factory = (url: string, key: string, opts: unknown) => SupabaseClient;

let client: SupabaseClient | null = null;
let loadError: string | null = null;

/** Erreur de chargement de la bibliothèque, à afficher à l'utilisateur. */
/** Le message à montrer quand la connexion au serveur n'a pas pu être créée.
 *  Renvoie TOUJOURS une phrase : un appelant qui recevrait « null » afficherait le mot
 *  « null » à la personne. Le cas est théorique — getClient() pose toujours loadError avant
 *  de renvoyer null — mais le type ne le garantissait pas, et un jour quelqu'un ajoutera un
 *  autre chemin de sortie. */
export function clientError(): string {
  return loadError ?? "La connexion au serveur n'a pas pu être établie. Rechargez la page.";
}

export function getClient(): SupabaseClient | null {
  if (client) return client;
  const w = globalThis as unknown as { supabase?: { createClient?: Factory } };
  const create = w.supabase?.createClient;
  if (typeof create !== "function") {
    loadError = "La connexion au serveur n'a pas pu être chargée. Vérifiez votre connexion Internet, puis rechargez la page.";
    return null;
  }
  const { url, anonKey } = config();
  client = create(url, anonKey, {
    auth: {
      persistSession: true,        // la session survit au rechargement de la page
      autoRefreshToken: true,      // le jeton est renouvelé automatiquement avant expiration
      detectSessionInUrl: true,    // confirmation d'e-mail et mot de passe oublié
      flowType: "pkce",            // le code arrive en « ?code= » : pas de conflit avec la navigation par ancre
      storage: safeStorage,
      storageKey: "yiri-auth",
    },
    global: { headers: { "x-application-name": "yiri-web" } },
  });
  loadError = null;
  return client;
}

// ---------------------------------------------------------------------------
// Messages d'erreur en français. On ne montre jamais le message technique brut.
// ---------------------------------------------------------------------------
const MESSAGES: [RegExp, string][] = [
  [/invalid login credentials/i, "E-mail ou mot de passe incorrect."],
  [/email not confirmed/i, "Votre adresse n'est pas encore confirmée. Ouvrez le message que nous vous avons envoyé."],
  [/user already registered|already been registered/i, "Un compte existe déjà avec cette adresse. Connectez-vous."],
  [/password should be at least (\d+)/i, "Le mot de passe doit contenir au moins 8 caractères."],
  [/weak password|password is too weak/i, "Mot de passe trop simple. Mélangez lettres, chiffres et majuscules."],
  [/unable to validate email|invalid format|invalid email/i, "Adresse e-mail invalide."],
  [/for security purposes|rate limit|too many requests/i, "Trop de tentatives. Patientez une minute, puis réessayez."],
  [/email rate limit exceeded/i, "Trop d'e-mails envoyés. Patientez quelques minutes."],
  [/signups not allowed|signup is disabled/i, "Les inscriptions sont momentanément fermées."],
  [/same.*password|new password should be different/i, "Le nouveau mot de passe doit être différent de l'ancien."],
  [/token has expired|invalid.*token|expired/i, "Ce lien a expiré. Demandez-en un nouveau."],
  [/failed to fetch|network|load failed/i, "Connexion au serveur impossible. Vérifiez votre connexion Internet."],
  [/jwt expired|session.*expired/i, "Votre session a expiré. Reconnectez-vous."],
];

/** Traduit une erreur Supabase ou PostgreSQL en message compréhensible. */
export function frMessage(e: unknown, fallback = "Une erreur est survenue. Réessayez."): string {
  if (!e) return fallback;
  const err = e as SbError & { details?: string; hint?: string };
  const raw = typeof err.message === "string" ? err.message : String(e);
  // Erreurs renvoyées par nos propres fonctions serveur (RAISE EXCEPTION) : déjà en français.
  if (err.code === "P0001" || /^[A-ZÀ-Ü][^]*[.!?]$/.test(raw.trim())) {
    if (/[éèêàùçô]/i.test(raw) || err.code === "P0001") return raw;
  }
  if (err.code === "42501") return "Action non autorisée.";
  if (err.code === "23505") return "Cette valeur existe déjà.";
  if (err.code === "PGRST301" || err.status === 401) return "Votre session a expiré. Reconnectez-vous.";
  for (const [re, msg] of MESSAGES) if (re.test(raw)) return msg;
  return fallback;
}
