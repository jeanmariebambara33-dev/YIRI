-- YIRI — 0009 : paiement en ligne avec confirmation automatique par un prestataire (agrégateur).
--
-- Décision du fondateur : passer d'une confirmation 100 % manuelle à une confirmation automatique
-- « quand c'est possible ». Ce fichier rend cela possible SANS affaiblir les règles existantes :
--
--  * le navigateur n'envoie JAMAIS de montant : start_online_payment() recalcule le prix côté serveur ;
--  * le prestataire ne peut rien confirmer directement : il parle à une fonction serveur (Edge Function)
--    qui vérifie la signature du message, PUIS réinterroge le prestataire, PUIS seulement appelle la base ;
--  * confirm_payment_online() est fermée aux clients : ni « anon » ni « authenticated » ne peuvent l'appeler.
--    Seule la clé de service, qui ne quitte jamais le serveur, y a accès ;
--  * le montant reçu doit égaler au centime près le montant recalculé, sinon rien n'est confirmé et
--    le dossier part en traitement manuel ;
--  * un même message reçu deux fois ne confirme qu'une fois (clé d'idempotence + index uniques de 0006) ;
--  * la confirmation manuelle par l'équipe reste disponible : elle est le filet de sécurité.
--
-- Rien n'est supprimé. confirm_payment() est redéfinie pour appeler la logique commune, à comportement
-- identique : les 256 tests de la migration 0006 sont rejoués et doivent tous passer.

-- =====================================================================
-- 1. Logique commune d'encaissement (jamais appelable par un client)
-- =====================================================================
create or replace function _apply_payment(
  p_object text, p_id uuid, p_received_amount_xof int,
  p_actor uuid, p_provider text, p_reference text, p_auto boolean
) returns payment_transactions
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  bk bookings%rowtype;
  sb subscriptions%rowtype;
  tx payment_transactions%rowtype;
  prop_id uuid;
  expected int;
  base date; st date; en date;
  before_status text;
  origine text := case when p_auto then 'confirmé automatiquement par le prestataire' else 'confirmé manuellement par l''équipe' end;
  action text := case when p_auto then 'payment.confirmed_online' else 'payment.confirmed' end;
begin
  if p_object not in ('reservation', 'abonnement') or p_id is null then
    raise exception 'Objet de paiement invalide.';
  end if;
  if p_received_amount_xof is null or p_received_amount_xof <= 0 then
    raise exception 'Indiquez le montant réellement reçu.';
  end if;

  if p_object = 'reservation' then
    select property_id into prop_id from bookings where id = p_id;
    if not found then raise exception 'Réservation introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;        -- 1er verrou : le logement
    select * into bk from bookings where id = p_id for update;      -- 2e verrou : la réservation
    if p_actor is not null and bk.guest_id = p_actor then
      raise exception 'Vous ne pouvez pas confirmer votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where booking_id = bk.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé.' using errcode = '23505';
    end if;
    if bk.status not in ('en_attente_paiement', 'expiree') then
      raise exception 'Cette réservation ne peut plus être confirmée (statut : %).', bk.status;
    end if;
    expected := bk.total_xof;
    if p_received_amount_xof <> expected then
      raise exception 'Montant reçu (%) différent du montant attendu (%). Rien n''a été confirmé.', p_received_amount_xof, expected;
    end if;
    before_status := bk.status::text;
    begin
      update bookings set status = 'confirmee', hold_expires_at = null where id = bk.id;
    exception when exclusion_violation then
      raise exception 'Les dates ont été reprises depuis l''expiration du blocage : confirmation impossible. Un remboursement éventuel doit être organisé hors plateforme.'
        using errcode = '23P01';
    end;
    select * into tx from payment_transactions
     where booking_id = bk.id and purpose = 'booking' and status in ('cree', 'en_attente')
     order by created_at desc limit 1 for update;
    if found then
      update payment_transactions
         set status = 'reussi', amount_xof = expected, received_amount_xof = p_received_amount_xof,
             provider = coalesce(p_provider, provider),
             provider_reference = coalesce(p_reference, provider_reference),
             confirmed_by = p_actor, confirmed_at = now(), updated_at = now()
       where id = tx.id returning * into tx;
    else
      insert into payment_transactions (purpose, booking_id, provider, provider_reference, idempotency_key, amount_xof, status,
                                        received_amount_xof, confirmed_by, confirmed_at)
      values ('booking', bk.id, coalesce(p_provider, 'chariow'), p_reference,
              case when p_auto then 'online:booking:' else 'manual:booking:' end || bk.id::text,
              expected, 'reussi', p_received_amount_xof, p_actor, now())
      returning * into tx;
    end if;
    insert into financial_ledger (booking_id, transaction_id, entry_type, credit_xof, description)
    values (bk.id, tx.id, 'paiement_voyageur', expected, 'Paiement reçu, ' || origine);
    update payment_notices set status = 'traite', handled_by = p_actor, handled_at = now()
     where booking_id = bk.id and status = 'nouveau';
    insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
    values (p_actor, action, 'booking', bk.id::text,
            jsonb_build_object('status', before_status),
            jsonb_build_object('status', 'confirmee', 'expected_xof', expected, 'received_xof', p_received_amount_xof,
                               'transaction_id', tx.id, 'provider', tx.provider, 'reference', tx.provider_reference));
  else
    select property_id into prop_id from subscriptions where id = p_id;
    if not found then raise exception 'Abonnement introuvable.'; end if;
    perform 1 from properties where id = prop_id for update;
    select * into sb from subscriptions where id = p_id for update;
    if p_actor is not null and sb.owner_id = p_actor then
      raise exception 'Vous ne pouvez pas confirmer votre propre paiement.' using errcode = '42501';
    end if;
    if exists (select 1 from payment_transactions where subscription_id = sb.id and status = 'reussi') then
      raise exception 'Paiement déjà confirmé.' using errcode = '23505';
    end if;
    if sb.status <> 'en_attente_paiement' then
      raise exception 'Cet abonnement ne peut plus être activé (statut : %).', sb.status;
    end if;
    expected := case sb.plan when 'mensuel' then 5000 else 30000 end;   -- tarif recalculé, jamais lu du navigateur
    if sb.amount_xof <> expected or p_received_amount_xof <> expected then
      raise exception 'Montant reçu (%) différent du montant attendu (%). Rien n''a été confirmé.', p_received_amount_xof, expected;
    end if;
    select coalesce(max(ends_at), current_date) into base
      from subscriptions where property_id = sb.property_id and status = 'actif' and ends_at > current_date;
    st := greatest(current_date, base);
    en := (st + case sb.plan when 'mensuel' then interval '1 month' else interval '1 year' end)::date;
    update subscriptions set status = 'actif', starts_at = st, ends_at = en where id = sb.id;
    select * into tx from payment_transactions
     where subscription_id = sb.id and purpose = 'subscription' and status in ('cree', 'en_attente')
     order by created_at desc limit 1 for update;
    if found then
      update payment_transactions
         set status = 'reussi', amount_xof = expected, received_amount_xof = p_received_amount_xof,
             provider = coalesce(p_provider, provider),
             provider_reference = coalesce(p_reference, provider_reference),
             confirmed_by = p_actor, confirmed_at = now(), updated_at = now()
       where id = tx.id returning * into tx;
    else
      insert into payment_transactions (purpose, subscription_id, provider, provider_reference, idempotency_key, amount_xof, status,
                                        received_amount_xof, confirmed_by, confirmed_at)
      values ('subscription', sb.id, coalesce(p_provider, 'chariow'), p_reference,
              case when p_auto then 'online:subscription:' else 'manual:subscription:' end || sb.id::text,
              expected, 'reussi', p_received_amount_xof, p_actor, now())
      returning * into tx;
    end if;
    insert into financial_ledger (transaction_id, entry_type, credit_xof, description)
    values (tx.id, 'abonnement', expected, 'Abonnement payé, ' || origine);
    update payment_notices set status = 'traite', handled_by = p_actor, handled_at = now()
     where subscription_id = sb.id and status = 'nouveau';
    if exists (select 1 from properties where id = sb.property_id and status = 'approuvee')
       and _listing_publish_problem(sb.property_id) is null then
      update properties set status = 'publiee', review_note = null where id = sb.property_id;
    end if;
    insert into audit_logs (actor_id, action, entity_type, entity_id, before, after)
    values (p_actor, action, 'subscription', sb.id::text,
            jsonb_build_object('status', 'en_attente_paiement'),
            jsonb_build_object('status', 'actif', 'starts_at', st, 'ends_at', en, 'expected_xof', expected,
                               'received_xof', p_received_amount_xof, 'transaction_id', tx.id,
                               'provider', tx.provider, 'reference', tx.provider_reference));
  end if;
  return tx;
end $$;
revoke all on function _apply_payment(text, uuid, int, uuid, text, text, boolean) from public, anon, authenticated;

-- =====================================================================
-- 2. Confirmation manuelle par l'équipe — comportement INCHANGÉ (tests 0006 rejoués)
-- =====================================================================
create or replace function confirm_payment(p_object text, p_id uuid, p_received_amount_xof int)
returns payment_transactions
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return _apply_payment(p_object, p_id, p_received_amount_xof, uid, null, null, false);
end $$;
revoke all on function confirm_payment(text, uuid, int) from public, anon;
grant execute on function confirm_payment(text, uuid, int) to authenticated;

-- =====================================================================
-- 3. Démarrage d'un paiement en ligne : le serveur fixe le montant
-- =====================================================================
create table if not exists payment_attempts (
  reference text primary key,
  object text not null check (object in ('reservation', 'abonnement')),
  target_id uuid not null,
  amount_xof int not null check (amount_xof > 0),
  provider text not null,
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now(),
  settled_at timestamptz,
  outcome text check (outcome in ('paye', 'echec', 'annule', 'ecart'))
);
create index if not exists payment_attempts_target_idx on payment_attempts (object, target_id, created_at desc);
alter table payment_attempts enable row level security;   -- aucune policy : fermé aux clients
revoke all on payment_attempts from public, anon, authenticated;

/* Prépare un paiement : vérifie que l'objet appartient bien à la personne connectée, recalcule le montant,
   et renvoie une référence unique. Le montant n'est JAMAIS reçu du navigateur. */
create or replace function start_online_payment(p_object text, p_id uuid, p_provider text)
returns table (reference text, amount_xof int, designation text)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  sb subscriptions%rowtype;
  expected int;
  label text;
  ref text;
begin
  if p_object not in ('reservation', 'abonnement') or p_id is null then
    raise exception 'Objet de paiement invalide.';
  end if;
  if p_provider is null or btrim(p_provider) = '' or char_length(p_provider) > 30 then
    raise exception 'Prestataire de paiement invalide.';
  end if;
  perform enforce_rate_limit('payinit:' || uid::text, 30, interval '1 day');

  if p_object = 'reservation' then
    select * into bk from bookings where id = p_id;
    if not found or bk.guest_id <> uid then
      raise exception 'Réservation introuvable.';
    end if;
    if bk.status <> 'en_attente_paiement' then
      raise exception 'Cette réservation n''est plus en attente de paiement.';
    end if;
    if exists (select 1 from payment_transactions where booking_id = bk.id and status = 'reussi') then
      raise exception 'Cette réservation est déjà payée.';
    end if;
    expected := bk.total_xof;
    label := 'YIRI - séjour du ' || to_char(lower(bk.stay), 'DD/MM/YYYY') || ' au ' || to_char(upper(bk.stay), 'DD/MM/YYYY');
  else
    select * into sb from subscriptions where id = p_id;
    if not found or sb.owner_id <> uid then
      raise exception 'Abonnement introuvable.';
    end if;
    if sb.status <> 'en_attente_paiement' then
      raise exception 'Cet abonnement n''est plus en attente de paiement.';
    end if;
    if exists (select 1 from payment_transactions where subscription_id = sb.id and status = 'reussi') then
      raise exception 'Cet abonnement est déjà payé.';
    end if;
    expected := case sb.plan when 'mensuel' then 5000 else 30000 end;
    if sb.amount_xof <> expected then
      raise exception 'Le tarif de cet abonnement a changé. Contactez l''équipe YIRI.';
    end if;
    label := 'YIRI - abonnement ' || sb.plan;
  end if;

  ref := 'YIRI' || to_char(now(), 'YYYYMMDDHH24MISS') || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8));

  insert into payment_attempts (reference, object, target_id, amount_xof, provider, created_by)
  values (ref, p_object, p_id, expected, btrim(p_provider), uid);

  -- trace côté paiements : une transaction « en attente » rattachée à l'objet
  insert into payment_transactions (purpose, booking_id, subscription_id, provider, provider_reference,
                                    idempotency_key, amount_xof, status)
  values ((case when p_object = 'reservation' then 'booking' else 'subscription' end)::payment_purpose,
          case when p_object = 'reservation' then p_id else null end,
          case when p_object = 'abonnement' then p_id else null end,
          btrim(p_provider), ref, 'online:' || ref, expected, 'en_attente');

  return query select ref, expected, label;
end $$;
revoke all on function start_online_payment(text, uuid, text) from public, anon;   -- le prestataire est passé en paramètre : aucun nom n'est figé ici
grant execute on function start_online_payment(text, uuid, text) to authenticated;

-- =====================================================================
-- 4. Confirmation automatique — réservée à la clé de service
-- =====================================================================
/* Appelée UNIQUEMENT par la fonction serveur qui a (1) vérifié la signature du message du prestataire
   et (2) réinterrogé le prestataire pour connaître le vrai statut. Fermée aux clients. */
create or replace function confirm_payment_online(p_reference text, p_received_amount_xof int, p_method text default null)
returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  at payment_attempts%rowtype;
  tx payment_transactions%rowtype;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  select * into at from payment_attempts where reference = p_reference for update;
  if not found then
    raise exception 'Référence de paiement inconnue : %', p_reference;
  end if;

  -- déjà encaissé : on ne confirme qu'une seule fois, même si le prestataire répète son message
  select * into tx from payment_transactions where provider_reference = p_reference;
  if found and tx.status = 'reussi' then
    return 'deja_confirme';
  end if;

  if p_received_amount_xof is distinct from at.amount_xof then
    update payment_attempts set settled_at = now(), outcome = 'ecart' where reference = p_reference;
    update payment_transactions set status = 'echoue', received_amount_xof = p_received_amount_xof, updated_at = now()
     where provider_reference = p_reference;
    insert into audit_logs (actor_id, action, entity_type, entity_id, after, reason)
    values (null, 'payment.amount_mismatch', at.object, at.target_id::text,
            jsonb_build_object('attendu', at.amount_xof, 'recu', p_received_amount_xof, 'reference', p_reference),
            'Montant reçu différent du montant attendu : traitement manuel requis.');
    -- On NE LÈVE PAS d'exception : elle annulerait la transaction, donc les trois écritures ci-dessus,
    -- et il ne resterait aucune trace de l'incident. Rien n'est encaissé, « ecart » est renvoyé,
    -- et le dossier apparaît à l'équipe avec l'issue « ecart ».
    return 'ecart';
  end if;

  perform _apply_payment(at.object, at.target_id, p_received_amount_xof, null, at.provider, p_reference, true);
  update payment_attempts set settled_at = now(), outcome = 'paye' where reference = p_reference;
  if p_method is not null then
    insert into audit_logs (actor_id, action, entity_type, entity_id, after)
    values (null, 'payment.method', at.object, at.target_id::text, jsonb_build_object('moyen', left(p_method, 40)));
  end if;
  return 'confirme';
end $$;
revoke all on function confirm_payment_online(text, int, text) from public, anon, authenticated;

/* Paiement échoué ou abandonné chez le prestataire : on referme la tentative sans rien encaisser. */
create or replace function fail_online_payment(p_reference text, p_reason text default null)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Cette opération ne peut pas être demandée depuis un navigateur.' using errcode = '42501';
  end if;
  update payment_attempts set settled_at = now(), outcome = 'echec'
   where reference = p_reference and settled_at is null;
  update payment_transactions set status = 'echoue', updated_at = now()
   where provider_reference = p_reference and status in ('cree', 'en_attente');
  insert into audit_logs (actor_id, action, entity_type, entity_id, reason)
  select null, 'payment.failed', a.object, a.target_id::text, left(coalesce(p_reason, 'Paiement non abouti'), 200)
    from payment_attempts a where a.reference = p_reference;
end $$;
revoke all on function fail_online_payment(text, text) from public, anon, authenticated;

-- =====================================================================
-- 5. Suivi pour l'équipe « paiements »
-- =====================================================================
create or replace function payment_attempts_recent(p_limit int default 50)
returns table (reference text, object text, target_id uuid, amount_xof int, provider text,
               created_at timestamptz, settled_at timestamptz, outcome text, tx_status text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return query
    select a.reference, a.object, a.target_id, a.amount_xof, a.provider, a.created_at, a.settled_at, a.outcome,
           t.status::text
      from payment_attempts a
      left join payment_transactions t on t.provider_reference = a.reference
     order by a.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200));
end $$;
revoke all on function payment_attempts_recent(int) from public, anon;
grant execute on function payment_attempts_recent(int) to authenticated;
