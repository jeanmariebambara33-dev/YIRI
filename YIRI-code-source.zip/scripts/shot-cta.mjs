import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const p = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
await p.goto("file:///home/claude/yiri/dist/yiri-demo.html"); await p.waitForSelector("h1");
await p.locator("text=Publiez-le en un clic").scrollIntoViewIfNeeded();
await p.screenshot({ path: "dist/cta-owner.png" });
await b.close();
