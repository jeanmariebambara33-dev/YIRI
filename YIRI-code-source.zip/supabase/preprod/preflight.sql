-- YIRI — contrôle AVANT migration, LECTURE SEULE. À coller dans l'éditeur SQL du projet de préproduction, AVANT 0001.
-- Attendu : aucune ligne « ÉCART ». Les lignes « INFO » sont à me recopier (aucune n'est secrète).
select * from (
  select 1 n, 'version PostgreSQL' controle, current_setting('server_version') obtenu, '15 ou plus (testé en local sur 16)' attendu,
         case when current_setting('server_version_num')::int >= 150000 then 'OK' else 'ÉCART' end statut
  union all select 2, 'utilisateur courant', current_user, 'postgres', case when current_user = 'postgres' then 'OK' else 'ÉCART' end
  union all select 3, 'fuseau horaire de la base (décalage avec UTC)', current_setting('TimeZone') || ' (décalage ' || to_char(now(), 'TZH:TZM') || ')', 'décalage +00:00 (le Burkina Faso est en UTC+0)', case when to_char(now(), 'TZH:TZM') in ('+00:00', '-00:00') then 'OK' else 'ÉCART' end
  union all select 4, 'rôles anon / authenticated présents',
         (select count(*)::text from pg_roles where rolname in ('anon','authenticated')), '2', case when (select count(*) from pg_roles where rolname in ('anon','authenticated')) = 2 then 'OK' else 'ÉCART' end
  union all select 5, 'schémas auth et storage présents',
         (select count(*)::text from pg_namespace where nspname in ('auth','storage')), '2', case when (select count(*) from pg_namespace where nspname in ('auth','storage')) = 2 then 'OK' else 'ÉCART' end
  union all select 6, 'objets déjà présents dans le schéma public (tables, vues, types, fonctions utilisateur)',
         ((select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind in ('r','v','m'))
          + (select count(*) from pg_type t join pg_namespace n on n.oid = t.typnamespace where n.nspname = 'public' and t.typtype in ('e','c') and not exists (select 1 from pg_class c where c.reltype = t.oid))
          + (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e')))::text,
         '0 (projet vide)', case when ((select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind in ('r','v','m'))
          + (select count(*) from pg_type t join pg_namespace n on n.oid = t.typnamespace where n.nspname = 'public' and t.typtype in ('e','c') and not exists (select 1 from pg_class c where c.reltype = t.oid))
          + (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e'))) = 0 then 'OK' else 'ÉCART' end
  union all select 7, 'comptes déjà créés (auth.users)', (select count(*)::text from auth.users), '0 (sinon ils n''auront pas de profil)', case when (select count(*) from auth.users) = 0 then 'OK' else 'ÉCART' end
  union all select 8, 'extension btree_gist disponible', (select count(*)::text from pg_available_extensions where name = 'btree_gist'), '1', case when (select count(*) from pg_available_extensions where name = 'btree_gist') = 1 then 'OK' else 'ÉCART' end
  union all select 9, 'extension pg_cron disponible / déjà activée',
         (select count(*)::text from pg_available_extensions where name = 'pg_cron') || ' / ' || (select count(*)::text from pg_extension where extname = 'pg_cron'),
         '1 / 1 (à activer avant 0006 sinon enable_cron.sql)', case when exists (select 1 from pg_extension where extname = 'pg_cron') then 'OK' else 'MANUEL' end
  union all select 10, 'INFO : déclencheurs d''événements existants (ex. activation automatique de la sécurité par ligne)',
         coalesce((select string_agg(evtname, ', ') from pg_event_trigger), 'aucun'), 'à me recopier', 'INFO'
  union all select 11, 'INFO : buckets de stockage existants', (select count(*)::text from storage.buckets), '0', 'INFO'
) s order by n;
