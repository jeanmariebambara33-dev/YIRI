// Tests du site public après le retrait de la démonstration : accueil, navigation, pages de présentation,
// formulaire « demande propriétaire » envoyé pour de bon, et absence totale de données fictives.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const DB = { leads: [], listings: [] };
window.__db = DB;
const okRes = (d) => ({ data: d, error: null });
function builder(table) {
  let op = "select", payload = null;
  const exec = () => {
    if (table === "owner_leads" && op === "insert") {
      if (!payload.consent) return Promise.resolve({ data: null, error: { code: "42501", message: "new row violates row-level security policy" } });
      DB.leads.push(payload); return Promise.resolve(okRes([{ id: "l-1" }]));
    }
    if (table === "public_listings") return Promise.resolve(okRes(DB.listings));
    return Promise.resolve(okRes([]));
  };
  const self = { select() { return self; }, insert(p) { op = "insert"; payload = p; return self; },
    upsert(p) { op = "upsert"; payload = p; return self; }, update(p) { op = "update"; payload = p; return self; },
    delete() { op = "delete"; return self; }, eq() { return self; }, order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); } };
  return self;
}
window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: null }); },
    async signInWithPassword() { return { data: null, error: { message: "Invalid login credentials" } }; },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange() { return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc() { return Promise.resolve(okRes(null)); },
  storage: { from: () => ({ async createSignedUrl() { return okRes({ signedUrl: "data:," }); }, async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); } }) },
}; } };
`;

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ viewport: { width: 1280, height: 1000 } });
await ctx.route("**cdn.jsdelivr.net/**", (r) => r.abort());
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));

// --- accueil ---
await p.goto(URL); await p.waitForTimeout(500);
const header = await p.locator("header").innerText();
ok("en-tête : plus de bande « DÉMO »", !/DÉMO|fictives|simulés/i.test(header));
ok("en-tête : plus de sélecteur de rôle", !/Voir en tant que|Réinitialiser/i.test(header));
ok("en-tête : les 4 entrées attendues", /Logements/.test(header) && /Propriétaires/.test(header) && /Mes séjours/.test(header) && /Publier mon logement/.test(header));
ok("en-tête : bouton de connexion", /Connexion/.test(header));
const page1 = await p.locator("body").innerText();
ok("accueil : aucune mention de démonstration", !/démonstration|fictif|fictives|Paiements simulés/i.test(page1));
ok("accueil : le discours de marque est intact", /Chez vous, partout/.test(page1));

// --- navigation vers les vraies pages ---
await p.getByRole("button", { name: "Logements", exact: true }).first().click();
await p.waitForTimeout(600);
ok("« Logements » ouvre le catalogue réel", /Logements disponibles/.test(await p.locator("main").innerText()));
ok("catalogue vide : message honnête, pas de faux logement", /Aucun logement publié/.test(await p.locator("main").innerText()));
await p.getByRole("button", { name: "Publier mon logement" }).first().click();
await p.waitForTimeout(600);
ok("« Publier mon logement » ouvre l'espace propriétaire réel", /Espace propriétaire/.test(await p.locator("main").innerText()));
await p.getByRole("button", { name: "Mes séjours" }).first().click();
await p.waitForTimeout(600);
ok("« Mes séjours » demande la connexion", /Connectez-vous pour retrouver/.test(await p.locator("main").innerText()));

// --- anciennes adresses : plus de page de démonstration ---
for (const [h, attendu] of [["logements", /Logements disponibles/], ["admin", /Espace équipe|Connectez-vous/], ["proprietaire", /Espace propriétaire/], ["reservations", /Mes réservations/], ["connexion", /Espace équipe|Connectez-vous/]]) {
  await p.goto(URL + "#" + h); await p.waitForTimeout(450);
  ok("ancienne adresse #" + h + " mène à la vraie page", attendu.test(await p.locator("main").innerText()));
}

// --- pages de présentation conservées ---
// L'adresse « #visibilite » est conservée pour ne pas casser les liens déjà partagés, mais la
// page affiche désormais le nom commercial « YIRI Annonce ».
for (const [h, attendu] of [["visibilite", /YIRI Annonce/i], ["serenite", /Sérénité/i], ["partenariat", /Partenariat/i], ["proprietaires", /propriétaire/i]]) {
  await p.goto(URL + "#" + h); await p.waitForTimeout(400);
  ok("page de présentation « " + h + " » conservée", attendu.test(await p.locator("main").innerText()));
}

// --- demande propriétaire : envoyée pour de bon ---
await p.goto(URL + "#demande"); await p.waitForTimeout(500);
await p.fill("#d-name", "A");
await p.getByRole("button", { name: "Envoyer ma demande à YIRI" }).click();
await p.waitForTimeout(300);
ok("demande : nom trop court refusé", /Indiquez votre nom/.test(await p.locator("main").innerText()));
ok("demande : rien n'est envoyé tant que la saisie est invalide", await p.evaluate(() => window.__db.leads.length === 0));
await p.fill("#d-name", "Salif Kabore");
await p.fill("#d-phone", "70 11 22 33");
await p.getByRole("button", { name: "Envoyer ma demande à YIRI" }).click();
await p.waitForTimeout(300);
ok("demande : accord obligatoire avant envoi", /accord est nécessaire/.test(await p.locator("main").innerText()));
ok("demande : toujours rien d'envoyé sans accord", await p.evaluate(() => window.__db.leads.length === 0));
await p.locator("#d-consent").check();
await p.getByRole("button", { name: "Envoyer ma demande à YIRI" }).click();
await p.waitForTimeout(700);
ok("demande envoyée à la base", await p.evaluate(() => window.__db.leads.length === 1));
const lead = await p.evaluate(() => window.__db.leads[0]);
ok("demande : le consentement est transmis", lead && lead.consent === true);
ok("demande : le statut est imposé à « nouvelle »", lead && lead.status === "nouvelle");
ok("demande : nom et téléphone transmis", lead && lead.name === "Salif Kabore" && /70 11 22 33/.test(lead.phone));
ok("demande : confirmation affichée", /Demande envoyée/.test(await p.locator("main").innerText()));

// --- pied de page ---
await p.goto(URL); await p.waitForTimeout(400);
const footer = await p.locator("footer").innerText();
ok("pied de page : plus de mention « version de démonstration »", !/démonstration|fictif/i.test(footer));
ok("pied de page : l'espace équipe est caché au visiteur", !/Espace équipe/.test(footer));
ok("pied de page : aucun nom de personne derrière le service", !/Bambara|Jean-Marie/i.test(footer));
ok("pied de page : les quatre colonnes attendues", /YIRI/.test(footer) && /Voyageurs/.test(footer) && /Propriétaires/.test(footer) && /Informations/.test(footer));

ok("aucune erreur JavaScript", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 3).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DU SITE PUBLIC SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
