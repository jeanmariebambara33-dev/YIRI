// Contenu commercial des solutions propriétaires — source unique pour la page « Solutions »,
// les pages de détail et le comparatif. Les montants viennent de lib/pricing.ts (PLANS) ;
// les pourcentages 60/40 sont l'hypothèse de départ du cahier des charges V1.1, à valider.

export type PackId = "visibilite" | "serenite" | "partenariat";

export interface Pack {
  id: PackId;
  name: string;
  tagline: string;
  profile: string;      // à qui s'adresse la solution
  need: string;         // besoin auquel elle répond
  benefit: string;      // bénéfice principal
  value: string;        // valeur apportée
  included: string[];   // ce que YIRI fait
  ownerDuties: string[]; // ce que le propriétaire fait
  limits: string[];     // limites et frais éventuels
  price: { main: string; sub: string; billing: string };
  steps: string[];
  commitment: string;   // engagement et résiliation
  availability: { label: string; tone: "good" | "info" | "warn" };
  detailCta: string;
  route: "offre-annonce" | "offre-gestion" | "offre-partenariat";
}

export const PACKS: Record<PackId, Pack> = {
  visibilite: {
    id: "visibilite",
    name: "YIRI Annonce",
    tagline: "Gardez la main. Soyez vu.",
    profile: "Vous avez un logement meublé et vous préférez l'accueillir et le gérer vous-même.",
    need: "Vous voulez que des voyageurs découvrent votre logement, sans confier sa gestion.",
    benefit: "Une annonce soignée dans le catalogue YIRI, avec votre contact direct.",
    value: "Les voyageurs voient votre logement, ses photos et sa description, puis vous contactent directement. Vous fixez vos prix, vos disponibilités et votre accueil.",
    included: [
      "Publication de votre annonce après vérification par l'équipe YIRI",
      "Mention « YIRI Annonce » sur l'annonce, pour que le voyageur sache qu'il vous contacte directement",
      "Affichage de votre téléphone et de votre WhatsApp aux voyageurs qui le demandent",
      "Suivi du nombre de consultations de votre contact",
      "Rappels avant la fin de l'abonnement",
      "Support de la plateforme",
    ],
    ownerDuties: [
      "Prix et disponibilités",
      "Réponse aux voyageurs, accueil et remise des clés",
      "Réservation et paiement avec le voyageur",
      "Ménage et entretien",
      "Exactitude des informations publiées",
    ],
    limits: [
      "YIRI ne gère ni les réservations ni les paiements de ces séjours.",
      "YIRI ne garantit ni réservations, ni taux d'occupation, ni revenus.",
    ],
    price: {
      main: "plans",
      sub: "",
      billing: "Abonnement payé en ligne. Aucune commission de YIRI sur vos séjours : la réservation et le paiement se font entre vous et le voyageur.",
    },
    steps: [
      "Ajoutez au moins 3 photos et décrivez tout ce que votre logement propose",
      "Indiquez votre contact : les voyageurs vous appellent ou vous écrivent",
      "Choisissez mensuel ou annuel et payez en ligne",
      "L'équipe YIRI vérifie l'annonce",
      "Votre annonce est publiée avec la mention YIRI Annonce",
    ],
    commitment: "Sans engagement : pas de renouvellement automatique. À la fin de la période payée, l'annonce n'est plus affichée tant que vous ne renouvelez pas.",
    availability: { label: "Disponible", tone: "good" },
    detailCta: "Découvrir YIRI Annonce",
    route: "offre-annonce",
  },
  serenite: {
    id: "serenite",
    name: "YIRI Sérénité",
    tagline: "Moins de gestion, plus de temps.",
    profile: "Votre logement est déjà meublé et vous voulez y consacrer moins de temps.",
    need: "Vous ne pouvez pas, ou ne souhaitez pas, accueillir chaque voyageur vous-même.",
    benefit: "YIRI organise les séjours selon un contrat standard, vous suivez le résultat.",
    value: "Les voyageurs réservent et paient en ligne via YIRI. L'équipe prend en charge les opérations prévues au contrat, et vous recevez un relevé financier chaque mois.",
    included: [
      "Annonce, demandes et communication avec les voyageurs",
      "Arrivées, départs et remise des clés",
      "Ménage standard entre les séjours",
      "Contrôle de préparation et signalement des incidents",
      "Relevés financiers mensuels",
    ],
    ownerDuties: [
      "Un logement meublé, équipé et prêt à accueillir",
      "Eau, électricité et Wi-Fi",
      "Réparations structurelles et remplacement d'équipements",
      "Assurance et obligations du propriétaire",
    ],
    limits: [
      "Ce n'est pas une gestion intégrale : le périmètre exact est fixé par le contrat standard.",
      "Les réparations, l'assurance, l'eau, l'électricité et le Wi-Fi restent à votre charge.",
      "YIRI ne garantit ni réservations, ni taux d'occupation, ni revenus.",
    ],
    price: {
      main: "60 % / 40 %",
      sub: "du revenu locatif partageable : 60 % pour vous, 40 % pour YIRI. Hypothèse de départ, à valider.",
      billing: "Pas de somme à avancer pour l'annonce : le partage est calculé chaque mois et détaillé dans votre relevé, avec vos charges déduites.",
    },
    steps: [
      "Vous envoyez une demande : YIRI vous rappelle",
      "Visite du logement, fiche d'état et inventaire",
      "Signature du contrat standard",
      "Publication du logement avec la mention YIRI Sérénité",
      "Vous suivez vos réservations et recevez un relevé chaque mois",
    ],
    commitment: "Durée, préavis et résiliation sont définis dans le contrat standard, en cours de validation juridique. Rien n'est signé avant la visite et votre accord écrit.",
    availability: { label: "Sur candidature : visite et contrat avant publication", tone: "info" },
    detailCta: "Découvrir YIRI Sérénité",
    route: "offre-gestion",
  },
  partenariat: {
    id: "partenariat",
    name: "YIRI Partenariat",
    tagline: "Un bien vide, un projet à deux.",
    profile: "Votre bien n'est pas meublé ou n'est pas prêt à accueillir des voyageurs.",
    need: "Vous voulez valoriser un bien vide sans financer son équipement.",
    benefit: "YIRI étudie le bien et, s'il est retenu, finance son ameublement et sa préparation.",
    value: "Si votre bien est retenu, YIRI l'équipe et l'exploite. Vous percevez un loyer fixe défini au contrat.",
    included: [
      "Visite et étude chiffrée du bien",
      "Ameublement et préparation financés par YIRI si le bien est retenu",
      "Exploitation du logement",
      "Versement d'un loyer fixe défini au contrat",
    ],
    ownerDuties: [
      "Un bien en règle (propriété, accès, état général)",
      "Accepter la visite et l'étude du bien",
      "Signer un contrat validé juridiquement",
    ],
    limits: [
      "Aucun loyer ni rendement n'est promis avant la visite, l'étude chiffrée et la signature du contrat.",
      "Tous les biens ne sont pas retenus.",
      "Cette formule est en cours de validation : elle est étudiée au cas par cas.",
    ],
    price: {
      main: "Loyer fixe",
      sub: "Le montant est défini après l'étude du bien.",
      billing: "Vous ne payez rien pour candidater. Le loyer est versé selon le contrat.",
    },
    steps: [
      "Vous présentez votre bien (candidature)",
      "Présélection par l'équipe YIRI",
      "Visite du bien et étude chiffrée",
      "Décision, puis contrat validé juridiquement",
      "Ameublement, préparation et mise en exploitation",
    ],
    commitment: "Durée et conditions de sortie : définies au contrat, qui sera validé juridiquement avant toute signature. La candidature n'engage ni vous ni YIRI.",
    availability: { label: "Formule en cours de validation", tone: "warn" },
    detailCta: "Découvrir YIRI Partenariat",
    route: "offre-partenariat",
  },
};

export const PACK_ORDER: PackId[] = ["visibilite", "serenite", "partenariat"];

/** Lignes du comparatif « Qui s'en charge ? » (une cellule par solution, dans PACK_ORDER). */
export const COMPARE: { label: string; cells: [string, string, string] }[] = [
  { label: "Logement accepté", cells: ["Meublé", "Meublé", "Non meublé"] },
  { label: "Annonce visible sur YIRI", cells: ["Oui", "Oui", "Oui"] },
  { label: "Réponse aux voyageurs", cells: ["Vous", "YIRI", "YIRI"] },
  { label: "Réservation et paiement", cells: ["Entre vous et le voyageur", "En ligne, via YIRI", "En ligne, via YIRI"] },
  { label: "Accueil et clés", cells: ["Vous", "YIRI", "YIRI"] },
  { label: "Ménage", cells: ["Vous", "YIRI", "YIRI"] },
  { label: "Ameublement", cells: ["Déjà en place", "Déjà en place", "Financé par YIRI si retenu"] },
  { label: "Ce que vous payez", cells: ["Abonnement", "Part de 40 % du revenu partageable (à valider)", "Rien : loyer fixe versé par YIRI"] },
];
