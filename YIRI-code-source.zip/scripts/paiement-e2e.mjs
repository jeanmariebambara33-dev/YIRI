// Tests de bout en bout du paiement en ligne vu du navigateur.
//
// L'appel à la fonction serveur « paiement-demarrer » est intercepté PAR LE TEST, au niveau réseau,
// et non dans la page : l'application quitte réellement la page pour aller chez le prestataire, et
// toute observation gardée dans la page serait perdue à ce moment-là.
//
// Ce qui est vérifié :
//   * le navigateur n'envoie AUCUN montant, seulement l'objet et son identifiant ;
//   * le jeton de la personne connectée est transmis, jamais une clé secrète ;
//   * succès : l'application part bien vers la page du prestataire ;
//   * fonction non déployée (404) ou prestataire muet (5xx) : message clair, aucune sortie,
//     et le paiement hors ligne reste accessible ;
//   * refus métier (400) : le message du serveur est affiché tel quel ;
//   * réponse incomplète : rien n'est tenté.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const DB = {
  bookings: [{
    id: "b-1", property_id: "p-1", guest_id: "v-1", stay: "[" + J(20) + "," + J(23) + ")",
    guests: 2, nightly_price_xof: 20000, accommodation_xof: 60000, total_xof: 60000,
    status: "en_attente_paiement", hold_expires_at: new Date(Date.now() + 15 * 60000).toISOString(),
    created_at: new Date().toISOString(),
  }],
  listings: [{ id: "p-1", offer: "gestion", title: "Villa Koulouba", description: "d", city: "Ouagadougou", district: "Koulouba", capacity: 4, bedrooms: 2, beds: 3, nightly_price_xof: 20000, min_nights: 2, house_rules: null, cancellation_policy: null }],
  notices: [],
};
window.__db = DB;
const UID = "v-1";
const okRes = (data) => ({ data, error: null });

function builder(table) {
  const run = () => {
    if (table === "public_listings") return okRes(DB.listings.slice());
    if (table === "public_listing_photos") return okRes([]);
    if (table === "bookings") return okRes(DB.bookings.slice());
    if (table === "profiles") return okRes([{ full_name: "Issa Traore", phone: null }]);
    if (table === "user_roles") return okRes([{ user_id: UID, role: "voyageur" }]);
    if (table === "team_permissions") return okRes([]);
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; }, insert() { return self; }, upsert() { return self; }, update() { return self; },
    delete() { return self; }, eq() { return self; }, in() { return self; }, order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => ({ data: (r.data || [])[0] ?? null, error: null })); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: "JETON-DE-TEST", user: { id: UID, email: "issa@test.local" } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem("fs") ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    if (fn === "public_booked_ranges") return Promise.resolve(okRes([]));
    if (fn === "refund_rules_public") return Promise.resolve(okRes([{ far_days: 7, far_pct: 100, mid_days: 2, mid_pct: 50, near_pct: 0, started_pct: 0 }]));
    if (fn === "my_refunds") return Promise.resolve(okRes([]));
    if (fn === "refund_quote") return Promise.resolve(okRes([{ gross_xof: 0, rate_pct: 100, fees_xof: 0, net_xof: 0, tier: "loin", days_before: 20, cancellable: true, reason: null }]));
    if (fn === "declare_payment") {
      DB.notices.push({ id: "n-1", booking_id: a.p_id, declared_amount_xof: a.p_amount });
      return Promise.resolve(okRes({}));
    }
    return Promise.resolve(okRes(null));
  },
  storage: { from() { return {
    async createSignedUrl() { return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); },
  }; } },
}; } };
`;

const PAGE_PRESTATAIRE = "https://exemple-prestataire.test/pay/abc";
let reponse = {
  status: 200,
  corps: { ok: true, reference: "YIRI20261011X", montant_xof: 60000, page_paiement: PAGE_PRESTATAIRE },
};
const appels = [];
const sorties = [];

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1100 } });

await ctx.route("**", async (r) => {
  const req = r.request();
  const u = req.url();
  if (u.includes("/functions/v1/paiement-demarrer")) {
    let corps = null;
    try { corps = JSON.parse(req.postData() || "null"); } catch { /* corps illisible : noté tel quel */ }
    appels.push({ url: u, methode: req.method(), entetes: await req.allHeaders(), corps });
    return r.fulfill({ status: reponse.status, contentType: "application/json", body: JSON.stringify(reponse.corps) });
  }
  if (u.startsWith("file://")) return r.continue();
  if (req.isNavigationRequest()) sorties.push(u);   // l'application a voulu quitter la page
  return r.abort();
});
await ctx.addInitScript(FAKE);

const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
const nb = (x) => x.replace(/ | /g, " ");
/** Repart d'un chargement propre : nécessaire après une redirection hors de l'application. */
const revenir = async () => {
  // Aller à une adresse qui ne diffère que par le « # » ne recharge RIEN : l'état de l'écran
  // précédent survivrait. On force donc un vrai rechargement.
  await p.goto(URL + "#mes-sejours");
  await p.reload();
  await p.waitForSelector("h1");
  await p.waitForTimeout(800);
};
const payer = async () => {
  await p.getByRole("button", { name: /en ligne/ }).click();
  await p.waitForTimeout(1200);
};

// --- connexion ---
await p.goto(URL + "#compte");
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "issa@test.local");
await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(700);
await revenir();

let t = await texte();
ok("la réservation en attente de paiement est listée", /60 000/.test(nb(t)));
ok("le paiement en ligne est proposé en premier", /en ligne/.test(t));
ok("le montant à payer est sur le bouton", /Payer\s*60 000/.test(nb(t)));
ok("le paiement hors ligne reste accessible, replié", /Ou payer hors ligne/.test(t));
ok("la confirmation automatique est annoncée d'avance", /se confirme ensuite d'elle-même/.test(t));
ok("un rappel invite à actualiser après paiement", /La confirmation arrive en général en moins d'une minute/.test(t));

// --- cas normal : ce que le navigateur envoie, et où il part ---
await payer();
const a1 = appels[0];
ok("un seul appel est parti vers la fonction serveur", appels.length === 1 && !!a1);
ok("vers la bonne adresse", !!a1 && /\/functions\/v1\/paiement-demarrer$/.test(a1.url));
ok("en POST", !!a1 && a1.methode === "POST");
ok("le corps ne contient QUE l'objet et l'identifiant",
  !!a1 && JSON.stringify(Object.keys(a1.corps).sort()) === '["id","objet"]');
ok("AUCUN montant n'est envoyé par le navigateur",
  !!a1 && !/montant|amount|total|prix|60000/i.test(JSON.stringify(a1.corps)));
ok("l'objet et l'identifiant sont corrects", !!a1 && a1.corps.objet === "reservation" && a1.corps.id === "b-1");
ok("le jeton de la personne connectée est transmis", !!a1 && a1.entetes.authorization === "Bearer JETON-DE-TEST");
ok("la clé publique du projet accompagne l'appel",
  !!a1 && typeof a1.entetes.apikey === "string" && a1.entetes.apikey.length > 20);
ok("aucune clé secrète ne circule depuis le navigateur",
  !!a1 && !/service_role|sk_live|sk_test|whsec/i.test(JSON.stringify(a1.entetes) + JSON.stringify(a1.corps)));
ok("l'application part vers la page du prestataire", sorties.includes(PAGE_PRESTATAIRE));

// --- fonction serveur pas encore déployée ---
reponse = { status: 404, corps: { erreur: "not found" } };
await revenir();
let avant = sorties.length;
await payer();
t = await texte();
ok("fonction non déployée : message compréhensible", /Le paiement en ligne n'est pas disponible pour le moment/.test(t));
ok("fonction non déployée : aucune sortie de l'application", sorties.length === avant);
ok("fonction non déployée : le paiement hors ligne est toujours là", /Ou payer hors ligne/.test(t));
ok("fonction non déployée : le bouton de paiement en ligne disparaît",
  await p.getByRole("button", { name: /en ligne/ }).count() === 0);

// --- prestataire muet ---
reponse = { status: 502, corps: { erreur: "bad gateway" } };
await revenir();
avant = sorties.length;
await payer();
t = await texte();
ok("prestataire muet : même message rassurant", /n'est pas disponible pour le moment/.test(t));
ok("prestataire muet : aucune sortie de l'application", sorties.length === avant);

// --- refus métier : le message du serveur est affiché tel quel ---
reponse = { status: 400, corps: { erreur: "Cette réservation est déjà payée." } };
await revenir();
avant = sorties.length;
await payer();
t = await texte();
ok("refus métier : le message du serveur est repris mot pour mot", /Cette réservation est déjà payée\./.test(t));
ok("refus métier : aucune sortie de l'application", sorties.length === avant);
ok("refus métier : le bouton reste disponible pour réessayer",
  await p.getByRole("button", { name: /en ligne/ }).count() === 1);

// --- réponse incomplète ---
reponse = { status: 200, corps: { ok: true, reference: "YIRI1" } };
await revenir();
avant = sorties.length;
await payer();
t = await texte();
ok("réponse sans page de paiement : rien n'est tenté",
  /Aucune page de paiement reçue/.test(t) && sorties.length === avant);

// --- le paiement hors ligne fonctionne toujours ---
reponse = { status: 200, corps: { ok: true, reference: "R", montant_xof: 60000, page_paiement: PAGE_PRESTATAIRE } };
await revenir();
await p.getByText("Ou payer hors ligne").click();
await p.waitForTimeout(400);
ok("le formulaire hors ligne s'ouvre", await p.locator("#d-a-b-1").isVisible());
await p.getByRole("button", { name: "J'ai payé" }).click();
await p.waitForTimeout(800);
t = await texte();
ok("la déclaration hors ligne est enregistrée", /Déclaration envoyée/.test(t));
ok("et elle ne confirme RIEN toute seule",
  await p.evaluate(() => window.__db.bookings[0].status === "en_attente_paiement"));

ok("aucune erreur JavaScript", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DU PAIEMENT EN LIGNE PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
