// Informations affichées sur les pages légales. Un seul fichier à modifier.
//
// RÈGLE D'AFFICHAGE : un champ laissé vide n'apparaît PAS sur le site.
// Aucune mention « à compléter » n'est jamais montrée au public : soit l'information est là,
// soit la ligne disparaît. Rien n'est inventé.

export const SOCIETE = {
  /** Nom commercial affiché partout. */
  nomCommercial: "YIRI",

  /** Dénomination inscrite au registre du commerce. Vide = non affichée. */
  nom: "",

  /** Forme juridique (SARL, entreprise individuelle…). Vide = non affichée. */
  forme: "",

  /** Capital social. Vide = non affiché. */
  capital: "",

  /** Numéro RCCM. Vide = non affiché. */
  rccm: "",

  /** Numéro IFU. Vide = non affiché. */
  ifu: "",

  /** Adresse du siège. Vide = seule la ville est mentionnée. */
  adresse: "",

  /** Ville de rattachement, utilisée aussi pour la juridiction compétente. */
  ville: "Ouagadougou",

  /** Adresse de contact publique, neutre : elle ne révèle aucun nom de personne. */
  email: "infos.yiri@gmail.com",

  /** Numéro WhatsApp public, au format lisible. Vide = non affiché. */
  whatsapp: "+226 06 44 33 15",

  /** Le même numéro sans espaces ni signe, pour le lien wa.me. */
  whatsappLien: "22606443315",

  /** Récépissé de déclaration CIL. Vide = la page dit simplement que les traitements relèvent de la loi. */
  cil: "",

  /** Villes où YIRI opère. */
  villes: "Ouagadougou et Bobo-Dioulasso",
};

export const HEBERGEUR = {
  nom: "Supabase, Inc.",
  adresse: "970 Toa Payoh North, #07-04, Singapour 318992",
  site: "https://supabase.com",
  /** Région exacte du projet. Vide = la page dit seulement « hors du Burkina Faso ». */
  region: "",
};

/** Tarifs publics, identiques à ceux appliqués par le serveur. */
export const TARIFS = { mensuel: 5000, annuel: 30000 };

/** Durées de conservation réellement appliquées. */
export const CONSERVATION = {
  imagesPiece: "supprimées dès que l'équipe a pris sa décision",
  numeroPiece: "conservé tant que le compte propriétaire existe, puis cinq ans",
  compte: "trois ans après la fermeture du compte",
  paiements: "dix ans, durée de conservation des pièces comptables",
  journal: "trois ans",
};

export const MAJ = "10 octobre 2026";

/** Année courante, pour le bas de page. */
export const ANNEE = new Date().getFullYear();
