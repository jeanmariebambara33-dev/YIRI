export const OWNER = { name: "Jean-Marie", email: "admin@yiri.test", code: "motdepasse-test" };
/** Ouvre l'espace équipe : crée le compte principal au premier passage, sinon se connecte. */
export async function adminLogin(p, creds = OWNER) {
  await p.getByRole("button", { name: "Espace équipe" }).click();
  if (await p.locator("text=Première configuration").count()) {
    await p.fill("#t-name", creds.name); await p.fill("#t-email", creds.email); await p.fill("#t-code", creds.code); await p.fill("#t-code2", creds.code);
    await p.getByRole("button", { name: "Créer le compte administrateur" }).click();
  } else {
    await p.fill("#t-email", creds.email); await p.fill("#t-code", creds.code);
    await p.getByRole("button", { name: "Se connecter" }).click();
  }
  await p.waitForSelector("text=Administration YIRI");
}

/** Confirme le premier paiement en attente : saisit le montant attendu lu dans le tableau (comme le ferait l'admin). */
export async function confirmFirstPayment(p, { wrongFirst = false } = {}) {
  const row = p.locator("tbody tr", { has: p.getByRole("button", { name: "Confirmer la réception" }) }).first();
  const amount = (await row.locator("td").nth(2).innerText()).replace(/\D/g, "");
  if (wrongFirst) {
    await row.getByRole("textbox").fill(String(+amount - 1000));
    await row.getByRole("button", { name: "Confirmer la réception" }).click();
  }
  await row.getByRole("textbox").fill(amount);
  await row.getByRole("button", { name: "Confirmer la réception" }).click();
}
