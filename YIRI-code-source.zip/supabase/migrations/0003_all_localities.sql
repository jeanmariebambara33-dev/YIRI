-- Toutes les localités du Burkina Faso : la ville devient un texte libre (plus de liste fermée à deux villes).
drop view if exists public_listings;
alter table properties alter column city type text using city::text;
alter table partnership_applications alter column city type text using city::text;
drop type if exists city;
alter table properties add constraint properties_city_len check (char_length(btrim(city)) between 2 and 60);
alter table partnership_applications add constraint partnership_city_len check (char_length(btrim(city)) between 2 and 60);

-- Vue publique recréée à l'identique (elle dépend de la colonne city).
create or replace view public_listings with (security_invoker = false) as
select p.id, p.offer, p.title, p.description, p.city, p.district, p.capacity, p.bedrooms, p.beds,
       p.nightly_price_xof, p.min_nights, p.house_rules, p.cancellation_policy
from properties p
where p.status = 'publiee'
  and p.is_demo = false
  and (
    (p.offer = 'annonce' and exists (
      select 1 from subscriptions s
      where s.property_id = p.id and s.status = 'actif' and current_date >= s.starts_at and current_date < s.ends_at))
    or (p.offer in ('gestion','partenariat') and exists (
      select 1 from management_agreements m
      where m.property_id = p.id and m.signed and m.operational_check_done))
  );
grant select on public_listings to anon, authenticated;
