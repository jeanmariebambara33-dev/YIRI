-- Tests de la migration 0007 (compte propriétaire avec pièce d'identité). Base LOCALE vide ; auth.uid() simulé ; Storage simulé (stub).
\o /dev/null
\ir helpers.sql

-- Utilisateurs : 1=futur propriétaire (validé), 2=sans fichier, 3=pièce à renvoyer, 4=déjà propriétaire, 5=ADMIN,
-- 6=équipe « validation », 7=équipe « reservations » (sans validation), 9=refusé, 10=pièce incomplète, 11=doublon du n°1
insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 12) n;
insert into user_roles (user_id, role) values (t.u(4), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values (t.u(6), 'validation', t.u(5)), (t.u(7), 'reservations', t.u(5));

-- Un brouillon d'annonce par futur propriétaire (la pièce n'est demandée qu'au moment de publier)
insert into properties (id, owner_id, offer, title, description, city, district, private_address, capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
select t.p(n), t.u(n), 'annonce', 'Brouillon ' || n, 'desc', 'Ouagadougou', 'Centre', 'adresse ' || n, 2, 1, 1, 10000, 1, 'brouillon', false
  from unnest(array[1, 3, 6, 9, 10, 11]) n;

create function t.up(n int, side text, ext text default 'jpg') returns text language sql as $$
  select format($q$insert into storage.objects (bucket_id, name) values ('owner-identity', %L)$q$, t.u(n) || '/' || side || '.' || ext) $$;
grant execute on function t.up(int, text, text) to anon, authenticated;
create or replace function t.draft(k int, st text default 'brouillon') returns text language sql as $$
  select format($q$insert into properties (id, owner_id, offer, title, description, city, district, private_address, capacity, bedrooms, beds, nightly_price_xof, min_nights, status) values (%L,%L,'annonce','Brouillon','d','Ouagadougou','C','a',2,1,1,1000,1,%L)$q$, t.p(100 + k), t.u(12), st) $$;
grant execute on function t.draft(int, text) to anon, authenticated;

-- ============ A. Configuration du stockage ============
reset role;
select t.eq('bucket owner-identity privé, 5 Mo', $$select (not public and file_size_limit = 5242880)::text from storage.buckets where id = 'owner-identity'$$, 'true');
select t.eq('bucket : images seulement (3 types)', $$select cardinality(allowed_mime_types)::text from storage.buckets where id = 'owner-identity'$$, '3');
select t.eq('6 règles de stockage yiri_identity_*', $$select count(*)::text from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname like 'yiri_identity_%'$$, '6');

-- ============ B. Envoi des fichiers (règles de stockage) ============
select t.as(0);
select t.must_fail('visiteur : ne peut pas envoyer de fichier', t.up(1, 'recto'));
reset role; select t.as(1);
select t.ok('futur propriétaire 1 : envoie son recto', t.up(1, 'recto'));
select t.ok('futur propriétaire 1 : envoie son verso (png)', t.up(1, 'verso', 'png'));
select t.must_fail('nom de fichier libre refusé', format($$insert into storage.objects (bucket_id, name) values ('owner-identity', %L)$$, t.u(1) || '/carte.jpg'));
select t.must_fail('type PDF refusé (extension)', t.up(1, 'recto', 'pdf'));
select t.must_fail('dossier d''un autre utilisateur refusé', t.up(2, 'recto'));
select t.must_fail('dossier non conforme refusé', $$insert into storage.objects (bucket_id, name) values ('owner-identity', 'x/recto.jpg')$$);
select t.cnt('1 : voit ses 2 fichiers', $$select 1 from storage.objects where bucket_id = 'owner-identity'$$, 2);
reset role; select t.as(2);
select t.cnt('2 : ne voit pas les fichiers de 1', $$select 1 from storage.objects where bucket_id = 'owner-identity'$$, 0);
reset role; select t.as(6);
select t.cnt('équipe validation : ne voit PAS les images sans avoir ouvert le dossier', $$select 1 from storage.objects where bucket_id = 'owner-identity'$$, 0);
reset role; select t.as(7);
select t.cnt('équipe sans validation : ne voit rien', $$select 1 from storage.objects where bucket_id = 'owner-identity'$$, 0);

-- ============ C. Envoi de la demande (numéro) ============
reset role; select t.as(0);
select t.must_fail('visiteur : submit_owner_identity refusé', $$select submit_owner_identity('cnib', 'B1234567')$$);
reset role; select t.as(2);
select t.must_fail('sans fichier : refusé', $$select submit_owner_identity('cnib', 'B1234567')$$);
reset role; select t.as(1);
select t.must_fail('type de pièce invalide refusé', $$select submit_owner_identity('badge', 'B1234567')$$);
select t.must_fail('numéro trop court refusé', $$select submit_owner_identity('cnib', 'AB')$$);
select t.must_fail('numéro avec caractères interdits refusé', $$select submit_owner_identity('cnib', 'B12;drop table')$$);
select t.ok('1 : envoie sa demande (n° avec espaces et tirets)', $$select submit_owner_identity('cnib', 'b 123-456')$$);
select t.must_fail('1 : lecture directe de la table d''identité refusée', $$select * from owner_identity$$);
select t.must_fail('1 : insertion directe dans la table refusée', format($$insert into owner_identity (user_id, id_type, id_number, id_number_norm) values (%L, 'cnib', 'X12345', 'X12345')$$, t.u(1)));
select t.must_fail('1 : renvoyer une 2e fois refusé', $$select submit_owner_identity('cnib', 'B123456')$$);
select t.eq('1 : état « en attente »', $$select state from my_owner_identity()$$, 'en_attente');
select t.eq('1 : numéro masqué, jamais en clair', $$select id_number_masked from my_owner_identity()$$, '****456');
select t.eq('1 : voit 2 fichiers envoyés', $$select files_sent::text from my_owner_identity()$$, '2');
select t.must_fail('1 : plus d''envoi de fichier après la demande', t.up(1, 'recto', 'webp'));
select t.rows('1 : ne peut plus supprimer ses fichiers après la demande', $$delete from storage.objects where bucket_id = 'owner-identity'$$, 0);
select t.must_fail('1 : ne peut pas s''attribuer le rôle', format($$select grant_owner_role(%L)$$, t.u(1)));
select t.must_fail('1 : ne peut pas écrire user_roles directement', format($$insert into user_roles (user_id, role) values (%L, 'proprietaire')$$, t.u(1)));
reset role; select t.as(4);
select t.must_fail('déjà propriétaire : refusé', $$select submit_owner_identity('cnib', 'Z999999')$$);

-- doublon : même numéro, autre mise en forme
reset role; select t.as(11);
select t.ok('11 : envoie ses fichiers', t.up(11, 'recto'));
select t.ok('11 : envoie ses fichiers (verso)', t.up(11, 'verso'));
select t.must_fail('11 : même pièce que 1 (autre mise en forme) refusée', $$select submit_owner_identity('cnib', 'B123456')$$);
select t.ok('11 : même numéro mais autre TYPE de pièce accepté (pas le même document)', $$select submit_owner_identity('passeport', 'B123456')$$);

-- cas supplémentaires : 3 (à renvoyer), 9 (refus), 10 (fichier manquant)
reset role; select t.as(3);
select t.ok('3 : recto', t.up(3, 'recto')); select t.ok('3 : verso', t.up(3, 'verso'));
select t.ok('3 : demande', $$select submit_owner_identity('permis', 'P777777')$$);
reset role; select t.as(9);
select t.ok('9 : recto', t.up(9, 'recto')); select t.ok('9 : verso', t.up(9, 'verso'));
select t.ok('9 : demande', $$select submit_owner_identity('cnib', 'R555555')$$);
reset role; select t.as(10);
select t.ok('10 : recto seulement', t.up(10, 'recto'));
select t.must_fail('10 : demande refusée avec le seul recto', $$select submit_owner_identity('cnib', 'M444444')$$);
reset role; select t.as(6);
select t.ok('6 (équipe) : sa propre demande', t.up(6, 'recto')); select t.ok('6 : verso', t.up(6, 'verso'));
select t.ok('6 : demande', $$select submit_owner_identity('cnib', 'S333333')$$);

reset role;
select t.eq('le numéro n''apparaît jamais dans le journal d''audit', $$select count(*)::text from audit_logs where coalesce(after::text, '') || entity_id || coalesce(reason, '') like '%123456%'$$, '0');
select t.eq('une entrée d''audit « identity.submitted » par demande (1, 11, 3, 9, 6)', $$select count(*)::text from audit_logs where action = 'identity.submitted'$$, '5');

-- ============ D. Ouverture du dossier par l'équipe (journalisée) ============
select t.as(1);
select t.must_fail('voyageur : open_owner_identity refusé', format($$select * from open_owner_identity(%L)$$, t.u(1)));
reset role; select t.as(7);
select t.must_fail('équipe sans « validation » : open refusé', format($$select * from open_owner_identity(%L)$$, t.u(1)));
reset role; select t.as(0);
select t.must_fail('visiteur : open refusé', format($$select * from open_owner_identity(%L)$$, t.u(1)));
reset role; select t.as(6);
select t.must_fail('validation : dossier inexistant refusé', format($$select * from open_owner_identity(%L)$$, t.u(2)));
select t.eq('validation : lit le numéro du dossier de 1', format($$select id_number from open_owner_identity(%L)$$, t.u(1)), 'b 123-456');
select t.cnt('validation : après ouverture, voit les 2 images de 1', format($$select 1 from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(1)::text), 2);
select t.cnt('validation : ne voit PAS les images d''un dossier non ouvert (3)', format($$select 1 from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(3)::text), 0);
reset role;
select t.eq('l''ouverture est journalisée (identity.viewed)', format($$select count(*)::text from audit_logs where action = 'identity.viewed' and entity_id = %L and actor_id = %L$$, t.u(1)::text, t.u(6)), '1');
-- expiration du droit de lecture (15 min)
alter table audit_logs disable trigger user;      -- le journal est en ajout seul : on lève la garde le temps du test (base locale)
update audit_logs set created_at = now() - interval '16 minutes' where action = 'identity.viewed';
alter table audit_logs enable trigger user;
select t.as(6);
select t.cnt('validation : droit de lecture expiré après 15 minutes', format($$select 1 from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(1)::text), 0);

-- ============ E. Décisions ============
reset role; select t.as(1);
select t.must_fail('voyageur : reject_owner_identity refusé', format($$select reject_owner_identity(%L, 'non')$$, t.u(3)));
reset role; select t.as(7);
select t.must_fail('équipe sans validation : grant refusé', format($$select grant_owner_role(%L)$$, t.u(1)));
reset role; select t.as(6);
select t.must_fail('validation : ne peut pas s''accorder le rôle à soi-même', format($$select grant_owner_role(%L)$$, t.u(6)));
select t.must_fail('validation : ne peut pas décider sur son propre dossier (refus)', format($$select reject_owner_identity(%L, 'x')$$, t.u(6)));
select t.must_fail('validation : sans pièce, pas de rôle (utilisateur 2)', format($$select grant_owner_role(%L)$$, t.u(2)));
reset role;
delete from storage.objects where name = t.u(10)::text || '/recto.jpg';       -- pas de demande pour 10 : rien à accorder
select t.as(6);
select t.must_fail('validation : dossier 10 (pas de demande) refusé', format($$select grant_owner_role(%L)$$, t.u(10)));
-- fichier disparu après la demande de 3 : l'équipe ne peut pas accorder
reset role;
delete from storage.objects where name = t.u(11)::text || '/verso.jpg';
select t.as(6);
select t.must_fail('validation : verso disparu → rôle refusé (utilisateur 11)', format($$select grant_owner_role(%L)$$, t.u(11)));
select t.ok('validation : accorde le rôle à 1', format($$select grant_owner_role(%L)$$, t.u(1)));
select t.must_fail('validation : double décision refusée', format($$select grant_owner_role(%L)$$, t.u(1)));
select t.must_fail('validation : refuser après acceptation impossible', format($$select reject_owner_identity(%L, 'tard')$$, t.u(1)));
reset role;
select t.eq('1 : rôle propriétaire créé', format($$select count(*)::text from user_roles where user_id = %L and role = 'proprietaire' and granted_by = %L$$, t.u(1), t.u(6)), '1');
select t.eq('1 : état « vérifié » et profil vérifié', format($$select (i.state = 'verifie' and p.verification_status = 'verifie')::text from owner_identity i join owner_profiles p using (user_id) where i.user_id = %L$$, t.u(1)), 'true');
select t.as(6);
select t.ok('validation : demande de renvoi pour 3', format($$select reject_owner_identity(%L, 'Photo floue', true)$$, t.u(3)));
select t.ok('validation : refus définitif pour 9', format($$select reject_owner_identity(%L, 'Pièce invalide')$$, t.u(9)));
reset role;
select t.eq('9 : profil propriétaire « refusé »', format($$select verification_status from owner_profiles where user_id = %L$$, t.u(9)), 'refuse');
select t.eq('9 : aucun rôle propriétaire', format($$select count(*)::text from user_roles where user_id = %L and role = 'proprietaire'$$, t.u(9)), '0');

-- renvoi (3)
select t.as(3);
select t.eq('3 : voit « à renvoyer » et la note', $$select state || '/' || decision_note from my_owner_identity()$$, 'a_renvoyer/Photo floue');
select t.ok('3 : peut supprimer son recto flou', $$delete from storage.objects where bucket_id = 'owner-identity' and name like '%/recto.jpg'$$);
select t.ok('3 : renvoie un nouveau recto', t.up(3, 'recto'));
select t.ok('3 : renvoie la demande', $$select submit_owner_identity('permis', 'P777777')$$);
select t.eq('3 : de nouveau « en attente »', $$select state from my_owner_identity()$$, 'en_attente');
-- refus (9)
reset role; select t.as(9);
select t.must_fail('9 : refusé définitivement, plus d''envoi', t.up(9, 'recto', 'png'));
select t.must_fail('9 : ne peut pas renvoyer une demande', $$select submit_owner_identity('cnib', 'R555556')$$);
select t.eq('9 : état « refusé »', $$select state from my_owner_identity()$$, 'refuse');
reset role; select t.as(1);
select t.must_fail('1 (maintenant propriétaire) : ne peut plus soumettre', $$select submit_owner_identity('cnib', 'N111111')$$);

-- ============ F. Suppression des images après décision ============
reset role; select t.as(1);
select t.must_fail('voyageur/propriétaire : identity_files_pending refusé', $$select * from identity_files_pending()$$);
reset role; select t.as(6);
select t.cnt('équipe : 2 dossiers décidés avec images restantes (1 et 9)', $$select 1 from identity_files_pending()$$, 2);
select t.must_fail('confirmation refusée tant que des images existent (1)', format($$select confirm_identity_files_deleted(%L)$$, t.u(1)));
select t.must_fail('confirmation refusée pour un dossier non décidé (3)', format($$select confirm_identity_files_deleted(%L)$$, t.u(3)));
select t.rows('équipe : ne peut PAS supprimer les images d''un dossier non décidé (3)', format($$delete from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(3)::text), 0);
select t.rows('équipe : sans ouverture récente du dossier, la suppression ne touche rien (ouvrir → supprimer → confirmer)', format($$delete from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(1)::text), 0);
select t.ok('équipe : ouvre le dossier de 1 (journalisé)', format($$select * from open_owner_identity(%L)$$, t.u(1)));
select t.ok('équipe : ouvre le dossier de 9 (journalisé)', format($$select * from open_owner_identity(%L)$$, t.u(9)));
select t.rows('équipe : supprime les 2 images de 1 (décidé)', format($$delete from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(1)::text), 2);
select t.ok('équipe : confirme la suppression pour 1', format($$select confirm_identity_files_deleted(%L)$$, t.u(1)));
select t.rows('équipe : supprime les images du dossier refusé 9', format($$delete from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = %L$$, t.u(9)::text), 2);
select t.ok('équipe : confirme pour 9', format($$select confirm_identity_files_deleted(%L)$$, t.u(9)));
select t.cnt('plus aucun dossier en attente de suppression', $$select 1 from identity_files_pending()$$, 0);
reset role; select t.as(7);
select t.rows('équipe sans « validation » : ne supprime rien', $$delete from storage.objects where bucket_id = 'owner-identity'$$, 0);
reset role; select t.as(1);
select t.rows('un utilisateur ordinaire ne supprime pas les fichiers des autres', $$delete from storage.objects where bucket_id = 'owner-identity'$$, 0);
select t.eq('1 : images supprimées, 0 fichier', $$select files_sent::text || '/' || files_deleted::text from my_owner_identity()$$, '0/true');
reset role;
select t.eq('le NUMÉRO est conservé après suppression des images (choix du fondateur)', format($$select id_number from owner_identity where user_id = %L$$, t.u(1)), 'b 123-456');
select t.eq('suppression journalisée (2 confirmations)', $$select count(*)::text from audit_logs where action = 'identity.files_deleted'$$, '2');
select t.eq('décisions journalisées', $$select string_agg(action, ',' order by action) from (select distinct action from audit_logs where action in ('role.owner_granted','identity.rejected','identity.resend_requested')) s$$, 'identity.rejected,identity.resend_requested,role.owner_granted');

-- ============ G. Accès fermé ============
select t.as(0);
select t.must_fail('visiteur : lecture directe de owner_identity refusée', $$select * from owner_identity$$);
select t.must_fail('visiteur : my_owner_identity refusé', $$select * from my_owner_identity()$$);
select t.must_fail('visiteur : confirm_identity_files_deleted refusé', format($$select confirm_identity_files_deleted(%L)$$, t.u(1)));
reset role;
select t.eq('aucun droit de table pour anon/authenticated sur owner_identity', $$select count(*)::text from information_schema.role_table_grants where table_name = 'owner_identity' and grantee in ('anon','authenticated','PUBLIC')$$, '0');
select t.eq('fonctions internes non exécutables par authenticated (file_count, files_left)', $$select count(*)::text from pg_proc where proname in ('identity_file_count','identity_files_left') and (has_function_privilege('authenticated', oid, 'execute') or has_function_privilege('anon', oid, 'execute'))$$, '0');
select t.eq('AUCUNE fonction de la migration 0007 n''est exécutable par anon', $$select count(*)::text from pg_proc where proname in ('identity_pending','identity_file_count','identity_files_left','identity_upload_open','identity_access_recent','identity_delete_allowed','submit_owner_identity','my_owner_identity','open_owner_identity','grant_owner_role','reject_owner_identity','identity_files_pending','confirm_identity_files_deleted') and has_function_privilege('anon', oid, 'execute')$$, '0');
select t.eq('les 7 fonctions publiques ne sont pas exécutables par anon', $$select count(*)::text from pg_proc where proname in ('submit_owner_identity','my_owner_identity','open_owner_identity','grant_owner_role','reject_owner_identity','identity_files_pending','confirm_identity_files_deleted') and has_function_privilege('anon', oid, 'execute')$$, '0');


-- ============ H. Parcours « compte → brouillon → pièce au moment de publier » ============
reset role; select t.as(0);
select t.must_fail('visiteur : ne peut pas créer d''annonce', format($$insert into properties (owner_id, offer, title, description, city, district, private_address, capacity, bedrooms, beds, nightly_price_xof, min_nights, status) values (%L,'annonce','x','d','Ouagadougou','C','a',2,1,1,1000,1,'brouillon')$$, t.u(12)));
reset role; select t.as(12);
select t.ok('simple voyageur : crée un 1er brouillon', t.draft(1));
select t.ok('simple voyageur : 2e brouillon', t.draft(2));
select t.ok('simple voyageur : 3e brouillon', t.draft(3));
select t.must_fail('simple voyageur : 4e brouillon refusé (3 au plus tant que non vérifié)', t.draft(4));
select t.must_fail('simple voyageur : ne peut pas créer directement une annonce « soumise »', t.draft(5, 'soumise'));
select t.must_fail('simple voyageur : ne peut pas créer une annonce « publiée »', t.draft(6, 'publiee'));
select t.must_fail('simple voyageur : ne peut pas créer pour un autre compte', format($$insert into properties (owner_id, offer, title, description, city, district, private_address, capacity, bedrooms, beds, nightly_price_xof, min_nights, status) values (%L,'annonce','x','d','Ouagadougou','C','a',2,1,1,1000,1,'brouillon')$$, t.u(2)));
select t.ok('simple voyageur : peut déposer une photo dans son brouillon (Storage)', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(12) || '/' || t.p(101) || '/a.jpg'));
select t.must_fail('simple voyageur : pas de photo dans l''annonce d''un autre', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(12) || '/' || t.p(1) || '/a.jpg'));
select t.must_fail('simple voyageur : pas de photo dans le dossier d''un autre', format($$insert into storage.objects (bucket_id, name) values ('property-photos', %L)$$, t.u(1) || '/' || t.p(1) || '/a.jpg'));
select t.must_fail('publier SANS pièce d''identité refusé', format($$update properties set status = 'soumise' where id = %L$$, t.p(101)));
select t.must_fail('envoyer la pièce sans les fichiers refusé', $$select submit_owner_identity('cnib', 'N222222')$$);
select t.ok('fichiers de la pièce', t.up(12, 'recto')); select t.ok('fichiers de la pièce (verso)', t.up(12, 'verso'));
select t.ok('envoi de la pièce au moment de publier', $$select submit_owner_identity('cnib', 'N222222')$$);
select t.ok('publier (soumettre) maintenant accepté', format($$update properties set status = 'soumise' where id = %L$$, t.p(101)));
select t.cnt('le brouillon ne contient pas d''annonce publique', format($$select 1 from public_listings where id = %L$$, t.p(101)), 0);
reset role; select t.as(0);
select t.cnt('visiteur : ne voit ni brouillon ni soumise', format($$select 1 from public_listings where id in (%L, %L)$$, t.p(101), t.p(102)), 0);
-- ajouts nécessaires à l'approbation (contact + photo vérifiée), puis refus d'approuver avant vérification
reset role;
insert into property_contacts (property_id, contact_name, phone, whatsapp) values (t.p(101), 'Contact', '+226 70 00 00 12', true);
insert into property_photos (property_id, storage_path, position, rights_checked) values (t.p(101), t.u(12) || '/' || t.p(101) || '/a.jpg', 0, true);
select t.as(6);
select t.must_fail('équipe : ne peut PAS approuver l''annonce avant la vérification du propriétaire', format($$select set_listing_status(%L, 'approuvee')$$, t.p(101)));
select t.ok('équipe : ouvre le dossier de 12', format($$select * from open_owner_identity(%L)$$, t.u(12)));
select t.ok('équipe : accorde le rôle propriétaire à 12', format($$select grant_owner_role(%L)$$, t.u(12)));
select t.ok('équipe : peut maintenant approuver l''annonce', format($$select set_listing_status(%L, 'approuvee')$$, t.p(101)));
reset role;
select t.must_fail('aucun acteur (même serveur) ne peut approuver l''annonce d''un non-vérifié', format($$update properties set status = 'approuvee' where id = %L$$, t.p(11)));
select t.must_fail('ni la publier', format($$update properties set status = 'publiee' where id = %L$$, t.p(11)));
select t.as(12);
select t.ok('12 (vérifié) : peut créer une 4e annonce (le plafond de 3 ne vise que les non-vérifiés)', t.draft(4));

reset role;
\o
do $$ begin
  if exists (select 1 from t.results where not pass) then
    raise exception 'ÉCHECS : %', (select string_agg(label || ' [' || coalesce(detail,'') || ']', E'\n  ') from t.results where not pass);
  end if;
end $$;
select count(*) || ' tests de la migration 0007 réussis, 0 échec' from t.results;
