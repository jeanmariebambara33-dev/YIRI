-- Tests de la migration 0022 : les relevés de revenus des propriétaires.
--
-- Ce qui compte ici, c'est l'argent. Trois choses sont éprouvées sans indulgence : que la somme
-- des deux parts égale TOUJOURS le revenu partageable, que le pourcentage de CHAQUE contrat est
-- respecté, et qu'une période ne peut pas être clôturée ni payée deux fois.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(4), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'paiements', t.u(5));

-- Propriétaire 3 : DEUX logements sous gestion, à des pourcentages DIFFÉRENTS.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'gestion', 'Villa 65', 'd', 'Ouagadougou', 'K', 'a', 4,2,2, 20000,1, 'publiee', false),
       (t.p(2), t.u(3), 'gestion', 'Studio 60', 'd', 'Ouagadougou', 'Z', 'a', 2,1,1, 10000,1, 'publiee', false),
       (t.p(3), t.u(3), 'annonce', 'Annonce',  'd', 'Ouagadougou', 'G', 'a', 2,1,1, 10000,1, 'publiee', false),
       (t.p(4), t.u(4), 'gestion', 'Autre',    'd', 'Bobo-Dioulasso', 'A', 'a', 2,1,1, 10000,1, 'publiee', false);
insert into management_agreements (property_id, contract_version, owner_percent, starts_on, signed, operational_check_done, expense_policy_version)
values (t.p(1), 'v1', 65, current_date - 400, true, true, 'v1'),
       (t.p(2), 'v1', 60, current_date - 400, true, true, 'v1'),
       (t.p(4), 'v1', 60, current_date - 400, true, true, 'v1');

-- Séjours PAYÉS, terminés le mois dernier.
create or replace function t.sejour(b uuid, p uuid, g uuid, depart date, nuits int, montant int, ref text)
returns void language plpgsql as $$
begin
  insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status)
  values (b, p, g, daterange(depart - nuits, depart), 2, montant / nuits, montant, montant, 'terminee');
  insert into payment_transactions (id, purpose, booking_id, amount_xof, status, provider, provider_reference, idempotency_key, fee_xof)
  values (gen_random_uuid(), 'booking', b, montant, 'reussi', 'saspay', ref, 'idem-' || ref, 1000);
end $$;

select t.sejour(t.b(1), t.p(1), t.u(1), current_date - 10, 3, 100000, 'r1');  -- villa, 65 %
select t.sejour(t.b(2), t.p(2), t.u(2), current_date - 8,  2,  50000, 'r2');  -- studio, 60 %
select t.sejour(t.b(3), t.p(3), t.u(1), current_date - 6,  2,  40000, 'r3');  -- ANNONCE : hors gestion
select t.sejour(t.b(4), t.p(4), t.u(2), current_date - 5,  2,  30000, 'r4');  -- autre propriétaire

-- ============ Le calcul ============
reset role; select t.as(7);
select t.eq('l''aperçu ne compte que les logements SOUS GESTION',
  format($$select logements::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '2');
select t.eq('et seulement les séjours de CE propriétaire',
  format($$select sejours::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '2');
select t.eq('l''encaissé est la somme des deux séjours sous gestion',
  format($$select encaisse_xof::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '150000');
-- 100000 à 65 % = 65000 ; 50000 à 60 % = 30000 → 95000
select t.eq('CHAQUE contrat applique SON pourcentage : 65 % sur la villa, 60 % sur le studio',
  format($$select part_proprietaire_xof::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '95000');
select t.eq('la commission est le reste exact',
  format($$select commission_yiri_xof::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '55000');
select t.eq('LA RÈGLE : part + commission = revenu partageable, toujours',
  format($$select (part_proprietaire_xof + commission_yiri_xof = rlp_xof)::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), 'true');
select t.eq('les frais du prestataire ne sont pas déduits de la part du propriétaire',
  format($$select (rlp_xof = encaisse_xof)::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), 'true');
select t.eq('mais ils sont affichés, pour que l''équipe les voie',
  format($$select frais_xof::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '2000');

-- Un remboursement réduit le revenu partageable.
reset role;
insert into refunds (payment_transaction_id, amount_xof, reason, status)
select id, 20000, 'geste commercial', 'approuve' from payment_transactions where provider_reference = 'r1';
select t.as(7);
select t.eq('un remboursement réduit le revenu partageable',
  format($$select rlp_xof::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '130000');
-- villa : 100000 - 20000 = 80000 à 65 % = 52000 ; studio 30000 → 82000
select t.eq('et la part du propriétaire suit, contrat par contrat',
  format($$select part_proprietaire_xof::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), '82000');
select t.eq('la somme reste exacte après remboursement',
  format($$select (part_proprietaire_xof + commission_yiri_xof = rlp_xof)::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), 'true');

-- ============ La clôture ============
select t.must_fail('on ne clôture pas une période qui n''est pas finie',
  format($$select close_owner_statement(%L, current_date - 10, current_date + 10)$$, t.u(3)));
select t.must_fail('ni une période à l''envers',
  format($$select close_owner_statement(%L, current_date, current_date - 40)$$, t.u(3)));
select t.must_fail('ni une période sans aucun séjour payé',
  format($$select close_owner_statement(%L, current_date - 400, current_date - 390)$$, t.u(3)));
select t.must_fail('les dépenses négatives sont refusées',
  format($$select close_owner_statement(%L, current_date - 40, current_date, -500)$$, t.u(3)));

select t.ok('l''équipe clôture la période, avec 12 000 de dépenses propriétaire',
  format($$select close_owner_statement(%L, current_date - 40, current_date, 12000)$$, t.u(3)));
reset role;
select t.eq('un relevé est enregistré', $$select count(*)::text from owner_statements$$, '1');
select t.eq('au bon revenu partageable', $$select rlp_xof::text from owner_statements$$, '130000');
select t.eq('à la bonne part', $$select owner_share_xof::text from owner_statements$$, '82000');
select t.eq('la contrainte de la base tient : part + commission = revenu',
  $$select (owner_share_xof + yiri_commission_xof = rlp_xof)::text from owner_statements$$, 'true');
select t.eq('le dû est la part moins les dépenses', $$select amount_due_xof::text from owner_statements$$, '70000');
select t.eq('le propriétaire est prévenu',
  format($$select count(*)::text from notifications where user_id = %L and type = 'statement.disponible'$$, t.u(3)), '1');
select t.eq('et le journal garde le détail du calcul',
  $$select count(*)::text from audit_logs where action = 'statement.closed' and (after->>'rlp')::int = 130000$$, '1');

select t.as(7);
select t.must_fail('LA MÊME PÉRIODE NE PEUT PAS ÊTRE CLÔTURÉE DEUX FOIS (sinon on paie double)',
  format($$select close_owner_statement(%L, current_date - 40, current_date, 12000)$$, t.u(3)));
select t.eq('l''aperçu signale qu''elle est déjà clôturée',
  format($$select deja_cloture::text from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)), 'true');

-- ============ Le versement ============
select t.must_fail('un montant supérieur au dû est refusé',
  format($$select register_payout((select id from owner_statements), 999999, '**0001', 'VIR-1')$$));
select t.must_fail('une référence vide est refusée : elle trace le virement',
  format($$select register_payout((select id from owner_statements), 70000, '**0001', '  ')$$));
select t.must_fail('une destination vide aussi',
  format($$select register_payout((select id from owner_statements), 70000, '', 'VIR-1')$$));
select t.ok('un versement partiel est accepté',
  $$select register_payout((select id from owner_statements), 30000, '**0001', 'VIR-1')$$);
reset role;
select t.eq('le relevé passe « en cours »', $$select status::text from owner_statements$$, 'en_cours');
select t.eq('et retient ce qui a été payé', $$select amount_paid_xof::text from owner_statements$$, '30000');
select t.as(7);
select t.must_fail('on ne verse pas plus que ce qui RESTE dû',
  $$select register_payout((select id from owner_statements), 50000, '**0001', 'VIR-2')$$);
select t.ok('le solde peut être versé',
  $$select register_payout((select id from owner_statements), 40000, '**0001', 'VIR-2')$$);
reset role;
select t.eq('le relevé est réglé', $$select status::text from owner_statements$$, 'verse');
select t.eq('deux versements sont tracés', $$select count(*)::text from payouts$$, '2');
select t.eq('chacun avec sa référence et sa date',
  $$select count(*)::text from payouts where provider_reference is not null and paid_at is not null$$, '2');
select t.eq('le propriétaire est prévenu des deux',
  format($$select count(*)::text from notifications where user_id = %L and type = 'payout.verse'$$, t.u(3)), '2');
select t.as(7);
select t.must_fail('un relevé réglé ne se repaie pas',
  $$select register_payout((select id from owner_statements), 1000, '**0001', 'VIR-3')$$);

-- ============ Cloisonnement ============
reset role; select t.as(3);
select t.eq('le propriétaire voit SON relevé', $$select count(*)::text from my_statements()$$, '1');
select t.eq('avec le détail du calcul, qu''il peut vérifier',
  $$select (rlp_xof = 130000 and owner_share_xof = 82000 and owner_expenses_xof = 12000)::text from my_statements()$$, 'true');
select t.eq('et la référence du virement', $$select (reference is not null)::text from my_statements()$$, 'true');
select t.as(4);
select t.eq('un AUTRE propriétaire ne voit rien', $$select count(*)::text from my_statements()$$, '0');
select t.cnt('et la table ne lui montre aucune ligne', $$select * from owner_statements$$, 0);
select t.cnt('ni aucun versement', $$select * from payouts$$, 0);
select t.must_fail('il ne clôture pas de période',
  format($$select close_owner_statement(%L, current_date - 40, current_date)$$, t.u(4)));
select t.must_fail('il n''enregistre aucun versement',
  $$select register_payout((select id from owner_statements limit 1), 100, '**x', 'VIR-X')$$);
select t.must_fail('il ne voit pas la file de l''équipe', $$select * from statements_queue()$$);
select t.must_fail('ni l''aperçu de qui que ce soit',
  format($$select * from statement_preview(%L, current_date - 40, current_date)$$, t.u(3)));
-- Le droit d'écriture est RETIRÉ, donc la tentative est refusée net.
select t.must_fail('il n''écrit pas dans les relevés',
  $$update owner_statements set amount_paid_xof = 999999$$);

reset role; select t.as(6);
select t.must_fail('l''équipe « validation » ne touche pas à l''argent', $$select * from statements_queue()$$);
select t.must_fail('ni ne clôture',
  format($$select close_owner_statement(%L, current_date - 40, current_date)$$, t.u(4)));
select t.as(0);
select t.must_fail('un visiteur ne voit rien', $$select * from my_statements()$$);

-- ============ La liste de travail ============
reset role; select t.as(7);
select t.ok('l''équipe voit qui reste à régler', $$select * from owners_to_settle()$$);
select t.eq('le propriétaire déjà clôturé n''y figure plus',
  format($$select count(*)::text from owners_to_settle() where owner_id = %L$$, t.u(3)), '0');
select t.eq('celui qui ne l''est pas, oui',
  format($$select count(*)::text from owners_to_settle() where owner_id = %L$$, t.u(4)), '1');
select t.eq('la file des relevés montre le relevé réglé',
  $$select count(*)::text from statements_queue()$$, '1');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0022 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
