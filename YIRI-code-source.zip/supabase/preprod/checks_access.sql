-- YIRI — contrôle d'accès en LECTURE SEULE (aucune écriture dans les tables de l'application).
-- Simule, dans l'éditeur SQL de Supabase, (1) un visiteur non connecté et (2) un utilisateur connecté quelconque
-- sans aucune donnée à son nom, puis compte les lignes visibles dans chaque table et vue du schéma public.
-- Attendu : 0 ligne partout, sauf « amenities » (référentiel public). Les vues publiques ne montrent que les annonces publiées
-- (donc 0 tant qu'aucune annonce réelle n'est publiée). Ceci vérifie la sécurité par ligne au niveau SQL ;
-- cela NE remplace PAS les tests via l'API (voir PREPROD.md §6).
create temp table if not exists yiri_access_check (n serial, controle text, obtenu text, attendu text, statut text);
truncate yiri_access_check;

do $$
declare
  r record; c bigint; bad_anon text := ''; bad_user text := '';
  fake uuid := gen_random_uuid();
begin
  -- 1. visiteur non connecté
  perform set_config('request.jwt.claims', '{"role":"anon"}', true);
  perform set_config('app.uid', '', true);                       -- (utilisé seulement par la base de test locale)
  set local role anon;
  for r in select c2.relname from pg_class c2 join pg_namespace n on n.oid = c2.relnamespace
            where n.nspname = 'public' and c2.relkind in ('r', 'v') and c2.relname <> 'amenities' order by 1 loop
    begin
      execute format('select count(*) from public.%I', r.relname) into c;
      if c > 0 then bad_anon := bad_anon || r.relname || '(' || c || ') '; end if;
    exception when insufficient_privilege then null;             -- refus de droits = aussi un accès fermé
    end;
  end loop;
  reset role;

  -- 2. utilisateur connecté inconnu (aucune donnée à son nom)
  perform set_config('request.jwt.claims', json_build_object('sub', fake, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', fake::text, true);
  perform set_config('app.uid', fake::text, true);
  set local role authenticated;
  for r in select c2.relname from pg_class c2 join pg_namespace n on n.oid = c2.relnamespace
            where n.nspname = 'public' and c2.relkind in ('r', 'v') and c2.relname <> 'amenities' order by 1 loop
    begin
      execute format('select count(*) from public.%I', r.relname) into c;
      if c > 0 then bad_user := bad_user || r.relname || '(' || c || ') '; end if;
    exception when insufficient_privilege then null;
    end;
  end loop;
  reset role;

  insert into yiri_access_check (controle, obtenu, attendu, statut) values
    ('visiteur non connecté : tables/vues contenant des lignes visibles', coalesce(nullif(btrim(bad_anon), ''), 'aucune'), 'aucune (ou vues publiques = annonces publiées réelles)',
       case when bad_anon = '' then 'OK' else 'À EXAMINER' end),
    ('utilisateur connecté sans données : tables/vues contenant des lignes visibles', coalesce(nullif(btrim(bad_user), ''), 'aucune'), 'aucune (ou vues publiques = annonces publiées réelles)',
       case when bad_user = '' then 'OK' else 'À EXAMINER' end);
end $$;
select n, controle, obtenu, attendu, statut from yiri_access_check order by n;
