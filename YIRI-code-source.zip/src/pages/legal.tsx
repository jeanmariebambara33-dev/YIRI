import * as React from "react";
import { SOCIETE, HEBERGEUR, TARIFS, CONSERVATION, MAJ } from "../data/legal";

// Pages légales de YIRI. Le contenu décrit le fonctionnement RÉEL de la plateforme
// (vérification d'identité, suppression des images, confirmation manuelle des paiements,
// blocage de 15 minutes, comptage des consultations de contact).
// Les informations d'entreprise viennent de src/data/legal.ts : un seul endroit à remplir.
//
// AVERTISSEMENT : ces textes sont rédigés avec soin mais ne sont pas un conseil juridique.
// Ils doivent être relus par un juriste au Burkina Faso avant l'ouverture au public.

export type LegalPage = "mentions" | "cgu" | "confidentialite" | "cookies";

const xof = (n: number) => n.toLocaleString("fr-FR").replace(/ | /g, " ") + " FCFA";

/** Liste dont les entrées vides sont simplement absentes : on n'affiche jamais un trou. */
function Infos({ items }: { items: [string, string][] }) {
  const remplies = items.filter(([, v]) => v && v.trim());
  if (remplies.length === 0) return null;
  return <ul className="mt-3 flex list-disc flex-col gap-1.5 pl-5 text-ink">
    {remplies.map(([k, v]) => <li key={k}>{k} : {v}</li>)}
  </ul>;
}

function H2({ children }: { children: React.ReactNode }) {
  return <h2 className="mt-8 font-display text-xl font-bold text-ink">{children}</h2>;
}
function P({ children }: { children: React.ReactNode }) {
  return <p className="mt-3 leading-relaxed text-ink">{children}</p>;
}
function UL({ items }: { items: React.ReactNode[] }) {
  return <ul className="mt-3 flex list-disc flex-col gap-1.5 pl-5 text-ink">{items.map((t, i) => <li key={i}>{t}</li>)}</ul>;
}

function Shell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <article className="mx-auto max-w-3xl py-10">
      <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">{title}</h1>
      <p className="mt-2 text-sm text-muted">Dernière mise à jour : {MAJ}</p>
      {children}
      {SOCIETE.email && (
        <p className="mt-10 rounded-xl border border-line bg-sunk px-4 py-3 text-sm text-muted">
          Une question sur ce texte ? Écrivez à {SOCIETE.email}.
        </p>
      )}
    </article>
  );
}

// ---------------------------------------------------------------------------
function Mentions() {
  const entite = [SOCIETE.nom, SOCIETE.forme, SOCIETE.capital ? `au capital de ${SOCIETE.capital}` : ""].filter(Boolean).join(", ");
  return (
    <Shell title="Mentions légales">
      <H2>Éditeur du service</H2>
      <P>{SOCIETE.nomCommercial} est un service de mise en relation pour la location meublée de courte durée,
        exploité {entite ? `par ${entite}, ` : ""}au Burkina Faso{SOCIETE.adresse ? `, ${SOCIETE.adresse}` : `, à ${SOCIETE.ville}`}.</P>
      <Infos items={[
        ["Registre du commerce et du crédit mobilier", SOCIETE.rccm],
        ["Identifiant financier unique", SOCIETE.ifu],
        ["Adresse e-mail", SOCIETE.email],
        ["WhatsApp", SOCIETE.whatsapp],
      ]} />

      <H2>Hébergement</H2>
      <P>Le service et les données sont hébergés par {HEBERGEUR.nom}, {HEBERGEUR.adresse} ({HEBERGEUR.site}).
        {HEBERGEUR.region
          ? ` Les données sont stockées dans la région ${HEBERGEUR.region}.`
          : " Les serveurs se situent hors du Burkina Faso, sur l'infrastructure de cet hébergeur."}</P>

      <H2>Protection des données</H2>
      <P>Les traitements de données personnelles réalisés par {SOCIETE.nomCommercial} relèvent de la loi n° 001-2021
        du 30 mars 2021 portant protection des personnes à l'égard du traitement des données à caractère personnel, et
        du contrôle de la Commission de l'informatique et des libertés (CIL) du Burkina Faso.
        {SOCIETE.cil ? ` Référence de déclaration : ${SOCIETE.cil}.` : ""}</P>

      <H2>Propriété intellectuelle</H2>
      <P>Le nom {SOCIETE.nomCommercial}, le logo, les textes et l'organisation du service appartiennent à son éditeur.
        Les photographies de logements restent la propriété des propriétaires qui les déposent : en les publiant, ils
        autorisent {SOCIETE.nomCommercial} à les afficher, et garantissent qu'ils disposent des droits nécessaires.</P>

      <H2>Signalement d'un contenu</H2>
      <P>Toute personne qui constate une annonce trompeuse, une photographie utilisée sans droit ou un contenu illicite
        peut le signaler{SOCIETE.email ? ` à ${SOCIETE.email}` : ""}. L'équipe peut suspendre une annonce le temps de
        vérifier.</P>
    </Shell>
  );
}

// ---------------------------------------------------------------------------
function CGU() {
  return (
    <Shell title="Conditions générales d'utilisation">
      <H2>1. Ce qu'est YIRI, et ce qu'elle n'est pas</H2>
      <P>YIRI est une plateforme de mise en relation pour la location meublée de courte durée au Burkina Faso.
        YIRI n'est ni propriétaire ni locataire des logements présentés. Le contrat de séjour est conclu entre le
        voyageur et le propriétaire. YIRI vérifie l'identité des propriétaires et le contenu des annonces, mais ne
        garantit pas l'état réel d'un logement.</P>

      <H2>2. Le compte</H2>
      <P>La consultation des annonces est libre. Réserver, publier un logement, voir les coordonnées d'un propriétaire
        ou déclarer un paiement exigent un compte, créé avec une adresse e-mail et un mot de passe. L'adresse doit être
        confirmée. Chaque personne est responsable de la confidentialité de son mot de passe et des actions faites
        depuis son compte.</P>
      <P>Un compte ne confère aucun rôle particulier à sa création : toute personne qui s'inscrit est un voyageur.
        Le rôle de propriétaire est accordé par l'équipe YIRI, jamais demandé par l'application elle-même.</P>

      <H2>3. Devenir propriétaire : vérification d'identité</H2>
      <P>Toute personne connectée peut préparer jusqu'à trois annonces en brouillon. Au moment de demander la
        publication, la plateforme exige la pièce d'identité du propriétaire : le recto, le verso et le numéro.</P>
      <UL items={[
        "L'équipe YIRI consulte ces documents uniquement pour vérifier l'identité. Chaque consultation est enregistrée, avec le nom de la personne et l'heure.",
        "Les images sont supprimées dès que la décision est prise, qu'elle soit favorable ou non.",
        "Le numéro de la pièce est conservé, afin d'éviter qu'une même pièce serve à ouvrir plusieurs comptes.",
        "Une pièce illisible peut être redemandée. Un refus est motivé.",
      ]} />
      <P>Fournir une pièce qui n'est pas la sienne, ou une pièce falsifiée, entraîne la fermeture du compte et peut
        faire l'objet de poursuites.</P>

      <H2>4. Les annonces</H2>
      <P>Le propriétaire est seul responsable de ce qu'il publie : description, prix, photographies, adresse,
        disponibilité. Il garantit qu'il a le droit de louer le logement et d'en publier les images.</P>
      <P>Une annonce est examinée par l'équipe avant publication. Elle peut être approuvée, renvoyée pour correction
        avec un motif, ou refusée. Une modification importante d'une annonce déjà en ligne, notamment le prix,
        l'adresse ou la capacité, la renvoie automatiquement en validation. Un propriétaire ne peut jamais approuver
        ni publier sa propre annonce.</P>
      <P>Une annonce publiée peut être suspendue à tout moment si elle devient trompeuse, si le logement n'est plus
        disponible, ou en cas de signalement sérieux.</P>

      <H2>5. L'abonnement YIRI Annonce</H2>
      <P>La publication d'une annonce dans l'offre YIRI Annonce suppose un abonnement actif : {xof(TARIFS.mensuel)} par
        mois ou {xof(TARIFS.annuel)} par an. L'annonce n'apparaît publiquement que pendant la période couverte.
        À l'échéance, elle cesse d'être visible immédiatement, sans être supprimée : un renouvellement la réaffiche
        aussitôt. Un renouvellement effectué avant l'échéance prolonge la période sans faire perdre de jours.</P>
      <P>L'abonnement est payable d'avance. Il n'est pas remboursable au prorata en cas d'arrêt volontaire avant le
        terme, sauf accord écrit de YIRI.</P>

      <H2>6. Réservation et paiement</H2>
      <UL items={[
        "Le prix d'un séjour est calculé par la plateforme à partir du prix par nuit fixé par le propriétaire et des dates choisies. Aucun montant saisi dans le navigateur n'est pris en compte.",
        "Une réservation retient les dates pendant 15 minutes, le temps du paiement. Passé ce délai, les dates redeviennent disponibles.",
        "Après avoir payé, le voyageur le signale par le bouton « J'ai payé ». Cette déclaration n'est pas une preuve de paiement et ne confirme rien.",
        "Seule l'équipe YIRI confirme un paiement, après avoir vérifié le montant réellement reçu. Un montant différent du montant attendu n'active rien.",
        "Une réservation n'est confirmée qu'après cette vérification.",
      ]} />
      <P>Les annonces de l'offre YIRI Annonce ne se réservent pas en ligne : le voyageur contacte directement le
        propriétaire, et le paiement se fait entre eux, hors de la plateforme. YIRI n'intervient pas dans ces
        transactions et n'en est pas responsable.</P>
      <P><strong>Aucune somme ne doit être versée à l'avance.</strong> Le paiement d'un séjour relevant de
        l'offre YIRI Annonce se fait sur place, au moment de la remise des clés. Aucun acompte, aucuns frais de
        réservation et aucun transfert destiné à « bloquer » des dates ne sont légitimes avant l'arrivée. Un
        propriétaire qui réclame un paiement anticipé contrevient aux présentes conditions : le voyageur doit
        refuser et le signaler à YIRI, qui peut suspendre l'annonce. YIRI n'encaisse rien pour ces séjours et ne
        peut récupérer une somme versée en dehors de la plateforme.</P>

      <H2>7. Annulation</H2>
      <P>Les conditions d'annulation sont indiquées sur chaque annonce par le propriétaire. En l'absence d'indication,
        toute demande d'annulation se règle entre le voyageur et le propriétaire. YIRI ne gère pas les remboursements :
        ils sont organisés directement entre les deux parties.</P>

      <H2>8. Ce qui est interdit</H2>
      <UL items={[
        "Publier un logement dont on n'a pas la disposition, ou des photographies dont on n'a pas les droits.",
        "Annoncer un prix différent de celui réellement demandé, ou réclamer un supplément non annoncé.",
        "Créer plusieurs comptes pour contourner une décision de l'équipe ou les limites de la plateforme.",
        "Collecter les coordonnées des propriétaires affichées sur la plateforme pour en faire un autre usage.",
        "Tenter d'accéder aux données d'autrui, ou de contourner les contrôles de la plateforme.",
      ]} />

      <H2>9. Responsabilité</H2>
      <P>YIRI met en œuvre les moyens raisonnables pour vérifier les identités et les annonces, et pour assurer la
        disponibilité du service. YIRI ne peut pas être tenue responsable de l'état d'un logement, du comportement d'un
        propriétaire ou d'un voyageur, ni d'un désaccord entre eux. En cas de manquement de YIRI, sa responsabilité est
        limitée aux sommes qu'elle a effectivement perçues au titre de la prestation concernée.</P>

      <H2>10. Suspension et fermeture d'un compte</H2>
      <P>YIRI peut suspendre ou fermer un compte en cas de manquement à ces conditions, de fraude, ou de signalement
        sérieux, après information de la personne concernée sauf urgence. Toute personne peut demander la fermeture de
        son compte{SOCIETE.email ? ` à ${SOCIETE.email}` : " auprès de l'équipe"}.</P>

      <H2>11. Modification des conditions</H2>
      <P>Ces conditions peuvent évoluer. Les utilisateurs sont informés des changements importants, qui s'appliquent
        aux réservations et abonnements postérieurs à leur publication.</P>

      <H2>12. Droit applicable</H2>
      <P>Ces conditions sont soumises au droit burkinabè. En cas de différend, les parties recherchent d'abord une
        solution amiable. À défaut, les tribunaux compétents de {SOCIETE.ville} sont saisis.</P>
    </Shell>
  );
}

// ---------------------------------------------------------------------------
function Confidentialite() {
  return (
    <Shell title="Politique de confidentialité">
      <P>Cette page explique quelles données {SOCIETE.nomCommercial} collecte, pourquoi, qui peut les voir, combien de
        temps elles sont gardées et comment exercer vos droits. Le responsable du traitement est
        l'éditeur du service {SOCIETE.nomCommercial}{SOCIETE.nom ? `, ${SOCIETE.nom}` : ""}
        {SOCIETE.adresse ? `, ${SOCIETE.adresse}` : ""}. {SOCIETE.nomCommercial} opère à {SOCIETE.villes}.</P>

      <H2>1. Les données collectées</H2>
      <UL items={[
        "Compte : nom complet, adresse e-mail, mot de passe (jamais lisible par YIRI, il est transformé en empreinte), et éventuellement un numéro de téléphone.",
        "Propriétaires : images du recto et du verso d'une pièce d'identité, type et numéro de cette pièce.",
        "Annonces : description du logement, adresse exacte, prix, photographies, coordonnées de contact.",
        "Réservations : dates, nombre de voyageurs, montant, état du paiement.",
        "Paiements : montant déclaré, montant reçu, référence, date, et la personne de l'équipe qui a confirmé.",
        "Demandes de contact : nom, téléphone, ville, type et nombre de logements, message.",
        "Traces techniques : journal des actions importantes (validation d'une annonce, consultation d'une pièce d'identité, confirmation d'un paiement) et compteurs servant à limiter les abus.",
      ]} />
      <P>YIRI ne collecte aucune donnée bancaire : les paiements se font chez le prestataire de paiement ou directement
        entre les personnes. Aucun numéro de carte ne transite par la plateforme.</P>

      <H2>2. Pourquoi ces données</H2>
      <UL items={[
        "Faire fonctionner le service : créer un compte, publier une annonce, réserver un séjour.",
        "Vérifier l'identité des propriétaires, pour protéger les voyageurs contre les fausses annonces.",
        "Vérifier les paiements et tenir une comptabilité.",
        "Prévenir la fraude et les abus, et pouvoir rendre compte des décisions prises.",
        "Répondre aux demandes de contact.",
      ]} />

      <H2>3. Qui peut voir quoi</H2>
      <UL items={[
        "Le public et les voyageurs non connectés : uniquement les annonces publiées. Jamais l'adresse exacte, jamais les coordonnées du propriétaire, jamais les réservations.",
        "Un voyageur connecté : ses propres réservations et son propre compte, rien d'autre.",
        "Un propriétaire : ses propres annonces, ses propres réservations, son propre dossier.",
        "L'équipe YIRI : seulement ce que son autorisation permet. La validation voit les dossiers d'identité, les paiements voient les transactions. Personne ne voit tout par défaut.",
        "Le numéro de pièce d'identité n'est accessible qu'à l'équipe de validation, par une action qui laisse une trace nominative.",
      ]} />
      <P>Ces règles ne sont pas de simples choix d'affichage : elles sont appliquées par la base de données elle-même,
        pour chaque demande, quelle que soit la façon dont elle arrive.</P>

      <H2>4. Combien de temps</H2>
      <UL items={[
        <>Images de la pièce d'identité : {CONSERVATION.imagesPiece}.</>,
        <>Numéro de la pièce d'identité : {CONSERVATION.numeroPiece}.</>,
        <>Compte et annonces : {CONSERVATION.compte}.</>,
        <>Pièces liées aux paiements : {CONSERVATION.paiements}.</>,
        <>Journal des actions : {CONSERVATION.journal}.</>,
      ]} />
      <P>Ces durées sont celles que YIRI applique. Elles peuvent être raccourcies à votre demande lorsque
        aucune obligation légale ni aucun litige en cours ne s'y oppose.</P>

      <H2>5. Où sont les données</H2>
      <P>Les données sont hébergées par {HEBERGEUR.nom}{HEBERGEUR.region ? `, dans la région ${HEBERGEUR.region}` : ""}.
        Elles sont donc stockées hors du Burkina Faso. Les échanges entre votre appareil et le serveur sont chiffrés.</P>

      <H2>6. Vos droits</H2>
      <P>Conformément à la loi n° 001-2021 du 30 mars 2021, vous disposez d'un droit d'accès, de rectification,
        d'effacement et d'opposition, et vous pouvez retirer votre consentement à tout moment. Pour les exercer,
        écrivez{SOCIETE.email ? ` à ${SOCIETE.email}` : " à l'adresse de contact du service"} en indiquant l'adresse
        e-mail de votre compte. YIRI répond dans un délai
        raisonnable et peut demander une preuve d'identité pour éviter qu'un tiers n'accède à vos données.</P>
      <P>Certaines données ne peuvent pas être effacées immédiatement, notamment celles qui se rapportent à des
        paiements et que la loi comptable impose de conserver. Dans ce cas, YIRI vous l'indique et en limite l'usage.</P>
      <P>Vous pouvez aussi saisir la Commission de l'informatique et des libertés (CIL) du Burkina Faso.</P>

      <H2>7. Sécurité</H2>
      <P>YIRI applique des mesures techniques pour protéger vos données : séparation stricte des accès au niveau de la
        base, droits réduits au minimum pour chaque membre de l'équipe, journalisation des actions sensibles,
        suppression des images d'identité après vérification, et limitation du nombre de tentatives sur les opérations
        sensibles. Aucun système n'est infaillible : en cas d'incident touchant vos données, YIRI vous en informe et
        prend les mesures nécessaires.</P>

      <H2>8. Partage avec des tiers</H2>
      <P>YIRI ne vend ni ne loue vos données. Elles sont partagées uniquement avec l'hébergeur, avec le prestataire de
        paiement pour le strict nécessaire à une transaction, et avec les autorités lorsque la loi l'exige.</P>
      <P>Lorsqu'un voyageur affiche les coordonnées d'un propriétaire dans l'offre YIRI Annonce, cette consultation est
        comptée, une fois par tranche de vingt-quatre heures. Le propriétaire en est informé par le décompte de son
        annonce.</P>
    </Shell>
  );
}

// ---------------------------------------------------------------------------
function Cookies() {
  return (
    <Shell title="Cookies et traceurs">
      <H2>Ce que YIRI n'utilise pas</H2>
      <P>YIRI n'utilise aucun cookie publicitaire, aucun traceur de mesure d'audience et aucun outil de réseau social.
        Vos visites ne sont pas suivies à des fins commerciales et rien n'est transmis à des régies.</P>

      <H2>Ce que YIRI utilise</H2>
      <P>Pour fonctionner, le site enregistre dans votre navigateur un jeton de connexion, qui vous évite de ressaisir
        votre mot de passe à chaque page. Il reste sur votre appareil, et il est effacé quand vous vous déconnectez.
        Il n'identifie que votre session : il ne sert à rien d'autre.</P>
      <P>Si votre navigateur interdit cet enregistrement, le site vous prévient : vous pouvez l'utiliser, mais vous
        devrez vous reconnecter en changeant d'onglet.</P>

      <H2>Les polices de caractères</H2>
      <P>Le site charge ses polices depuis un service extérieur, ce qui transmet à celui-ci votre adresse réseau.
        Aucun compte n'est créé et aucune donnée personnelle ne lui est envoyée par YIRI.</P>

      <H2>Votre choix</H2>
      <P>Comme aucun traceur publicitaire n'est utilisé, aucune bannière de consentement n'est nécessaire. Vous pouvez
        effacer les données enregistrées par le site à tout moment depuis les réglages de votre navigateur : vous serez
        alors simplement déconnecté.</P>
    </Shell>
  );
}

export function LegalRoute({ page }: { page: LegalPage }) {
  if (page === "mentions") return <Mentions />;
  if (page === "cgu") return <CGU />;
  if (page === "confidentialite") return <Confidentialite />;
  return <Cookies />;
}
