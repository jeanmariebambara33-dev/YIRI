// Règles de publication d'une annonce (utilisées par le formulaire et par le serveur simulé).
export const MIN_PHOTOS = 3;
export const MAX_PHOTOS = 30;
export const MIN_DESC = 150;
