// YIRI — pousser les notifications sur les appareils enregistrés.
//
// La base écrit déjà une notification à chaque événement qui compte (migration 0011). Cette
// fonction prend celles qui n'ont pas encore été poussées et les envoie aux appareils de leurs
// destinataires, en Web Push standard : aucun prestataire, aucun abonnement, rien à payer. Le
// message va directement au service du navigateur de la personne (Google, Apple, Mozilla…).
//
// Ce qu'elle ne fait PAS, et c'est délibéré : elle ne décide pas qui reçoit quoi. C'est
// push_pending(), en base, qui relit les autorisations au moment de l'envoi. Ici on chiffre et
// on poste, sans jamais interpréter un droit.
//
// Le contenu est chiffré de bout en bout (RFC 8291) : le service du navigateur transporte le
// message sans pouvoir le lire. Même Google ne voit pas le texte des alertes YIRI.
//
// Fichier AUTONOME : rien à importer, pour pouvoir être collé tel quel dans le tableau de bord
// Supabase. À déployer SANS vérification de JWT (c'est un déclencheur de base, pas un appel
// d'utilisateur) : sa preuve d'identité est l'en-tête secret vérifié en premier.
//
// Variables d'environnement attendues (Edge Functions → Secrets) :
//   VAPID_PRIVATE_KEY   la clé privée — elle ne doit JAMAIS sortir d'ici
//   PUSH_TRIGGER_SECRET le mot de passe de l'en-tête, pour que n'importe qui ne puisse pas
//                       déclencher des envois en boucle
//   SITE_URL            pour que le clic sur la notification ouvre le bon site
//   SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont fournies automatiquement par Supabase.
//
// La clé PUBLIQUE n'est pas un secret et n'est donc PAS ici : elle est lue en base, au même
// endroit que le site la lit. Une seule source, donc aucun risque de désaccord entre deux
// copies — un désaccord qui aurait fait échouer tous les envois sans message clair.

// ---------------------------------------------------------------------------
// Petits outils
// ---------------------------------------------------------------------------

export function requis(nom: string): string {
  const v = Deno.env.get(nom);
  if (!v || v.trim() === "") throw new Error(`Variable d'environnement manquante : ${nom}`);
  return v.trim();
}

export function b64urlVersOctets(s: string): Uint8Array {
  const net = s.replace(/-/g, "+").replace(/_/g, "/");
  const rembourre = net + "=".repeat((4 - (net.length % 4)) % 4);
  const brut = atob(rembourre);
  const out = new Uint8Array(brut.length);
  for (let i = 0; i < brut.length; i++) out[i] = brut.charCodeAt(i);
  return out;
}

export function octetsVersB64url(o: Uint8Array): string {
  let s = "";
  for (let i = 0; i < o.length; i++) s += String.fromCharCode(o[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function concat(...morceaux: Uint8Array[]): Uint8Array {
  const total = morceaux.reduce((n, m) => n + m.length, 0);
  const out = new Uint8Array(total);
  let i = 0;
  for (const m of morceaux) { out.set(m, i); i += m.length; }
  return out;
}

const utf8 = (s: string) => new TextEncoder().encode(s);

/** HKDF-SHA256 en une fois (extraction + expansion), tel que l'utilisent les RFC 8188 et 8291. */
async function hkdf(sel: Uint8Array, ikm: Uint8Array, info: Uint8Array, octets: number): Promise<Uint8Array> {
  const cle = await crypto.subtle.importKey("raw", ikm as unknown as BufferSource, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: sel as unknown as BufferSource, info: info as unknown as BufferSource },
    cle, octets * 8,
  );
  return new Uint8Array(bits);
}

// ---------------------------------------------------------------------------
// VAPID (RFC 8292) : prouver au service du navigateur que l'envoi vient bien de YIRI
// ---------------------------------------------------------------------------

/** La clé privée arrive comme le scalaire « d » seul (32 octets, base64url) : c'est ce que
 *  produisent tous les générateurs de clés VAPID. Pour signer, il faut la recomposer avec les
 *  coordonnées x et y, qui sont dans la clé publique (65 octets : 0x04 || x || y). */
export async function importerCleSignature(publiqueB64: string, priveeB64: string): Promise<CryptoKey> {
  const pub = b64urlVersOctets(publiqueB64);
  if (pub.length !== 65 || pub[0] !== 0x04) {
    throw new Error("Clé publique invalide : 65 octets non compressés attendus. Vérifiez la valeur posée en base (public_settings).");
  }
  const d = b64urlVersOctets(priveeB64);
  if (d.length !== 32) throw new Error("VAPID_PRIVATE_KEY invalide : 32 octets attendus.");
  return await crypto.subtle.importKey(
    "jwk",
    {
      kty: "EC", crv: "P-256", ext: true,
      x: octetsVersB64url(pub.slice(1, 33)),
      y: octetsVersB64url(pub.slice(33, 65)),
      d: octetsVersB64url(d),
    },
    { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"],
  );
}

export async function enteteVapid(
  endpoint: string, publiqueB64: string, cleSignature: CryptoKey, sujet: string, maintenant = Date.now(),
): Promise<string> {
  const origine = new URL(endpoint).origin;
  const entete = octetsVersB64url(utf8(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  // 12 heures : assez pour un envoi, assez court pour qu'un jeton intercepté ne serve pas longtemps.
  const corps = octetsVersB64url(utf8(JSON.stringify({
    aud: origine, exp: Math.floor(maintenant / 1000) + 12 * 3600, sub: sujet,
  })));
  const aSigner = utf8(`${entete}.${corps}`);
  const sig = new Uint8Array(await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" }, cleSignature, aSigner as unknown as BufferSource,
  ));
  return `vapid t=${entete}.${corps}.${octetsVersB64url(sig)}, k=${publiqueB64}`;
}

// ---------------------------------------------------------------------------
// Chiffrement du contenu (RFC 8291 « aes128gcm »)
// ---------------------------------------------------------------------------

/** Chiffre `texte` pour UN appareil. Le résultat est le corps à poster tel quel.
 *  Les paramètres `sel` et `ephemere` n'existent que pour les tests : en vrai ils sont tirés au
 *  hasard à chaque message, comme l'exige la RFC — deux messages identiques ne doivent jamais
 *  produire deux corps identiques. */
export async function chiffrer(
  texte: string, p256dhB64: string, authB64: string,
  sel?: Uint8Array, ephemere?: CryptoKeyPair,
): Promise<Uint8Array> {
  const uaPub = b64urlVersOctets(p256dhB64);
  if (uaPub.length !== 65 || uaPub[0] !== 0x04) {
    throw new Error("Clé d'appareil invalide : 65 octets non compressés attendus.");
  }
  const authSecret = b64urlVersOctets(authB64);
  if (authSecret.length !== 16) throw new Error("Secret d'appareil invalide : 16 octets attendus.");

  const paire = ephemere ?? await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"],
  ) as CryptoKeyPair;
  const asPub = new Uint8Array(await crypto.subtle.exportKey("raw", paire.publicKey));

  const cleUa = await crypto.subtle.importKey(
    "raw", uaPub as unknown as BufferSource, { name: "ECDH", namedCurve: "P-256" }, false, [],
  );
  const partage = new Uint8Array(await crypto.subtle.deriveBits(
    { name: "ECDH", public: cleUa }, paire.privateKey, 256,
  ));

  // Le secret de l'appareil entre d'abord : c'est lui qui lie le message à CET appareil.
  const ikm = await hkdf(
    authSecret, partage,
    concat(utf8("WebPush: info"), new Uint8Array([0]), uaPub, asPub), 32,
  );

  const selReel = sel ?? crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(selReel, ikm, concat(utf8("Content-Encoding: aes128gcm"), new Uint8Array([0])), 16);
  const nonce = await hkdf(selReel, ikm, concat(utf8("Content-Encoding: nonce"), new Uint8Array([0])), 12);

  // 0x02 : marqueur de dernier (et unique) enregistrement.
  const clair = concat(utf8(texte), new Uint8Array([0x02]));
  const cleAes = await crypto.subtle.importKey("raw", cek as unknown as BufferSource, "AES-GCM", false, ["encrypt"]);
  const chiffre = new Uint8Array(await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonce as unknown as BufferSource, tagLength: 128 },
    cleAes, clair as unknown as BufferSource,
  ));

  // En-tête RFC 8188 : sel(16) | taille d'enregistrement(4) | longueur de la clé(1) | clé(65)
  const tailleEnr = new Uint8Array(4);
  new DataView(tailleEnr.buffer).setUint32(0, 4096, false);
  return concat(selReel, tailleEnr, new Uint8Array([asPub.length]), asPub, chiffre);
}

// ---------------------------------------------------------------------------
// Le texte de l'alerte
// ---------------------------------------------------------------------------
// Ces phrases doivent rester alignées sur notificationLabel() de src/lib/api.ts : c'est ce que
// la personne lit dans le site. Un test vérifie qu'aucun type connu de l'un ne manque à l'autre.

export interface Alerte { titre: string; corps: string; lien: string }

export function texteAlerte(type: string, payload: Record<string, unknown>): Alerte {
  const titre = typeof payload.titre === "string" ? payload.titre : null;
  const jours = typeof payload.jours === "number" ? payload.jours : null;
  const montant = typeof payload.montant === "number" ? payload.montant : null;
  const j = (n: number) => `${n} jour${n > 1 ? "s" : ""}`;
  const fcfa = (n: number) => `${n.toLocaleString("fr-FR").replace(/ | /g, " ")} FCFA`;

  switch (type) {
    case "booking.confirmee":
      return { titre: "Réservation payée", corps: titre ? `Sur ${titre}.` : "Une réservation a été payée.", lien: "#espace" };
    case "booking.confirmee.equipe":
      return { titre: "Réservation payée", corps: titre ? `${titre}. À préparer.` : "Une réservation a été payée.", lien: "#equipe" };
    case "booking.annulee":
      return { titre: "Réservation annulée", corps: titre ? `Sur ${titre}.` : "Une réservation a été annulée.", lien: "#espace" };
    case "booking.annulee.equipe":
      return { titre: "Réservation annulée", corps: titre ? `${titre}.` : "Une réservation a été annulée.", lien: "#equipe" };
    case "subscription.bientot_expiree":
      return { titre: "Votre abonnement expire bientôt", corps: jours !== null ? `Il reste ${j(jours)}. Renouvelez pour garder vos annonces en ligne.` : "Renouvelez pour garder vos annonces en ligne.", lien: "#espace" };
    case "subscription.expire_demain":
      return { titre: "Votre abonnement expire demain", corps: "Sans renouvellement, vos annonces seront masquées.", lien: "#espace" };
    case "subscription.expiree":
      return { titre: "Abonnement expiré", corps: "Vos annonces sont masquées. Un renouvellement les remet en ligne.", lien: "#espace" };
    case "subscription.expiree.equipe":
      return { titre: "Un abonnement a expiré", corps: "Les annonces du propriétaire sont masquées.", lien: "#equipe" };
    case "subscription.offerte":
      return { titre: "YIRI vous a offert un abonnement", corps: "Vous pouvez publier vos annonces.", lien: "#espace" };
    case "free_pass.offert":
      return { titre: "YIRI vous a offert un accès gratuit", corps: "Vous pouvez publier sans abonnement.", lien: "#espace" };
    case "free_pass.bientot_fini":
      return { titre: "Votre accès offert se termine bientôt", corps: jours !== null ? `Il reste ${j(jours)}.` : "Pensez à prendre un abonnement.", lien: "#espace" };
    case "free_pass.retire":
      return { titre: "Votre accès offert a été retiré", corps: "Un abonnement est nécessaire pour publier.", lien: "#espace" };
    case "refund.automatique":
      return { titre: "Remboursement en cours", corps: montant !== null ? `${fcfa(montant)}.` : "Votre remboursement est en cours.", lien: "#mes-sejours" };
    case "statement.disponible":
      return { titre: "Votre relevé est prêt",
               corps: montant !== null ? `${fcfa(montant)} vous reviennent. Le détail est dans votre espace.` : "Le détail est dans votre espace.",
               lien: "#espace" };
    case "payout.verse":
      return { titre: "Virement effectué",
               corps: montant !== null ? `YIRI vous a versé ${fcfa(montant)}.` : "YIRI vous a fait un virement.",
               lien: "#espace" };
    case "support.traite":
      return { titre: "Votre signalement a été traité", corps: "La réponse de l'équipe est dans votre espace.", lien: "#espace" };
    case "support.ouvert.equipe":
      return { titre: "Un signalement attend l'équipe",
               corps: titre ? `Sur ${titre}. Un problème d'accès ne peut pas attendre.` : "Un problème vient d'être signalé.",
               lien: "#equipe" };
    case "refund.attente_equipe_compte_inconnu":
    case "refund.attente_equipe_plafond_journalier":
      return { titre: "Remboursement en vérification", corps: "L'équipe YIRI vérifie votre remboursement.", lien: "#mes-sejours" };
    default:
      if (type.startsWith("identity.")) return { titre: "Pièce d'identité", corps: "Votre vérification a avancé.", lien: "#espace" };
      if (type.startsWith("listing.")) return { titre: "Votre annonce a changé de statut", corps: "Ouvrez votre espace pour voir où elle en est.", lien: "#espace" };
      if (type.endsWith(".equipe")) return { titre: "YIRI", corps: "Une action attend l'équipe.", lien: "#equipe" };
      return { titre: "YIRI", corps: "Nouvelle information sur votre compte.", lien: "#espace" };
  }
}

// ---------------------------------------------------------------------------
// La base
// ---------------------------------------------------------------------------

async function rpc<T>(fn: string, args: Record<string, unknown>, cle: string): Promise<T> {
  const r = await fetch(`${requis("SUPABASE_URL")}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { "apikey": cle, "Authorization": `Bearer ${cle}`, "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  const texte = await r.text();
  if (!r.ok) throw new Error(`${fn} a échoué (${r.status}) : ${texte.slice(0, 300)}`);
  return (texte ? JSON.parse(texte) : null) as T;
}

interface Ligne {
  notification_id: string; subscription_id: string; user_id: string;
  type: string; payload: Record<string, unknown> | null;
  created_at: string; endpoint: string; p256dh: string; auth: string;
}

// ---------------------------------------------------------------------------
// L'envoi
// ---------------------------------------------------------------------------

Deno.serve(async (req) => {
  // 1. L'en-tête secret, AVANT toute lecture. Sans lui, n'importe qui pourrait déclencher des
  //    envois en rafale et faire blacklister nos clés par les services de notification.
  const attendu = Deno.env.get("PUSH_TRIGGER_SECRET")?.trim();
  if (!attendu) return new Response("non configuré", { status: 503 });
  const fourni = req.headers.get("x-yiri-push")?.trim() ?? "";
  // Comparaison à temps constant : une comparaison ordinaire laisse deviner le secret
  // caractère par caractère en mesurant le temps de réponse.
  const egal = fourni.length === attendu.length &&
    fourni.split("").reduce((acc, c, i) => acc | (c.charCodeAt(0) ^ attendu.charCodeAt(i)), 0) === 0;
  if (!egal) return new Response("refusé", { status: 401 });

  const cleService = requis("SUPABASE_SERVICE_ROLE_KEY");
  const vapidPub = (await rpc<string | null>("push_public_key", {}, cleService)) ?? "";
  if (!vapidPub) {
    return new Response(
      "La clé publique n'est pas posée en base. Dans l'éditeur SQL : insert into public_settings (key, value) values ('push_vapid_public', 'VOTRE_CLE_PUBLIQUE').",
      { status: 500 },
    );
  }
  const sujet = Deno.env.get("VAPID_SUBJECT")?.trim() || Deno.env.get("SITE_URL")?.trim() || "https://yiri.bf";
  const site = Deno.env.get("SITE_URL")?.trim() || "";

  let cleSignature: CryptoKey;
  try {
    cleSignature = await importerCleSignature(vapidPub, requis("VAPID_PRIVATE_KEY"));
  } catch (e) {
    // Une clé mal collée est l'erreur la plus probable : on le dit clairement dans le journal.
    return new Response(`clés VAPID inutilisables : ${(e as Error).message}`, { status: 500 });
  }

  const lignes = await rpc<Ligne[]>("push_pending", { p_limit: 50 }, cleService);
  if (!lignes || lignes.length === 0) {
    return Response.json({ envoyees: 0, appareils: 0, retires: 0 });
  }

  const partis = new Set<string>();      // notifications envoyées à au moins un appareil
  const ratees = new Set<string>();      // notifications dont AUCUN appareil n'a répondu
  const disparus: string[] = [];         // appareils dont le service dit qu'ils n'existent plus

  for (const l of lignes) {
    const a = texteAlerte(l.type, l.payload ?? {});
    const contenu = JSON.stringify({
      titre: a.titre, corps: a.corps, lien: site ? site + "/" + a.lien : a.lien,
      id: l.notification_id, date: l.created_at,
    });

    try {
      const corps = await chiffrer(contenu, l.p256dh, l.auth);
      const r = await fetch(l.endpoint, {
        method: "POST",
        headers: {
          "Authorization": await enteteVapid(l.endpoint, vapidPub, cleSignature, sujet),
          "Content-Encoding": "aes128gcm",
          "Content-Type": "application/octet-stream",
          "TTL": "86400",
          "Urgency": "high",
        },
        body: corps as unknown as BodyInit,
      });

      if (r.status === 404 || r.status === 410) {
        // L'appareil n'existe plus (application désinstallée, notifications refusées).
        disparus.push(l.subscription_id);
        partis.add(l.notification_id);   // inutile de réessayer vers un appareil mort
      } else if (r.ok || r.status === 201 || r.status === 202) {
        partis.add(l.notification_id);
      } else {
        ratees.add(l.notification_id);
        console.error(`push refusé (${r.status}) vers ${new URL(l.endpoint).host} : ${(await r.text()).slice(0, 200)}`);
      }
    } catch (e) {
      ratees.add(l.notification_id);
      console.error(`push impossible : ${(e as Error).message}`);
    }
  }

  // Une notification partie vers UN appareil est partie : elle ne doit pas être renvoyée à tous
  // les autres au prochain tour.
  for (const id of partis) ratees.delete(id);

  if (partis.size) await rpc("push_mark_sent", { p_notifications: [...partis], p_echecs: disparus }, cleService);
  if (ratees.size) await rpc("push_mark_failed", { p_notifications: [...ratees] }, cleService);

  return Response.json({ envoyees: partis.size, echouees: ratees.size, appareils: lignes.length, retires: disparus.length });
});
