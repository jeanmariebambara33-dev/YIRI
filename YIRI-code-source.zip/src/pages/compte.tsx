import * as React from "react";
import { Button, Field, inputCls, Pill } from "../ui";
import { useSession } from "../session";
import { AlertesAppareil } from "../push";

// Écrans de compte RÉELS (Supabase Auth) : inscription, connexion, mot de passe oublié,
// nouveau mot de passe, et page « Mon compte ».

export type CompteMode = "connexion" | "inscription" | "oubli" | "nouveau";

function Alert({ tone, children }: { tone: "bad" | "good"; children: React.ReactNode }) {
  return (
    <p role={tone === "bad" ? "alert" : "status"}
       className={tone === "bad"
         ? "rounded-xl border border-danger/40 bg-danger/10 px-3.5 py-2.5 text-sm font-medium text-danger"
         : "rounded-xl border border-good/40 bg-good/10 px-3.5 py-2.5 text-sm font-medium text-good"}>
      {children}
    </p>
  );
}

function Shell({ title, intro, children }: { title: string; intro?: string; children: React.ReactNode }) {
  const { warning } = useSession();
  return (
    <div className="mx-auto max-w-md py-10">
      <h1 className="font-display text-3xl font-extrabold tracking-tight text-ink">{title}</h1>
      {intro && <p className="mt-2 text-muted">{intro}</p>}
      {warning && <p className="mt-4 rounded-xl border border-warn/40 bg-warn/10 px-3.5 py-2.5 text-sm text-warn">{warning}</p>}
      <div className="mt-6 flex flex-col gap-4">{children}</div>
    </div>
  );
}

export function ComptePage({ mode, onMode, onDone }: {
  mode: CompteMode; onMode: (m: CompteMode) => void; onDone: () => void;
}) {
  const s = useSession();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [password2, setPassword2] = React.useState("");
  const [fullName, setFullName] = React.useState("");

  // Un lien « mot de passe oublié » ouvert depuis l'e-mail bascule tout de suite sur le bon écran.
  React.useEffect(() => { if (s.recovery && mode !== "nouveau") onMode("nouveau"); }, [s.recovery, mode, onMode]);

  const switchTo = (m: CompteMode) => { s.clearMessages(); setPassword(""); setPassword2(""); onMode(m); };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (s.busy) return;
    if (mode === "connexion") { if (await s.signIn(email, password)) onDone(); return; }
    if (mode === "inscription") { if (await s.signUp(email, password, fullName)) setPassword(""); return; }
    if (mode === "oubli") { await s.sendReset(email); return; }
    if (password !== password2) { return; }
    if (await s.setPassword(password)) { setPassword(""); setPassword2(""); onDone(); }
  };

  const titles: Record<CompteMode, [string, string]> = {
    connexion: ["Connexion", "Entrez l'adresse et le mot de passe de votre compte YIRI."],
    inscription: ["Créer un compte", "Un compte suffit pour préparer une annonce. La pièce d'identité n'est demandée qu'au moment de publier."],
    oubli: ["Mot de passe oublié", "Nous vous envoyons un lien pour en choisir un nouveau."],
    nouveau: ["Nouveau mot de passe", "Choisissez un mot de passe d'au moins 8 caractères."],
  };
  const mismatch = mode === "nouveau" && password2.length > 0 && password !== password2;

  return (
    <Shell title={titles[mode][0]} intro={titles[mode][1]}>
      {s.error && <Alert tone="bad">{s.error}</Alert>}
      {s.notice && <Alert tone="good">{s.notice}</Alert>}

      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        {mode === "inscription" && (
          <Field label="Nom complet" htmlFor="c-nom">
            <input id="c-nom" className={inputCls} value={fullName} autoComplete="name" required
                   onChange={(e) => setFullName(e.target.value)} placeholder="Votre nom complet" />
          </Field>
        )}

        {mode !== "nouveau" && (
          <Field label="Adresse e-mail" htmlFor="c-mail">
            <input id="c-mail" type="email" className={inputCls} value={email} autoComplete="email" required
                   onChange={(e) => setEmail(e.target.value)} placeholder="vous@exemple.com" />
          </Field>
        )}

        {mode !== "oubli" && (
          <Field label={mode === "nouveau" ? "Nouveau mot de passe" : "Mot de passe"} htmlFor="c-mdp"
                 hint={mode === "inscription" ? "8 caractères minimum." : undefined}>
            <input id="c-mdp" type="password" className={inputCls} value={password} required minLength={8}
                   autoComplete={mode === "connexion" ? "current-password" : "new-password"}
                   onChange={(e) => setPassword(e.target.value)} />
          </Field>
        )}

        {mode === "nouveau" && (
          <Field label="Confirmez le mot de passe" htmlFor="c-mdp2" error={mismatch ? "Les deux mots de passe sont différents." : undefined}>
            <input id="c-mdp2" type="password" className={inputCls} value={password2} required minLength={8}
                   autoComplete="new-password" onChange={(e) => setPassword2(e.target.value)} />
          </Field>
        )}

        <Button type="submit" size="lg" disabled={s.busy || mismatch}>
          {s.busy ? "Patientez…"
            : mode === "connexion" ? "Se connecter"
            : mode === "inscription" ? "Créer mon compte"
            : mode === "oubli" ? "Envoyer le lien"
            : "Enregistrer"}
        </Button>
      </form>

      <div className="flex flex-col gap-2 text-sm text-muted">
        {mode === "connexion" && <>
          <button type="button" onClick={() => switchTo("inscription")} className="text-left font-semibold text-ink underline underline-offset-4 cursor-pointer">Créer un compte</button>
          <button type="button" onClick={() => switchTo("oubli")} className="text-left underline underline-offset-4 cursor-pointer hover:text-ink">Mot de passe oublié</button>
        </>}
        {mode !== "connexion" && (
          <button type="button" onClick={() => switchTo("connexion")} className="text-left underline underline-offset-4 cursor-pointer hover:text-ink">Revenir à la connexion</button>
        )}
      </div>
    </Shell>
  );
}

/** Page « Mon compte » : ce que le serveur dit de vous, pas ce que le navigateur croit. */
export function MonCompte({ onLogin }: { onLogin: () => void }) {
  const s = useSession();
  if (!s.ready) return <p className="py-16 text-center text-muted">Chargement…</p>;
  if (!s.account) {
    return (
      <Shell title="Mon compte" intro="Vous n'êtes pas connecté.">
        <Button size="lg" onClick={onLogin}>Se connecter</Button>
      </Shell>
    );
  }
  const a = s.account;
  const labels: Record<string, string> = {
    voyageur: "Voyageur", proprietaire: "Propriétaire", gestionnaire: "Gestionnaire", finance: "Finance", admin: "Administrateur",
    validation: "Validation", reservations: "Réservations", partenariat: "Partenariat", demandes: "Demandes", paiements: "Paiements", audit: "Journal",
  };
  return (
    <Shell title="Mon compte">
      {s.notice && <Alert tone="good">{s.notice}</Alert>}
      {s.error && <Alert tone="bad">{s.error}</Alert>}
      <dl className="divide-y divide-line rounded-2xl border border-line bg-surface px-4">
        <div className="flex items-center justify-between gap-4 py-3">
          <dt className="text-sm text-muted">Nom</dt><dd className="font-semibold text-ink">{a.fullName || "—"}</dd>
        </div>
        <div className="flex items-center justify-between gap-4 py-3">
          <dt className="text-sm text-muted">Adresse e-mail</dt><dd className="truncate font-semibold text-ink">{a.email}</dd>
        </div>
        <div className="flex items-center justify-between gap-4 py-3">
          <dt className="text-sm text-muted">Rôle</dt>
          <dd className="flex flex-wrap justify-end gap-1.5">
            {a.roles.length === 0 ? <Pill>Aucun</Pill> : a.roles.map((r) => <Pill key={r} tone={r === "admin" ? "accent" : "info"}>{labels[r] ?? r}</Pill>)}
          </dd>
        </div>
        {a.perms.length > 0 && (
          <div className="flex items-center justify-between gap-4 py-3">
            <dt className="text-sm text-muted">Autorisations d'équipe</dt>
            <dd className="flex flex-wrap justify-end gap-1.5">{a.perms.map((p) => <Pill key={p} tone="good">{labels[p] ?? p}</Pill>)}</dd>
          </div>
        )}
      </dl>
      <AlertesAppareil />

      <p className="text-xs text-muted">
        Ce rôle est lu dans la base de données à chaque connexion. Il ne peut pas être modifié depuis ce navigateur :
        seule l'équipe YIRI peut l'accorder, après vérification de la pièce d'identité.
      </p>
      <Button variant="secondary" onClick={() => void s.signOut()} disabled={s.busy}>Se déconnecter</Button>
    </Shell>
  );
}
