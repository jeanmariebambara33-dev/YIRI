// Fabrique les versions web de la photo d'ouverture.
//
// La photo est le seul fichier que le site télécharge en plus. Sur une connexion lente, chaque
// kilo-octet se paie, d'où : plusieurs largeurs pour que les téléphones ne chargent pas une image
// d'ordinateur, AVIF en premier (nettement plus léger) et WebP en secours, et une vignette floue
// de quelques centaines d'octets glissée dans la page elle-même pour que l'écran ne soit jamais
// vide pendant le téléchargement.
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "..");
const src = path.join(root, "assets/photo/accueil-source.png");
const out = path.join(root, "assets/photo");

const py = `
from PIL import Image, ImageFilter
import io, base64, json, os
im = Image.open(${JSON.stringify(src)}).convert("RGB")
res = {}
for w in (1536, 1100, 760, 540):
    r = im.resize((w, round(w * im.height / im.width)), Image.LANCZOS)
    for ext, opts in (("avif", dict(quality=58)), ("webp", dict(quality=74, method=6))):
        p = os.path.join(${JSON.stringify(out)}, f"accueil-{w}.{ext}")
        r.save(p, **opts)
        res[f"{w}.{ext}"] = os.path.getsize(p)
# vignette floue, intégrée à la page : invisible à l'oeil mais évite l'écran vide
v = im.resize((24, 16), Image.LANCZOS).filter(ImageFilter.GaussianBlur(0.6))
b = io.BytesIO(); v.save(b, "webp", quality=42)
res["lqip"] = "data:image/webp;base64," + base64.b64encode(b.getvalue()).decode()
print(json.dumps(res))
`;
const r = JSON.parse(execFileSync("python3", ["-c", py], { encoding: "utf8" }));
const lqip = r.lqip; delete r.lqip;
for (const [k, v] of Object.entries(r)) console.log(`  accueil-${k.replace(".", ".")}`.padEnd(26), (v / 1024).toFixed(0).padStart(4), "Ko");
console.log("  vignette intégrée".padEnd(26), (lqip.length / 1024).toFixed(1).padStart(4), "Ko");
fs.writeFileSync(path.join(root, "src/data/photo.ts"),
`// Fichier ENGENDRÉ par scripts/photo-accueil.mjs — ne pas modifier à la main.
//
// Vignette de la photo d'ouverture : 24 pixels de large, floutée, pesant quelques centaines
// d'octets. Elle est dans la page elle-même, donc affichée sans aucun aller-retour réseau, et
// tient lieu d'image le temps que la vraie photo arrive. Pendant la première seconde
// l'introduction est de toute façon dans la nuit : personne ne voit jamais le flou.
export const PHOTO_VIGNETTE = "${lqip}";

/** Largeurs engendrées, de la plus grande à la plus petite. */
export const PHOTO_LARGEURS = [1536, 1100, 760, 540] as const;

/** Dimensions de la photo d'origine, et position du soleil dedans (mesurée, pixel le plus clair). */
export const PHOTO = { largeur: 1536, hauteur: 1024, soleilX: 885, soleilY: 497 } as const;
`);
