-- TEST UNIQUEMENT : imite le strict nécessaire de Supabase sur une base PostgreSQL locale vide.
-- (rôles anon/authenticated, auth.users, auth.uid(), privilèges par défaut). Ne jamais l'appliquer à un vrai projet.
do $$ begin create role anon nologin; exception when duplicate_object then null; end $$;
do $$ begin create role authenticated nologin; exception when duplicate_object then null; end $$;
create schema if not exists auth;
create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb not null default '{}');
-- auth.uid() lit un réglage de session posé par les tests (comme le jeton JWT sur Supabase).
create or replace function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('app.uid', true), '')::uuid $$;
grant usage on schema public, auth to anon, authenticated;
grant execute on function auth.uid() to anon, authenticated;
-- Comme sur Supabase : les nouvelles tables sont accessibles à anon/authenticated, la RLS fait la protection.
alter default privileges in schema public grant all on tables to anon, authenticated;
alter default privileges in schema public grant all on sequences to anon, authenticated;
-- Supabase accorde aussi, par défaut, l'exécution de toute nouvelle fonction du schéma public à anon et authenticated :
-- chaque fonction sensible doit donc être retirée explicitement (c'est ce que les tests d'hygiène vérifient).
alter default privileges in schema public grant execute on functions to anon, authenticated;
