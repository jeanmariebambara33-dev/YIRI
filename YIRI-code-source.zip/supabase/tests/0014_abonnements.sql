-- Tests de la migration 0014 (créer, renouveler, expirer un abonnement).
-- Base LOCALE ; auth.uid() simulé ; « reset role » = clé de service (postgres).
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values
  (t.u(3), 'proprietaire'), (t.u(4), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)),
  (t.u(7), 'paiements',  t.u(5)),
  (t.u(9), 'demandes',   t.u(5));

-- p1 : Visibilité du propriétaire 3   p2 : Visibilité du propriétaire 4
-- p3 : Gestion du propriétaire 3      p4 : Visibilité, annonce de démonstration
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'annonce', 'Studio Gounghin', 'd', 'Ouagadougou', 'Gounghin', 'a', 2,1,1, 15000,1, 'approuvee', false),
       (t.p(2), t.u(4), 'annonce', 'Studio Zogona',   'd', 'Ouagadougou', 'Zogona',   'a', 2,1,1, 18000,1, 'approuvee', false),
       (t.p(3), t.u(3), 'gestion', 'Villa Koulouba',  'd', 'Ouagadougou', 'Koulouba', 'a', 4,2,2, 30000,1, 'approuvee', false),
       (t.p(4), t.u(3), 'annonce', 'Demo',            'd', 'Ouagadougou', 'Centre',   'a', 2,1,1, 10000,1, 'brouillon', true);

-- ============ Créer un abonnement ============
reset role; select t.as(0);
select t.must_fail('visiteur : abonnement refusé', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(1)));
reset role; select t.as(4);
select t.must_fail('on ne s''abonne pas pour l''annonce d''un autre', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(1)));
reset role; select t.as(3);
select t.must_fail('une annonce de démonstration ne s''abonne pas', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(4)));
select t.must_fail('un logement sous gestion ne s''abonne pas', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(3)));
select t.ok('le propriétaire crée son abonnement', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(1)));
select t.eq('il est en attente de paiement',
  format($$select status::text from subscriptions where property_id = %L$$, t.p(1)), 'en_attente_paiement');
select t.eq('le montant vient du forfait, pas du navigateur',
  format($$select amount_xof::text from subscriptions where property_id = %L$$, t.p(1)), '5000');
select t.ok('appelée deux fois, elle ne crée pas de doublon', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(1)));
select t.eq('une seule ligne existe toujours',
  format($$select count(*)::text from subscriptions where property_id = %L$$, t.p(1)), '1');
reset role; select t.as(4);
select t.eq('le forfait annuel coûte 30 000',
  format($$select amount_xof::text from subscribe_property(%L, 'annuel')$$, t.p(2)), '30000');
reset role;
delete from subscriptions where property_id = t.p(2) and status = 'en_attente_paiement';
reset role; select t.as(3);

-- ============ Tant qu'il n'est pas payé, rien n'est publiable ============
-- Publier est un geste d'équipe (set_listing_status), jamais du propriétaire.
reset role;
update properties set status = 'soumise' where id in (t.p(1), t.p(2), t.p(3));
update properties set status = 'approuvee' where id in (t.p(1), t.p(2), t.p(3));
reset role; select t.as(6);
select t.must_fail('publier sans abonnement payé : refusé',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(1)));

-- ============ Le paiement l'active, et l'annonce devient publiable ============
reset role; select t.as(7);
select t.ok('l''équipe confirme le paiement',
  format($$select confirm_payment('abonnement', (select id from subscriptions where property_id = %L), 5000)$$, t.p(1)));
reset role;
select t.eq('l''abonnement est actif',
  format($$select status::text from subscriptions where property_id = %L$$, t.p(1)), 'actif');
reset role; select t.as(3);
select t.eq('le propriétaire voit son abonnement',
  $$select count(*)::text from my_subscriptions() where visible_publiquement$$, '1');
select t.eq('et ne voit pas celui des autres',
  format($$select count(*)::text from my_subscriptions() where property_id = %L$$, t.p(2)), '0');

-- ============ L'abonnement offert ============
reset role; select t.as(3);
select t.must_fail('un propriétaire ne s''offre pas un abonnement',
  format($$select * from grant_subscription(%L, 30, 'cadeau')$$, t.p(2)));
reset role; select t.as(6);
select t.must_fail('l''équipe « validation » non plus',
  format($$select * from grant_subscription(%L, 30, 'cadeau')$$, t.p(2)));
reset role; select t.as(5);
select t.must_fail('un motif est obligatoire', format($$select * from grant_subscription(%L, 30, '  ')$$, t.p(2)));
select t.must_fail('une durée absurde est refusée', format($$select * from grant_subscription(%L, 5000, 'test')$$, t.p(2)));
select t.ok('l''administrateur offre un abonnement',
  format($$select * from grant_subscription(%L, 30, 'Logement vitrine YIRI')$$, t.p(2)));
reset role;
select t.eq('il vaut 0 FCFA, pas un faux encaissement',
  format($$select amount_xof::text from subscriptions where property_id = %L and offert$$, t.p(2)), '0');
select t.eq('il est actif tout de suite',
  format($$select status::text from subscriptions where property_id = %L and offert$$, t.p(2)), 'actif');
select t.eq('le motif est conservé',
  format($$select offert_motif from subscriptions where property_id = %L and offert$$, t.p(2)), 'Logement vitrine YIRI');
select t.eq('le geste est tracé au journal',
  $$select count(*)::text from audit_logs where action = 'subscription.offerte'$$, '1');
select t.eq('et le propriétaire est prévenu',
  format($$select count(*)::text from notifications where user_id = %L and type = 'subscription.offerte'$$, t.u(4)), '1');

-- ============ Le contrat de gestion ============
reset role; select t.as(3);
select t.must_fail('un propriétaire ne signe pas son propre contrat',
  format($$select * from set_management_agreement(%L, true, true)$$, t.p(3)));
reset role; select t.as(6);
select t.must_fail('un contrat sur une annonce Visibilité : refusé',
  format($$select * from set_management_agreement(%L, true, true)$$, t.p(1)));
select t.ok('l''équipe « validation » enregistre le contrat',
  format($$select * from set_management_agreement(%L, true, true)$$, t.p(3)));
select t.ok('elle peut le remettre à jour sans doublon',
  format($$select * from set_management_agreement(%L, true, true)$$, t.p(3)));
reset role;
select t.eq('une seule ligne de contrat',
  format($$select count(*)::text from management_agreements where property_id = %L$$, t.p(3)), '1');

-- Et maintenant le logement sous gestion est publiable : c'était le blocage principal.
reset role; select t.as(6);
select t.must_fail('il manque encore une photo aux droits vérifiés',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(3)));
reset role;
insert into property_photos (property_id, storage_path, position, rights_checked)
values (t.p(3), 'x/1.jpg', 0, true), (t.p(1), 'y/1.jpg', 0, true), (t.p(2), 'z/1.jpg', 0, true);
reset role; select t.as(6);
select t.ok('avec le contrat et la photo, le logement sous gestion se publie',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(3)));

-- Et l'annonce Visibilité aussi, maintenant qu'elle a un abonnement actif et une photo.
reset role;
insert into property_contacts (property_id, contact_name, phone, whatsapp) values (t.p(1), 'Issa', '70000003', true);
reset role; select t.as(6);
select t.ok('et l''annonce Visibilité se publie', format($$select set_listing_status(%L, 'publiee')$$, t.p(1)));
reset role;
select t.eq('elle apparaît bien dans la vitrine publique',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(1)), '1');

-- ============ Les relances ============
reset role;
-- On rapproche l'échéance de l'abonnement de p1 : plus que 5 jours.
update subscriptions set ends_at = current_date + 5 where property_id = t.p(1);
select t.eq('la tâche prévient à J-7 (fenêtre des 7 jours)',
  $$select relances_j7::text from expire_subscriptions()$$, '1');
select t.eq('le propriétaire a reçu la relance',
  format($$select count(*)::text from notifications where user_id = %L and type = 'subscription.bientot_expiree'$$, t.u(3)), '1');
select t.eq('rejouée le lendemain, elle ne prévient pas deux fois',
  $$select relances_j7::text from expire_subscriptions()$$, '0');

update subscriptions set ends_at = current_date + 1 where property_id = t.p(1);
select t.eq('puis la veille',
  $$select relances_j1::text from expire_subscriptions()$$, '1');
select t.eq('et pas deux fois non plus',
  $$select relances_j1::text from expire_subscriptions()$$, '0');

-- ============ L'expiration ============
reset role;
-- La contrainte de 0001 exige ends_at > starts_at tant que l'abonnement est « actif » :
-- on recule donc aussi la date de début, comme pour un abonnement souscrit il y a un mois.
update subscriptions set starts_at = current_date - 30, ends_at = current_date
 where property_id = t.p(1) and not offert;
select t.eq('l''annonce sort de la vitrine dès le jour de l''échéance, avant même la tâche',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(1)), '0');
select t.eq('la tâche enregistre l''expiration',
  $$select expires::text from expire_subscriptions() limit 1$$, '1');
select t.eq('l''abonnement n''est plus « actif » : la base cesse de mentir',
  format($$select status::text from subscriptions where property_id = %L and not offert$$, t.p(1)), 'expire');
select t.eq('et l''annonce passe en « expirée », au lieu d''afficher « En ligne »',
  format($$select status::text from properties where id = %L$$, t.p(1)), 'expiree');
select t.eq('le propriétaire est prévenu',
  format($$select count(*)::text from notifications where user_id = %L and type = 'subscription.expiree'$$, t.u(3)), '1');
select t.eq('l''équipe « validation » aussi',
  format($$select count(*)::text from notifications where user_id = %L and type = 'subscription.expiree.equipe'$$, t.u(6)), '1');
select t.eq('l''équipe « demandes » n''est pas dérangée',
  format($$select count(*)::text from notifications where user_id = %L$$, t.u(9)), '0');
select t.eq('rejouée, la tâche ne réexpire rien', $$select expires::text from expire_subscriptions()$$, '0');

-- L'abonnement OFFERT de p2, lui, court toujours : l'expiration ne touche pas ce qui est valide.
select t.eq('un abonnement encore valide n''est pas touché',
  format($$select status::text from subscriptions where property_id = %L$$, t.p(2)), 'actif');

-- ============ Le renouvellement remet en ligne ============
reset role; select t.as(3);
select t.ok('le propriétaire renouvelle', format($$select * from subscribe_property(%L, 'mensuel')$$, t.p(1)));
reset role; select t.as(7);
select t.ok('le paiement est confirmé',
  format($$select confirm_payment('abonnement', (select id from subscriptions where property_id = %L and status = 'en_attente_paiement'), 5000)$$, t.p(1)));
reset role;
select t.eq('l''annonce est revenue en ligne toute seule',
  format($$select status::text from properties where id = %L$$, t.p(1)), 'publiee');
select t.eq('et elle réapparaît dans la vitrine',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(1)), '1');
select t.eq('les relances repartent à zéro pour le nouveau cycle',
  format($$select count(*)::text from subscription_reminders r
            join subscriptions s on s.id = r.subscription_id
           where s.property_id = %L and s.status = 'actif'$$, t.p(1)), '0');

-- ============ Qui peut lire la file de l'équipe ============
reset role; select t.as(3);
select t.must_fail('un propriétaire n''ouvre pas la file des abonnements', $$select * from subscriptions_queue()$$);
reset role; select t.as(9);
select t.must_fail('l''équipe « demandes » non plus', $$select * from subscriptions_queue()$$);
reset role; select t.as(6);
select t.ok('l''équipe « validation » oui', $$select * from subscriptions_queue()$$);
reset role; select t.as(7);
select t.ok('l''équipe « paiements » aussi', $$select * from subscriptions_queue()$$);
select t.eq('elle voit les abonnements offerts comme tels',
  format($$select count(*)::text from subscriptions_queue() where offert and property_id = %L$$, t.p(2)), '1');

-- ============ La tâche planifiée est fermée au navigateur ============
reset role; select t.as(5);
select t.must_fail('même un administrateur ne lance pas l''expiration à la main', $$select * from expire_subscriptions()$$);
select t.must_fail('et n''écrit pas dans la table des relances',
  $$insert into subscription_reminders (subscription_id, kind) select id, 'j7' from subscriptions limit 1$$);

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0014 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
