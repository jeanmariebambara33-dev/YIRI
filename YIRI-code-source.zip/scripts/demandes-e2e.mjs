// Tests de bout en bout des trois trous bouchés après l'audit :
//   1. la candidature Partenariat part vraiment vers la BASE (elle restait dans le navigateur) ;
//   2. l'onglet Demandes montre enfin les demandes de rappel et les candidatures ;
//   3. la cloche affiche les notifications, qui n'étaient lues par aucun écran.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const DB = {
  candidatures: [
    { id: 'a-1', contact_name: 'Awa Sawadogo', contact_phone: '70000001', city: 'Ouagadougou', district: 'Zogona', property_kind: 'Villa', rooms: 4, condition_notes: 'Construction recente, carrelage neuf', estimated_works: 'Climatisation', status: 'recue', decision_reason: null, created_at: new Date().toISOString() },
    { id: 'a-2', contact_name: 'Boukary Zongo', contact_phone: '70000002', city: 'Bobo-Dioulasso', district: 'Accart', property_kind: 'Immeuble', rooms: 8, condition_notes: 'Gros oeuvre termine', estimated_works: null, status: 'acceptee', decision_reason: 'Visite concluante', created_at: new Date().toISOString() },
  ],
  demandes: [
    { id: 'l-1', pack: 'visibilite', property_kind: 'Studio', city: 'Ouagadougou', property_count: 2, level: 'autonomie', name: 'Clarisse Kabore', phone: '70000003', message: 'Je veux publier deux studios', status: 'nouvelle', created_at: new Date().toISOString() },
    { id: 'l-2', pack: 'serenite', property_kind: 'Villa', city: 'Ouagadougou', property_count: 1, level: 'delegation', name: 'Daouda Ouedraogo', phone: '70000004', message: null, status: 'contactee', created_at: new Date().toISOString() },
  ],
  notifications: [
    { id: 'n-1', type: 'subscription.bientot_expiree', payload: { jours: 7 }, created_at: new Date().toISOString(), read_at: null },
    { id: 'n-2', type: 'booking.confirmee', payload: { titre: 'Studio Gounghin' }, created_at: new Date().toISOString(), read_at: null },
    { id: 'n-3', type: 'free_pass.offert', payload: {}, created_at: new Date().toISOString(), read_at: new Date().toISOString() },
  ],
  journal: [
    { id: 3, actor_id: 'moi', action: 'listing.approve', entity_type: 'properties', entity_id: 'p-9', reason: null, created_at: new Date().toISOString() },
    { id: 2, actor_id: 'autre', action: 'free_pass.grant', entity_type: 'owner_free_pass', entity_id: 'o-4', reason: 'Partenaire historique', created_at: new Date().toISOString() },
    { id: 1, actor_id: null, action: 'subscription.expire', entity_type: 'subscriptions', entity_id: 's-2', reason: null, created_at: new Date().toISOString() },
  ],
  profilsLisibles: true,
  envoyees: [],
  lues: 0,
  roles: [{ role: 'voyageur' }],
  perms: [],
};
window.__db = DB;
const UID = 'moi';
const err = (code, message) => ({ data: null, error: { code, message } });
const okRes = (data) => ({ data, error: null });
const estAdmin = () => DB.roles.some((r) => r.role === 'admin');
const peut = (p) => estAdmin() || DB.perms.some((x) => x.perm === p);

function builder(table) {
  let action = null, charge = null;
  const run = () => {
    if (table === 'partnership_applications') {
      if (action === 'insert') {
        // La règle de 0005 n'accepte que « recue » sans motif.
        if (charge.status !== 'recue' || charge.decision_reason !== null || !charge.consent) {
          return err('42501', 'new row violates row-level security policy');
        }
        DB.envoyees.push(charge);
        return okRes([{ id: 'a-new' }]);
      }
      if (action === 'update') { return okRes([{ id: 'x' }]); }
      if (!peut('partenariat')) return okRes([]);
      return okRes(DB.candidatures.slice());
    }
    if (table === 'owner_leads') {
      if (action === 'insert') { return okRes([{ id: 'l-new' }]); }
      if (action === 'update') { return okRes([{ id: 'x' }]); }
      if (!peut('demandes')) return okRes([]);
      return okRes(DB.demandes.slice());
    }
    if (table === 'audit_logs') {
      if (!peut('audit')) return err('42501', 'permission denied for table audit_logs');
      return okRes(DB.journal.slice());
    }
    if (table === 'profiles' && !DB.profilsLisibles) {
      return err('42501', 'permission denied for table profiles');
    }
    if (table === 'properties') return okRes([]);
    if (table === 'payment_notices') return peut('paiements') ? okRes([]) : err('42501', 'refuse');
    if (table === 'user_roles') return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    if (table === 'team_permissions') return okRes(DB.perms.map((x) => ({ user_id: UID, perm: x.perm })));
    if (table === 'profiles') return okRes([{ id: UID, full_name: 'Moussa Compaore', phone: null }]);
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; },
    insert(v) { action = 'insert'; charge = v; return self; },
    update(v) { action = 'update'; charge = v; return self; },
    upsert() { return self; }, delete() { return self; },
    eq() { return self; }, in() { return self; }, order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: 'jeton', user: { id: UID, email: 'moussa@test.local' } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem('fs') ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem('fs', '1'); listeners.forEach((f) => f('SIGNED_IN', SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem('fs'); listeners.forEach((f) => f('SIGNED_OUT', null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn) {
    if (fn === 'my_notifications') return Promise.resolve(okRes(DB.notifications.slice()));
    if (fn === 'mark_notifications_read') {
      DB.lues++; DB.notifications = DB.notifications.map((n) => ({ ...n, read_at: n.read_at || new Date().toISOString() }));
      return Promise.resolve(okRes(2));
    }
    if (fn === 'my_owner_identity') return Promise.resolve(okRes([{ state: 'verifie', id_type: 'cnib', id_number_masked: '****1', files_sent: 0, decision_note: null, files_deleted: true }]));
    if (fn === 'my_subscription' || fn === 'my_listing_counts') return Promise.resolve(okRes([]));
    return Promise.resolve(okRes([]));
  },
  storage: { from() { return {
    async createSignedUrl() { return okRes({ signedUrl: 'data:image/svg+xml,%3Csvg xmlns=\\'http://www.w3.org/2000/svg\\'/%3E' }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1500 } });
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
const aller = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(700); };
const reconnexion = async () => {
  await aller("#compte");
  // Si une session est ouverte, on la ferme ; sinon on se connecte directement.
  const sortie = p.getByRole("button", { name: "Se déconnecter" });
  if (await sortie.count()) {
    await sortie.click();
    await p.waitForTimeout(400);
  }
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "moussa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(800);
};

// =====================================================================
// 1. La candidature Partenariat part vers la BASE
// =====================================================================
await p.goto(URL + "#partenariat");
await p.waitForSelector("h1");
await p.waitForTimeout(500);
ok("le formulaire de candidature est bien sur la page",
  await p.locator("#pa-name").count() === 1);

await p.fill("#pa-name", "Salif Kabore");
await p.fill("#pa-phone", "+226 70 12 34 56");
await p.fill("#pa-district", "Koulouba");
await p.fill("#pa-cond", "Villa recente, carrelage neuf, pas de climatisation.");
await p.fill("#pa-works", "Climatisation et portail");
await p.check("#pa-consent");
await p.getByRole("button", { name: "Envoyer ma candidature" }).click();
await p.waitForTimeout(800);

const envoyees = await p.evaluate(() => window.__db.envoyees);
ok("la candidature atteint la base (elle restait dans le navigateur avant)", envoyees.length === 1);
ok("avec le nom saisi", envoyees[0] && envoyees[0].contact_name === "Salif Kabore");
ok("le quartier et le type de bien", envoyees[0] && envoyees[0].district === "Koulouba" && envoyees[0].property_kind === "Villa");
ok("l'état du bien", envoyees[0] && envoyees[0].condition_notes.startsWith("Villa recente"));
ok("le statut imposé est « recue », jamais un statut choisi par le candidat",
  envoyees[0] && envoyees[0].status === "recue" && envoyees[0].decision_reason === null);
ok("et le consentement", envoyees[0] && envoyees[0].consent === true);
ok("la confirmation s'affiche", /Candidature re/.test(await texte()));

// Un échec d'envoi doit se voir, sinon le visiteur croit sa candidature partie.
await p.evaluate(() => { window.__db.refuser = true; });
await aller("#serenite");
await aller("#partenariat");
await p.waitForTimeout(500);
await p.fill("#pa-name", "Test Refus");
await p.fill("#pa-phone", "+226 70 00 00 00");
await p.fill("#pa-district", "Centre");
await p.fill("#pa-cond", "Texte suffisamment long pour passer la validation.");
await p.check("#pa-consent");
await p.evaluate(() => {
  const vrai = window.supabase.createClient;
  window.__forcer = true;
});
// On force un refus du serveur en vidant la règle côté imitation.
await p.evaluate(() => { window.__db.envoyees.push = () => { throw new Error("refus simule"); }; });
await p.getByRole("button", { name: "Envoyer ma candidature" }).click();
await p.waitForTimeout(800);
ok("un échec d'envoi est montré au visiteur, pas avalé",
  /L'envoi de la candidature a échoué|L'envoi a échoué|refus simule/.test(await texte()));

// =====================================================================
// 2. L'onglet Demandes
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "paiements" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
ok("sans les autorisations « demandes » ni « partenariat », l'onglet est absent",
  !/Demandes/.test(await texte()));

await p.evaluate(() => { window.__db.perms = [{ perm: "demandes" }, { perm: "partenariat" }]; });
await reconnexion();
await aller("#equipe");
await p.getByRole("button", { name: "Demandes" }).click();
await p.waitForTimeout(800);
let t = await texte();
ok("l'onglet Demandes s'ouvre", /À rappeler/.test(t));
ok("il annonce combien de personnes attendent", /2 personnes attendent une réponse/.test(t));
ok("la demande de rappel non traitée est affichée", /Clarisse Kabore/.test(t));
ok("avec l'offre visée, traduite en clair", /YIRI Annonce/.test(t));
ok("et son message", /Je veux publier deux studios/.test(t));
ok("celle déjà traitée est repliée", /Déjà rappelés \(1\)/.test(t));
ok("la candidature reçue est affichée", /Awa Sawadogo/.test(t));
ok("avec l'état du bien", /Construction recente/.test(t));
ok("les dossiers clos sont repliés", /Dossiers clos \(1\)/.test(t));

const liens = await p.evaluate(() => ({
  wa: Array.from(document.querySelectorAll("a[href*='wa.me']")).map((a) => a.getAttribute("href")),
  tel: Array.from(document.querySelectorAll("a[href^='tel:']")).map((a) => a.getAttribute("href")),
}));
ok("on peut écrire sur WhatsApp en un clic", liens.wa.some((h) => h.includes("70000003")));
ok("et appeler", liens.tel.some((h) => h.includes("70000003")));

ok("refuser une candidature exige un motif",
  await p.getByRole("button", { name: "Refuser" }).first().isDisabled());
await p.locator("input[id^='m-']").first().fill("Bien trop éloigné de nos zones");
await p.waitForTimeout(200);
ok("avec un motif, le refus devient possible",
  await p.getByRole("button", { name: "Refuser" }).first().isEnabled());

// =====================================================================
// 3. La cloche de notifications
// =====================================================================
t = await texte();
ok("la cloche affiche le nombre de non lues", /Alertes\s*2/.test(t.replace(/\n/g, " ")));
await p.getByRole("button", { name: /Notifications/ }).click();
await p.waitForTimeout(600);
t = await texte();
ok("la relance d'abonnement est lisible en français", /Votre abonnement expire dans 7 jours/.test(t));
ok("la réservation payée aussi, avec le logement", /Réservation payée sur Studio Gounghin/.test(t));
ok("et l'accès offert", /YIRI vous a offert un accès gratuit/.test(t));
ok("l'ouverture marque les notifications comme lues",
  await p.evaluate(() => window.__db.lues === 1));

// =====================================================================
// 4. L'onglet Journal — l'autorisation « audit » n'ouvrait rien avant
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "paiements" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
ok("sans l'autorisation « audit », l'onglet Journal est absent", !/Journal/.test(await texte()));

await p.evaluate(() => { window.__db.perms = [{ perm: "audit" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForTimeout(500);
ok("avec l'autorisation « audit », l'onglet Journal apparaît", /Journal/.test(await texte()));
await p.getByRole("button", { name: "Journal" }).click();
await p.waitForTimeout(800);
t = await texte();
ok("le journal annonce qu'il est en lecture seule", /lecture seule/.test(t));
ok("les actions sont traduites en français", /Annonce validée/.test(t) && /Accès offert accordé/.test(t));
ok("une action du système est attribuée au système", /Par le système/.test(t));
ok("le motif est affiché quand il y en a un", /Partenaire historique/.test(t));
ok("le code technique reste visible, c'est lui qui fait foi", /listing\.approve/.test(t));
ok("le nombre de lignes est annoncé", /3 lignes/.test(t));
ok("aucun bouton ne permet de modifier le journal",
  await p.getByRole("button", { name: /Supprimer|Modifier|Effacer/ }).count() === 0);

// Le filtre
await p.fill("#j-q", "Partenaire historique");
await p.waitForTimeout(300);
t = await texte();
ok("le filtre réduit la liste", /1 ligne sur 3/.test(t) && !/Annonce validée/.test(t));
await p.fill("#j-q", "");
await p.waitForTimeout(300);

// Un membre qui n'a QUE « audit » ne peut pas lire les profils : le nom doit manquer
// SANS faire disparaître la ligne.
await p.evaluate(() => { window.__db.profilsLisibles = false; });
await p.getByRole("button", { name: "Actualiser" }).click();
await p.waitForTimeout(800);
t = await texte();
ok("sans accès aux profils, les lignes restent visibles", /Annonce validée/.test(t) && /3 lignes/.test(t));
ok("et le nom manquant est expliqué, pas inventé", /nom non accessible avec vos autorisations/.test(t));
await p.evaluate(() => { window.__db.profilsLisibles = true; });

// Un visiteur non connecté ne voit pas de cloche.
await aller("#compte");
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForTimeout(800);
ok("déconnecté, aucune cloche", await p.getByRole("button", { name: /Notifications/ }).count() === 0);

ok("aucune erreur JavaScript pendant tout le parcours", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DES DEMANDES PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
