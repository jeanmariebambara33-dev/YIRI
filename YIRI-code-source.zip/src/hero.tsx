import * as React from "react";

/**
 * Scène d'accueil illustrée : un village de cases à la tombée du jour, en contre-jour, ambiance cinéma.
 * C'est une illustration générée en code. Pour une vraie photo, passer `photoUrl` :
 * elle remplace la scène et garde les mêmes dégradés de lecture.
 */

type HutProps = { x: number; y: number; s?: number; wall?: "dark" | "plaster"; lit?: boolean; window?: boolean; idp?: string };

/** Case ronde : mur cylindrique, toit de chaume conique, porte arrondie. (x, y) = pied du mur au centre. */
function Hut({ x, y, s = 1, wall = "dark", lit = true, window: win = false, idp = "hs" }: HutProps) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <ellipse cx="0" cy="5" rx="86" ry="8" fill="#000" opacity="0.4" />
      <rect x="-58" y="-70" width="116" height="70" fill={`url(#${idp}-${wall === "plaster" ? "wB" : "wA"})`} />
      {/* bande de banco au pied du mur */}
      <rect x="-58" y="-9" width="116" height="9" fill="#000" opacity="0.18" />
      {lit && <path d="M-15 0 v-44 a15 15 0 0 1 30 0 v44 z" fill="#ffb25a" filter={`url(#${idp}-blur-s)`} opacity="0.85" />}
      <path d="M-14 0 v-42 a14 14 0 0 1 28 0 v42 z" fill={lit ? `url(#${idp}-glass)` : "#2a1812"} />
      {win && <rect x="30" y="-54" width="16" height="24" rx="8" fill={`url(#${idp}-glass)`} />}
      {/* chaume */}
      <path d="M-84 -60 Q-36 -82 0 -152 Q36 -82 84 -60 Q42 -50 0 -52 Q-42 -50 -84 -60 Z" fill={`url(#${idp}-roof)`} />
      {[-66, -50, -34, -18, -4, 10, 26, 42, 58, 72].map((px) => (
        <path key={px} d={`M${px * 0.08} -146 L${px} -56`} stroke="#1f120a" strokeWidth="1.3" opacity="0.55" fill="none" />
      ))}
      <path d="M-84 -60 Q-36 -82 0 -152" stroke="#ffbb73" strokeWidth="1.8" fill="none" opacity="0.5" />
      <path d="M-84 -60 Q-42 -50 0 -52 Q42 -50 84 -60" stroke="#120a06" strokeWidth="2.2" fill="none" opacity="0.6" />
    </g>
  );
}

function FarHut({ x, y, s }: { x: number; y: number; s: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x="-58" y="-70" width="116" height="70" fill="#20120f" />
      <path d="M-84 -60 Q-36 -82 0 -152 Q36 -82 84 -60 Z" fill="#190e0c" />
      <rect x="-6" y="-26" width="12" height="26" rx="6" fill="#ffb25a" opacity="0.75" />
    </g>
  );
}

function Baobab({ x, y, s = 1 }: { x: number; y: number; s?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill="#0f0a09" stroke="#0f0a09" strokeLinecap="round">
      <path d="M-36 0 C-30 -48 -44 -96 -34 -140 L34 -140 C44 -96 30 -48 36 0 Z" stroke="none" />
      <path d="M-28 -138 C-60 -170 -96 -190 -130 -194" strokeWidth="11" fill="none" />
      <path d="M-4 -140 C-6 -180 -16 -210 -30 -236" strokeWidth="10" fill="none" />
      <path d="M22 -140 C54 -172 92 -186 126 -190" strokeWidth="11" fill="none" />
      <path d="M-84 -176 C-96 -196 -100 -210 -98 -224" strokeWidth="6" fill="none" />
      <path d="M92 -178 C102 -198 108 -214 106 -226" strokeWidth="6" fill="none" />
      {[[-130, -196, 34, 13], [-98, -228, 24, 10], [-30, -240, 30, 12], [126, -192, 34, 13], [106, -230, 24, 10], [10, -222, 28, 10]].map(([cx, cy, rx, ry], i) => (
        <ellipse key={i} cx={cx} cy={cy} rx={rx} ry={ry} stroke="none" />
      ))}
    </g>
  );
}

function Smoke({ x, y, h = 120, o = 0.22, idp = "hs" }: { x: number; y: number; h?: number; o?: number; idp?: string }) {
  return (
    <path
      d={`M${x} ${y} C${x - 22} ${y - h * 0.25} ${x + 26} ${y - h * 0.45} ${x - 6} ${y - h * 0.7} C${x - 26} ${y - h * 0.88} ${x + 12} ${y - h} ${x + 4} ${y - h * 1.15}`}
      stroke="#e9cdb0" strokeWidth="16" strokeLinecap="round" fill="none" opacity={o} filter={`url(#${idp}-blur-s)`}
    />
  );
}

/** Case isolée (SVG autonome), utilisée sous chaque lettre du mot YIRI. */
export function HutSvg({ plaster = false, className }: { plaster?: boolean; className?: string }) {
  const wall = plaster ? "hw-wall-p" : "hw-wall-d";
  return (
    <svg viewBox="-92 -162 184 176" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="hw-wall-d" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#9a6247" /><stop offset="1" stopColor="#3b2520" /></linearGradient>
        <linearGradient id="hw-wall-p" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#e3c3a0" /><stop offset="1" stopColor="#7a4d3a" /></linearGradient>
        <linearGradient id="hw-roof" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7a5230" /><stop offset="1" stopColor="#33200f" /></linearGradient>
        <linearGradient id="hw-glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffe3a8" /><stop offset="1" stopColor="#ff9a48" /></linearGradient>
        <filter id="hw-blur" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="6" /></filter>
      </defs>
      <ellipse cx="0" cy="6" rx="86" ry="8" fill="#000" opacity="0.45" />
      <rect x="-58" y="-70" width="116" height="70" fill={`url(#${wall})`} />
      <rect x="-58" y="-9" width="116" height="9" fill="#000" opacity="0.18" />
      <path d="M-15 0 v-44 a15 15 0 0 1 30 0 v44 z" fill="#ffb25a" filter="url(#hw-blur)" opacity="0.9" />
      <path d="M-14 0 v-42 a14 14 0 0 1 28 0 v42 z" fill="url(#hw-glass)" />
      <rect x="30" y="-54" width="16" height="24" rx="8" fill="url(#hw-glass)" />
      <path d="M-84 -60 Q-36 -82 0 -152 Q36 -82 84 -60 Q42 -50 0 -52 Q-42 -50 -84 -60 Z" fill="url(#hw-roof)" />
      {[-66, -50, -34, -18, -4, 10, 26, 42, 58, 72].map((px) => (
        <path key={px} d={`M${px * 0.08} -146 L${px} -56`} stroke="#1f120a" strokeWidth="1.3" opacity="0.55" fill="none" />
      ))}
      <path d="M-84 -60 Q-36 -82 0 -152" stroke="#ffbb73" strokeWidth="1.8" fill="none" opacity="0.55" />
      <path d="M-84 -60 Q-42 -50 0 -52 Q42 -50 84 -60" stroke="#120a06" strokeWidth="2.2" fill="none" opacity="0.6" />
    </svg>
  );
}

/** Le mot YIRI : chaque lettre est posée au-dessus d'une case.
 *
 *  `anim` marque chaque lettre d'une classe ; les décalages sont dans index.css (nth-child),
 *  pour que toute la chorégraphie de l'introduction tienne en un seul endroit.
 *  `tag` : l'accueil porte déjà le seul <h1> de la page ; l'introduction prend donc un <div>,
 *  sinon le document aurait deux titres de premier niveau et le référencement en pâtirait.
 */
export function HutWordmark({ anim = false, tag = "h1" }: { anim?: boolean; tag?: "h1" | "div" } = {}) {
  const letters = ["Y", "I", "R", "I"];
  const Tag = tag;
  return (
    <Tag aria-label="YIRI" className="flex items-end justify-center gap-[clamp(0.25rem,2.4vw,2rem)]">
      {letters.map((l, i) => (
        <span key={i} className={anim ? "yi-lettre flex flex-col items-center" : "flex flex-col items-center"} aria-hidden="true">
          <span className="font-display text-[clamp(4.2rem,14vw,9.5rem)] font-extrabold leading-[0.82] tracking-[-0.03em] text-[#f7ecd8] [text-shadow:0_6px_30px_rgb(0_0_0/0.45)]">{l}</span>
          <HutSvg plaster={i % 2 === 1} className="-mt-[0.4em] h-auto w-[clamp(74px,17vw,178px)]" />
        </span>
      ))}
    </Tag>
  );
}

/**
 * La scène du village, en SVG pur.
 *
 * `idp` préfixe tous les identifiants internes (dégradés, filtres) : deux scènes peuvent ainsi
 * coexister dans la même page sans se voler leurs dégradés. L'introduction s'en sert pour
 * dessiner EXACTEMENT le même village que la page d'accueil — c'est ce qui rend le passage de
 * l'animation au site invisible : l'image d'arrivée et l'image de départ sont la même.
 *
 * `children` se glisse entre le ciel et la terre. C'est la seule place où un soleil peut se
 * lever DERRIÈRE le village au lieu de flotter devant.
 */
export function VillageSvg({ idp = "hs", className, children }: { idp?: string; className?: string; children?: React.ReactNode }) {
  // herbes du premier plan, répartition déterministe
  const blades = React.useMemo(() => {
    const out: string[] = [];
    let r = 7;
    const rnd = () => ((r = (r * 9301 + 49297) % 233280) / 233280);
    for (let i = 0; i < 90; i++) {
      const x = rnd() * 1600, h = 26 + rnd() * 46, bend = (rnd() - 0.5) * 22;
      out.push(`M${x.toFixed(0)} 906 q${(bend * 0.4).toFixed(0)} ${(-h * 0.6).toFixed(0)} ${bend.toFixed(0)} ${(-h).toFixed(0)}`);
    }
    return out;
  }, []);

  return (
    <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMax slice" className={className}>
      <defs>
        {/* Le ciel, relevé pixel par pixel sur la photo de référence : bleu-gris froid au zénith,
            qui se réchauffe puis bascule dans l'orange à l'approche de l'horizon.

            L'orange tient une BANDE ÉTROITE près de l'horizon, et non les deux tiers du ciel.
            C'est la structure de la photo, et c'est aussi ce qui rend la page lisible : le bloc
            de texte occupe le milieu de l'image, et un orange vif à cet endroit obligeait à
            poser un voile si épais pour le texte crème que toute la lumière y passait. L'éclat
            se concentre donc là où il sert — l'horizon — et le texte retrouve un fond sombre
            sans qu'on ait rien à éteindre. */}
        <linearGradient id={`${idp}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#434f5d" />
          <stop offset="0.18" stopColor="#525e6b" />
          <stop offset="0.32" stopColor="#6c6d71" />
          <stop offset="0.44" stopColor="#8b7769" />
          <stop offset="0.54" stopColor="#c08f62" />
          <stop offset="0.62" stopColor="#e89140" />
          <stop offset="0.68" stopColor="#f9832a" />
          <stop offset="0.73" stopColor="#fb7a1e" />
          <stop offset="1" stopColor="#ffae45" />
        </linearGradient>
        {/* L'éclat autour du soleil. Sur la photo, son coeur est blanc pur (#fdfdfa) et vire au
            jaune franc (#ffd504) en quelques dizaines de pixels : c'est beaucoup plus vif que la
            lueur crépusculaire d'avant. */}
        <radialGradient id={`${idp}-sun`} gradientUnits="userSpaceOnUse" cx="940" cy="640" r="650">
          <stop offset="0" stopColor="#fffdf2" stopOpacity="0.98" />
          <stop offset="0.14" stopColor="#ffe580" stopOpacity="0.7" />
          <stop offset="0.34" stopColor="#ffb13c" stopOpacity="0.35" />
          <stop offset="1" stopColor="#ff8a1e" stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`${idp}-glass`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffe3a8" />
          <stop offset="1" stopColor="#ff9a48" />
        </linearGradient>
        {/* Murs et toits du village, assombris pour le contre-jour de la photo : là-bas le
            village est presque une silhouette, seules les fenêtres éclairent. Ces dégradés ne
            servent qu'à la scène ; les cases posées sous les lettres du nom ont les leurs
            (hw-…) et restent claires, puisqu'elles doivent se lire. */}
        <linearGradient id={`${idp}-wA`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#5f3a29" />
          <stop offset="1" stopColor="#241512" />
        </linearGradient>
        <linearGradient id={`${idp}-wB`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#93725a" />
          <stop offset="1" stopColor="#3f261d" />
        </linearGradient>
        <linearGradient id={`${idp}-roof`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#47301b" />
          <stop offset="1" stopColor="#1b1009" />
        </linearGradient>
        <linearGradient id={`${idp}-ground`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a241b" />
          <stop offset="1" stopColor="#0c0807" />
        </linearGradient>
        <linearGradient id={`${idp}-fog`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffb765" stopOpacity="0" />
          <stop offset="1" stopColor="#ffbe74" stopOpacity="0.5" />
        </linearGradient>
        <filter id={`${idp}-blur`} x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="22" /></filter>
        <filter id={`${idp}-blur-s`} x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="7" /></filter>
        <filter id={`${idp}-grain`} x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" />
          <feColorMatrix values="0 0 0 0 0.5  0 0 0 0 0.5  0 0 0 0 0.5  0 0 0 0.9 0" />
        </filter>
      </defs>

      {/* ---------- le ciel ---------- */}
      <rect width="1600" height="900" fill={`url(#${idp}-sky)`} />
      <rect width="1600" height="900" fill={`url(#${idp}-sun)`} />
      {[[120, 70], [300, 140], [520, 50], [760, 110], [930, 40], [1210, 90], [1420, 60], [1520, 170], [60, 200]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i % 3 === 0 ? 1.8 : 1.2} fill="#fff4dc" opacity="0.7" />
      ))}
      {/* oiseaux */}
      {[[1010, 250, 1], [1062, 226, 0.8], [1120, 262, 0.9]].map(([x, y, k], i) => (
        <path key={i} d={`M${x} ${y} q${8 * k} ${-9 * k} ${16 * k} 0 q${8 * k} ${-9 * k} ${16 * k} 0`} stroke="#2a1822" strokeWidth="2" fill="none" opacity="0.7" />
      ))}

      {/* horizon : collines lointaines, puis brume chaude */}
      <path d="M0 640 C 180 596 320 614 470 632 C 640 654 760 596 930 612 C 1120 630 1260 592 1420 612 C 1500 622 1560 618 1600 610 L1600 740 L0 740 Z" fill="#6b3522" opacity="0.82" />
      <rect x="0" y="560" width="1600" height="140" fill={`url(#${idp}-fog)`} />

      {/* ---------- ce que l'introduction glisse derrière le village ---------- */}
      {children}

      {/* ---------- la terre ---------- */}
      <g>
        {[[560, 668, 0.3], [620, 662, 0.26], [700, 670, 0.32], [1240, 664, 0.28], [1300, 670, 0.34], [1380, 664, 0.3], [1480, 670, 0.3], [1550, 666, 0.26]].map(([x, y, s], i) => (
          <FarHut key={i} x={x} y={y} s={s} />
        ))}
      </g>
      <path d="M0 700 C 220 676 380 694 560 688 C 760 682 900 708 1100 696 C 1300 684 1460 700 1600 686 L1600 800 L0 800 Z" fill="#2d1b1c" />

      {/* éclat du soleil derrière le village */}
      <ellipse cx="940" cy="636" rx="430" ry="130" fill="#ffc473" opacity="0.38" filter={`url(#${idp}-blur)`} />

      {/* plan intermédiaire */}
      <Hut idp={idp} x={760} y={716} s={0.6} wall="dark" lit />
      <Hut idp={idp} x={1330} y={722} s={0.7} wall="plaster" lit window />
      <Smoke idp={idp} x={760} y={716 - 152 * 0.6} h={110} o={0.18} />

      {/* baobab */}
      <Baobab x={1510} y={742} s={1.15} />

      {/* sentier */}
      <path d="M840 910 C 940 830 1010 770 1048 722 L 1090 722 C 1096 780 1200 850 1330 910 Z" fill="#6b4630" opacity="0.5" />

      {/* cases du premier plan */}
      <Hut idp={idp} x={960} y={760} s={1.0} wall="dark" lit window />
      <Hut idp={idp} x={1170} y={744} s={1.35} wall="plaster" lit />
      <Smoke idp={idp} x={1170} y={744 - 152 * 1.35} h={150} o={0.24} />
      <Smoke idp={idp} x={960} y={760 - 152} h={120} o={0.2} />

      {/* mur bas en banco et feu de cuisine */}
      <path d="M1010 770 Q1100 800 1250 768" stroke="#2a1a14" strokeWidth="9" strokeLinecap="round" fill="none" />
      <circle cx="1068" cy="796" r="22" fill="#ff9a48" opacity="0.7" filter={`url(#${idp}-blur-s)`} />
      <circle cx="1068" cy="796" r="5" fill="#ffd9a0" />

      {/* lumière au sol */}
      <ellipse cx="1170" cy="752" rx="190" ry="14" fill="#ffb25a" opacity="0.35" filter={`url(#${idp}-blur-s)`} />
      <rect x="0" y="770" width="1600" height="140" fill={`url(#${idp}-ground)`} opacity="0.92" />

      {/* acacia à gauche */}
      <g fill="#120c0b">
        <path d="M470 776 C 474 716 468 678 454 646 L 468 644 C 482 672 490 716 492 776 Z" />
        <ellipse cx="440" cy="632" rx="116" ry="25" />
        <ellipse cx="510" cy="614" rx="92" ry="19" />
        <ellipse cx="392" cy="656" rx="64" ry="13" />
      </g>

      {/* premier plan : herbes en contre-jour */}
      <path d="M0 820 C 90 786 190 800 260 830 L 260 900 L 0 900 Z" fill="#0e0908" />
      <path d="M1360 836 C 1450 800 1540 812 1600 790 L 1600 900 L 1360 900 Z" fill="#0e0908" />
      <path d={blades.join(" ")} stroke="#0e0908" strokeWidth="3.2" strokeLinecap="round" fill="none" />

      {/* reflet d'objectif et grain de pellicule */}
      <ellipse cx="940" cy="646" rx="300" ry="5" fill="#fff3d2" opacity="0.3" filter={`url(#${idp}-blur-s)`} />
      <rect width="1600" height="900" filter={`url(#${idp}-grain)`} opacity="0.1" style={{ mixBlendMode: "overlay" }} />
    </svg>
  );
}

/** Les deux voiles de lecture posés sur la scène. L'introduction les reprend à l'identique. */
export function VoilesScene() {
  return (
    <>
      {/* Trois couches, et chacune a une raison.

          1. L'ambiance : un assombrissement large et léger, qui donne sa profondeur à l'image.
          2. Le lit du texte : un voile resserré sous la colonne de texte. Depuis que le ciel est
             lumineux, le texte crème n'y passait plus qu'à 2,4 contre 1, là où la norme
             d'accessibilité en demande 4,5 pour du texte courant. Ce voile-ci est donc une
             question de lisibilité, pas de goût : sans lui, une partie des gens ne lit pas la
             page. Il est volontairement étroit, pour laisser le ciel vif sur les côtés et le
             soleil intact à l'horizon.
          3. Les bords : le vignettage, et le fondu vers le bas de la section. */}
      <div className="absolute inset-0" style={{ background: "radial-gradient(78% 88% at 50% 54%, rgba(40,16,2,0.16) 0%, rgba(40,16,2,0.1) 60%, rgba(40,16,2,0) 100%)" }} />
      <div className="absolute inset-0" style={{ background: "radial-gradient(86% 34% at 50% 61%, rgba(36,13,0,0.74) 0%, rgba(36,13,0,0.56) 50%, rgba(36,13,0,0.18) 80%, rgba(36,13,0,0) 100%)" }} />
      <div className="absolute inset-0" style={{ background: "linear-gradient(0deg, rgba(20,10,4,0.42) 0%, rgba(20,10,4,0) 42%), radial-gradient(120% 90% at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.42) 100%)" }} />
    </>
  );
}

/** Le soleil.
 *
 *  Il appartient à la scène, pas seulement à l'introduction. Deux raisons. La photo de référence
 *  en montre un, bien visible : sans lui la page d'accueil n'est qu'une lueur sans source. Et
 *  comme l'introduction affiche le MÊME soleil, simplement animé, la dernière image de
 *  l'animation est exactement celle du site — il n'y a rien à faire disparaître au raccord.
 *
 *  Position : 940 sur les 1600 du dessin. Le dessin se recadre en « slice », si bien qu'un écran
 *  de téléphone n'en montre qu'une bande centrale, environ de 550 à 1050 ; posé plus à droite,
 *  le soleil serait invisible pour la quasi-totalité des gens, qui sont sur téléphone.
 *
 *  Hauteur 606 : la ligne de collines passe vers 630 ici, le disque y pose donc son pied, comme
 *  sur la photo où il touche l'eau. Quatre cercles emboîtés plutôt qu'un seul : un disque net
 *  posé sous les voiles de lecture ne ressemblait pas à une source de lumière mais à un trou
 *  gris. Un soleil se reconnaît à son débordement, pas à son contour.
 */
export function Soleil({ idp = "hs", className }: { idp?: string; className?: string }) {
  return (
    <g className={className}>
      <circle cx="940" cy="606" r="250" fill="#ffb44f" opacity="0.5" filter={`url(#${idp}-blur)`} />
      <circle cx="940" cy="606" r="104" fill="#ffd98a" opacity="0.8" filter={`url(#${idp}-blur-s)`} />
      <circle cx="940" cy="606" r="44" fill="#fff6d8" opacity="0.95" filter={`url(#${idp}-blur-s)`} />
      <circle cx="940" cy="606" r="27" fill="#fffdf2" />
    </g>
  );
}

/** Le contenu du héros : accroche, nom, promesse, bouton.
 *
 *  Il vit ici, et non dans la page d'accueil, parce que l'introduction doit afficher EXACTEMENT
 *  le même bloc, au même endroit. C'est ce qui fait disparaître le raccord : au moment où le
 *  voile s'efface, le nom YIRI de l'animation se trouve au pixel près sur celui du site, et ne
 *  bouge donc pas. Deux copies dans deux fichiers auraient dérivé au premier ajustement.
 *
 *  Sans `onDecouvrir`, le bouton est un décor inerte : l'introduction ne propose pas un bouton
 *  qui ne mène nulle part à la navigation au clavier ni aux lecteurs d'écran.
 *
 *  `resume` ne garde que l'accroche et le nom. L'introduction s'en sert : posée sur une photo,
 *  elle doit être un carton-titre, pas une page d'accueil recopiée. Comme les deux éléments
 *  conservés sont les premiers du bloc, retirer ce qui suit ne les déplace pas d'un pixel — le
 *  nom reste donc exactement sur celui du site.
 */
export function HeroContenu({ anim = false, tag = "h1", resume = false, onDecouvrir }: { anim?: boolean; tag?: "h1" | "div"; resume?: boolean; onDecouvrir?: () => void }) {
  const cls = (base: string) => (anim ? `yi-reste ${base}` : base);
  const bouton = "mt-3 inline-flex w-full items-center justify-center gap-3 rounded-full bg-[#f2b27a] px-10 py-5 text-xl font-extrabold text-[#2a1a12] shadow-[0_12px_40px_-10px_rgb(242_178_122/0.55)] transition-colors sm:w-auto";
  return (
    <div data-yiri-hero className="mx-auto flex w-full max-w-3xl flex-col items-center gap-5 px-4 py-14 text-center sm:px-6 md:py-20">
      <p className={(anim ? "yi-sus " : "") + "text-xs font-bold uppercase tracking-[0.28em] text-[#f7e3c6]"}>Burkina Faso</p>
      <div className={anim ? "yi-mot contents" : "contents"}><HutWordmark anim={anim} tag={tag} /></div>
      {resume ? null : (
      <p className={cls("font-display text-[clamp(1.6rem,4.2vw,2.8rem)] font-bold leading-tight text-[#f7ecd8] text-balance")}>
        Chez vous, partout.
      </p>
      )}
      {resume ? null : (
      <p className={cls("max-w-[44ch] text-lg leading-relaxed text-[#eadcc4] text-balance")}>
        Une marque de séjours qui vous fait sentir chez vous, où que vous soyez.
      </p>
      )}
      {resume ? null : onDecouvrir ? (
        <button onClick={onDecouvrir} className={`${bouton} cursor-pointer hover:bg-[#f8c595] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]`}>
          Découvrir nos logements <span aria-hidden="true">→</span>
        </button>
      ) : (
        <span aria-hidden="true" className={cls(bouton)}>Découvrir nos logements <span>→</span></span>
      )}
    </div>
  );
}

export function HeroScene({ photoUrl }: { photoUrl?: string }) {
  return (
    <div className="absolute inset-0 -z-10 overflow-hidden bg-[#14121f]" aria-hidden="true">
      {photoUrl ? (
        <img src={photoUrl} alt="" className="h-full w-full object-cover" />
      ) : (
        <VillageSvg className="h-full w-full"><Soleil /></VillageSvg>
      )}
      {/* lisibilité du texte et vignettage */}
      <VoilesScene />
    </div>
  );
}

function Person({ x, y, s = 1, bag = false, wave = false }: { x: number; y: number; s?: number; bag?: boolean; wave?: boolean }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill="#140d0b" stroke="#140d0b" strokeLinecap="round">
      <circle cx="0" cy="-108" r="12" stroke="none" />
      <path d="M-18 -92 Q0 -100 18 -92 L25 -8 L-25 -8 Z" stroke="none" />
      <rect x="-14" y="-10" width="9" height="12" stroke="none" />
      <rect x="5" y="-10" width="9" height="12" stroke="none" />
      {wave && <path d="M14 -88 L44 -112" strokeWidth="8" fill="none" />}
      {wave && <circle cx="46" cy="-114" r="5" stroke="none" />}
      {bag && <rect x="-46" y="-30" width="22" height="30" rx="3" stroke="none" />}
      {bag && <path d="M-40 -30 v-8 h10 v8" strokeWidth="2.5" fill="none" />}
    </g>
  );
}

/** Scène « propriétaire » : lumière dorée du matin, un propriétaire accueille un voyageur devant sa case. */
export function OwnerScene() {
  return (
    <div className="absolute inset-0 -z-10 overflow-hidden bg-[#2a1d22]" aria-hidden="true">
      <svg viewBox="0 0 1600 900" preserveAspectRatio="xMaxYMax slice" className="h-full w-full">
        <defs>
          {/* Préfixe « os- » sur TOUS les identifiants, sans exception.
              Cette scène redéfinissait hs-glass, hs-wA, hs-wB, hs-roof et hs-blur-s, qui
              appartiennent déjà à la scène du héros. Deux identifiants identiques dans une même
              page : le navigateur retient le premier et ignore le second, donc ces définitions-ci
              ne servaient à rien — elles donnaient seulement l'illusion d'être réglables. */}
          <linearGradient id="os-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#6d7984" />
            <stop offset="0.14" stopColor="#8d8787" />
            <stop offset="0.34" stopColor="#c79a78" />
            <stop offset="0.54" stopColor="#ed9644" />
            <stop offset="0.76" stopColor="#fb8726" />
            <stop offset="1" stopColor="#ffb14a" />
          </linearGradient>
          <radialGradient id="os-sun" gradientUnits="userSpaceOnUse" cx="1060" cy="600" r="620">
            <stop offset="0" stopColor="#fffdf2" stopOpacity="1" />
            <stop offset="0.14" stopColor="#ffe580" stopOpacity="0.7" />
            <stop offset="0.34" stopColor="#ffb13c" stopOpacity="0.35" />
            <stop offset="1" stopColor="#ff8a1e" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="os-glass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffe3a8" /><stop offset="1" stopColor="#ff9a48" /></linearGradient>
          <linearGradient id="os-wA" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#5f3a29" /><stop offset="1" stopColor="#241512" /></linearGradient>
          <linearGradient id="os-wB" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#93725a" /><stop offset="1" stopColor="#3f261d" /></linearGradient>
          <linearGradient id="os-roof" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#47301b" /><stop offset="1" stopColor="#1b1009" /></linearGradient>
          <linearGradient id="os-ground" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#4a2f21" /><stop offset="1" stopColor="#160c08" /></linearGradient>
          <filter id="os-blur-s" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="7" /></filter>
        </defs>
        <rect width="1600" height="900" fill="url(#os-sky)" />
        <rect width="1600" height="900" fill="url(#os-sun)" />
        <circle cx="1060" cy="600" r="118" fill="#ffd98a" opacity="0.6" filter="url(#os-blur-s)" />
        <circle cx="1060" cy="600" r="44" fill="#fff6d8" opacity="0.95" filter="url(#os-blur-s)" />
        <circle cx="1060" cy="600" r="27" fill="#fffdf2" />
        <path d="M0 650 C 200 610 360 636 520 650 C 700 668 820 622 1000 636 C 1180 650 1340 612 1600 634 L1600 760 L0 760 Z" fill="#8d4328" opacity="0.6" />
        {[[520, 690, 0.3], [590, 684, 0.26], [1330, 686, 0.3], [1410, 690, 0.26]].map(([x, y, s], i) => <FarHut key={i} x={x} y={y} s={s} />)}
        <path d="M0 716 C 260 694 460 712 700 704 C 900 698 1100 716 1600 700 L1600 820 L0 820 Z" fill="#3a2217" />
        <ellipse cx="930" cy="690" rx="420" ry="90" fill="#ffc473" opacity="0.42" filter="url(#os-blur-s)" />

        <Baobab x={1560} y={800} s={0.95} />
        <Hut idp="os" x={1340} y={810} s={1.6} wall="plaster" lit window />
        <Smoke idp="os" x={1340} y={810 - 152 * 1.6} h={170} o={0.24} />
        <path d="M820 910 C 960 860 1100 820 1230 808 L 1320 808 C 1330 850 1380 880 1420 910 Z" fill="#6b462c" opacity="0.55" />
        <ellipse cx="1340" cy="818" rx="250" ry="14" fill="#ffc473" opacity="0.45" filter="url(#os-blur-s)" />
        <rect x="0" y="826" width="1600" height="90" fill="url(#os-ground)" opacity="0.95" />

        {/* le propriétaire accueille, le voyageur arrive avec sa valise */}
        <Person x={1170} y={866} s={1.5} wave />
        <Person x={1010} y={880} s={1.3} bag />
        <path d="M0 850 C 120 826 240 836 320 864 L320 900 L0 900 Z" fill="#0e0908" />
        <path d="M1420 870 C 1500 840 1560 850 1600 836 L1600 900 L1420 900 Z" fill="#0e0908" />
      </svg>
      <div className="absolute inset-0 bg-gradient-to-r from-[#1a0f12]/75 via-[#1a0f12]/30 to-transparent max-lg:from-[#1a0f12]/65 max-lg:via-[#1a0f12]/35" />
      <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#1a0f12] to-transparent" />
    </div>
  );
}
