-- Tests de la migration 0011 (voir les réservations, être prévenu).
-- Base LOCALE ; auth.uid() simulé ; « reset role » = clé de service (postgres).
--
-- Ce qui est vraiment vérifié ici :
--   * un propriétaire ne voit QUE ses logements ;
--   * les coordonnées du voyageur sont MASQUÉES avant paiement et visibles après ;
--   * un voyageur ne peut pas ouvrir la file de l'équipe ;
--   * un membre d'équipe sans la bonne permission non plus ;
--   * la confirmation d'un paiement écrit bien une notification au propriétaire ET à l'équipe ;
--   * chacun ne lit que SES notifications.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
update profiles set phone = '7000000' || substr(full_name, 13) where full_name like 'Utilisateur %';

insert into user_roles (user_id, role) values
  (t.u(3), 'proprietaire'),   -- propriétaire du logement 1
  (t.u(4), 'proprietaire'),   -- propriétaire du logement 2 (cloisonnement)
  (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(7), 'reservations', t.u(5)),
  (t.u(8), 'paiements',    t.u(5)),
  (t.u(9), 'demandes',     t.u(5));   -- équipe, mais PAS la bonne permission

-- Logement 1 : offre « annonce » (Visibilité) chez l'utilisateur 3.
-- Logement 2 : offre « gestion » (Sérénité) chez l'utilisateur 4 → « sous gestion ».
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'annonce', 'Studio Visibilite', 'desc', 'Ouagadougou', 'Centre', 'adr',
        2, 1, 1, 20000, 1, 'publiee', false),
       (t.p(2), t.u(4), 'gestion', 'Villa Serenite',   'desc', 'Bobo-Dioulasso', 'Accart', 'adr',
        4, 2, 2, 30000, 1, 'publiee', false);

create function t.mkbk(n int, prop int, guest int, d1 int, d2 int, total int, st booking_status)
returns void language plpgsql as $$
begin
  insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof,
                        accommodation_xof, taxes_xof, discount_xof, total_xof, status)
  values (t.b(n), t.p(prop), t.u(guest),
          daterange(current_date + d1, current_date + d2, '[)'), 2, 20000,
          total, 0, 0, total, st);
end $$;

-- Logement 1 : une réservation payée (dans 10 jours), une NON payée en attente (dans 3 jours).
select t.mkbk(1, 1, 1, 10, 13, 60000, 'confirmee');
select t.mkbk(2, 1, 2,  3,  5, 40000, 'en_attente_paiement');
-- Logement 1 : une réservation terminée, loin dans le passé.
select t.mkbk(3, 1, 1, -40, -37, 50000, 'terminee');
-- Logement 2 (sous gestion), chez un AUTRE propriétaire.
select t.mkbk(4, 2, 1, 20, 22, 70000, 'confirmee');

-- Encaissements réussis pour les réservations 1, 3 et 4.
create function t.mkpay(n int, amount int) returns void language plpgsql as $$
declare ref text := 'YIRI-TEST-' || lpad(n::text, 4, '0');
begin
  insert into payment_attempts (reference, object, target_id, amount_xof, provider, created_by,
                                settled_at, outcome)
  values (ref, 'reservation', t.b(n), amount, 'testpay', t.u(1), now(), 'paye');
  insert into payment_transactions (purpose, booking_id, provider, provider_reference, idempotency_key,
                                    amount_xof, status)
  values ('booking', t.b(n), 'testpay', ref, 'online:' || ref, amount, 'reussi');
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (null, 'payment.method', 'reservation', t.b(n)::text, jsonb_build_object('moyen', 'orange_money'));
end $$;
select t.mkpay(1, 60000);
select t.mkpay(3, 50000);
select t.mkpay(4, 70000);

-- ============ Qui peut ouvrir la file de l'équipe ============
reset role; select t.as(0);
select t.must_fail('visiteur : file des réservations refusée', $$select * from bookings_queue()$$);
select t.must_fail('visiteur : mes réservations de propriétaire refusées', $$select * from owner_bookings()$$);
select t.must_fail('visiteur : mes notifications refusées', $$select * from my_notifications()$$);

reset role; select t.as(1);
select t.must_fail('un voyageur ne peut pas ouvrir la file de l''équipe', $$select * from bookings_queue()$$);
reset role; select t.as(3);
select t.must_fail('un propriétaire ne peut pas ouvrir la file de l''équipe', $$select * from bookings_queue()$$);
reset role; select t.as(9);
select t.must_fail('équipe « demandes » : mauvaise permission, refusée', $$select * from bookings_queue()$$);
reset role; select t.as(7);
select t.ok('équipe « reservations » : file autorisée', $$select * from bookings_queue()$$);
reset role; select t.as(8);
select t.ok('équipe « paiements » : file autorisée aussi', $$select * from bookings_queue()$$);
reset role; select t.as(5);
select t.ok('administrateur : file autorisée', $$select * from bookings_queue()$$);

-- ============ Ce que l'équipe voit ============
reset role; select t.as(7);
select t.cnt('l''équipe voit les quatre réservations', $$select * from bookings_queue()$$, 4);
select t.eq('prochaine arrivée en tête : la réservation non payée dans 3 jours',
  format($$select (id = %L)::text from bookings_queue() limit 1$$, t.b(2)), 'true');
select t.eq('la réservation terminée est rejetée en fin de liste',
  format($$select (id = %L)::text from (select id, row_number() over () r from bookings_queue()) s where r = 4$$, t.b(3)), 'true');
select t.eq('l''équipe voit le téléphone du voyageur même avant paiement',
  format($$select guest_phone from bookings_queue() where id = %L$$, t.b(2)), '70000002');
select t.eq('l''équipe voit l''adresse électronique du voyageur',
  format($$select guest_email from bookings_queue() where id = %L$$, t.b(1)), 'u1@test.local');
select t.eq('réservation payée : marquée payée',
  format($$select paye::text from bookings_queue() where id = %L$$, t.b(1)), 'true');
select t.eq('réservation non payée : marquée non payée',
  format($$select paye::text from bookings_queue() where id = %L$$, t.b(2)), 'false');
select t.eq('la référence du prestataire est reprise',
  format($$select reference from bookings_queue() where id = %L$$, t.b(1)), 'YIRI-TEST-0001');
select t.eq('le moyen de paiement est retrouvé dans le journal',
  format($$select moyen from bookings_queue() where id = %L$$, t.b(1)), 'orange_money');
select t.eq('le moyen est nul quand rien n''a été payé',
  format($$select coalesce(moyen, 'NUL') from bookings_queue() where id = %L$$, t.b(2)), 'NUL');
select t.eq('l''offre « gestion » est signalée sous gestion',
  format($$select sous_gestion::text from bookings_queue() where id = %L$$, t.b(4)), 'true');
select t.eq('l''offre « annonce » ne l''est pas',
  format($$select sous_gestion::text from bookings_queue() where id = %L$$, t.b(1)), 'false');
select t.eq('le nombre de nuits est calculé',
  format($$select nuits::text from bookings_queue() where id = %L$$, t.b(1)), '3');
select t.cnt('la limite est respectée', $$select * from bookings_queue(2)$$, 2);
select t.cnt('une limite absurde ne vide pas la liste', $$select * from bookings_queue(0)$$, 1);

-- ============ Ce qu'un propriétaire voit — et surtout ce qu'il NE voit pas ============
reset role; select t.as(3);
select t.cnt('le propriétaire 3 voit ses trois réservations', $$select * from owner_bookings()$$, 3);
select t.eq('et aucune du logement de l''autre propriétaire',
  format($$select count(*)::text from owner_bookings() where property_id = %L$$, t.p(2)), '0');
select t.eq('AVANT paiement : le nom du voyageur est masqué',
  format($$select coalesce(guest_name, 'MASQUE') from owner_bookings() where id = %L$$, t.b(2)), 'MASQUE');
select t.eq('AVANT paiement : le téléphone est masqué',
  format($$select coalesce(guest_phone, 'MASQUE') from owner_bookings() where id = %L$$, t.b(2)), 'MASQUE');
select t.eq('AVANT paiement : le drapeau le dit explicitement',
  format($$select coordonnees_visibles::text from owner_bookings() where id = %L$$, t.b(2)), 'false');
select t.eq('APRÈS paiement : le nom apparaît',
  format($$select guest_name from owner_bookings() where id = %L$$, t.b(1)), 'Utilisateur 1');
select t.eq('APRÈS paiement : le téléphone apparaît',
  format($$select guest_phone from owner_bookings() where id = %L$$, t.b(1)), '70000001');
select t.eq('séjour terminé : les coordonnées restent visibles',
  format($$select coordonnees_visibles::text from owner_bookings() where id = %L$$, t.b(3)), 'true');
select t.eq('le propriétaire voit les dates et le montant même non payé',
  format($$select total_xof::text from owner_bookings() where id = %L$$, t.b(2)), '40000');
select t.eq('prochaine arrivée en tête chez le propriétaire aussi',
  format($$select (id = %L)::text from owner_bookings() limit 1$$, t.b(2)), 'true');

reset role; select t.as(4);
select t.cnt('le propriétaire 4 ne voit que la sienne', $$select * from owner_bookings()$$, 1);
reset role; select t.as(1);
select t.cnt('un voyageur n''est propriétaire de rien : liste vide', $$select * from owner_bookings()$$, 0);
reset role; select t.as(9);
select t.cnt('un membre d''équipe non propriétaire : liste vide aussi', $$select * from owner_bookings()$$, 0);

-- ============ Le signal : qui est prévenu, et de quoi ============
-- Les notifications ci-dessus ont été écrites par le déclencheur, au moment des insertions.
reset role;
-- Seule la réservation 1 est passée en « confirmée » ; la 3 a été créée déjà terminée
-- et la 2 attend encore son paiement. Le propriétaire 3 n'a donc qu'UN message.
select t.eq('le propriétaire 3 est prévenu de la seule confirmation qui le concerne',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee'$$, t.u(3)), '1');
select t.eq('le propriétaire 4 a été prévenu de la sienne',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee'$$, t.u(4)), '1');
select t.eq('l''équipe « reservations » est prévenue des deux confirmations',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(7)), '2');
select t.eq('l''équipe « paiements » aussi',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(8)), '2');
select t.eq('l''administrateur aussi, et une seule fois par réservation',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(5)), '2');
select t.eq('l''équipe « demandes » n''est pas dérangée',
  format($$select count(*)::text from notifications where user_id = %L$$, t.u(9)), '0');
select t.eq('rien n''est envoyé pour une réservation seulement en attente de paiement',
  format($$select count(*)::text from notifications where payload ->> 'reservation' = %L$$, t.b(2)::text), '0');
select t.eq('le message dit si le logement est sous gestion',
  format($$select payload ->> 'sous_gestion' from notifications where user_id = %L and payload ->> 'reservation' = %L$$,
         t.u(4), t.b(4)::text), 'true');
select t.eq('le message porte le titre du logement',
  format($$select payload ->> 'logement' from notifications where user_id = %L and payload ->> 'reservation' = %L$$,
         t.u(3), t.b(1)::text), 'Studio Visibilite');
select t.eq('l''équipe sait si elle a un geste à faire (sous gestion)',
  format($$select payload ->> 'a_traiter' from notifications where user_id = %L and payload ->> 'reservation' = %L$$,
         t.u(7), t.b(4)::text), 'true');
select t.eq('et qu''elle n''en a pas sur une simple annonce',
  format($$select payload ->> 'a_traiter' from notifications where user_id = %L and payload ->> 'reservation' = %L$$,
         t.u(7), t.b(1)::text), 'false');

-- Une annulation prévient aussi : les dates se libèrent, il faut que ça se sache.
reset role;
update bookings set status = 'annulee' where id = t.b(1);
select t.eq('une annulation prévient le propriétaire',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.annulee'$$, t.u(3)), '1');
select t.eq('une annulation prévient l''équipe',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.annulee.equipe'$$, t.u(7)), '1');
-- Le déclencheur ne doit pas se répéter si le statut est réécrit à l'identique.
update bookings set status = 'annulee' where id = t.b(1);
select t.eq('réécrire le même statut ne prévient pas deux fois',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.annulee'$$, t.u(3)), '1');
-- Une expiration de blocage ne dérange personne : ce n'est pas un événement commercial.
update bookings set status = 'expiree' where id = t.b(2);
select t.eq('une expiration de blocage ne prévient personne',
  format($$select count(*)::text from notifications where payload ->> 'reservation' = %L$$, t.b(2)::text), '0');

-- ============ Chacun ne lit que ses notifications ============
reset role; select t.as(3);
select t.eq('le propriétaire 3 lit ses propres notifications',
  $$select (count(*) > 0)::text from my_notifications()$$, 'true');
select t.eq('et aucune des autres',
  format($$select count(*)::text from my_notifications() n
            where exists (select 1 from notifications x where x.id = n.id and x.user_id <> %L)$$, t.u(3)), '0');
reset role; select t.as(9);
select t.cnt('l''équipe « demandes » n''a rien à lire', $$select * from my_notifications()$$, 0);
reset role; select t.as(3);
select t.eq('marquer comme lu renvoie un nombre et vide la liste des non lues',
  $$select (mark_notifications_read() > 0)::text$$, 'true');
select t.eq('et une seconde fois il n''y a plus rien à marquer',
  $$select mark_notifications_read()::text$$, '0');

-- Les fonctions internes restent fermées au navigateur.
reset role; select t.as(5);
select t.must_fail('admin : le déclencheur n''est pas appelable à la main', $$select notify_booking_change()$$);
select t.must_fail('admin : la table des notifications n''est pas modifiable librement',
  format($$insert into notifications (user_id, type) values (%L, 'faux')$$, t.u(1)));

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0011 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
