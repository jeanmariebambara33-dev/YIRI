#!/usr/bin/env bash
# Scénarios concurrents : plusieurs connexions SIMULTANÉES sur la base de test b6 (déjà préparée par 0006_functions.sql).
# Chaque session garde sa transaction ouverte ~1 s (pg_sleep) pour forcer le chevauchement réel avec les autres.
set -uo pipefail
Q="${PSQL_C:?}"
W="$(mktemp -d)"; fails=0
u() { printf '00000000-0000-0000-0000-%012d' "$1"; }
P3='aaaaaaaa-0000-0000-0000-000000000003'; P2='aaaaaaaa-0000-0000-0000-000000000002'
check() { if [ "$2" = "$3" ]; then echo "   OK   $1"; else echo "   ÉCHEC $1 (attendu $3, obtenu $2)"; fails=$((fails+1)); fi; }
session() { # $1 = n° utilisateur, $2 = requête, $3 = fichier de sortie, $4 = délai avant départ
  ( sleep "${4:-0}"; printf "select set_config('app.uid','%s',false); set role authenticated;\nbegin;\n%s\nselect pg_sleep(1);\ncommit;\n" "$(u "$1")" "$2" | $Q > "$3" 2>&1 ) &
}

# 1. Six voyageurs réservent EXACTEMENT les mêmes dates en même temps : une seule réservation doit exister.
for n in 9 10 11 12 13 16; do session "$n" "select 'OK:' || id from create_booking('$P3', current_date+320, current_date+322, 2);" "$W/book$n"; done
wait
ok=$(cat "$W"/book* | grep -c '^OK:' || true)
refused=$(cat "$W"/book* | grep -c 'ne sont plus disponibles' || true)
rows=$($Q -c "select count(*) from bookings where property_id='$P3' and stay && daterange(current_date+320, current_date+322) and status='en_attente_paiement'")
check "réservations simultanées : 1 seule acceptée" "$ok" 1
check "réservations simultanées : les 5 autres refusées proprement (« dates non disponibles »)" "$refused" 5
check "réservations simultanées : 1 seule ligne en base" "$rows" 1

# 2. Trois confirmations simultanées du même paiement : une seule doit passer.
B=bbbbbbbb-0000-0000-0000-000000000101
session 8 "select 'OK:' || id from confirm_payment('reservation','$B',100000);" "$W/c1"
session 5 "select 'OK:' || id from confirm_payment('reservation','$B',100000);" "$W/c2"
session 8 "select 'OK:' || id from confirm_payment('reservation','$B',100000);" "$W/c3" 0.2
wait
ok=$(cat "$W"/c? | grep -c '^OK:' || true)
check "confirmations simultanées : 1 seule acceptée" "$ok" 1
check "confirmations simultanées : 1 transaction réussie" "$($Q -c "select count(*) from payment_transactions where booking_id='$B' and status='reussi'")" 1
check "confirmations simultanées : 1 écriture au registre" "$($Q -c "select count(*) from financial_ledger where booking_id='$B'")" 1
check "confirmations simultanées : 1 ligne de journal" "$($Q -c "select count(*) from audit_logs where action='payment.confirmed' and entity_id='$B'")" 1
check "confirmations simultanées : réservation confirmée" "$($Q -c "select status from bookings where id='$B'")" confirmee

# 3. Cinq révélations simultanées du même contact par le même voyageur : une seule consultation comptée.
for i in 1 2 3 4 5; do session 11 "select 'OK:' || (reveal_contact('$P2') ->> 'phone');" "$W/r$i"; done
wait
check "révélations simultanées : toutes servies" "$(cat "$W"/r? | grep -c '^OK:' || true)" 5
check "révélations simultanées : 1 seule consultation comptée" "$($Q -c "select count(*) from contact_views where property_id='$P2' and viewer_id='$(u 11)'")" 1

# 4. La tâche d'expiration tourne PENDANT une confirmation en cours : la réservation confirmée ne doit pas être libérée.
B2=bbbbbbbb-0000-0000-0000-000000000102
session 8 "select 'OK:' || id from confirm_payment('reservation','$B2',60000);" "$W/x1"
( sleep 0.5; $Q -c "select 'EXP:' || expire_booking_holds()" > "$W/x2" 2>&1 ) &
wait
check "expiration pendant confirmation : confirmation réussie" "$(grep -c '^OK:' "$W/x1" || true)" 1
check "expiration pendant confirmation : la réservation reste confirmée" "$($Q -c "select status from bookings where id='$B2'")" confirmee
check "expiration pendant confirmation : la tâche d'expiration n'a pas été bloquée ni n'a rien libéré" "$(cat "$W/x2")" "EXP:0"

# 5. Montants INCORRECTS déclarés en rafale (6 connexions simultanées) : le blocage ne doit jamais être prolongé.
B3=bbbbbbbb-0000-0000-0000-000000000103
HOLD3=$($Q -c "select hold_expires_at from bookings where id='$B3'")
for a in 59999 60001 1 99999999 30000 59998; do session 1 "select 'OK:' || id from declare_payment('reservation','$B3',$a);" "$W/w$a"; done
wait
check "montants erronés simultanés : toutes les déclarations enregistrées sans erreur" "$(cat "$W"/w* | grep -c '^OK:' || true)" 6
check "montants erronés simultanés : un seul avis ouvert" "$($Q -c "select count(*) from payment_notices where booking_id='$B3'")" 1
check "montants erronés simultanés : blocage inchangé" "$($Q -c "select hold_expires_at from bookings where id='$B3'")" "$HOLD3"
check "montants erronés simultanés : compteur de prolongation = 0" "$($Q -c "select hold_extensions from bookings where id='$B3'")" 0
check "montants erronés simultanés : aucune prolongation au journal" "$($Q -c "select count(*) from audit_logs where action='booking.hold_extended' and entity_id='$B3'")" 0

# 6. Mélange simultané de bons et mauvais montants : au plus UNE prolongation, tracée, plafonnée.
B4=bbbbbbbb-0000-0000-0000-000000000104
for a in 59999 60000 1 60000 60001 60000; do session 2 "select 'OK:' || id from declare_payment('reservation','$B4',$a);" "$W/m${a}_$RANDOM"; done
wait
ext=$($Q -c "select hold_extensions from bookings where id='$B4'")
if [ "$ext" -le 1 ]; then echo "   OK   mélange simultané : au plus 1 prolongation (compteur = $ext)"; else echo "   ÉCHEC mélange simultané : compteur = $ext"; fails=$((fails+1)); fi
check "mélange simultané : prolongations tracées = compteur" "$($Q -c "select count(*) from audit_logs where action='booking.hold_extended' and entity_id='$B4'")" "$ext"
check "mélange simultané : blocage ≤ création + 2 h 15" "$($Q -c "select (hold_expires_at <= created_at + interval '2 hours 15 minutes')::text from bookings where id='$B4'")" true
check "mélange simultané : un seul avis ouvert" "$($Q -c "select count(*) from payment_notices where booking_id='$B4'")" 1

# 7. Bon montant déclaré 4 fois en rafale + 2 montants erronés juste après : exactement UNE prolongation.
B5=bbbbbbbb-0000-0000-0000-000000000105
for i in 1 2 3 4; do session 1 "select 'OK:' || id from declare_payment('reservation','$B5',60000);" "$W/g$i"; done
for a in 1 59999; do session 1 "select 'OK:' || id from declare_payment('reservation','$B5',$a);" "$W/h$a" 0.3; done
wait
check "bon montant en rafale : exactement 1 prolongation (compteur)" "$($Q -c "select hold_extensions from bookings where id='$B5'")" 1
check "bon montant en rafale : exactement 1 prolongation tracée" "$($Q -c "select count(*) from audit_logs where action='booking.hold_extended' and entity_id='$B5'")" 1
check "bon montant en rafale : blocage ≈ 2 h (pas plus de 2 h 15 après création)" "$($Q -c "select (hold_expires_at > now() + interval '100 minutes' and hold_expires_at <= created_at + interval '2 hours 15 minutes')::text from bookings where id='$B5'")" true
check "bon montant en rafale : la réservation n'est PAS confirmée" "$($Q -c "select status from bookings where id='$B5'")" en_attente_paiement

rm -rf "$W"
if [ "$fails" -eq 0 ]; then echo "   Scénarios concurrents : tous réussis"; else echo "   $fails scénario(s) concurrent(s) en échec"; exit 1; fi
