-- Tests de la migration 0008 (files d'attente de l'équipe). Base LOCALE ; auth.uid() simulé ; Storage simulé.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 8) n;
insert into user_roles (user_id, role) values (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values (t.u(6), 'validation', t.u(5)), (t.u(7), 'paiements', t.u(5));

-- deux candidats propriétaires : 1 (dossier complet) et 2 (dossier complet)
insert into properties (id, owner_id, offer, title, description, city, district, private_address, capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
select t.p(n), t.u(n), 'annonce', 'Brouillon ' || n, 'desc', 'Ouagadougou', 'Centre', 'a', 2, 1, 1, 10000, 1, 'brouillon', false from unnest(array[1, 2]) n;
create function t.up(n int, side text) returns text language sql as $$
  select format($q$insert into storage.objects (bucket_id, name) values ('owner-identity', %L)$q$, t.u(n) || '/' || side || '.jpg') $$;
grant execute on function t.up(int, text) to anon, authenticated;

reset role; select t.as(1);
select t.ok('1 : recto', t.up(1, 'recto')); select t.ok('1 : verso', t.up(1, 'verso'));
select t.ok('1 : demande', $$select submit_owner_identity('cnib', 'B1234567')$$);
reset role; select t.as(2);
select t.ok('2 : recto', t.up(2, 'recto')); select t.ok('2 : verso', t.up(2, 'verso'));
select t.ok('2 : demande', $$select submit_owner_identity('passeport', 'P9876543')$$);

-- ============ Accès ============
reset role; select t.as(0);
select t.must_fail('visiteur : file d''attente refusée', $$select * from identity_queue()$$);
select t.must_fail('visiteur : chemins des fichiers refusés', format($$select * from identity_file_paths(%L)$$, t.u(1)));
reset role; select t.as(1);
select t.must_fail('candidat : ne voit pas la file d''attente', $$select * from identity_queue()$$);
select t.must_fail('candidat : ne voit pas les chemins', format($$select * from identity_file_paths(%L)$$, t.u(1)));
reset role; select t.as(7);
select t.must_fail('équipe « paiements » : file d''attente refusée', $$select * from identity_queue()$$);
reset role; select t.as(3);
select t.must_fail('utilisateur quelconque : refusé', $$select * from identity_queue()$$);

-- ============ Contenu ============
reset role; select t.as(6);
select t.cnt('validation : voit les 2 dossiers en attente', $$select * from identity_queue()$$, 2);
select t.eq('validation : le plus ancien d''abord', $$select (array_agg(id_type order by submitted_at))[1] from identity_queue()$$, 'cnib');
select t.eq('validation : nom et adresse e-mail présents', format($$select full_name || '/' || email from identity_queue() where user_id = %L$$, t.u(1)), 'Utilisateur 1/u1@test.local');
select t.eq('validation : 2 fichiers comptés', format($$select files_sent::text from identity_queue() where user_id = %L$$, t.u(1)), '2');
select t.eq('la file d''attente ne contient AUCUN numéro de pièce',
  $$select count(*)::text from (select * from identity_queue()) q where q::text like '%1234567%' or q::text like '%9876543%'$$, '0');
select t.cnt('validation : chemins recto et verso listés', format($$select * from identity_file_paths(%L)$$, t.u(1)), 2);
select t.eq('les chemins restent dans le dossier du candidat', format($$select bool_and(path like %L) from identity_file_paths(%L)$$, t.u(1)::text || '/%', t.u(1)), 'true');

-- ============ La file suit les décisions ============
select t.ok('validation : ouvre le dossier 1', format($$select * from open_owner_identity(%L)$$, t.u(1)));
select t.ok('validation : accorde le rôle à 1', format($$select grant_owner_role(%L)$$, t.u(1)));
select t.cnt('le dossier traité quitte la file d''attente', $$select * from identity_queue()$$, 1);
select t.ok('validation : demande un renvoi pour 2', format($$select reject_owner_identity(%L, 'Photo illisible', true)$$, t.u(2)));
select t.cnt('un dossier « à renvoyer » reste visible dans la file', $$select * from identity_queue()$$, 1);
select t.eq('son état est bien « à renvoyer »', $$select state from identity_queue()$$, 'a_renvoyer');

-- ============ Droits sur les fonctions ============
reset role;
select t.eq('identity_queue et identity_file_paths ne sont pas exécutables par anon',
  $$select count(*)::text from pg_proc where proname in ('identity_queue','identity_file_paths') and has_function_privilege('anon', oid, 'execute')$$, '0');
select t.eq('les deux fonctions fixent leur search_path',
  $$select count(*)::text from pg_proc where proname in ('identity_queue','identity_file_paths') and prosecdef and proconfig is null$$, '0');

reset role;
\o
do $$ begin
  if exists (select 1 from t.results where not pass) then
    raise exception 'ÉCHECS : %', (select string_agg(label || ' [' || coalesce(detail,'') || ']', E'\n  ') from t.results where not pass);
  end if;
end $$;
select count(*) || ' tests de la migration 0008 réussis, 0 échec' from t.results;
