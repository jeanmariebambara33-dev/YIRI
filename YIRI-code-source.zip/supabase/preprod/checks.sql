-- YIRI — contrôles en LECTURE SEULE d'un projet Supabase après application des migrations 0001 à 0024.
-- La liste des RPC attendues s'adapte d'elle-même aux migrations réellement appliquées.
-- À coller dans l'éditeur SQL de Supabase (préproduction). Ne modifie rien. Chaque ligne : contrôle | obtenu | attendu | statut.
-- Statuts : OK, ÉCART (à corriger avant d'aller plus loin), MANUEL (ne peut pas se vérifier en SQL ou extension absente).
with
exec_fn as (  -- fonctions non-trigger du schéma public et qui peut les exécuter
  select p.proname,
         has_function_privilege('anon', p.oid, 'execute') as anon_ok,
         has_function_privilege('authenticated', p.oid, 'execute') as auth_ok,
         p.prosecdef, p.proconfig
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' and p.prorettype <> 'trigger'::regtype and p.prokind = 'f'
     and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e')   -- hors fonctions d'extensions (btree_gist...)
),
fn_sets as (  -- la liste attendue dépend des migrations appliquées : chaque palier ajoute ses RPC
  select
    array['has_any_perm','has_perm','has_role','is_staff','listing_transition_ok','public_booked_ranges']
    || (case when to_regclass('public.refund_rules') is null then array[]::text[]
             else array['refund_rules_public'] end)
    -- 0012 : normalize_phone ne lit aucune donnée, elle met un numéro en forme. Ouverte à tous.
    || (case when not exists (select 1 from information_schema.columns
                               where table_schema = 'public' and table_name = 'bookings'
                                 and column_name = 'guest_phone') then array[]::text[]
             else array['normalize_phone'] end)
    -- 0015 : la vitrine publique l'appelle pour un visiteur non connecté.
    || (case when to_regclass('public.owner_free_pass') is null then array[]::text[]
             else array['owner_has_free_pass'] end)
    -- 0016 : la vitrine publique l'appelle pour un visiteur non connecté.
    || (case when to_regprocedure('public.owner_can_publish(uuid)') is null then array[]::text[]
             else array['owner_can_publish'] end)
    -- 0017 : la clé publique des notifications doit être lisible AVANT toute connexion,
    -- sinon un visiteur qui vient de s'inscrire ne pourrait pas activer ses alertes.
    || (case when to_regclass('public.public_settings') is null then array[]::text[]
             else array['push_public_key'] end) as anon,
    array['confirm_payment','create_booking','declare_payment','grant_owner_role','listing_publish_problem',
          'reject_payment','request_owner_role','reveal_contact','set_listing_status']
    || (case when to_regclass('public.owner_identity') is null then array[]::text[]
             else array['confirm_identity_files_deleted','identity_access_recent','identity_delete_allowed',
                        'identity_file_paths','identity_files_pending','identity_pending','identity_queue',
                        'identity_upload_open','my_owner_identity','open_owner_identity','reject_owner_identity',
                        'submit_owner_identity'] end)
    || (case when to_regclass('public.payment_attempts') is null then array[]::text[]
             else array['payment_attempts_recent','start_online_payment'] end)
    || (case when to_regclass('public.refund_rules') is null then array[]::text[]
             else array['approve_refund','cancel_my_booking','my_refunds',
                        'refunds_queue','set_refund_rules']
                  -- refund_quote reste ouverte au voyageur tant que 0019 n'est pas appliquée.
                  || (case when to_regprocedure('public.create_refund(uuid,integer,text)') is null
                           then array['refund_quote'] else array[]::text[] end) end)
    -- 0011 se reconnaît à la colonne de date ajoutée aux notifications : un repère de SCHÉMA,
    -- et non la présence des fonctions elles-mêmes, sinon le contrôle se validerait tout seul.
    || (case when not exists (select 1 from information_schema.columns
                               where table_schema = 'public' and table_name = 'notifications'
                                 and column_name = 'created_at') then array[]::text[]
             else array['bookings_queue','mark_notifications_read','my_notifications',
                        'owner_bookings'] end)
    -- 0014 se reconnaît à la colonne « offert » des abonnements : un repère de SCHÉMA,
    -- et non la présence des fonctions elles-mêmes, sinon le contrôle se validerait tout seul.
    || (case when not exists (select 1 from information_schema.columns
                               where table_schema = 'public' and table_name = 'subscriptions'
                                 and column_name = 'offert') then array[]::text[]
             else array['set_management_agreement','subscriptions_queue'] end)
    -- 0016 : l'abonnement passe au profil. subscribe_property, grant_subscription et
    -- my_subscriptions sont retirées, remplacées par celles-ci.
    || (case when to_regprocedure('public.owner_can_publish(uuid)') is null then array[]::text[]
             else array['my_listing_counts','my_subscription','subscribe_owner'] end)
    -- 0015 se reconnaît à la table des accès offerts.
    || (case when to_regclass('public.owner_free_pass') is null then array[]::text[]
             else array['free_passes_queue','grant_owner_pass','my_free_pass',
                        'revoke_owner_pass'] end)
    -- 0017 se reconnaît à la table des appareils enregistrés. push_pending, push_mark_sent et
    -- push_mark_failed ne sont PAS dans cette liste : elles sont fermées au navigateur, et
    -- leur apparition ici serait une alerte, pas un oubli.
    || (case when to_regclass('public.push_subscriptions') is null then array[]::text[]
             else array['my_push_devices','register_push','unregister_push'] end)
    -- 0019 : le remboursement passe par l'équipe. refund_quote DISPARAÎT de cette liste — le
    -- voyageur ne doit plus pouvoir l'appeler — et deux outils d'équipe la rejoignent.
    || (case when to_regprocedure('public.create_refund(uuid,integer,text)') is null then array[]::text[]
             else array['cancellations_to_review','create_refund'] end)
    -- 0022 : les relevés de revenus. Le propriétaire LIT les siens, l'équipe clôture et verse ;
    -- les deux passent par ces fonctions, jamais par la table.
    || (case when to_regprocedure('public.close_owner_statement(uuid,date,date,integer,integer)') is null then array[]::text[]
             else array['my_statements','statements_queue','owners_to_settle','statement_preview',
                        'close_owner_statement','register_payout'] end)
    -- 0023 : les réclamations.
    || (case when to_regprocedure('public.open_support_request(text,text,uuid,uuid)') is null then array[]::text[]
             else array['my_support_requests','open_support_request','support_queue',
                        'set_support_status'] end) as auth
    -- 0020 : les courriels. AUCUNE fonction ne rejoint cette liste, volontairement :
    -- email_pending, email_mark_sent, email_mark_failed et _email_eligible sont réservées au
    -- serveur. Le contrôle 4 vérifie qu'elles restent fermées ; les voir ici serait une alerte.
),
attendu_fn as (
  select s.anon as anon_arr,
         (select string_agg(distinct x, ', ' order by x) from unnest(s.anon) x) as anon_txt,
         (select string_agg(distinct x, ', ' order by x) from unnest(s.auth) x where x <> all (s.anon)) as auth_txt
    from fn_sets s
)
select 1 as n, 'extension btree_gist installée' as controle,
       (select count(*)::text from pg_extension where extname = 'btree_gist') as obtenu, '1' as attendu,
       case when (select count(*) from pg_extension where extname = 'btree_gist') = 1 then 'OK' else 'ÉCART' end as statut
union all select 2, 'tables du schéma public SANS sécurité par ligne',
       (select coalesce(string_agg(c.relname, ', '), 'aucune') from pg_class c join pg_namespace n on n.oid = c.relnamespace
         where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity), 'aucune',
       case when exists (select 1 from pg_class c join pg_namespace n on n.oid = c.relnamespace
         where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity) then 'ÉCART' else 'OK' end
union all select 3, 'fonctions exécutables par « anon » (hors déclencheurs)',
       (select coalesce(string_agg(distinct proname, ', ' order by proname), 'aucune') from exec_fn where anon_ok),
       (select anon_txt from attendu_fn),
       case when (select coalesce(string_agg(distinct proname, ', ' order by proname), '') from exec_fn where anon_ok)
                 = (select anon_txt from attendu_fn) then 'OK' else 'ÉCART' end
union all select 4, 'fonctions exécutables par « authenticated » en plus des aides ci-dessus (les RPC attendues)',
       (select coalesce(string_agg(distinct proname, ', ' order by proname), 'aucune') from exec_fn
         where auth_ok and proname::text <> all (select x from attendu_fn, unnest(anon_arr) x)),
       (select auth_txt from attendu_fn),
       case when (select coalesce(string_agg(distinct proname, ', ' order by proname), '') from exec_fn
                   where auth_ok and proname::text <> all (select x from attendu_fn, unnest(anon_arr) x))
                 = (select auth_txt from attendu_fn) then 'OK' else 'ÉCART' end
union all select 5, 'fonctions SECURITY DEFINER sans search_path fixé',
       (select coalesce(string_agg(proname, ', '), 'aucune') from exec_fn where prosecdef and proconfig is null), 'aucune',
       case when exists (select 1 from exec_fn where prosecdef and proconfig is null) then 'ÉCART' else 'OK' end
union all select 6, 'vues lisibles par « anon » (hors schémas système)',
       (select coalesce(string_agg(table_name, ', ' order by table_name), 'aucune') from information_schema.role_table_grants
         where grantee = 'anon' and table_schema = 'public' and privilege_type = 'SELECT'
           and table_name in (select viewname from pg_views where schemaname = 'public')),
       'public_listing_photos, public_listings',
       case when (select coalesce(string_agg(table_name, ', ' order by table_name), '') from information_schema.role_table_grants
         where grantee = 'anon' and table_schema = 'public' and privilege_type = 'SELECT'
           and table_name in (select viewname from pg_views where schemaname = 'public')) = 'public_listing_photos, public_listings' then 'OK' else 'ÉCART' end
union all select 7, 'déclencheur de création de profil sur auth.users',
       (select count(*)::text from pg_trigger t where t.tgrelid = to_regclass('auth.users') and t.tgname = 'on_auth_user_created' and not t.tgisinternal),
       '1',
       case when (select count(*) from pg_trigger t where t.tgrelid = to_regclass('auth.users') and t.tgname = 'on_auth_user_created' and not t.tgisinternal) = 1 then 'OK' else 'ÉCART' end
union all select 8, 'bucket « property-photos » privé, 5 Mo, jpeg/png/webp',
       coalesce((select 'public=' || public || ', limite=' || coalesce(file_size_limit::text, 'aucune') || ', types=' || coalesce(array_to_string(allowed_mime_types, '/'), 'tous')
                   from storage.buckets where id = 'property-photos'), 'absent'),
       'public=false, limite=5242880, types=image/jpeg/image/png/image/webp',
       case when exists (select 1 from storage.buckets where id = 'property-photos' and not public and file_size_limit = 5242880
                           and allowed_mime_types @> array['image/jpeg','image/png','image/webp'] and cardinality(allowed_mime_types) = 3)
            then 'OK' else 'ÉCART' end
union all select 9, 'règles de stockage YIRI sur storage.objects',
       (select count(*)::text from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname like 'yiri_photos_%'), '6',
       case when (select count(*) from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname like 'yiri_photos_%') = 6 then 'OK' else 'ÉCART' end
union all select 10, 'extension pg_cron + tâche d''expiration des blocages (chaque minute)',
       case when to_regnamespace('cron') is null then 'pg_cron absent'
            else coalesce((xpath('/row/c/text()', query_to_xml('select schedule || '' / actif='' || active as c from cron.job where jobname = ''yiri-expire-holds''', false, true, '')))[1]::text, 'tâche absente') end,
       '* * * * * / actif=true',
       case when to_regnamespace('cron') is null then 'MANUEL'
            when (xpath('/row/c/text()', query_to_xml('select schedule || '' / actif='' || active as c from cron.job where jobname = ''yiri-expire-holds''', false, true, '')))[1]::text = '* * * * * / actif=true' then 'OK'
            else 'ÉCART' end
union all select 11, 'aucune donnée de démonstration ni compte de test (annonces is_demo, adresses @test.local, schéma de tests « t »)',
       (select (select count(*) from properties where is_demo)::text || ' démo / '
               || (select count(*) from auth.users where email like '%@test.local')::text || ' comptes test / schéma t: '
               || (select count(*) from pg_namespace where nspname = 't')::text),
       '0 démo / 0 comptes test / schéma t: 0',
       case when (select count(*) from properties where is_demo) = 0 and (select count(*) from auth.users where email like '%@test.local') = 0
                 and not exists (select 1 from pg_namespace where nspname = 't') then 'OK' else 'ÉCART' end
union all select 12, 'au moins un administrateur créé (par SQL, jamais depuis l''application)',
       (select count(*)::text from user_roles where role = 'admin'), '≥ 1',
       case when (select count(*) from user_roles where role = 'admin') >= 1 then 'OK' else 'MANUEL' end
union all select 13, 'inscriptions anonymes, e-mail confirmé, SMTP, URLs de redirection (réglages Auth)', 'non lisible en SQL', 'voir PREPROD.md §3', 'MANUEL'
union all select 14, 'bucket « owner-identity » privé, 5 Mo, jpeg/png/webp (si 0007 appliquée)',
       case when to_regclass('public.owner_identity') is null then '0007 non appliquée'
            else coalesce((select 'public=' || public || ', limite=' || coalesce(file_size_limit::text, 'aucune') || ', types=' || coalesce(array_to_string(allowed_mime_types, '/'), 'tous')
                             from storage.buckets where id = 'owner-identity'), 'absent') end,
       'public=false, limite=5242880, types=image/jpeg/image/png/image/webp',
       case when to_regclass('public.owner_identity') is null then 'MANUEL'
            when exists (select 1 from storage.buckets where id = 'owner-identity' and not public and file_size_limit = 5242880
                           and allowed_mime_types @> array['image/jpeg','image/png','image/webp'] and cardinality(allowed_mime_types) = 3)
            then 'OK' else 'ÉCART' end
union all select 15, 'règles de stockage des pièces d''identité (si 0007 appliquée)',
       case when to_regclass('public.owner_identity') is null then '0007 non appliquée'
            else (select count(*)::text from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname like 'yiri_identity_%') end,
       '6',
       case when to_regclass('public.owner_identity') is null then 'MANUEL'
            when (select count(*) from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname like 'yiri_identity_%') = 6 then 'OK' else 'ÉCART' end
union all select 16, 'dossiers d''identité décidés dont les images ne sont pas encore supprimées (si 0007 appliquée)',
       case when to_regclass('public.owner_identity') is null then '0007 non appliquée'
            else (select count(*)::text from owner_identity i where i.state in ('verifie','refuse') and identity_files_left(i.user_id) > 0) end,
       '0',
       case when to_regclass('public.owner_identity') is null then 'MANUEL'
            when (select count(*) from owner_identity i where i.state in ('verifie','refuse') and identity_files_left(i.user_id) > 0) = 0 then 'OK' else 'À EXAMINER' end
union all select 17, 'déclencheur qui prévient d''une réservation confirmée ou annulée (si 0011 appliquée)',
       case when not exists (select 1 from information_schema.columns
                              where table_schema = 'public' and table_name = 'notifications' and column_name = 'created_at')
            then '0011 non appliquée'
            else (select count(*)::text from pg_trigger
                   where tgrelid = to_regclass('public.bookings') and tgname = 'bookings_notify' and not tgisinternal) end,
       '1',
       case when not exists (select 1 from information_schema.columns
                              where table_schema = 'public' and table_name = 'notifications' and column_name = 'created_at')
            then 'MANUEL'
            when (select count(*) from pg_trigger
                   where tgrelid = to_regclass('public.bookings') and tgname = 'bookings_notify' and not tgisinternal) = 1
            then 'OK' else 'ÉCART' end
union all select 18, 'ancienne réservation sans téléphone encore possible (à retirer après le redéploiement du site)',
       case when to_regprocedure('public.create_booking(uuid,date,date,int)') is null
            then 'retirée' else 'encore ouverte' end,
       'retirée',
       case when to_regprocedure('public.create_booking(uuid,date,date,int)') is null then 'OK' else 'MANUEL' end
union all select 19, 'réservations payées sans aucun numéro de téléphone (impossible à joindre)',
       case when not exists (select 1 from information_schema.columns
                              where table_schema = 'public' and table_name = 'bookings' and column_name = 'guest_phone')
            then '0012 non appliquée'
            else (select count(*)::text from bookings b
                   left join profiles pr on pr.id = b.guest_id
                  where b.status in ('confirmee','en_cours')
                    and coalesce(b.guest_phone, pr.phone) is null) end,
       '0',
       case when not exists (select 1 from information_schema.columns
                              where table_schema = 'public' and table_name = 'bookings' and column_name = 'guest_phone')
            then 'MANUEL'
            when (select count(*) from bookings b
                   left join profiles pr on pr.id = b.guest_id
                  where b.status in ('confirmee','en_cours')
                    and coalesce(b.guest_phone, pr.phone) is null) = 0 then 'OK' else 'À EXAMINER' end
union all select 20, 'tâche planifiée des abonnements (relances et expiration, une fois par jour)',
       case when to_regnamespace('cron') is null then 'pg_cron absent'
            else coalesce((xpath('/row/c/text()', query_to_xml('select schedule || '' / actif='' || active as c from cron.job where jobname = ''yiri-abonnements''', false, true, '')))[1]::text, 'tâche absente') end,
       '5 2 * * * / actif=true',
       case when to_regnamespace('cron') is null then 'MANUEL'
            when (xpath('/row/c/text()', query_to_xml('select schedule || '' / actif='' || active as c from cron.job where jobname = ''yiri-abonnements''', false, true, '')))[1]::text = '5 2 * * * / actif=true' then 'OK'
            else 'ÉCART' end
union all select 21, 'annonces de l''offre YIRI Annonce affichées « en ligne » sans abonnement actif (l''écran mentirait)',
       case when not exists (select 1 from information_schema.columns
                              where table_schema = 'public' and table_name = 'subscriptions' and column_name = 'offert')
            then '0014 non appliquée'
            else (select count(*)::text from properties p
                   where p.offer = 'annonce' and p.status = 'publiee'
                     and not exists (select 1 from subscriptions s
                                      where s.property_id = p.id and s.status = 'actif'
                                        and s.starts_at <= current_date and s.ends_at > current_date)) end,
       '0',
       case when not exists (select 1 from information_schema.columns
                              where table_schema = 'public' and table_name = 'subscriptions' and column_name = 'offert')
            then 'MANUEL'
            when (select count(*) from properties p
                   where p.offer = 'annonce' and p.status = 'publiee'
                     and not exists (select 1 from subscriptions s
                                      where s.property_id = p.id and s.status = 'actif'
                                        and s.starts_at <= current_date and s.ends_at > current_date)) = 0
            then 'OK' else 'À EXAMINER' end
-- 0017 : les trois fonctions d'envoi sont fermées au navigateur. Le contrôle 4 vérifie qu'elles
-- ne figurent pas dans la liste autorisée ; celui-ci le vérifie DIRECTEMENT sur les droits, parce
-- qu'une erreur ici donnerait au premier visiteur venu les clés de chiffrement de tous les
-- appareils enregistrés.
union all select 22, 'fonctions d''envoi des notifications accessibles depuis un navigateur (ne doit jamais arriver)',
       case when to_regclass('public.push_subscriptions') is null then '0017 non appliquée'
            else (select coalesce(string_agg(p.proname, ', '), 'aucune')
                    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                   where n.nspname = 'public'
                     and p.proname in ('push_pending', 'push_mark_sent', 'push_mark_failed',
                                       '_push_destinataire_legitime', 'push_declencher',
                                       'push_declencher_manuel', 'push_relancer')
                     and (has_function_privilege('anon', p.oid, 'execute')
                          or has_function_privilege('authenticated', p.oid, 'execute'))) end,
       'aucune',
       case when to_regclass('public.push_subscriptions') is null then 'MANUEL'
            when not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                              where n.nspname = 'public'
                                and p.proname in ('push_pending', 'push_mark_sent', 'push_mark_failed',
                                                  '_push_destinataire_legitime', 'push_declencher',
                                                  'push_declencher_manuel', 'push_relancer')
                                and (has_function_privilege('anon', p.oid, 'execute')
                                     or has_function_privilege('authenticated', p.oid, 'execute')))
            then 'OK' else 'ÉCART' end

-- Les réglages publics sont lisibles par le monde entier : une clé privée rangée là par
-- commodité serait publiée. Ce contrôle existe pour que cette erreur ne passe pas inaperçue.
union all select 23, 'réglage public qui ressemble à un secret (la table est lisible par tous)',
       case when to_regclass('public.public_settings') is null then '0017 non appliquée'
            else (select coalesce(string_agg(key, ', '), 'aucun') from public_settings
                   where key ~* '(priv|secret|token|jeton|mot_de_passe|password|sk_)'
                      or value ~* '(BEGIN [A-Z ]*PRIVATE|^sk_|^whsec_)'
                      or (key <> 'push_vapid_public' and length(value) > 200)) end,
       'aucun',
       case when to_regclass('public.public_settings') is null then 'MANUEL'
            when not exists (select 1 from public_settings
                              where key ~* '(priv|secret|token|jeton|mot_de_passe|password|sk_)'
                                 or value ~* '(BEGIN [A-Z ]*PRIVATE|^sk_|^whsec_)'
                                 or (key <> 'push_vapid_public' and length(value) > 200))
            then 'OK' else 'ÉCART' end

-- Un appareil enregistré pour un compte qui n'existe plus ne recevra jamais rien : c'est du
-- bruit dans la table, pas un danger. Mais un nombre qui grimpe signale un problème ailleurs.
union all select 24, 'appareils enregistrés dont le compte a disparu',
       case when to_regclass('public.push_subscriptions') is null then '0017 non appliquée'
            else (select count(*)::text from push_subscriptions s
                   where not exists (select 1 from profiles pr where pr.id = s.user_id)) end,
       '0',
       case when to_regclass('public.push_subscriptions') is null then 'MANUEL'
            when (select count(*) from push_subscriptions s
                   where not exists (select 1 from profiles pr where pr.id = s.user_id)) = 0
            then 'OK' else 'À EXAMINER' end
-- 0018 : le déclencheur existe-t-il vraiment ? Sans lui, les notifications s'écrivent et ne
-- partent jamais — exactement la situation d'avant, mais en silence.
union all select 25, 'déclencheur d''envoi des notifications posé (0018)',
       case when to_regprocedure('public.push_declencher()') is null then '0018 non appliquée'
            else (select count(*)::text from pg_trigger
                   where tgname = 'notifications_push' and not tgisinternal) end,
       '1',
       case when to_regprocedure('public.push_declencher()') is null then 'MANUEL'
            when (select count(*) from pg_trigger where tgname = 'notifications_push' and not tgisinternal) = 1
            then 'OK' else 'ÉCART' end

-- Le mot de passe du déclencheur vit dans le coffre (Vault). On ne le contrôle PAS ici : une
-- requête sur vault.decrypted_secrets est résolue à l'analyse, même dans une branche non prise,
-- ce qui ferait échouer tout ce fichier sur une base sans coffre. Pour le vérifier, appeler
-- push_declencher_manuel() : elle dit en clair s'il manque, sans jamais afficher sa valeur.
-- 0022 et 0023 : les fonctions internes de calcul restent fermées au navigateur. _owner_periode
-- décide de l'argent qui part ; l'exposer laisserait lire les revenus de tous les propriétaires.
union all select 26, 'fonctions internes des relevés et signalements accessibles depuis un navigateur (ne doit jamais arriver)',
       case when to_regprocedure('public.close_owner_statement(uuid,date,date,integer,integer)') is null then '0022 non appliquée'
            else (select coalesce(string_agg(p.proname, ', '), 'aucune')
                    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                   where n.nspname = 'public' and p.proname in ('_owner_periode')
                     and (has_function_privilege('anon', p.oid, 'execute')
                          or has_function_privilege('authenticated', p.oid, 'execute'))) end,
       'aucune',
       case when to_regprocedure('public.close_owner_statement(uuid,date,date,integer,integer)') is null then 'MANUEL'
            when not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                              where n.nspname = 'public' and p.proname in ('_owner_periode')
                                and (has_function_privilege('anon', p.oid, 'execute')
                                     or has_function_privilege('authenticated', p.oid, 'execute')))
            then 'OK' else 'ÉCART' end

-- 0020 : les quatre fonctions de courriel restent fermées au navigateur. Elles lisent les
-- adresses de TOUS les destinataires d'une notification : ouvertes, elles donneraient le carnet
-- d'adresses complet de YIRI à n'importe quel compte connecté.
union all select 30, 'fonctions de courriel accessibles depuis un navigateur (ne doit jamais arriver)',
       case when to_regprocedure('public.email_pending(integer)') is null then '0020 non appliquée'
            else (select coalesce(string_agg(p.proname, ', '), 'aucune')
                    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                   where n.nspname = 'public'
                     and p.proname in ('email_pending','email_mark_sent','email_mark_failed','_email_eligible')
                     and (has_function_privilege('anon', p.oid, 'execute')
                          or has_function_privilege('authenticated', p.oid, 'execute'))) end,
       'aucune',
       case when to_regprocedure('public.email_pending(integer)') is null then 'MANUEL'
            when not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                              where n.nspname = 'public'
                                and p.proname in ('email_pending','email_mark_sent','email_mark_failed','_email_eligible')
                                and (has_function_privilege('anon', p.oid, 'execute')
                                     or has_function_privilege('authenticated', p.oid, 'execute')))
            then 'OK' else 'ÉCART' end

-- 0024 : la file des remboursements porte bien le motif d'échec. Sans cette colonne, l'équipe
-- voit « échoué » sans jamais savoir pourquoi.
union all select 31, 'la file des remboursements renvoie le motif d''échec (0024)',
       case when to_regprocedure('public.refunds_queue(integer)') is null then 'fonction absente'
            when exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                          where n.nspname = 'public' and p.proname = 'refunds_queue'
                            and 'failure_reason' = any (p.proargnames)) then 'oui' else 'non' end,
       'oui',
       case when to_regprocedure('public.refunds_queue(integer)') is null then 'ÉCART'
            when exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                          where n.nspname = 'public' and p.proname = 'refunds_queue'
                            and 'failure_reason' = any (p.proargnames)) then 'OK' else 'ÉCART' end

-- La règle qui protège l'argent du propriétaire : la somme des deux parts égale TOUJOURS le
-- revenu partageable. La contrainte de la table l'impose, ce contrôle le constate sur les données.
union all select 27, 'relevés dont la part et la commission ne totalisent pas le revenu partageable',
       case when to_regclass('public.owner_statements') is null then 'table absente'
            else (select count(*)::text from owner_statements
                   where owner_share_xof + yiri_commission_xof <> rlp_xof) end,
       '0',
       case when to_regclass('public.owner_statements') is null then 'MANUEL'
            when (select count(*) from owner_statements
                   where owner_share_xof + yiri_commission_xof <> rlp_xof) = 0
            then 'OK' else 'ÉCART' end

-- Un versement supérieur à ce qui était dû signalerait une erreur de saisie ou pire.
union all select 28, 'relevés versés au-delà du montant dû',
       case when to_regclass('public.owner_statements') is null then 'table absente'
            else (select count(*)::text from owner_statements where amount_paid_xof > amount_due_xof) end,
       '0',
       case when to_regclass('public.owner_statements') is null then 'MANUEL'
            when (select count(*) from owner_statements where amount_paid_xof > amount_due_xof) = 0
            then 'OK' else 'À EXAMINER' end

-- Un signalement ouvert depuis plus de trois jours : personne ne l'a traité.
union all select 29, 'signalements ouverts depuis plus de 3 jours',
       case when to_regprocedure('public.open_support_request(text,text,uuid,uuid)') is null then '0023 non appliquée'
            else (select count(*)::text from support_requests
                   where status in ('ouvert', 'en_cours') and created_at < now() - interval '3 days') end,
       '0',
       case when to_regprocedure('public.open_support_request(text,text,uuid,uuid)') is null then 'MANUEL'
            when (select count(*) from support_requests
                   where status in ('ouvert', 'en_cours') and created_at < now() - interval '3 days') = 0
            then 'OK' else 'À EXAMINER' end
order by n;
