# Fonctions serveur YIRI (paiement en ligne)

Deux fonctions. Elles tournent **sur Supabase**, jamais dans le navigateur. C'est pour ça que
la clé secrète du prestataire peut y vivre sans risque : elle ne descend jamais chez le visiteur.

| Fonction | Qui l'appelle | Rôle |
|---|---|---|
| `paiement-demarrer` | l'application, avec le jeton de la personne connectée | la base fixe le montant, puis crée la page de paiement |
| `paiement-webhook` | le prestataire, sans jeton | vérifie la signature, redemande le vrai statut, puis confirme |

La vérification de signature est testée par
`node --experimental-strip-types supabase/functions/tests/signature.test.mjs` (23 contrôles), directement sur le fichier déployé.

## 1. Les secrets, que tu colles toi-même

Ne me les envoie jamais. Dans Supabase → **Edge Functions** → **Secrets**, ajoute :

| Nom | Où le trouver |
|---|---|
| `SASPAY_SECRET_KEY` | tableau de bord du prestataire → Développeurs → clé `sk_test_…` puis `sk_live_…` |
| `SASPAY_WEBHOOK_SECRET` | affiché **une seule fois** à la création du point de réception. À copier immédiatement ; sinon il faut le régénérer. |
| `SITE_URL` | `https://yiri-plum.vercel.app` |

`SUPABASE_URL`, `SUPABASE_ANON_KEY` et `SUPABASE_SERVICE_ROLE_KEY` sont fournies
automatiquement par Supabase : il n'y a rien à saisir.

## 2. Déploiement

```
supabase link --project-ref kzzrowymwwxoydklnkfb
supabase functions deploy paiement-demarrer
supabase functions deploy paiement-webhook --no-verify-jwt
```

`--no-verify-jwt` est **indispensable** sur le webhook : le prestataire n'a pas de compte
chez nous, donc aucun jeton à présenter. Sa seule preuve d'identité est la signature,
et elle est vérifiée avant toute lecture du contenu.

## 3. Le point de réception, côté prestataire

Adresse à déclarer dans son tableau de bord :

```
https://kzzrowymwwxoydklnkfb.supabase.co/functions/v1/paiement-webhook
```

Événements à souscrire : `transaction.success`, `transaction.failed`, `transaction.cancelled`.

Puis envoyer le message de test depuis son tableau de bord : la réponse attendue est
`{"ok":true,"resultat":"test_recu"}`. Si c'est `403`, le secret de signature ne correspond pas.

## 4. Ce qui protège l'argent

1. **Le navigateur n'envoie aucun montant.** Il dit « je paie cette réservation » ; la base
   recalcule le prix. Un navigateur modifié ne peut pas payer 100 FCFA une réservation de 60 000.
2. **Signature avant tout.** Texte signé : `horodatage + "." + corps brut`, HMAC-SHA256.
   L'horodatage est dans la signature, donc on ne peut pas le changer pour rejouer un vieux message.
   Tolérance 5 minutes. Comparaison à durée constante.
3. **On ne croit pas le message sur parole.** Même signé, il est suivi d'une question directe au
   prestataire (`GET /payments/{id}/verify/`). Seule sa réponse fait foi.
4. **La base refuse tout écart.** Un montant différent de celui qu'elle a calculé n'encaisse rien,
   et l'incident reste tracé.
5. **Cinq fois le même message n'encaisse qu'une fois.** Le prestataire réessaie jusqu'à 5 fois
   (immédiat, 30 s, 5 min, 30 min, 2 h) ; les index d'unicité et les clés d'idempotence s'en chargent.
6. **La confirmation est fermée au navigateur.** `confirm_payment_online` refuse `authenticated`
   et `anon` : même connecté en administrateur, personne ne peut confirmer un paiement depuis le site.

## 5. Les frais : deux modes, deux traitements

Le prestataire annonce `fee_charge_mode` :

- **`DEDUCTED`** — il retient ses frais sur la somme encaissée. YIRI reçoit moins que le prix
  affiché, donc les frais sont retenus sur un éventuel remboursement.
- **`ADD_ON`** — il ajoute ses frais par-dessus. Le voyageur les a déjà payés séparément et YIRI
  a reçu la totalité. Les retenir une seconde fois sur le remboursement les lui ferait payer deux
  fois : on enregistre donc 0.

C'est `record_payment_fee()` qui applique cette distinction, et `refund_quote()` qui s'en sert.
`refund_quote()` n'est plus accessible au voyageur depuis la migration 0019 : elle sert à l'équipe
pour connaître le montant de référence, pas à promettre une somme dans le navigateur.

## 6. Ce qui n'est PAS encore écrit, et pourquoi

Le **versement du remboursement**. Le prestataire ne documente pas d'opération de remboursement :
il faudrait passer par son API de versement (`POST /payouts/initialize/`), qui **exige une adresse
IP autorisée**. Les fonctions Supabase n'ont pas d'adresse IP de sortie fixe. Tant que ce point
n'est pas levé, l'envoi automatique de l'argent ne peut pas être fiable, et il vaut mieux ne pas
l'écrire que l'écrire à moitié.

Depuis la migration 0019, l'annulation ne crée PLUS de remboursement. `cancel_my_booking`
libère les dates, inscrit le barème au journal, prévient l'équipe (`refund.a_examiner.equipe`)
et renvoie `sans_remboursement_auto`. C'est ensuite l'équipe habilitée « paiements » qui décide,
avec `create_refund(reservation, montant, motif)`, puis `approve_refund()`.

Le parcours complet est donc :

1. Le voyageur annule — aucune somme n'est engagée
2. L'équipe voit la demande dans `cancellations_to_review()`
3. Elle crée le remboursement au montant qu'elle juge dû
4. Elle l'approuve
5. **Elle envoie l'argent à la main**, depuis le tableau de bord du prestataire, en se servant
   de la file `refunds_queue()`

Seule l'étape 5 est manuelle, et pour la raison ci-dessus. Les quatre premières sont en base.
