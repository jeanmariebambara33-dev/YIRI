// Contact du propriétaire (YIRI Annonce). Numéros du Burkina Faso : 8 chiffres, indicatif +226.

export interface Contact {
  name: string;
  phone: string; // tel que saisi par le propriétaire
  whatsapp: boolean; // le numéro est aussi sur WhatsApp
}

export function phoneDigits(phone: string): string {
  return phone.replace(/\D/g, "");
}

export function isValidPhone(phone: string): boolean {
  if (!/^[+\d][\d\s().-]*$/.test(phone.trim())) return false;
  const d = phoneDigits(phone);
  return d.length >= 8 && d.length <= 13;
}

/** Numéro au format international sans « + », pour un lien WhatsApp. */
export function waNumber(phone: string): string {
  let d = phoneDigits(phone);
  if (d.startsWith("00")) d = d.slice(2);
  if (d.length === 8) d = "226" + d;
  return d;
}
