-- Tests du déclencheur d'envoi (migration 0018).
--
-- pg_net et le coffre de Supabase n'existent pas sur une base locale : on les IMITE, exactement
-- comme le prestataire de paiement est imité ailleurs. Ce qui est éprouvé ici est la LOGIQUE du
-- déclencheur — quand il part, quand il se tait, et surtout qu'il ne fasse jamais échouer ce qui
-- l'a provoqué. Le vrai appel réseau, lui, ne peut être prouvé que sur le projet en ligne.
\o /dev/null
\ir helpers.sql

-- ---- Imitation du coffre et de pg_net ----
create schema if not exists vault;
create table vault.decrypted_secrets (name text primary key, decrypted_secret text);

create table t.appels (id serial, url text, entetes jsonb, quand timestamptz default clock_timestamp());
create schema if not exists net;
create function net.http_post(url text, body jsonb default '{}', params jsonb default '{}',
                              headers jsonb default '{}', timeout_milliseconds int default 5000)
returns bigint language plpgsql as $$
begin
  if current_setting('t.casser', true) = 'oui' then
    raise exception 'service de notification injoignable';
  end if;
  insert into t.appels (url, entetes) values (url, headers);
  return 1;
end $$;

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 5) n;
insert into user_roles (user_id, role) values (t.u(5), 'admin');

-- ============ Sans mot de passe dans le coffre : silence, pas d'erreur ============
reset role;
select t.ok('une notification s''écrit même si rien n''est configuré',
  $$insert into notifications (user_id, type, payload) values (t.u(1), 'booking.confirmee', '{}')$$);
select t.eq('et aucun appel n''est tenté', $$select count(*)::text from t.appels$$, '0');

-- ============ Configuré : l'appel part ============
insert into vault.decrypted_secrets values ('push_trigger_secret', 'ma-phrase-secrete');
select t.ok('une notification déclenche l''envoi',
  $$insert into notifications (user_id, type, payload) values (t.u(1), 'booking.confirmee', '{}')$$);
select t.eq('un appel est parti', $$select count(*)::text from t.appels$$, '1');
select t.eq('vers l''adresse de la fonction d''envoi',
  $$select url from t.appels order by id desc limit 1$$,
  'https://kzzrowymwwxoydklnkfb.supabase.co/functions/v1/push-envoyer');
select t.eq('avec le mot de passe du coffre dans l''en-tête',
  $$select entetes->>'x-yiri-push' from t.appels order by id desc limit 1$$, 'ma-phrase-secrete');
select t.eq('le mot de passe n''est écrit nulle part en clair dans la fonction',
  $$select (prosrc not like '%ma-phrase-secrete%')::text from pg_proc where proname = 'push_declencher'$$, 'true');

-- ============ Un appel par INSTRUCTION, pas par ligne ============
delete from t.appels;
insert into notifications (user_id, type, payload)
select t.u(1), 'booking.confirmee', '{}' from generate_series(1, 10);
select t.eq('dix notifications en une instruction ne font qu''UN appel',
  $$select count(*)::text from t.appels$$, '1');

-- ============ LA RÈGLE ABSOLUE : un envoi raté ne casse rien ============
-- C'est le test le plus important du fichier. Une notification part au moment où un paiement est
-- confirmé : si l'envoi levait une erreur, l'encaissement serait perdu.
delete from t.appels;
select set_config('t.casser', 'oui', false);
select t.ok('une notification s''écrit même quand l''envoi échoue',
  $$insert into notifications (user_id, type, payload) values (t.u(2), 'booking.confirmee', '{}')$$);
select t.eq('et la notification est bien en base',
  format($$select count(*)::text from notifications where user_id = %L$$, t.u(2)), '1');
select t.eq('aucun appel n''a abouti', $$select count(*)::text from t.appels$$, '0');
select t.eq('elle reste en attente, donc le filet la reprendra',
  format($$select count(*)::text from notifications where user_id = %L and pushed_at is null$$, t.u(2)), '1');
select set_config('t.casser', 'non', false);

-- Le même scénario à travers une vraie confirmation de paiement serait l'idéal ; ce qui compte
-- ici est que l'écriture d'une notification ne puisse jamais être annulée par l'envoi.
delete from t.appels;
select set_config('t.casser', 'oui', false);
select t.ok('plusieurs notifications d''un coup, envoi en panne : rien n''est perdu',
  $$insert into notifications (user_id, type, payload)
    select t.u(3), 'subscription.expiree', '{}' from generate_series(1, 5)$$);
select t.eq('les cinq sont en base',
  format($$select count(*)::text from notifications where user_id = %L$$, t.u(3)), '5');
select set_config('t.casser', 'non', false);

-- ============ Fermé au navigateur ============
reset role; select t.as(5);
select t.must_fail('un administrateur ne déclenche pas d''envoi depuis le site',
  $$select push_declencher_manuel()$$);
select t.must_fail('ni la relance', $$select push_relancer()$$);
select t.as(0);
select t.must_fail('un visiteur encore moins', $$select push_declencher_manuel()$$);
reset role;
select t.eq('et le coffre n''est lisible par personne depuis le site',
  $$select count(*)::text from information_schema.role_table_grants
     where table_schema = 'vault' and grantee in ('anon', 'authenticated')$$, '0');

-- ============ L'adresse est un réglage, pas une valeur figée ============
select t.eq('l''adresse de la fonction est dans les réglages publics',
  $$select count(*)::text from public_settings where key = 'push_function_url'$$, '1');
select t.eq('et ce réglage n''est pas pris pour un secret par le contrôle de préproduction',
  $$select count(*)::text from public_settings
     where key = 'push_function_url'
       and (key ~* '(priv|secret|token|jeton|mot_de_passe|password|sk_)'
            or value ~* '(BEGIN [A-Z ]*PRIVATE|^sk_|^whsec_)')$$, '0');

-- ============ Le filet ============
delete from t.appels; delete from notifications;
select t.eq('rien à relancer quand la file est vide', $$select push_relancer()::text$$, '0');
insert into notifications (user_id, type, payload, created_at)
values (t.u(4), 'booking.confirmee', '{}', now() - interval '10 minutes');
delete from t.appels;
select t.eq('une notification restée en route depuis dix minutes est relancée',
  $$select push_relancer()::text$$, '1');
select t.eq('et l''appel est bien reparti', $$select count(*)::text from t.appels$$, '1');

delete from t.appels; delete from notifications;
insert into notifications (user_id, type, payload) values (t.u(4), 'booking.confirmee', '{}');
delete from t.appels;
select t.eq('une notification de la seconde n''est pas relancée tout de suite (le départ immédiat a sa chance)',
  $$select push_relancer()::text$$, '0');

delete from notifications;
insert into notifications (user_id, type, payload, created_at, push_attempts)
values (t.u(4), 'booking.confirmee', '{}', now() - interval '10 minutes', 3);
select t.eq('après trois tentatives, on ne relance plus', $$select push_relancer()::text$$, '0');

delete from notifications;
insert into notifications (user_id, type, payload, created_at)
values (t.u(4), 'booking.confirmee', '{}', now() - interval '5 days');
select t.eq('une alerte de la semaine dernière n''est pas relancée', $$select push_relancer()::text$$, '0');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0018 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
