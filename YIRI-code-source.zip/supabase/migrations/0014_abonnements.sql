-- YIRI — 0014 : créer un abonnement, le renouveler, et prévenir avant qu'il expire.
--
-- Ce que la vérification a trouvé, et qui bloquait tout :
--
--   1. RIEN ne créait d'abonnement. Aucune fonction, aucun écran, et la règle de sécurité sur
--      « subscriptions » n'autorisait que la lecture. Comme la garde de publication exige un
--      abonnement actif, AUCUNE annonce Visibilité ne pouvait être mise en ligne depuis
--      l'application. Il fallait insérer la ligne à la main en SQL.
--   2. Même chose pour les contrats de gestion : lecture seule. Donc aucune annonce Sérénité
--      ni Partenariat ne pouvait être publiée non plus — et ce sont les seules réservables.
--   3. À l'expiration, la vitrine publique cachait bien l'annonce (la vue recalcule la règle à
--      chaque lecture, c'est solide). Mais l'abonnement restait marqué « actif » et l'annonce
--      « publiée » : le propriétaire lisait « En ligne » alors que plus personne ne la voyait.
--   4. Personne n'était prévenu de rien, et il n'existait aucun moyen de renouveler.
--
-- Décisions du fondateur reprises telles quelles :
--   * à l'expiration, retrait automatique, PLUS des relances à J-7, J-1 et le jour même ;
--   * le propriétaire crée et paie son abonnement lui-même ;
--   * l'administrateur peut en offrir un, avec un motif et une durée, tracé au journal.
--
-- Rien n'est supprimé. Le chemin de paiement existant (declare_payment, start_online_payment,
-- confirm_payment) est réutilisé tel quel : 0014 ne fait que créer la ligne qui lui manquait.

-- =====================================================================
-- 0. Garde : 0014 s'appuie sur 0012
-- =====================================================================
do $$
begin
  if not exists (select 1 from information_schema.columns
                  where table_schema = 'public' and table_name = 'bookings' and column_name = 'guest_phone') then
    raise exception 'La migration 0012 n''est pas appliquée. Appliquez-la d''abord. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. L'abonnement offert
-- =====================================================================
-- Un abonnement offert vaut 0 FCFA, ce que la contrainte d'origine interdisait (elle n'acceptait
-- que 5 000 ou 30 000). On l'élargit plutôt que de facturer pour de faux : une ligne à 5 000 jamais
-- encaissée fausserait les comptes et donnerait un chiffre d'affaires imaginaire.
alter table subscriptions add column if not exists offert boolean not null default false;
alter table subscriptions add column if not exists offert_motif text;

do $$
begin
  if exists (select 1 from pg_constraint
              where conrelid = 'subscriptions'::regclass and conname = 'subscriptions_check') then
    alter table subscriptions drop constraint subscriptions_check;
  end if;
  alter table subscriptions add constraint subscriptions_check check (
       (offert and amount_xof = 0)
    or (not offert and plan = 'mensuel' and amount_xof = 5000)
    or (not offert and plan = 'annuel'  and amount_xof = 30000)
  );
end $$;

-- =====================================================================
-- 2. Mémoire des relances, pour ne pas écrire deux fois le même message
-- =====================================================================
-- Sans cette table, une tâche planifiée rejouée (ou un rattrapage après une panne) enverrait
-- la même relance chaque jour jusqu'à l'échéance. L'unicité est portée par la base, pas par le code.
create table if not exists subscription_reminders (
  subscription_id uuid not null references subscriptions(id) on delete cascade,
  kind text not null check (kind in ('j7', 'j1', 'expire')),
  sent_at timestamptz not null default now(),
  primary key (subscription_id, kind)
);
alter table subscription_reminders enable row level security;   -- aucune policy : fermée aux clients
revoke all on subscription_reminders from public, anon, authenticated;

-- =====================================================================
-- 3. Le propriétaire crée son abonnement
-- =====================================================================
/* Crée une ligne « en attente de paiement », puis le chemin de paiement habituel prend le relais :
   paiement en ligne (start_online_payment) ou déclaration hors ligne (declare_payment), et c'est
   confirm_payment qui l'active. Le montant n'est JAMAIS reçu du navigateur : il vient du forfait.
   Appelée deux fois de suite, elle renvoie la ligne déjà en attente au lieu d'en créer une seconde. */
create or replace function subscribe_property(p_property uuid, p_plan subscription_plan)
returns subscriptions
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  p properties%rowtype;
  s subscriptions%rowtype;
  montant int;
begin
  if p_property is null or p_plan is null then
    raise exception 'Informations d''abonnement incomplètes.';
  end if;
  perform enforce_rate_limit('sub:' || uid::text, 10, interval '1 hour');

  select * into p from properties where id = p_property for update;
  if not found then
    raise exception 'Annonce introuvable.';
  end if;
  if p.owner_id <> uid and not has_role('admin') then
    raise exception 'Cette annonce n''est pas la vôtre.' using errcode = '42501';
  end if;
  if p.is_demo then
    raise exception 'Une annonce de démonstration ne s''abonne pas.';
  end if;
  -- Seule l'offre Visibilité fonctionne par abonnement. Sérénité et Partenariat passent par un
  -- contrat de gestion : facturer un abonnement dessus serait facturer deux fois.
  if p.offer <> 'annonce' then
    raise exception 'Cette annonce relève de YIRI Gestion : elle ne nécessite pas d''abonnement.';
  end if;

  -- Déjà une demande en attente ? On la rend telle quelle : deux lignes en attente pour la même
  -- annonce donneraient deux paiements possibles pour un seul service.
  select * into s from subscriptions
   where property_id = p.id and status = 'en_attente_paiement'
   order by created_at desc limit 1;
  if found then
    return s;
  end if;

  montant := case p_plan when 'mensuel' then 5000 else 30000 end;

  insert into subscriptions (owner_id, property_id, plan, amount_xof, status)
  values (p.owner_id, p.id, p_plan, montant, 'en_attente_paiement')
  returning * into s;

  return s;
end $$;
revoke all on function subscribe_property(uuid, subscription_plan) from public, anon;
grant execute on function subscribe_property(uuid, subscription_plan) to authenticated;

-- =====================================================================
-- 4. L'administrateur offre un abonnement
-- =====================================================================
/* Pour ses propres logements, un geste commercial, ou un propriétaire qu'on dépanne.
   Actif immédiatement, à 0 FCFA, avec un motif obligatoire et une trace au journal : un accès
   gratuit qu'on ne peut pas expliquer six mois plus tard est un trou dans les comptes. */
create or replace function grant_subscription(p_property uuid, p_days int, p_reason text)
returns subscriptions
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  p properties%rowtype;
  s subscriptions%rowtype;
  base date;
begin
  if not has_role('admin') then
    raise exception 'Seul un administrateur peut offrir un abonnement.' using errcode = '42501';
  end if;
  if p_days is null or p_days < 1 or p_days > 730 then
    raise exception 'Durée invalide : entre 1 et 730 jours.';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'Indiquez le motif de cet abonnement offert.';
  end if;

  select * into p from properties where id = p_property for update;
  if not found then raise exception 'Annonce introuvable.'; end if;
  if p.offer <> 'annonce' then
    raise exception 'Cette annonce relève de YIRI Gestion : elle ne nécessite pas d''abonnement.';
  end if;

  -- On prolonge à la suite de ce qui existe, on ne recouvre pas : le propriétaire ne perd pas
  -- les jours qu'il a déjà payés.
  select coalesce(max(ends_at), current_date) into base
    from subscriptions where property_id = p.id and status = 'actif' and ends_at > current_date;

  insert into subscriptions (owner_id, property_id, plan, amount_xof, status,
                             starts_at, ends_at, offert, offert_motif)
  values (p.owner_id, p.id, 'mensuel', 0, 'actif',
          base, base + p_days, true, btrim(p_reason))
  returning * into s;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after, reason)
  values (uid, 'subscription.offerte', 'subscription', s.id::text,
          jsonb_build_object('annonce', p.id, 'jours', p_days, 'jusqu_au', s.ends_at),
          btrim(p_reason));

  insert into notifications (user_id, type, payload)
  values (p.owner_id, 'subscription.offerte',
          jsonb_build_object('annonce', p.id, 'titre', p.title, 'jusqu_au', s.ends_at));

  return s;
end $$;
revoke all on function grant_subscription(uuid, int, text) from public, anon;
grant execute on function grant_subscription(uuid, int, text) to authenticated;

-- =====================================================================
-- 5. Le contrat de gestion, pour Sérénité et Partenariat
-- =====================================================================
/* Même trou que pour les abonnements : la table était en lecture seule, donc aucune annonce
   sous gestion ne pouvait être publiée — alors que ce sont les SEULES réservables en ligne.
   Réservée à l'équipe « validation », parce que signer un contrat engage YIRI. */
create or replace function set_management_agreement(
  p_property uuid, p_signed boolean, p_check_done boolean, p_version text default 'v1')
returns management_agreements
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  p properties%rowtype;
  m management_agreements%rowtype;
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;

  select * into p from properties where id = p_property for update;
  if not found then raise exception 'Annonce introuvable.'; end if;
  if p.offer not in ('gestion', 'partenariat') then
    raise exception 'Cette annonce relève de l''offre Visibilité : elle fonctionne par abonnement.';
  end if;

  select * into m from management_agreements where property_id = p.id;
  if found then
    update management_agreements
       set signed = coalesce(p_signed, signed),
           operational_check_done = coalesce(p_check_done, operational_check_done),
           contract_version = coalesce(p_version, contract_version)
     where property_id = p.id
    returning * into m;
  else
    insert into management_agreements (property_id, contract_version, starts_on, signed,
                                       operational_check_done, expense_policy_version)
    values (p.id, coalesce(p_version, 'v1'), current_date,
            coalesce(p_signed, false), coalesce(p_check_done, false), 'v1')
    returning * into m;
  end if;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'agreement.set', 'property', p.id::text,
          jsonb_build_object('signe', m.signed, 'visite_faite', m.operational_check_done));

  return m;
end $$;
revoke all on function set_management_agreement(uuid, boolean, boolean, text) from public, anon;
grant execute on function set_management_agreement(uuid, boolean, boolean, text) to authenticated;

-- =====================================================================
-- 6. Ce que chacun voit de ses abonnements
-- =====================================================================
create or replace function my_subscriptions()
returns table (id uuid, property_id uuid, titre text, plan subscription_plan, amount_xof int,
               status subscription_status, starts_at date, ends_at date, jours_restants int,
               offert boolean, visible_publiquement boolean)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select s.id, s.property_id, p.title, s.plan, s.amount_xof, s.status, s.starts_at, s.ends_at,
           case when s.ends_at is null then null else (s.ends_at - current_date) end,
           s.offert,
           (s.status = 'actif' and s.starts_at <= current_date and s.ends_at > current_date)
      from subscriptions s
      join properties p on p.id = s.property_id
     where s.owner_id = uid
     order by (s.status = 'actif') desc, s.ends_at desc nulls last, s.created_at desc;
end $$;
revoke all on function my_subscriptions() from public, anon;
grant execute on function my_subscriptions() to authenticated;

create or replace function subscriptions_queue(p_limit int default 100)
returns table (id uuid, property_id uuid, titre text, ville text, owner_id uuid, proprietaire text,
               plan subscription_plan, amount_xof int, status subscription_status,
               starts_at date, ends_at date, jours_restants int, offert boolean, offert_motif text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_any_perm('validation', 'paiements') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  return query
    select s.id, s.property_id, p.title, p.city::text, s.owner_id, pr.full_name,
           s.plan, s.amount_xof, s.status, s.starts_at, s.ends_at,
           case when s.ends_at is null then null else (s.ends_at - current_date) end,
           s.offert, s.offert_motif
      from subscriptions s
      join properties p on p.id = s.property_id
      join profiles pr on pr.id = s.owner_id
     order by
       -- Ce qu'on vient voir ici : qui va expirer, et quand.
       (case when s.status = 'actif' then 0 when s.status = 'en_attente_paiement' then 1 else 2 end),
       s.ends_at asc nulls first,
       s.created_at desc
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function subscriptions_queue(int) from public, anon;
grant execute on function subscriptions_queue(int) to authenticated;

-- =====================================================================
-- 7. Les relances et l'expiration, une fois par jour
-- =====================================================================
/* Fermée au navigateur : c'est une tâche planifiée, pas un bouton. Elle est écrite pour être
   rejouable sans dégât — si la tâche saute une nuit, le lendemain rattrape, et la table des
   relances empêche d'écrire deux fois le même message. */
create or replace function expire_subscriptions()
returns table (relances_j7 int, relances_j1 int, expires int, annonces_retirees int)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  n7 int := 0; n1 int := 0; ne int := 0; na int := 0;
begin
  if current_user in ('authenticated', 'anon') then
    raise exception 'Fonction réservée au serveur.' using errcode = '42501';
  end if;

  -- ---- Relance à J-7 ----
  with cibles as (
    select s.id, s.owner_id, s.property_id, s.ends_at, p.title
      from subscriptions s join properties p on p.id = s.property_id
     where s.status = 'actif' and s.ends_at > current_date and s.ends_at <= current_date + 7
       and not exists (select 1 from subscription_reminders r where r.subscription_id = s.id and r.kind = 'j7')
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'j7' from cibles returning 1
  )
  insert into notifications (user_id, type, payload)
  select c.owner_id, 'subscription.bientot_expiree',
         jsonb_build_object('abonnement', c.id, 'annonce', c.property_id, 'titre', c.title,
                            'jusqu_au', c.ends_at, 'jours', c.ends_at - current_date)
    from cibles c;
  get diagnostics n7 = row_count;

  -- ---- Relance à J-1 ----
  with cibles as (
    select s.id, s.owner_id, s.property_id, s.ends_at, p.title
      from subscriptions s join properties p on p.id = s.property_id
     where s.status = 'actif' and s.ends_at > current_date and s.ends_at <= current_date + 1
       and not exists (select 1 from subscription_reminders r where r.subscription_id = s.id and r.kind = 'j1')
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'j1' from cibles returning 1
  )
  insert into notifications (user_id, type, payload)
  select c.owner_id, 'subscription.expire_demain',
         jsonb_build_object('abonnement', c.id, 'annonce', c.property_id, 'titre', c.title,
                            'jusqu_au', c.ends_at)
    from cibles c;
  get diagnostics n1 = row_count;

  -- ---- Expiration ----
  -- Le statut rejoint enfin la réalité : jusqu'ici l'abonnement restait « actif » pour toujours
  -- et l'application affichait « En ligne » à un propriétaire que plus personne ne voyait.
  -- « get diagnostics » ne verrait que la DERNIÈRE écriture, c'est-à-dire le nombre de membres
  -- d'équipe prévenus — pas le nombre d'abonnements expirés. On compte donc explicitement.
  -- Les écritures d'un WITH s'exécutent toutes, qu'on lise leur résultat ou non.
  with echus as (
    update subscriptions s set status = 'expire'
     where s.status = 'actif' and s.ends_at <= current_date
    returning s.id, s.owner_id, s.property_id, s.ends_at
  ), avec_titre as (
    select e.*, p.title from echus e join properties p on p.id = e.property_id
  ), trace as (
    insert into subscription_reminders (subscription_id, kind) select id, 'expire' from avec_titre
    on conflict do nothing returning 1
  ), au_proprietaire as (
    insert into notifications (user_id, type, payload)
    select t.owner_id, 'subscription.expiree',
           jsonb_build_object('abonnement', t.id, 'annonce', t.property_id, 'titre', t.title,
                              'expire_le', t.ends_at)
      from avec_titre t
    returning 1
  ), a_equipe as (
    insert into notifications (user_id, type, payload)
    select distinct x.user_id, 'subscription.expiree.equipe',
           jsonb_build_object('abonnement', t.id, 'annonce', t.property_id, 'titre', t.title,
                              'expire_le', t.ends_at)
      from avec_titre t
      cross join (
        select tp.user_id from team_permissions tp where tp.perm in ('validation', 'paiements')
        union
        select ur.user_id from user_roles ur where ur.role = 'admin'
      ) x
     where x.user_id <> t.owner_id
    returning 1
  )
  select count(*) into ne from avec_titre;

  -- ---- Les annonces concernées passent en « Expirée » ----
  -- La vitrine publique les cachait déjà : ce changement ne retire rien au public, il met
  -- simplement l'écran du propriétaire d'accord avec ce que voit le monde.
  update properties p set status = 'expiree'
   where p.offer = 'annonce' and p.status = 'publiee'
     and not exists (select 1 from subscriptions s
                      where s.property_id = p.id and s.status = 'actif'
                        and s.starts_at <= current_date and s.ends_at > current_date);
  get diagnostics na = row_count;

  return query select n7, n1, ne, na;
end $$;
revoke all on function expire_subscriptions() from public, anon, authenticated;

-- =====================================================================
-- 8. Un renouvellement remet l'annonce en ligne
-- =====================================================================
/* Sans ça, le propriétaire paierait son renouvellement et son annonce resterait « Expirée » :
   il faudrait qu'un humain la republie, et personne ne saurait qu'il faut le faire. */
create or replace function subscription_reactivate_listing()
returns trigger
language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.status = 'actif' and (tg_op = 'INSERT' or old.status is distinct from 'actif') then
    update properties set status = 'publiee'
     where id = new.property_id and status = 'expiree' and offer = 'annonce';
    -- Les relances repartent à zéro : le prochain cycle doit pouvoir prévenir à nouveau.
    delete from subscription_reminders where subscription_id = new.id;
  end if;
  return new;
end $$;
revoke all on function subscription_reactivate_listing() from public, anon, authenticated;

drop trigger if exists subscriptions_reactivate on subscriptions;
create trigger subscriptions_reactivate
  after insert or update of status on subscriptions
  for each row execute function subscription_reactivate_listing();
