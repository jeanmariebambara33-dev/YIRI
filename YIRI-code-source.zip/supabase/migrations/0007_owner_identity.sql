-- YIRI — 0007 : compte propriétaire avec pièce d'identité (recto + verso + numéro).
-- Principes :
--  * on ne devient PAS propriétaire sans avoir envoyé le recto, le verso et le numéro de la pièce ;
--  * le numéro est conservé (décision du fondateur) dans une table FERMÉE aux clients : aucune lecture directe,
--    ni par le propriétaire, ni par le public ; seule l'équipe « validation » le lit, par une fonction qui journalise ;
--  * les IMAGES sont supprimées après la décision de l'équipe (décision du fondateur) : la base ne peut pas supprimer
--    de façon fiable un fichier du Storage (il faut passer par l'API Storage) ; elle impose donc la règle autrement :
--    elle autorise la suppression par l'équipe, liste ce qui reste à supprimer et enregistre la confirmation ;
--  * aucune identité ne vient d'un paramètre : tout part de auth.uid() ; rien des migrations 0001–0006 n'est réécrit,
--    sauf la redéfinition de grant_owner_role (fonction de 0006) pour exiger la pièce.
--  * PARCOURS (décision du fondateur) : un compte suffit pour créer des BROUILLONS (3 au plus tant que la personne n'est pas
--    vérifiée) ; la pièce n'est demandée qu'au moment de PUBLIER (passage du brouillon à « soumise »). L'équipe vérifie la pièce
--    et l'annonce ; aucune annonce ne peut être approuvée ni publiée avant que son auteur soit vérifié. Redéfinitions de 0005 :
--    politique properties_owner_insert et politique de stockage yiri_photos_insert_owner (sans exiger le rôle propriétaire).
-- Prérequis : 0001–0006 appliquées. Le stockage n'est configuré que si le schéma storage existe.

-- =====================================================================
-- 1. Table de l'identité (fermée aux clients)
-- =====================================================================
create table owner_identity (
  user_id uuid primary key references profiles(id) on delete cascade,
  id_type text not null check (id_type in ('cnib', 'passeport', 'permis', 'autre')),
  id_number text not null,
  id_number_norm text not null,
  state text not null default 'en_attente' check (state in ('en_attente', 'a_renvoyer', 'verifie', 'refuse')),
  submitted_at timestamptz not null default now(),
  decided_by uuid references profiles(id),
  decided_at timestamptz,
  decision_note text,                -- montrée au propriétaire quand la pièce est à renvoyer
  files_deleted_at timestamptz,      -- confirmation que les images ont été supprimées du Storage
  constraint owner_identity_number_chk check (id_number_norm ~ '^[A-Z0-9]{5,25}$'),
  constraint owner_identity_decision_chk check ((state in ('verifie', 'refuse', 'a_renvoyer')) = (decided_at is not null))
);
-- Une même pièce ne peut pas ouvrir deux comptes (détection des doublons sur le numéro normalisé).
create unique index owner_identity_number_uidx on owner_identity (id_type, id_number_norm);

alter table owner_identity enable row level security;      -- aucune politique : fermé à tous les clients
revoke all on owner_identity from public, anon, authenticated;

-- =====================================================================
-- 2. Fonctions utilitaires (internes)
-- =====================================================================
create or replace function identity_file_count(p_user uuid) returns int
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare n int := 0;
begin
  if to_regclass('storage.objects') is null then return 0; end if;
  execute $q$ select count(distinct (regexp_match(name, '^[^/]+/(recto|verso)\.(jpg|jpeg|png|webp)$'))[1])
                from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = $1::text
                  and name ~ '^[^/]+/(recto|verso)\.(jpg|jpeg|png|webp)$' $q$ into n using p_user;
  return coalesce(n, 0);
end $$;
revoke all on function identity_file_count(uuid) from public, anon, authenticated;

create or replace function identity_files_left(p_user uuid) returns int
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare n int := 0;
begin
  if to_regclass('storage.objects') is null then return 0; end if;
  execute $q$ select count(*) from storage.objects where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = $1::text $q$
    into n using p_user;
  return coalesce(n, 0);
end $$;
revoke all on function identity_files_left(uuid) from public, anon, authenticated;

-- Le dossier d'un utilisateur est-il ouvert à l'envoi ? (aucune demande, ou pièce à renvoyer ; jamais après une décision)
create or replace function identity_upload_open(p_user uuid) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select p_user is not null and p_user = auth.uid()      -- ne renseigne que sur SON propre dossier
         and not exists (select 1 from owner_identity where user_id = p_user and state <> 'a_renvoyer')
$$;
revoke all on function identity_upload_open(uuid) from public, anon;
grant execute on function identity_upload_open(uuid) to authenticated;

-- L'équipe a-t-elle ouvert ce dossier (via open_owner_identity, donc journalisé) dans les 15 dernières minutes ?
create or replace function identity_access_recent(p_target text) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select auth.uid() is not null and has_perm('validation') and exists (
    select 1 from audit_logs where actor_id = auth.uid() and action = 'identity.viewed'
       and entity_id = p_target and created_at > now() - interval '15 minutes')
$$;
revoke all on function identity_access_recent(text) from public, anon;
grant execute on function identity_access_recent(text) to authenticated;

-- Après une décision, l'équipe peut supprimer les images de ce dossier.
create or replace function identity_delete_allowed(p_target text) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select auth.uid() is not null and has_perm('validation') and exists (
    select 1 from owner_identity where user_id::text = p_target and state in ('verifie', 'refuse'))
$$;
revoke all on function identity_delete_allowed(text) from public, anon;
grant execute on function identity_delete_allowed(text) to authenticated;

-- =====================================================================
-- 3. Fonctions serveur (appelées par l'application)
-- =====================================================================
-- Le futur propriétaire envoie le numéro ; les deux images doivent déjà être dans le Storage.
create or replace function submit_owner_identity(p_type text, p_number text) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user(); norm text; cur owner_identity;
begin
  perform enforce_rate_limit('idsubmit:' || uid::text, 10, interval '1 day');
  if has_role('proprietaire') then raise exception 'Vous êtes déjà propriétaire.'; end if;
  if p_type is null or p_type not in ('cnib', 'passeport', 'permis', 'autre') then
    raise exception 'Type de pièce invalide.';
  end if;
  norm := upper(regexp_replace(coalesce(p_number, ''), '[\s\-./]+', '', 'g'));
  if norm !~ '^[A-Z0-9]{5,25}$' then
    raise exception 'Numéro de pièce invalide (5 à 25 lettres ou chiffres).';
  end if;
  select * into cur from owner_identity where user_id = uid for update;
  if found and cur.state <> 'a_renvoyer' then
    raise exception 'Votre demande a déjà été envoyée ou traitée.';
  end if;
  if not exists (select 1 from properties where owner_id = uid and status in ('brouillon', 'a_corriger', 'soumise')) then
    raise exception 'Créez d''abord une annonce : la pièce est demandée au moment de publier.';
  end if;
  if identity_file_count(uid) < 2 then
    raise exception 'Envoyez d''abord le recto ET le verso de votre pièce.';
  end if;
  if exists (select 1 from owner_identity where id_type = p_type and id_number_norm = norm and user_id <> uid) then
    raise exception 'Cette pièce ne peut pas être utilisée. Contactez l''équipe YIRI.';
  end if;

  insert into owner_identity (user_id, id_type, id_number, id_number_norm, state, submitted_at)
  values (uid, p_type, btrim(p_number), norm, 'en_attente', now())
  on conflict (user_id) do update
    set id_type = excluded.id_type, id_number = excluded.id_number, id_number_norm = excluded.id_number_norm,
        state = 'en_attente', submitted_at = now(), decided_by = null, decided_at = null, decision_note = null;
  insert into owner_profiles (user_id, proof_type) values (uid, p_type)
  on conflict (user_id) do update set proof_type = excluded.proof_type where owner_profiles.verification_status = 'en_attente';
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)       -- jamais le numéro dans le journal
  values (uid, 'identity.submitted', 'user', uid::text, jsonb_build_object('id_type', p_type));
end $$;
revoke all on function submit_owner_identity(text, text) from public, anon;
grant execute on function submit_owner_identity(text, text) to authenticated;

-- Ce que le propriétaire a le droit de voir de SON dossier (numéro masqué).
create or replace function my_owner_identity()
returns table (state text, id_type text, id_number_masked text, files_sent int, decision_note text, files_deleted boolean)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select coalesce(i.state, 'aucune'), i.id_type,
           case when i.id_number_norm is null then null else repeat('*', greatest(length(i.id_number_norm) - 3, 0)) || right(i.id_number_norm, 3) end,
           identity_file_count(uid), i.decision_note, (i.files_deleted_at is not null)
      from (select 1) x left join owner_identity i on i.user_id = uid;
end $$;
revoke all on function my_owner_identity() from public, anon;
grant execute on function my_owner_identity() to authenticated;

-- L'équipe « validation » ouvre un dossier : numéro + chemins des images. Chaque ouverture est journalisée,
-- et c'est elle qui ouvre (15 min) le droit de lire les images dans le Storage.
create or replace function open_owner_identity(p_user uuid)
returns table (user_id uuid, id_type text, id_number text, state text, submitted_at timestamptz, files_sent int, files_left int)
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  perform enforce_rate_limit('idview:' || uid::text, 200, interval '1 hour');
  if not exists (select 1 from owner_identity i where i.user_id = p_user) then
    raise exception 'Aucune pièce envoyée par cet utilisateur.';
  end if;
  insert into audit_logs (actor_id, action, entity_type, entity_id)
  values (uid, 'identity.viewed', 'user', p_user::text);
  return query select i.user_id, i.id_type, i.id_number, i.state, i.submitted_at, identity_file_count(p_user), identity_files_left(p_user)
                 from owner_identity i where i.user_id = p_user;
end $$;
revoke all on function open_owner_identity(uuid) from public, anon;
grant execute on function open_owner_identity(uuid) to authenticated;

-- Redéfinit grant_owner_role (0006) : le rôle n'est accordé qu'avec une pièce complète en attente de décision.
create or replace function grant_owner_role(p_user uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  if not has_any_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  if p_user is null or p_user = uid then
    raise exception 'Vous ne pouvez pas vous attribuer ce rôle vous-même.' using errcode = '42501';
  end if;
  if not exists (select 1 from profiles where id = p_user) then
    raise exception 'Utilisateur introuvable.';
  end if;
  perform 1 from owner_identity where user_id = p_user and state = 'en_attente' for update;
  if not found then
    raise exception 'Aucune pièce d''identité en attente de décision pour cet utilisateur.';
  end if;
  if identity_file_count(p_user) < 2 then
    raise exception 'Le recto et le verso de la pièce sont requis.';
  end if;
  insert into user_roles (user_id, role, granted_by) values (p_user, 'proprietaire', uid) on conflict do nothing;
  update owner_profiles set verification_status = 'verifie' where user_id = p_user;
  update owner_identity set state = 'verifie', decided_by = uid, decided_at = now(), decision_note = null where user_id = p_user;
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'role.owner_granted', 'user', p_user::text, jsonb_build_object('role', 'proprietaire'));
end $$;
revoke all on function grant_owner_role(uuid) from public, anon;
grant execute on function grant_owner_role(uuid) to authenticated;

-- Refus définitif, ou demande de renvoyer une pièce illisible (p_resend = true : le propriétaire peut renvoyer).
create or replace function reject_owner_identity(p_user uuid, p_note text default null, p_resend boolean default false) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  if p_user is null or p_user = uid then
    raise exception 'Action impossible sur votre propre dossier.' using errcode = '42501';
  end if;
  perform 1 from owner_identity where user_id = p_user and state = 'en_attente' for update;
  if not found then
    raise exception 'Aucune pièce d''identité en attente de décision pour cet utilisateur.';
  end if;
  if p_resend then
    update owner_identity set state = 'a_renvoyer', decided_by = uid, decided_at = now(), decision_note = left(btrim(p_note), 300)
     where user_id = p_user;
  else
    update owner_identity set state = 'refuse', decided_by = uid, decided_at = now(), decision_note = left(btrim(p_note), 300)
     where user_id = p_user;
    update owner_profiles set verification_status = 'refuse' where user_id = p_user;
  end if;
  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, case when p_resend then 'identity.resend_requested' else 'identity.rejected' end, 'user', p_user::text, null);
end $$;
revoke all on function reject_owner_identity(uuid, text, boolean) from public, anon;
grant execute on function reject_owner_identity(uuid, text, boolean) to authenticated;

-- Dossiers décidés dont des images existent encore dans le Storage (à supprimer par l'API Storage).
create or replace function identity_files_pending()
returns table (user_id uuid, state text, decided_at timestamptz, files_left int)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  return query select i.user_id, i.state, i.decided_at, identity_files_left(i.user_id)
                 from owner_identity i
                where i.state in ('verifie', 'refuse') and identity_files_left(i.user_id) > 0 order by i.decided_at;
end $$;
revoke all on function identity_files_pending() from public, anon;
grant execute on function identity_files_pending() to authenticated;

-- Confirme la suppression : refuse tant qu'il reste un fichier dans le Storage.
create or replace function confirm_identity_files_deleted(p_user uuid) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  perform 1 from owner_identity where user_id = p_user and state in ('verifie', 'refuse') for update;
  if not found then
    raise exception 'Dossier introuvable ou décision non prise.';
  end if;
  if identity_files_left(p_user) > 0 then
    raise exception 'Des images existent encore dans le stockage : supprimez-les d''abord.';
  end if;
  update owner_identity set files_deleted_at = coalesce(files_deleted_at, now()) where user_id = p_user;
  insert into audit_logs (actor_id, action, entity_type, entity_id)
  values (uid, 'identity.files_deleted', 'user', p_user::text);
end $$;
revoke all on function confirm_identity_files_deleted(uuid) from public, anon;
grant execute on function confirm_identity_files_deleted(uuid) to authenticated;

-- =====================================================================
-- 3 bis. Parcours « compte → brouillon → pièce au moment de publier »
-- =====================================================================
-- Créer un brouillon : tout utilisateur connecté, pour lui-même, statut « brouillon », 3 annonces en cours au plus
-- tant qu'il n'est pas propriétaire vérifié. Le propriétaire vérifié garde la règle de 0005 (brouillon ou soumise, via le garde).
drop policy if exists properties_owner_insert on properties;
create policy properties_owner_insert on properties for insert
  with check (
    owner_id = auth.uid()
    and (has_role('proprietaire')
         or (status = 'brouillon'
             and (select count(*) from properties p where p.owner_id = auth.uid() and p.status in ('brouillon', 'a_corriger', 'soumise')) < 3)));

-- Passer en « soumise » (publier) : un non-propriétaire doit avoir envoyé sa pièce (demande en attente de décision).
create or replace function identity_pending(p_user uuid) returns boolean
language sql stable security definer set search_path = public, pg_temp as $$
  select p_user is not null and p_user = auth.uid() and exists (select 1 from owner_identity where user_id = p_user and state = 'en_attente')
$$;
revoke all on function identity_pending(uuid) from public, anon;
grant execute on function identity_pending(uuid) to authenticated;

create or replace function properties_identity_guard() returns trigger language plpgsql
set search_path = public, pg_temp as $$
begin
  if current_user in ('authenticated', 'anon') and new.status = 'soumise' and old.status is distinct from 'soumise'
     and old.owner_id = auth.uid() and not has_role('proprietaire')
     and not identity_pending(old.owner_id) then
    raise exception 'Pour publier, envoyez d''abord votre pièce d''identité (recto, verso et numéro).';
  end if;
  return new;
end $$;
create trigger properties_identity_guard_trg before update on properties
  for each row execute function properties_identity_guard();

-- Aucune annonce approuvée ni publiée si son auteur n'est pas un propriétaire vérifié (valable pour TOUT acteur).
create or replace function properties_owner_verified_guard() returns trigger language plpgsql
set search_path = public, pg_temp as $$
begin
  if new.status in ('approuvee', 'publiee') and old.status is distinct from new.status
     and not exists (select 1 from user_roles where user_id = new.owner_id and role = 'proprietaire') then
    raise exception 'Le propriétaire n''est pas encore vérifié : validez d''abord sa pièce d''identité.';
  end if;
  return new;
end $$;
create trigger properties_owner_verified_guard_trg before update on properties
  for each row execute function properties_owner_verified_guard();

-- =====================================================================
-- 4. Stockage des pièces (Supabase Storage) — appliqué seulement si le schéma storage existe
-- =====================================================================
-- Fichiers rangés sous  <id utilisateur>/recto.<ext>  et  <id utilisateur>/verso.<ext> ; bucket PRIVÉ ; images, 5 Mo max.
do $$
begin
  if to_regclass('storage.objects') is null then
    raise notice 'Schéma storage absent : règles de stockage des pièces non appliquées (à vérifier sur un vrai projet Supabase).';
    return;
  end if;

  insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('owner-identity', 'owner-identity', false, 5242880, array['image/jpeg','image/png','image/webp'])
  on conflict (id) do update
    set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

  -- photos d'annonce : un brouillon appartenant à l'utilisateur suffit (le rôle propriétaire n'est plus exigé, 0005 le demandait)
  drop policy if exists yiri_photos_insert_owner on storage.objects;
  create policy yiri_photos_insert_owner on storage.objects for insert to authenticated
    with check (bucket_id = 'property-photos'
                and (storage.foldername(name))[1] = auth.uid()::text
                and exists (select 1 from public.properties p
                            where p.id::text = (storage.foldername(name))[2] and p.owner_id = auth.uid()));

  drop policy if exists yiri_identity_insert_own on storage.objects;
  drop policy if exists yiri_identity_update_own on storage.objects;
  drop policy if exists yiri_identity_read_own on storage.objects;
  drop policy if exists yiri_identity_delete_own on storage.objects;
  drop policy if exists yiri_identity_read_staff on storage.objects;
  drop policy if exists yiri_identity_delete_staff on storage.objects;

  -- le futur propriétaire : seulement son dossier, seulement recto/verso, seulement tant que la demande n'est pas envoyée
  create policy yiri_identity_insert_own on storage.objects for insert to authenticated
    with check (bucket_id = 'owner-identity'
                and (storage.foldername(name))[1] = auth.uid()::text
                and name ~ '^[0-9a-f-]{36}/(recto|verso)\.(jpg|jpeg|png|webp)$'
                and public.identity_upload_open(auth.uid()));
  create policy yiri_identity_update_own on storage.objects for update to authenticated
    using (bucket_id = 'owner-identity' and (storage.foldername(name))[1] = auth.uid()::text and public.identity_upload_open(auth.uid()))
    with check (bucket_id = 'owner-identity' and (storage.foldername(name))[1] = auth.uid()::text
                and name ~ '^[0-9a-f-]{36}/(recto|verso)\.(jpg|jpeg|png|webp)$' and public.identity_upload_open(auth.uid()));
  create policy yiri_identity_read_own on storage.objects for select to authenticated
    using (bucket_id = 'owner-identity' and (storage.foldername(name))[1] = auth.uid()::text);
  create policy yiri_identity_delete_own on storage.objects for delete to authenticated
    using (bucket_id = 'owner-identity' and (storage.foldername(name))[1] = auth.uid()::text and public.identity_upload_open(auth.uid()));
  -- l'équipe : lecture seulement après open_owner_identity (journalisé, 15 min) ; suppression seulement après décision
  create policy yiri_identity_read_staff on storage.objects for select to authenticated
    using (bucket_id = 'owner-identity' and public.identity_access_recent((storage.foldername(name))[1]));
  create policy yiri_identity_delete_staff on storage.objects for delete to authenticated
    using (bucket_id = 'owner-identity' and public.identity_delete_allowed((storage.foldername(name))[1]));
end $$;
