// Tests de bout en bout de l'abonnement YIRI Annonce (migrations 0014 à 0016).
//
// Le serveur est remplacé par une imitation qui applique les MÊMES règles que la base :
//   * un abonnement par PROFIL : ajouter un logement ne redemande jamais de payer ;
//   * à l'expiration, toutes les annonces du profil sont masquées, rien n'est supprimé ;
//   * le propriétaire garde l'accès à son tableau de bord et comprend ce qui se passe ;
//   * un accès offert par YIRI remplace l'abonnement et couvre tous ses logements ;
//   * seule l'équipe habilitée ouvre la file des abonnements, et un motif est exigé.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const DB = {
  // Abonnement du propriétaire connecté : null, ou { plan, status, ends_at, offert }
  abo: null,
  pass: null,
  annonces: [
    { id: "p-1", title: "Studio Gounghin", status: "publiee" },
    { id: "p-2", title: "Studio Zogona",   status: "soumise" },
    { id: "p-3", title: "Villa Koulouba",  status: "refusee" },
  ],
  // Côté équipe
  equipe: [
    { id: "s-1", owner_id: "o-1", proprietaire: "Awa Sawadogo",  email: "awa@test.local",  plan: "mensuel", amount_xof: 5000,  status: "actif", starts_at: J(-25), ends_at: J(3),  jours_restants: 3,  peut_publier: true,  acces_offert: false, annonces: 2, publiees: 2 },
    { id: "s-2", owner_id: "o-2", proprietaire: "Boukary Zongo", email: "bouk@test.local", plan: "annuel",  amount_xof: 30000, status: "actif", starts_at: J(-10), ends_at: J(300), jours_restants: 300, peut_publier: true, acces_offert: false, annonces: 1, publiees: 1 },
    { id: "s-3", owner_id: "o-3", proprietaire: "Clarisse Kabore", email: "cla@test.local", plan: "mensuel", amount_xof: 5000, status: "expire", starts_at: J(-60), ends_at: J(-5), jours_restants: -5, peut_publier: false, acces_offert: false, annonces: 4, publiees: 0 },
    { id: "s-4", owner_id: "o-4", proprietaire: "Daouda Partenaire", email: "dao@test.local", plan: "mensuel", amount_xof: 0, status: "en_attente_paiement", starts_at: null, ends_at: null, jours_restants: null, peut_publier: true, acces_offert: true, annonces: 6, publiees: 6 },
  ],
  passes: [
    { id: "f-1", owner_id: "o-4", proprietaire: "Daouda Partenaire", email: "dao@test.local", starts_on: J(-5), ends_on: J(85), jours_restants: 85, reason: "Partenariat de lancement", revoke_at: null, annonces: 6 },
  ],
  gestes: [],
  roles: [{ role: "voyageur" }, { role: "proprietaire" }],
  perms: [],
};
window.__db = DB;
const UID = "moi";
const err = (code, message) => ({ data: null, error: { code, message } });
const okRes = (data) => ({ data, error: null });
const estAdmin = () => DB.roles.some((r) => r.role === "admin");
const peut = (p) => estAdmin() || DB.perms.some((x) => x.perm === p);

// La MÊME règle que owner_can_publish() en base.
const peutPublier = () =>
  (DB.abo && DB.abo.status === "actif" && DB.abo.ends_at > J(0)) ||
  (DB.pass && DB.pass.ends_on > J(0));

function builder(table) {
  const run = () => {
    if (table === "properties") return okRes(DB.annonces.map((a) => ({
      id: a.id, title: a.title, description: "d", city: "Ouagadougou", district: "Centre",
      private_address: "a", capacity: 2, bedrooms: 1, beds: 1, nightly_price_xof: 20000,
      min_nights: 1, status: a.status, review_note: null, created_at: new Date().toISOString(),
    })));
    if (table === "payment_notices") return peut("paiements") ? okRes([]) : err("42501", "refuse");
    if (table === "user_roles") return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    if (table === "team_permissions") return okRes(DB.perms.map((x) => ({ user_id: UID, perm: x.perm })));
    if (table === "profiles") return okRes([{ full_name: "Moussa Compaore", phone: null }]);
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; }, insert() { return self; }, upsert() { return self; }, update() { return self; },
    delete() { return self; }, eq() { return self; }, in() { return self; }, order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: "jeton", user: { id: UID, email: "moussa@test.local" } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem("fs") ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    if (fn === "my_owner_identity") return Promise.resolve(okRes([{ state: "verifie", id_type: "cnib", id_number_masked: "****1", files_sent: 0, decision_note: null, files_deleted: true }]));

    if (fn === "my_subscription") {
      if (!DB.abo) return Promise.resolve(okRes([]));
      return Promise.resolve(okRes([{
        id: "s-moi", plan: DB.abo.plan, amount_xof: DB.abo.plan === "mensuel" ? 5000 : 30000,
        status: DB.abo.status, starts_at: DB.abo.starts_at || null, ends_at: DB.abo.ends_at || null,
        jours_restants: DB.abo.ends_at ? Math.round((Date.parse(DB.abo.ends_at) - Date.parse(J(0))) / 86400000) : null,
        actif: peutPublier(), acces_offert: !!DB.pass,
        offert_jusqu_au: DB.pass ? DB.pass.ends_on : null,
      }]));
    }

    if (fn === "my_listing_counts") {
      const n = (s) => DB.annonces.filter((x) => x.status === s).length;
      return Promise.resolve(okRes([{
        soumis: DB.annonces.length, publies: n("publiee"),
        en_attente: DB.annonces.filter((x) => ["brouillon", "soumise", "a_corriger", "approuvee"].includes(x.status)).length,
        refuses: n("refusee"), suspendus: n("suspendue"), expirees: n("expiree"),
      }]));
    }

    if (fn === "subscribe_owner") {
      if (DB.abo && DB.abo.status === "en_attente_paiement") return Promise.resolve(okRes({ id: "s-moi" }));
      DB.abo = { plan: a.p_plan, status: "en_attente_paiement", ends_at: null, starts_at: null };
      DB.gestes.push("subscribe:" + a.p_plan);
      return Promise.resolve(okRes({ id: "s-moi", plan: a.p_plan, status: "en_attente_paiement" }));
    }

    if (fn === "subscriptions_queue") {
      if (!peut("validation") && !peut("paiements")) {
        return Promise.resolve(err("42501", "Action réservée à l'équipe habilitée (validation)."));
      }
      return Promise.resolve(okRes(DB.equipe.slice()));
    }
    if (fn === "free_passes_queue") {
      if (!peut("validation") && !peut("paiements")) return Promise.resolve(err("42501", "refuse"));
      return Promise.resolve(okRes(DB.passes.slice()));
    }
    if (fn === "grant_owner_pass") {
      if (!estAdmin()) return Promise.resolve(err("42501", "Seul un administrateur peut offrir un accès."));
      if (!a.p_reason || !a.p_reason.trim()) return Promise.resolve(err("P0001", "Indiquez le motif de cet accès offert."));
      DB.gestes.push("pass:" + a.p_owner + ":" + a.p_days + ":" + a.p_reason);
      return Promise.resolve(okRes({ id: "f-new" }));
    }
    if (fn === "revoke_owner_pass") {
      if (!estAdmin()) return Promise.resolve(err("42501", "Seul un administrateur peut retirer un accès."));
      DB.gestes.push("revoke:" + a.p_owner);
      return Promise.resolve(okRes(1));
    }

    if (fn === "identity_queue" || fn === "identity_files_pending" || fn === "refunds_queue") return Promise.resolve(okRes([]));
    if (fn === "bookings_queue" || fn === "owner_bookings" || fn === "payment_attempts_recent") return Promise.resolve(okRes([]));
    if (fn === "public_booked_ranges" || fn === "my_refunds") return Promise.resolve(okRes([]));
    return Promise.resolve(okRes(null));
  },
  storage: { from() { return {
    async createSignedUrl() { return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1500 } });
// La fonction serveur de paiement est injoignable : on vérifie que la demande n'est PAS perdue.
await ctx.route("**", (r) => {
  const u = r.request().url();
  if (u.includes("/functions/v1/paiement-demarrer")) return r.fulfill({ status: 503, contentType: "application/json", body: '{"erreur":"indisponible"}' });
  return u.startsWith("file://") ? r.continue() : r.abort();
});
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
const aller = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(700); };
const rafraichir = async (h) => { await aller("#accueil"); await aller(h); };
const reconnexion = async () => {
  await aller("#compte");
  await p.getByRole("button", { name: "Se déconnecter" }).click();
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "moussa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(800);
};
const nb = (s) => s.replace(/[   ]/g, " ");

await p.goto(URL + "#compte");
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "moussa@test.local");
await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(800);

// =====================================================================
// 1. Sans abonnement
// =====================================================================
await aller("#espace");
await p.waitForSelector("h1");
let t = nb(await texte());
ok("le bloc YIRI Annonce apparaît", /YIRI Annonce/.test(t));
ok("l'ancien nom n'apparaît nulle part", !/Visibilité/.test(t));
ok("l'absence d'abonnement est dite clairement", /Aucun abonnement/.test(t));
ok("la règle « un seul abonnement » est expliquée",
  /Un seul abonnement pour tous vos logements/.test(t));
ok("ajouter un logement ne coûte rien de plus, et c'est écrit",
  /Ajouter un logement ne coûte rien de plus/.test(t));
ok("les deux tarifs sont proposés", /5 000 FCFA/.test(t) && /30 000 FCFA/.test(t));
ok("les compteurs sont affichés", /logements/.test(t) && /en validation/.test(t));
ok("le compteur « en ligne » compte la seule annonce publiée",
  await p.evaluate(() => {
    const el = [...document.querySelectorAll("p")].find((x) => x.textContent.trim() === "en ligne");
    return el && el.previousElementSibling.textContent.trim() === "1";
  }));
ok("et le compteur des refusés aussi",
  await p.evaluate(() => {
    const el = [...document.querySelectorAll("p")].find((x) => x.textContent.trim() === "refusés ou suspendus");
    return el && el.previousElementSibling.textContent.trim() === "1";
  }));

// =====================================================================
// 2. Souscrire : la demande survit même si le paiement est injoignable
// =====================================================================
await p.selectOption("select[aria-label='Forfait']", "annuel");
await p.getByRole("button", { name: "S'abonner et payer" }).click();
await p.waitForTimeout(900);
t = nb(await texte());
ok("la demande d'abonnement a bien été créée côté serveur",
  await p.evaluate(() => window.__db.gestes.includes("subscribe:annuel")));
ok("le forfait choisi est celui envoyé, pas un autre",
  await p.evaluate(() => window.__db.abo.plan === "annuel"));
ok("le paiement injoignable est expliqué sans perdre la demande",
  /demande d'abonnement est enregistrée/.test(t));
ok("et l'écran propose de contacter l'équipe", /contactez l'équipe YIRI/.test(t));
ok("l'état « en attente de paiement » est affiché", /En attente de paiement/.test(t));

// =====================================================================
// 3. Abonnement actif
// =====================================================================
await p.evaluate(() => {
  const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
  window.__db.abo = { plan: "mensuel", status: "actif", starts_at: J(-10), ends_at: J(20) };
});
await rafraichir("#espace");
t = nb(await texte());
ok("l'abonnement actif est signalé", /Abonnement actif/.test(t));
ok("la date d'échéance est affichée", /Valable jusqu'au/.test(t));
ok("les jours restants aussi", /20 jours restants/.test(t));
ok("le bouton devient « Renouveler »", await p.getByRole("button", { name: "Renouveler" }).count() === 1);
ok("et il est dit qu'aucune journée n'est perdue", /vous ne perdez aucune journée/.test(t));

// =====================================================================
// 4. Échéance proche : la relance est annoncée
// =====================================================================
await p.evaluate(() => {
  const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
  window.__db.abo = { plan: "mensuel", status: "actif", starts_at: J(-27), ends_at: J(3) };
});
await rafraichir("#espace");
t = nb(await texte());
ok("l'échéance proche est signalée", /se termine dans 3 jours/.test(t));
ok("et la conséquence est dite", /toutes vos annonces seront masquées/.test(t));
ok("avec la promesse que rien n'est perdu", /logements et\s+vos photos sont conservés|photos sont conservés/.test(t));

// =====================================================================
// 5. Expiré : le cas qui compte vraiment
// =====================================================================
await p.evaluate(() => {
  const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
  window.__db.abo = { plan: "mensuel", status: "expire", starts_at: J(-40), ends_at: J(-2) };
  window.__db.annonces = [
    { id: "p-1", title: "Studio Gounghin", status: "expiree" },
    { id: "p-2", title: "Studio Zogona",   status: "soumise" },
    { id: "p-3", title: "Villa Koulouba",  status: "refusee" },
  ];
});
await rafraichir("#espace");
t = nb(await texte());
ok("le propriétaire garde l'accès à son tableau de bord", /YIRI Annonce/.test(t));
ok("l'expiration est annoncée", /Abonnement expiré/.test(t));
ok("avec la date", /a expiré le/.test(t));
ok("il est dit que les annonces sont masquées", /temporairement masquées du catalogue/.test(t));
ok("et que RIEN n'est supprimé", /Rien n'est supprimé/.test(t));
ok("la réactivation automatique est promise", /redeviendront automatiquement/.test(t));
ok("avec sa limite : ni en attente, ni refusée, ni suspendue",
  /en attente de validation, refusées ou suspendues/.test(t));
ok("le nombre d'annonces masquées est donné", /1 annonce masquée faute d'abonnement actif/.test(t));
ok("il peut toujours ajouter un logement", await p.getByRole("button", { name: "Ajouter un logement" }).count() === 1);
ok("et toujours payer", await p.getByRole("button", { name: /S'abonner|Renouveler/ }).count() === 1);

// =====================================================================
// 6. Accès offert par YIRI
// =====================================================================
await p.evaluate(() => {
  const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
  window.__db.pass = { ends_on: J(60) };
});
await rafraichir("#espace");
t = nb(await texte());
ok("l'accès offert est annoncé", /Accès offert par YIRI/.test(t));
ok("avec sa date de fin", /Accès offert par YIRI jusqu'au/.test(t));
ok("et aucun paiement n'est demandé",
  await p.getByRole("button", { name: /S'abonner|Renouveler/ }).count() === 0);
ok("mais il peut toujours ajouter un logement",
  await p.getByRole("button", { name: "Ajouter un logement" }).count() === 1);

// =====================================================================
// 7. Côté équipe
// =====================================================================
await p.evaluate(() => { window.__db.pass = null; window.__db.perms = [{ perm: "reservations" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
ok("sans la bonne autorisation, l'onglet Abonnements est absent",
  !/Abonnements/.test(await texte()));

await p.evaluate(() => { window.__db.perms = [{ perm: "validation" }]; });
await reconnexion();
await aller("#equipe");
await p.getByRole("button", { name: "Abonnements" }).click();
await p.waitForTimeout(700);
t = nb(await texte());
ok("l'onglet Abonnements s'ouvre", /Un abonnement par propriétaire, pas par logement/.test(t));
ok("les échéances proches sont mises en avant", /Expire bientôt \(1\)/.test(t));
ok("et l'équipe sait qu'elle n'a rien à envoyer", /Les relances partent automatiquement/.test(t));
ok("les abonnements actifs sont listés", /Actifs \(1\)/.test(t));
ok("les expirés aussi", /Expirés et annulés \(1\)/.test(t));
ok("le nombre de logements par propriétaire est affiché", /Clarisse Kabore/.test(t));
ok("un propriétaire sans droit de publier est signalé",
  /ne peut rien publier : ses 4 annonces sont masquées/.test(t));
ok("les accès offerts en cours sont listés", /Accès offerts en cours \(1\)/.test(t));
ok("avec leur motif", /Partenariat de lancement/.test(t));
ok("et le nombre de logements couverts", /couvre 6 logements/.test(t));

// Un validateur n'est pas administrateur : le serveur doit refuser l'octroi.
await p.getByRole("button", { name: "Offrir un accès" }).first().click();
await p.waitForTimeout(300);
t = nb(await texte());
ok("le formulaire explique que l'accès couvre tous les logements",
  /couvre tous les logements/.test(t));
ok("et qu'il n'entre pas dans le chiffre d'affaires", /n'entre dans le chiffre d'affaires/.test(t));
ok("le bouton reste inactif sans motif",
  await p.getByRole("button", { name: "Accorder" }).isDisabled());
await p.locator("input[id^='m-']").first().fill("Geste commercial");
await p.waitForTimeout(200);
ok("avec un motif, il s'active", await p.getByRole("button", { name: "Accorder" }).isEnabled());
await p.getByRole("button", { name: "Accorder" }).click();
await p.waitForTimeout(700);
ok("mais le serveur refuse : seul un administrateur peut offrir",
  /Seul un administrateur peut offrir un accès/.test(nb(await texte())));

// Un administrateur, lui, peut.
await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }, { role: "admin" }]; window.__db.perms = []; });
await reconnexion();
await aller("#equipe");
await p.getByRole("button", { name: "Abonnements" }).click();
await p.waitForTimeout(700);
await p.getByRole("button", { name: "Offrir un accès" }).first().click();
await p.waitForTimeout(300);
await p.locator("input[id^='j-']").first().fill("120");
await p.locator("input[id^='m-']").first().fill("Partenaire pilote");
await p.getByRole("button", { name: "Accorder" }).click();
await p.waitForTimeout(700);
ok("l'administrateur accorde l'accès, avec la durée et le motif saisis",
  await p.evaluate(() => window.__db.gestes.some((g) => g.startsWith("pass:") && g.includes(":120:") && g.includes("Partenaire pilote"))));

ok("aucune erreur JavaScript pendant tout le parcours", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS D'ABONNEMENT PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
