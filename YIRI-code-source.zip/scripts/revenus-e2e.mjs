// Tests de bout en bout des deux fonctionnalités ajoutées après l'audit :
//   1. les relevés de revenus — côté propriétaire ET côté équipe ;
//   2. les signalements — ouverture par un propriétaire, traitement par l'équipe.
//
// Ce qui compte ici, c'est l'ARGENT : qu'aucun montant ne soit calculé par le navigateur, que
// l'écran affiche exactement ce que la base a décidé, et qu'on ne puisse pas verser plus que dû.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const DB = {
  // Un relevé déjà clôturé : 130 000 de revenu, 82 000 pour le propriétaire (deux contrats à des
  // pourcentages différents), 12 000 de dépenses, donc 70 000 dus.
  releves: [{
    id: 'st-1', owner_id: 'moi', proprietaire: 'Moussa Compaore', telephone: '70000001',
    period_start: '2026-09-01', period_end: '2026-09-30',
    rlp_xof: 130000, owner_share_xof: 82000, yiri_commission_xof: 48000,
    owner_expenses_xof: 12000, amount_due_xof: 70000, amount_paid_xof: 0,
    status: 'a_valider', verse_le: null, reference: null,
  }],
  aRegler: [{ owner_id: 'autre', proprietaire: 'Salif Kabore', telephone: '70000002',
              logements: 2, sejours_non_clotures: 3, dernier_depart: '2026-10-05' }],
  apercu: { owner_id: 'autre', proprietaire: 'Salif Kabore', encaisse_xof: 200000,
            remboursements_xof: 20000, frais_xof: 3000, rlp_xof: 180000,
            part_proprietaire_xof: 113000, commission_yiri_xof: 67000,
            sejours: 3, logements: 2, deja_cloture: false },
  signalements: [
    { id: 'sg-1', user_id: 'v1', demandeur: 'Awa Sawadogo', telephone: '70000003',
      role_demandeur: 'voyageur', category: 'acces_logement',
      message: 'La serrure du portail ne souvre pas avec le code donne.',
      status: 'ouvert', resolution: null, titre: 'Villa Koulouba', ville: 'Ouagadougou',
      booking_id: null, created_at: new Date().toISOString(), closed_at: null },
    { id: 'sg-2', user_id: 'p1', demandeur: 'Boukary Zongo', telephone: '70000004',
      role_demandeur: 'proprietaire', category: 'comportement',
      message: 'Le voyageur a laisse le logement en desordre complet.',
      status: 'resolu', resolution: 'Menage facture au voyageur.', titre: 'Studio Zogona',
      ville: 'Ouagadougou', booking_id: null, created_at: new Date().toISOString(), closed_at: new Date().toISOString() },
  ],
  mesSignalements: [],
  versements: [],
  clotures: [],
  ouvertures: [],
  statuts: [],
  roles: [{ role: 'proprietaire' }],
  perms: [],
  refuserVersement: null,
};
window.__db = DB;
const UID = 'moi';
const okRes = (data) => ({ data, error: null });
const err = (code, message) => ({ data: null, error: { code, message } });
const estAdmin = () => DB.roles.some((r) => r.role === 'admin');
const peut = (p) => estAdmin() || DB.perms.some((x) => x.perm === p);

function builder(table) {
  const run = () => {
    if (table === 'user_roles') return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    if (table === 'team_permissions') return okRes(DB.perms.map((x) => ({ user_id: UID, perm: x.perm })));
    if (table === 'profiles') return okRes([{ id: UID, full_name: 'Moussa Compaore', phone: null }]);
    if (table === 'properties') return okRes([]);
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; }, insert() { return self; }, update() { return self; }, upsert() { return self; },
    delete() { return self; }, eq() { return self; }, in() { return self; }, order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => (r.error ? r : { data: (r.data || [])[0] ?? null, error: null })); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: 'jeton', user: { id: UID, email: 'moussa@test.local' } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem('fs') ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem('fs', '1'); listeners.forEach((f) => f('SIGNED_IN', SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem('fs'); listeners.forEach((f) => f('SIGNED_OUT', null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    if (fn === 'my_statements') return Promise.resolve(okRes(DB.releves.filter((r) => r.owner_id === UID)));
    if (fn === 'statements_queue') {
      if (!peut('paiements')) return Promise.resolve(err('42501', 'Action reservee a lequipe habilitee (paiements).'));
      return Promise.resolve(okRes(DB.releves.slice()));
    }
    if (fn === 'owners_to_settle') {
      if (!peut('paiements')) return Promise.resolve(err('42501', 'Action reservee a lequipe habilitee (paiements).'));
      return Promise.resolve(okRes(DB.aRegler.slice()));
    }
    if (fn === 'statement_preview') {
      if (!peut('paiements')) return Promise.resolve(err('42501', 'refuse'));
      DB.apercuDemande = { debut: a.p_debut, fin: a.p_fin };
      return Promise.resolve(okRes([DB.apercu]));
    }
    if (fn === 'close_owner_statement') {
      if (!peut('paiements')) return Promise.resolve(err('42501', 'refuse'));
      DB.clotures.push(a);
      DB.aRegler = [];
      return Promise.resolve(okRes('st-2'));
    }
    if (fn === 'register_payout') {
      if (!peut('paiements')) return Promise.resolve(err('42501', 'refuse'));
      if (DB.refuserVersement) return Promise.resolve(err('P0001', DB.refuserVersement));
      DB.versements.push(a);
      const r = DB.releves.find((x) => x.id === a.p_statement);
      r.amount_paid_xof += a.p_montant;
      if (r.amount_paid_xof >= r.amount_due_xof) { r.status = 'verse'; r.verse_le = new Date().toISOString(); r.reference = a.p_reference; }
      else { r.status = 'en_cours'; }
      return Promise.resolve(okRes('po-1'));
    }
    if (fn === 'my_support_requests') return Promise.resolve(okRes(DB.mesSignalements.slice()));
    if (fn === 'open_support_request') {
      DB.ouvertures.push(a);
      DB.mesSignalements.unshift({ id: 'sg-new', category: a.p_category, message: a.p_message,
        status: 'ouvert', resolution: null, titre: null, created_at: new Date().toISOString(), closed_at: null });
      return Promise.resolve(okRes('sg-new'));
    }
    if (fn === 'support_queue') {
      if (!peut('demandes') && !peut('reservations')) return Promise.resolve(err('42501', 'refuse'));
      return Promise.resolve(okRes(DB.signalements.slice()));
    }
    if (fn === 'set_support_status') {
      if (!peut('demandes') && !peut('reservations')) return Promise.resolve(err('42501', 'refuse'));
      DB.statuts.push(a);
      const s = DB.signalements.find((x) => x.id === a.p_id);
      if (s) { s.status = a.p_status; s.resolution = a.p_resolution || s.resolution; }
      return Promise.resolve(okRes(null));
    }
    if (fn === 'my_notifications') return Promise.resolve(okRes([]));
    if (fn === 'my_owner_identity') return Promise.resolve(okRes([{ state: 'verifie', id_type: 'cnib', id_number_masked: '****1', files_sent: 0, decision_note: null, files_deleted: true }]));
    if (fn === 'my_subscription' || fn === 'my_listing_counts') return Promise.resolve(okRes([]));
    return Promise.resolve(okRes([]));
  },
  storage: { from() { return { async createSignedUrl() { return okRes({ signedUrl: '' }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); } }; } },
}; } };
`;

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1600 } });
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
const nb = (s) => s.replace(/[   ]/g, " ");
const aller = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(700); };
const reconnexion = async () => {
  await aller("#compte");
  const sortie = p.getByRole("button", { name: "Se déconnecter" });
  if (await sortie.count()) { await sortie.click(); await p.waitForTimeout(400); }
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "moussa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(800);
};

await p.goto(URL + "#compte");
await p.waitForSelector("h1");
await reconnexion();

// =====================================================================
// 1. Le propriétaire voit ce que son logement lui rapporte
// =====================================================================
await aller("#espace");
await p.waitForTimeout(600);
let t = nb(await texte());
ok("le propriétaire voit un bloc « Mes revenus »", /Mes revenus/.test(t));
ok("la période est écrite en toutes lettres", /septembre 2026/.test(t));
ok("le revenu partageable est affiché", /130 000/.test(t));
ok("la commission YIRI aussi — rien n'est caché", /Commission YIRI/.test(t) && /48 000/.test(t));
ok("sa part est affichée", /Votre part/.test(t) && /82 000/.test(t));
ok("les dépenses retenues sont détaillées", /Dépenses avancées/.test(t) && /12 000/.test(t));
ok("et le montant qui lui revient", /Montant qui vous revient/.test(t) && /70 000/.test(t));
ok("le total restant dû est rappelé en tête", /Reste à vous verser/.test(t));
ok("le relevé est marqué à régler", /À régler/.test(t));

// Le calcul doit être vérifiable : part + commission = revenu partageable.
ok("le calcul affiché est cohérent : 82 000 + 48 000 = 130 000",
  await p.evaluate(() => 82000 + 48000 === 130000));

// =====================================================================
// 2. Le propriétaire signale un problème
// =====================================================================
ok("le bloc de signalement est proposé", /Un problème \?/.test(t));
await p.getByRole("button", { name: "Signaler un problème" }).click();
await p.waitForTimeout(400);
t = await texte();
ok("les catégories sont en français, pas en code", /Je n'arrive pas à entrer dans le logement/.test(t));
ok("et il y en a une pour l'argent", /Un problème de paiement ou de facture/.test(t));

await p.selectOption("#s-cat", "equipement");
await p.fill("#s-msg", "Le climatiseur de la chambre ne demarre plus depuis hier soir.");
await p.getByRole("button", { name: "Envoyer", exact: true }).click();
await p.waitForTimeout(700);
const envoi = await p.evaluate(() => window.__db.ouvertures[0]);
ok("le signalement part vers la base", await p.evaluate(() => window.__db.ouvertures.length === 1));
ok("avec la catégorie choisie", envoi && envoi.p_category === "equipement");
ok("et le message saisi", envoi && /climatiseur/.test(envoi.p_message));
t = await texte();
ok("il apparaît aussitôt dans la liste", /Un équipement est cassé ou manquant/.test(t));
ok("avec son statut lisible", /Reçu/.test(t));

// Un message trop court ne peut pas être envoyé.
await p.getByRole("button", { name: "Signaler un problème" }).click();
await p.waitForTimeout(300);
await p.fill("#s-msg", "cassé");
ok("un message trop court n'est pas envoyable",
  await p.getByRole("button", { name: "Envoyer", exact: true }).isDisabled());
await p.getByRole("button", { name: "Annuler" }).click();

// =====================================================================
// 3. L'équipe : les revenus sont fermés sans l'autorisation « paiements »
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "validation" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForSelector("h1");
ok("sans l'autorisation « paiements », l'onglet Revenus est absent",
  !/Revenus propriétaires/.test(await texte()));

await p.evaluate(() => { window.__db.perms = [{ perm: "paiements" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForTimeout(500);
ok("avec « paiements », l'onglet apparaît", /Revenus propriétaires/.test(await texte()));
await p.getByRole("button", { name: "Revenus propriétaires" }).click();
await p.waitForTimeout(800);
t = nb(await texte());
ok("le total restant à verser est annoncé", /Reste à verser aux propriétaires/.test(t) && /70 000/.test(t));
ok("il est rappelé que les virements sont manuels", /virements se font à la main/.test(t));
ok("le propriétaire à clôturer est listé", /Salif Kabore/.test(t));
ok("avec de quoi juger", /2 logements/.test(t) && /3 séjours payés/.test(t));

// =====================================================================
// 4. On REGARDE avant d'engager l'argent
// =====================================================================
ok("aucune clôture n'est possible avant l'aperçu",
  await p.getByRole("button", { name: "Clôturer cette période" }).count() === 0);
await p.getByRole("button", { name: /Voir ce que donnerait la clôture/ }).click();
await p.waitForTimeout(700);
t = nb(await texte());
ok("l'aperçu montre l'encaissé", /200 000/.test(t));
ok("les remboursements déduits", /Remboursements déduits/.test(t) && /20 000/.test(t));
ok("le revenu partageable", /Revenu partageable/.test(t) && /180 000/.test(t));
ok("la part du propriétaire", /113 000/.test(t));
ok("la commission YIRI", /67 000/.test(t));
ok("les frais du prestataire, à la charge de YIRI", /à la charge de YIRI/.test(t) && /3 000/.test(t));
ok("il est dit que le pourcentage vient du CONTRAT, pas d'une règle unique",
  /vient du contrat de chaque logement/.test(t));
ok("et que la clôture est définitive", /définitive/.test(t));
ok("l'aperçu ne clôture rien", await p.evaluate(() => window.__db.clotures.length === 0));

// Les montants viennent du serveur, pas d'un calcul de la page.
ok("aucun montant n'est calculé par le navigateur : 113 000 + 67 000 = 180 000 vient de la base",
  await p.evaluate(() => window.__db.apercu.part_proprietaire_xof + window.__db.apercu.commission_yiri_xof === window.__db.apercu.rlp_xof));

await p.fill("#e-autre", "5000");
await p.getByRole("button", { name: "Clôturer cette période" }).click();
await p.waitForTimeout(800);
const cl = await p.evaluate(() => window.__db.clotures[0]);
ok("la clôture part avec la bonne période", cl && cl.p_debut === "2026-10-01" && cl.p_fin === "2026-10-05");
ok("et les dépenses saisies", cl && cl.p_depenses_proprietaire === 5000);

// =====================================================================
// 5. Enregistrer un versement
// =====================================================================
t = await texte();
ok("le relevé à régler est listé", /Moussa Compaore/.test(t));
await p.getByRole("button", { name: "Enregistrer un versement" }).first().click();
await p.waitForTimeout(400);
t = await texte();
ok("il est dit que l'écran ne transfère pas d'argent", /ne transfère pas d'argent/.test(t));
ok("et qu'on enregistre APRÈS le virement", /UNE FOIS LE VIREMENT FAIT/.test(t));
ok("sans référence, on ne peut pas enregistrer",
  await p.getByRole("button", { name: "Enregistrer", exact: true }).isDisabled());

await p.fill("#de-st-1", "**4567");
await p.fill("#re-st-1", "OM-20261014-001");
ok("avec destination et référence, l'enregistrement devient possible",
  await p.getByRole("button", { name: "Enregistrer", exact: true }).isEnabled());

// Un montant supérieur au dû doit être refusé par l'écran avant même la base.
await p.fill("#m-st-1", "999999");
ok("un montant supérieur au dû est refusé avant d'atteindre la base",
  await p.getByRole("button", { name: "Enregistrer", exact: true }).isDisabled());
await p.fill("#m-st-1", "70000");
await p.getByRole("button", { name: "Enregistrer", exact: true }).click();
await p.waitForTimeout(800);
const v = await p.evaluate(() => window.__db.versements[0]);
ok("le versement est enregistré", await p.evaluate(() => window.__db.versements.length === 1));
ok("avec le montant", v && v.p_montant === 70000);
ok("la destination", v && v.p_destination_masquee === "**4567");
ok("et la référence qui trace le virement", v && v.p_reference === "OM-20261014-001");
ok("le relevé passe à « Réglé »", /Réglé/.test(await texte()));

// Un refus de la base s'affiche.
await p.evaluate(() => {
  window.__db.refuserVersement = "Ce relevé est déjà réglé.";
  window.__db.releves[0].amount_paid_xof = 0; window.__db.releves[0].status = "a_valider";
});
// On repasse par un autre onglet : rester sur le même ne relit pas les données.
await p.getByRole("button", { name: "Remboursements", exact: true }).click();
await p.waitForTimeout(400);
await p.getByRole("button", { name: "Revenus propriétaires" }).click();
await p.waitForTimeout(800);
await p.getByRole("button", { name: "Enregistrer un versement" }).first().click();
await p.waitForTimeout(300);
await p.fill("#de-st-1", "**4567");
await p.fill("#re-st-1", "OM-2");
await p.getByRole("button", { name: "Enregistrer", exact: true }).click();
await p.waitForTimeout(700);
ok("un refus de la base est montré, pas avalé", /déjà réglé/.test(await texte()));

// =====================================================================
// 6. L'équipe traite les signalements
// =====================================================================
await p.evaluate(() => { window.__db.perms = [{ perm: "demandes" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForTimeout(500);
ok("l'onglet Signalements apparaît avec « demandes »", /Signalements/.test(await texte()));
await p.getByRole("button", { name: "Signalements" }).click();
await p.waitForTimeout(800);
t = await texte();
ok("les signalements en attente sont annoncés", /1 signalement en attente/.test(t));
ok("avec un mot sur l'urgence", /ne peut pas attendre le lendemain/.test(t));
ok("le signalement du voyageur est affiché", /Awa Sawadogo/.test(t));
ok("avec sa qualité", /voyageur/.test(t));
ok("le logement concerné", /Villa Koulouba/.test(t));
ok("et son message", /serrure du portail/.test(t));
ok("celui du propriétaire est rangé dans les traités", /Traités/.test(t));

ok("on ne peut pas marquer résolu sans dire ce qui a été fait",
  await p.getByRole("button", { name: "Marquer résolu" }).first().isDisabled());
await p.fill("#r-sg-1", "Nouveau code transmis au voyageur, acces verifie.");
await p.waitForTimeout(200);
ok("avec une réponse, la clôture devient possible",
  await p.getByRole("button", { name: "Marquer résolu" }).first().isEnabled());
await p.getByRole("button", { name: "Marquer résolu" }).first().click();
await p.waitForTimeout(800);
const st = await p.evaluate(() => window.__db.statuts[0]);
ok("le statut part vers la base", st && st.p_status === "resolu");
ok("avec la réponse, que la personne lira", st && /Nouveau code transmis/.test(st.p_resolution));

// Sans aucune des deux autorisations, l'onglet disparaît.
await p.evaluate(() => { window.__db.perms = [{ perm: "paiements" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForTimeout(500);
ok("sans « demandes » ni « réservations », l'onglet Signalements est absent",
  !/Signalements/.test(await texte()));

ok("aucune erreur JavaScript pendant tout le parcours", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DES REVENUS ET SIGNALEMENTS PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
