-- Tests de la migration 0010 (annulation par le voyageur, remboursement automatique).
-- Base LOCALE ; auth.uid() simulé ; « reset role » = clé de service (postgres).
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 8) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values (t.u(7), 'paiements', t.u(5));

-- Un logement publié appartenant à l'utilisateur 3.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'annonce', 'Studio test', 'desc', 'Ouagadougou', 'Centre', 'adresse',
        2, 1, 1, 20000, 1, 'publiee', false);

-- Six réservations, dates non chevauchantes (contrainte d'exclusion de 0001).
-- 1 : dans 30 jours (palier « loin »)      4 : commencée hier (palier « commence »)
-- 2 : dans 4 jours  (palier « moyen »)     5 : voyageur 2, pour tester le cloisonnement
-- 3 : demain        (palier « proche »)    6 : voyageur 1, JAMAIS payée
create function t.mkbk(n int, guest int, d1 int, d2 int, total int) returns void language plpgsql as $$
begin
  insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof,
                        accommodation_xof, taxes_xof, discount_xof, total_xof, status)
  values (t.b(n), t.p(1), t.u(guest),
          daterange(current_date + d1, current_date + d2, '[)'), 2, 20000,
          total, 0, 0, total, 'confirmee');
end $$;
select t.mkbk(1, 1, 30, 33, 60000);
select t.mkbk(2, 1,  4,  7, 50000);
select t.mkbk(3, 1,  1,  3, 40000);
select t.mkbk(4, 1, -1,  1, 30000);
select t.mkbk(5, 2, 50, 52, 70000);
select t.mkbk(6, 1, 60, 62, 25000);

-- Encaissements réussis pour 1, 2, 3, 4 et 5. La réservation 6 n'a jamais été payée.
-- Le compte du payeur est connu pour 1, 3, 4 et 5 ; il est INCONNU pour la 2 (cas du garde-fou).
create function t.mkpay(n int, amount int, fee int, account text) returns void language plpgsql as $$
declare ref text := 'REF' || lpad(n::text, 4, '0');
begin
  insert into payment_attempts (reference, object, target_id, amount_xof, provider, created_by,
                                payer_account, settled_at, outcome)
  values (ref, 'reservation', t.b(n), amount, 'testpay', t.u(1), account, now(), 'paye');
  insert into payment_transactions (purpose, booking_id, provider, provider_reference, idempotency_key,
                                    amount_xof, fee_xof, status)
  values ('booking', t.b(n), 'testpay', ref, 'online:' || ref, amount, fee, 'reussi');
end $$;
select t.mkpay(1, 60000, 1200, '70000001');
select t.mkpay(2, 50000, 1000, null);
select t.mkpay(3, 40000,  800, '70000003');
select t.mkpay(4, 30000,  600, '70000004');
select t.mkpay(5, 70000, 1400, '70000005');

-- ============ Accès : qui peut quoi ============
reset role; select t.as(0);
select t.must_fail('visiteur : annulation refusée', format($$select * from cancel_my_booking(%L)$$, t.b(1)));
select t.must_fail('visiteur : estimation refusée', format($$select * from refund_quote(%L)$$, t.b(1)));
select t.ok('visiteur : peut lire le barème public', $$select * from refund_rules_public()$$);
select t.must_fail('visiteur : barème interne illisible', $$select * from refund_rules$$);
select t.must_fail('visiteur : table des remboursements illisible', $$select * from refunds$$);

reset role; select t.as(2);
select t.must_fail('un autre voyageur ne peut pas annuler ma réservation', format($$select * from cancel_my_booking(%L)$$, t.b(1)));
select t.must_fail('un autre voyageur ne voit pas mon estimation', format($$select * from refund_quote(%L)$$, t.b(1)));
reset role; select t.as(3);
select t.must_fail('le propriétaire ne peut pas annuler à la place du voyageur', format($$select * from cancel_my_booking(%L)$$, t.b(1)));
reset role; select t.as(7);
select t.must_fail('l''équipe « paiements » ne peut pas annuler à la place du voyageur', format($$select * from cancel_my_booking(%L)$$, t.b(1)));
select t.ok('l''équipe « paiements » peut lire une estimation', format($$select * from refund_quote(%L)$$, t.b(1)));
reset role; select t.as(5);
select t.must_fail('l''administrateur non plus ne peut pas annuler à la place du voyageur', format($$select * from cancel_my_booking(%L)$$, t.b(1)));

-- Les fonctions de versement sont fermées au navigateur, même pour un administrateur.
reset role; select t.as(5);
select t.must_fail('admin : liste des versements refusée', $$select * from refunds_to_pay()$$);
select t.must_fail('admin : mémorisation du payeur refusée', $$select set_payment_payer('REF0001', '70000009')$$);
select t.must_fail('admin : lancement du versement refusé', format($$select start_refund_payout(%L, 'X')$$, t.b(1)));
select t.must_fail('admin : confirmation de versement refusée', $$select confirm_refund_paid('X', 1)$$);
select t.must_fail('admin : échec de versement refusé', $$select fail_refund('X', 'non')$$);
select t.must_fail('admin : table des tentatives illisible', $$select * from payment_attempts$$);

-- ============ Le barème : une seule formule ============
reset role; select t.as(1);
select t.eq('palier « loin » : taux 100 %', format($$select rate_pct::text from refund_quote(%L)$$, t.b(1)), '100');
select t.eq('palier « loin » : palier nommé', format($$select tier from refund_quote(%L)$$, t.b(1)), 'loin');
select t.eq('palier « loin » : net = 60000 - 1200 de frais', format($$select net_xof::text from refund_quote(%L)$$, t.b(1)), '58800');
select t.eq('palier « moyen » : taux 50 %', format($$select rate_pct::text from refund_quote(%L)$$, t.b(2)), '50');
select t.eq('palier « moyen » : net = 25000 - 1000 de frais', format($$select net_xof::text from refund_quote(%L)$$, t.b(2)), '24000');
select t.eq('palier « proche » : taux 0 %', format($$select rate_pct::text from refund_quote(%L)$$, t.b(3)), '0');
select t.eq('palier « proche » : rien à rembourser', format($$select net_xof::text from refund_quote(%L)$$, t.b(3)), '0');
select t.eq('séjour commencé : palier « commence »', format($$select tier from refund_quote(%L)$$, t.b(4)), 'commence');
select t.eq('séjour commencé : rien à rembourser', format($$select net_xof::text from refund_quote(%L)$$, t.b(4)), '0');
select t.eq('jamais payée : encaissé 0', format($$select gross_xof::text from refund_quote(%L)$$, t.b(6)), '0');
select t.eq('le net ne dépasse jamais l''encaissé',
  format($$select bool_and(net_xof <= gross_xof)::text from (select * from refund_quote(%L) union all select * from refund_quote(%L) union all select * from refund_quote(%L)) q$$,
         t.b(1), t.b(2), t.b(3)), 'true');

-- ============ Annulation automatique ============
reset role; select t.as(1);
select t.eq('annulation « loin » : mode automatique', format($$select mode from cancel_my_booking(%L, 'changement de programme')$$, t.b(1)), 'automatique');
select t.eq('la réservation passe à « annulee »', format($$select status::text from bookings where id = %L$$, t.b(1)), 'annulee');
reset role;
select t.eq('un remboursement approuvé de 58800 est créé',
  format($$select f.amount_xof || '/' || f.status from refunds f join payment_transactions x on x.id = f.payment_transaction_id where x.booking_id = %L$$, t.b(1)),
  '58800/approuve');
select t.ok('les dates sont libérées : une autre réservation est acceptée',
  format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, taxes_xof, discount_xof, total_xof, status)
            values (%L, %L, daterange(current_date + 30, current_date + 33, '[)'), 2, 20000, 60000, 0, 0, 60000, 'confirmee')$$,
         t.p(1), t.u(2)));

reset role; select t.as(1);
select t.must_fail('annuler deux fois est refusé', format($$select * from cancel_my_booking(%L)$$, t.b(1)));
select t.eq('jamais payée : annulation sans remboursement', format($$select mode from cancel_my_booking(%L)$$, t.b(6)), 'sans_remboursement');
select t.eq('palier « proche » : annulation sans remboursement', format($$select mode from cancel_my_booking(%L)$$, t.b(3)), 'sans_remboursement');
select t.eq('séjour commencé : annulation sans remboursement', format($$select mode from cancel_my_booking(%L)$$, t.b(4)), 'sans_remboursement');
reset role;
select t.cnt('aucun remboursement créé pour ces trois cas',
  format($$select 1 from refunds f join payment_transactions x on x.id = f.payment_transaction_id where x.booking_id in (%L, %L, %L)$$,
         t.b(3), t.b(4), t.b(6)), 0);

-- ============ Garde-fou 1 : destination inconnue ============
reset role; select t.as(1);
select t.eq('compte du payeur inconnu : mise en attente', format($$select mode from cancel_my_booking(%L)$$, t.b(2)), 'attente_equipe_compte_inconnu');
reset role;
select t.eq('le remboursement est « demande », pas « approuve »',
  format($$select f.status from refunds f join payment_transactions x on x.id = f.payment_transaction_id where x.booking_id = %L$$, t.b(2)),
  'demande');
reset role; select t.as(7);
select t.eq('l''équipe le voit en tête de file', $$select status from refunds_queue() limit 1$$, 'demande');
select t.eq('l''équipe voit que le payeur est inconnu',
  format($$select payer_known::text from refunds_queue() where booking_id = %L$$, t.b(2)), 'false');
reset role; select t.as(1);
select t.must_fail('le voyageur ne peut pas approuver son propre remboursement',
  format($$select approve_refund(id) from my_refunds() where booking_id = %L$$, t.b(2)));
reset role; select t.as(7);
select t.ok('l''équipe débloque le remboursement',
  format($$select approve_refund(id) from refunds_queue(100) where booking_id = %L$$, t.b(2)));
reset role;
select t.eq('il passe à « approuve »',
  format($$select f.status from refunds f join payment_transactions x on x.id = f.payment_transaction_id where x.booking_id = %L$$, t.b(2)),
  'approuve');
select t.cnt('mais il ne part pas : destination toujours inconnue',
  format($$select 1 from refunds_to_pay(100) r join payment_transactions x on x.provider_reference = r.source_reference where x.booking_id = %L$$, t.b(2)), 0);

-- ============ Garde-fou 2 : plafond journalier ============
reset role; select t.as(1);
select t.must_fail('seul l''administrateur change le barème', $$select set_refund_rules(7, 100, 2, 50, 0, 0, 1000)$$);
reset role; select t.as(5);
select t.must_fail('un barème incohérent est refusé', $$select set_refund_rules(7, 50, 2, 100, 0, 0, 500000)$$);
select t.ok('l''administrateur abaisse le plafond à 1000', $$select set_refund_rules(7, 100, 2, 50, 0, 0, 1000)$$);
select t.eq('le changement est tracé', $$select count(*)::text from audit_logs where action = 'refund_rules.update'$$, '1');
reset role; select t.as(2);
select t.eq('plafond atteint : mise en attente', format($$select mode from cancel_my_booking(%L)$$, t.b(5)), 'attente_equipe_plafond_journalier');
reset role; select t.as(5);
select t.ok('le plafond est remis à 500000', $$select set_refund_rules(7, 100, 2, 50, 0, 0, 500000)$$);
select t.eq('le plafond n''est jamais exposé au public',
  $$select count(*)::text from (select * from refund_rules_public()) q where q::text like '%500000%'$$, '0');

-- ============ Versement : clé de service uniquement ============
reset role;
select t.cnt('un seul remboursement prêt à partir', $$select * from refunds_to_pay(100)$$, 1);
select t.eq('avec la destination mémorisée à l''encaissement',
  format($$select payer_account from refunds_to_pay(100) r join payment_transactions x on x.provider_reference = r.source_reference where x.booking_id = %L$$, t.b(1)),
  '70000001');
select t.ok('lancement du versement',
  format($$select start_refund_payout((select f.id from refunds f join payment_transactions x on x.id = f.payment_transaction_id where x.booking_id = %L), 'PAYOUT-1')$$, t.b(1)));
select t.eq('il passe à « en_cours »', $$select status from refunds where provider_reference = 'PAYOUT-1'$$, 'en_cours');
select t.must_fail('le relancer est refusé',
  format($$select start_refund_payout((select f.id from refunds f join payment_transactions x on x.id = f.payment_transaction_id where x.booking_id = %L), 'PAYOUT-1-BIS')$$, t.b(1)));
select t.cnt('il ne figure plus dans la liste à payer',
  $$select 1 from refunds_to_pay(100) r where r.id = (select id from refunds where provider_reference = 'PAYOUT-1')$$, 0);
select t.eq('un montant différent n''est pas confirmé', $$select confirm_refund_paid('PAYOUT-1', 50000)$$, 'ecart');
select t.eq('et il reste « en_cours »', $$select status from refunds where provider_reference = 'PAYOUT-1'$$, 'en_cours');
select t.eq('l''écart est tracé', $$select count(*)::text from audit_logs where action = 'refund.amount_mismatch'$$, '1');
select t.eq('confirmation au bon montant', $$select confirm_refund_paid('PAYOUT-1', 58800)$$, 'confirme');
select t.eq('il passe à « reussi »', $$select status from refunds where provider_reference = 'PAYOUT-1'$$, 'reussi');
select t.eq('le registre financier est débité une fois de 58800',
  $$select count(*) || '/' || coalesce(sum(debit_xof), 0) from financial_ledger where entry_type = 'remboursement'$$, '1/58800');
select t.eq('message rejoué : aucune double écriture', $$select confirm_refund_paid('PAYOUT-1', 58800)$$, 'deja_confirme');
select t.eq('le registre n''a toujours qu''une écriture',
  $$select count(*) || '/' || coalesce(sum(debit_xof), 0) from financial_ledger where entry_type = 'remboursement'$$, '1/58800');
select t.ok('un échec sur un remboursement déjà payé ne le défait pas', $$select fail_refund('PAYOUT-1', 'test')$$);
select t.eq('il reste « reussi »', $$select status from refunds where provider_reference = 'PAYOUT-1'$$, 'reussi');

-- ============ Le lien avec l'identifiant du prestataire ============
reset role; select t.as(5);
select t.must_fail('admin : pose du lien refusée depuis le navigateur', $$select link_payment_provider_id('REF0003', 'sp_123')$$);
select t.must_fail('admin : lecture inverse refusée depuis le navigateur', $$select payment_reference_of('sp_123')$$);
reset role;
select t.ok('le lien est posé', $$select link_payment_provider_id('REF0003', 'sp_123')$$);
select t.eq('on retrouve notre référence depuis celle du prestataire', $$select payment_reference_of('sp_123')$$, 'REF0003');
select t.must_fail('le lien ne se remplace pas', $$select link_payment_provider_id('REF0003', 'sp_999')$$);
select t.must_fail('deux tentatives ne peuvent pas partager le même identifiant', $$select link_payment_provider_id('REF0004', 'sp_123')$$);
select t.must_fail('identifiant vide refusé', $$select link_payment_provider_id('REF0004', '  ')$$);
select t.eq('identifiant inconnu : aucune référence', $$select coalesce(payment_reference_of('sp_inexistant'), 'aucune')$$, 'aucune');

-- ============ Les frais : deux modes, deux traitements ============
reset role; select t.as(5);
select t.must_fail('admin : enregistrement des frais refusé depuis le navigateur', $$select record_payment_fee('REF0005', 100, 'DEDUCTED')$$);
reset role;
select t.ok('mode DEDUCTED : frais enregistrés', $$select record_payment_fee('REF0005', 1400, 'DEDUCTED')$$);
select t.eq('DEDUCTED : les frais sont retenus', $$select fee_xof::text from payment_transactions where provider_reference = 'REF0005'$$, '1400');
select t.ok('mode ADD_ON : frais remis à zéro', $$select record_payment_fee('REF0005', 1400, 'ADD_ON')$$);
select t.eq('ADD_ON : rien à retenir, le voyageur a déjà payé les frais',
  $$select fee_xof::text from payment_transactions where provider_reference = 'REF0005'$$, '0');
select t.eq('les deux enregistrements sont tracés', $$select count(*)::text from audit_logs where action = 'payment.fee_recorded'$$, '2');

-- ============ Un seul remboursement vivant par encaissement ============
reset role;
select t.must_fail('deux remboursements vivants sur le même encaissement : impossible',
  format($$insert into refunds (payment_transaction_id, amount_xof, reason, status)
            select x.id, 1000, 'doublon', 'approuve' from payment_transactions x where x.booking_id = %L$$, t.b(1)));

-- ============ Ce que chacun voit de ses remboursements ============
reset role; select t.as(1);
select t.cnt('le voyageur 1 voit ses deux remboursements', $$select * from my_refunds()$$, 2);
select t.eq('dont celui qui a été payé',
  $$select count(*)::text from my_refunds() where status = 'reussi'$$, '1');
reset role; select t.as(3);
select t.cnt('le propriétaire ne voit aucun remboursement', $$select * from my_refunds()$$, 0);
reset role; select t.as(2);
select t.eq('le voyageur 2 ne voit que le sien',
  $$select count(*)::text from my_refunds()$$, '1');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0010 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
