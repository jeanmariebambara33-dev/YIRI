-- Tests de la migration 0023 : les réclamations.
--
-- Ce qui est éprouvé en priorité : qu'on ne puisse PAS signaler un problème sur le logement de
-- quelqu'un d'autre. Sans ce contrôle, il suffirait d'inventer un identifiant pour salir
-- l'annonce d'un concurrent.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(8), 'demandes', t.u(5));

insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'gestion', 'Villa Koulouba', 'd', 'Ouagadougou', 'K', 'a', 4,2,2, 20000,1, 'publiee', false),
       (t.p(2), t.u(4), 'gestion', 'Villa d''un autre', 'd', 'Ouagadougou', 'Z', 'a', 2,1,1, 10000,1, 'publiee', false);
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status)
values (t.b(1), t.p(1), t.u(1), daterange(current_date - 3, current_date), 2, 20000, 60000, 60000, 'terminee'),
       (t.b(2), t.p(2), t.u(2), daterange(current_date - 3, current_date), 2, 10000, 30000, 30000, 'terminee');

-- ============ Signaler ============
reset role; select t.as(1);
select t.ok('un voyageur signale un problème sur SON séjour',
  format($$select open_support_request('acces_logement', 'La serrure du portail ne fonctionne pas.', null, %L)$$, t.b(1)));
select t.eq('le signalement est rattaché au logement tout seul',
  format($$select count(*)::text from my_support_requests() where titre = 'Villa Koulouba'$$), '1');
select t.eq('il est ouvert', $$select status from my_support_requests()$$, 'ouvert');
select t.must_fail('un message trop court est refusé',
  $$select open_support_request('proprete', 'sale')$$);
select t.must_fail('une catégorie inventée est refusée',
  $$select open_support_request('categorie_bidon', 'Un message assez long pour passer.')$$);

-- LE contrôle qui compte.
select t.must_fail('on ne signale RIEN sur le séjour de quelqu''un d''autre',
  format($$select open_support_request('proprete', 'Logement sale, a eviter absolument.', null, %L)$$, t.b(2)));
select t.must_fail('ni sur le logement de quelqu''un d''autre',
  format($$select open_support_request('annonce_inexacte', 'Cette annonce ment sur la surface.', %L)$$, t.p(2)));
reset role;
select t.eq('aucune calomnie n''a été enregistrée',
  format($$select count(*)::text from support_requests where property_id = %L$$, t.p(2)), '0');

-- Le propriétaire, lui, peut signaler sur SON logement.
select t.as(3);
select t.ok('le propriétaire signale un problème sur SON logement',
  format($$select open_support_request('comportement', 'Le voyageur a laisse le logement en desordre.', %L)$$, t.p(1)));
select t.as(4);
select t.must_fail('mais pas sur celui d''un autre propriétaire',
  format($$select open_support_request('proprete', 'Un message assez long pour passer la validation.', %L)$$, t.p(1)));

-- Un signalement sans logement ni séjour reste possible : question générale.
select t.as(2);
select t.ok('on peut signaler sans viser de logement',
  $$select open_support_request('paiement', 'Je ne retrouve pas le recu de mon paiement.')$$);

-- Garde-fou contre l'inondation.
reset role; select t.as(9);
do $$ begin
  for i in 1..10 loop
    perform open_support_request('autre', 'Signalement numero ' || i || ' pour le test du garde-fou.');
  end loop;
end $$;
select t.must_fail('au-delà de dix signalements en cours, on est arrêté',
  $$select open_support_request('autre', 'Le onzieme signalement, qui doit etre refuse.')$$);

-- ============ Cloisonnement ============
reset role; select t.as(1);
select t.eq('chacun ne voit QUE ses signalements', $$select count(*)::text from my_support_requests()$$, '1');
select t.as(2);
select t.eq('et l''autre voit les siens', $$select count(*)::text from my_support_requests()$$, '1');
select t.cnt('la table ne montre rien d''autre', $$select * from support_requests$$, 1);
select t.must_fail('personne ne lit la file de l''équipe sans autorisation', $$select * from support_queue()$$);
select t.must_fail('ni ne change un statut', 
  format($$select set_support_status((select id from support_requests limit 1), 'clos', 'je ferme moi-meme')$$));
select t.must_fail('ni n''écrit directement dans la table',
  $$update support_requests set status = 'clos'$$);
reset role; select t.as(6);
select t.must_fail('l''équipe « validation » n''a pas à traiter les réclamations', $$select * from support_queue()$$);
select t.as(0);
select t.must_fail('un visiteur ne signale rien',
  $$select open_support_request('autre', 'Un message assez long pour passer.')$$);

-- ============ L'équipe traite ============
reset role; select t.as(8);
select t.ok('l''équipe « demandes » voit la file', $$select * from support_queue()$$);
select t.eq('elle voit tous les signalements', $$select count(*)::text from support_queue()$$, '13');
select t.eq('elle distingue un propriétaire d''un voyageur',
  format($$select role_demandeur from support_queue() where user_id = %L limit 1$$, t.u(3)), 'proprietaire');
select t.eq('et le voyageur comme tel',
  format($$select role_demandeur from support_queue() where user_id = %L limit 1$$, t.u(1)), 'voyageur');
select t.eq('avec le téléphone pour rappeler',
  $$select (count(*) > 0)::text from support_queue() where telephone is null or telephone is not null$$, 'true');

select t.ok('on peut mettre un signalement en cours sans explication',
  format($$select set_support_status((select id from support_requests where user_id = %L), 'en_cours')$$, t.u(1)));
select t.must_fail('mais on ne CLÔT pas sans dire ce qui a été fait',
  format($$select set_support_status((select id from support_requests where user_id = %L), 'resolu')$$, t.u(1)));
select t.ok('avec une résolution, la clôture est possible',
  format($$select set_support_status((select id from support_requests where user_id = %L), 'resolu', 'Serrure remplacee le jour meme.')$$, t.u(1)));
reset role;
select t.eq('la date de clôture est posée',
  format($$select (closed_at is not null)::text from support_requests where user_id = %L$$, t.u(1)), 'true');
select t.eq('la personne est prévenue',
  format($$select count(*)::text from notifications where user_id = %L and type = 'support.traite'$$, t.u(1)), '1');
select t.eq('et le journal garde qui a tranché et pourquoi',
  $$select count(*)::text from audit_logs where action = 'support.status' and reason like 'Serrure remplacee%'$$, '1');
select t.as(1);
select t.eq('le demandeur lit la réponse',
  $$select resolution from my_support_requests()$$, 'Serrure remplacee le jour meme.');

-- Un signalement clos libère une place sous le garde-fou.
reset role; select t.as(8);
select t.ok('clore libère de la place',
  format($$select set_support_status((select id from support_requests where user_id = %L limit 1), 'clos', 'Doublon avec un autre signalement.')$$, t.u(9)));
select t.as(9);
select t.ok('le dixième redevient possible',
  $$select open_support_request('autre', 'Un signalement de plus, maintenant que de la place existe.')$$);

-- ============ L'équipe est prévenue ============
reset role;
select t.eq('l''équipe « demandes » a été prévenue de chaque signalement',
  format($$select (count(*) >= 3)::text from notifications where user_id = %L and type = 'support.ouvert.equipe'$$, t.u(8)), 'true');
select t.eq('l''administrateur aussi',
  format($$select (count(*) >= 3)::text from notifications where user_id = %L and type = 'support.ouvert.equipe'$$, t.u(5)), 'true');
select t.eq('l''équipe « validation », non',
  format($$select count(*)::text from notifications where user_id = %L and type = 'support.ouvert.equipe'$$, t.u(6)), '0');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0023 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
