// Tests des fonctions pures qui partent VRAIMENT dans le site livré.
//
// Ils remplacent src/lib/payments.test.ts, qui éprouvait le faux serveur du navigateur :
// ce code a été supprimé, et ses neuf tests ne garantissaient donc plus rien de ce qui est
// livré. Le vrai chemin de paiement est éprouvé dans la base (supabase/tests/0009 et 0010)
// et dans le navigateur (scripts/paiement-e2e.mjs).
import test from "node:test";
import assert from "node:assert/strict";
import { notificationLabel, auditActionLabel, arriveBientot, type AppNotification } from "./api";

const n = (type: string, payload: Record<string, unknown> = {}): AppNotification =>
  ({ id: "x", type, payload, created_at: "2026-10-12T08:00:00Z", read_at: null } as AppNotification);

test("chaque notification se lit en français, jamais en code technique", () => {
  assert.equal(notificationLabel(n("booking.confirmee", { titre: "Studio Gounghin" })),
               "Réservation payée sur Studio Gounghin");
  assert.equal(notificationLabel(n("subscription.expiree")),
               "Votre abonnement a expiré : vos annonces sont masquées");
  assert.equal(notificationLabel(n("free_pass.offert")), "YIRI vous a offert un accès gratuit");
});

test("le singulier et le pluriel des jours sont corrects", () => {
  assert.match(notificationLabel(n("subscription.bientot_expiree", { jours: 1 })), /dans 1 jour$/);
  assert.match(notificationLabel(n("subscription.bientot_expiree", { jours: 7 })), /dans 7 jours$/);
});

test("une charge utile absente ou abîmée ne casse pas l'affichage", () => {
  assert.equal(notificationLabel(n("booking.confirmee")), "Une réservation a été payée");
  assert.equal(notificationLabel(n("subscription.bientot_expiree")), "Votre abonnement expire bientôt");
  assert.equal(notificationLabel(n("booking.confirmee", { titre: 42 })), "Une réservation a été payée");
});

test("un type inconnu reste lisible plutôt que d'afficher du code", () => {
  assert.equal(notificationLabel(n("listing.chose_inedite")), "Votre annonce a changé de statut");
  assert.equal(notificationLabel(n("truc.jamais.vu")), "Nouvelle information sur votre compte");
});

test("le montant d'un remboursement est écrit avec des séparateurs", () => {
  assert.match(notificationLabel(n("refund.automatique", { montant: 40000 })), /40\s?000 FCFA/);
});

test("les actions du journal sont traduites, et l'inconnu reste lisible", () => {
  assert.equal(auditActionLabel("listing.approve"), "Annonce validée");
  assert.equal(auditActionLabel("free_pass.revoke"), "Accès offert retiré");
  assert.equal(auditActionLabel("quelque.chose_de_neuf"), "quelque chose de neuf");
});

test("« arrive bientôt » couvre les sept jours qui viennent, pas le passé", () => {
  const j = (n: number) => {
    const d = new Date(); d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  };
  assert.equal(arriveBientot(j(0)), true);
  assert.equal(arriveBientot(j(2)), true);
  assert.equal(arriveBientot(j(7)), true);
  assert.equal(arriveBientot(j(8)), false);
  assert.equal(arriveBientot(j(-1)), false);
});
