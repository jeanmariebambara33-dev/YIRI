// Tests du chiffrement Web Push, sur le fichier RÉELLEMENT déployé.
//
// Ce qui est éprouvé ici n'est pas « le code ne plante pas » : c'est que le message chiffré est
// DÉCHIFFRABLE par le destinataire. La vérification se fait en refaisant le chemin inverse avec
// node:crypto — une implémentation indépendante de celle qui chiffre. Si les deux tombent
// d'accord sur le texte clair, la formule de la RFC 8291 est la bonne. Un test qui se
// contenterait de rappeler la fonction de chiffrement ne prouverait rien.
//
// Usage : node --experimental-strip-types supabase/functions/tests/push.test.mjs

import { createHmac, createDecipheriv, createECDH, webcrypto } from "node:crypto";

globalThis.Deno = { env: { get: (k) => process.env[k] }, serve: () => {} };

const mod = await import("../push-envoyer/index.ts");
const { chiffrer, enteteVapid, importerCleSignature, texteAlerte, b64urlVersOctets, octetsVersB64url } = mod;

let reussis = 0, total = 0;
const echecs = [];
const ok = (label, condition, detail = "") => {
  total++;
  if (condition) reussis++; else echecs.push(`${label}${detail ? " — " + detail : ""}`);
};

const utf8 = (s) => new TextEncoder().encode(s);
const cat = (...m) => {
  const out = new Uint8Array(m.reduce((n, x) => n + x.length, 0));
  let i = 0; for (const x of m) { out.set(x, i); i += x.length; }
  return out;
};

// ---------------------------------------------------------------------------
// HKDF refait à la main avec node:crypto (HMAC seulement), pour ne rien partager
// avec l'implémentation testée.
// ---------------------------------------------------------------------------
function hkdfIndependant(sel, ikm, info, octets) {
  const prk = createHmac("sha256", Buffer.from(sel)).update(Buffer.from(ikm)).digest();
  const t = createHmac("sha256", prk).update(Buffer.concat([Buffer.from(info), Buffer.from([1])])).digest();
  return new Uint8Array(t.subarray(0, octets));
}

/** Le rôle du destinataire : refaire l'accord de clés et déchiffrer. */
function dechiffrerCommeUnNavigateur(corps, ecdhNavigateur, authSecret) {
  const sel = corps.subarray(0, 16);
  const longueurCle = corps[20];
  const asPub = corps.subarray(21, 21 + longueurCle);
  const chiffre = corps.subarray(21 + longueurCle);
  const uaPub = new Uint8Array(ecdhNavigateur.getPublicKey());

  const partage = new Uint8Array(ecdhNavigateur.computeSecret(Buffer.from(asPub)));
  const ikm = hkdfIndependant(authSecret, partage,
    cat(utf8("WebPush: info"), new Uint8Array([0]), uaPub, asPub), 32);
  const cek = hkdfIndependant(sel, ikm, cat(utf8("Content-Encoding: aes128gcm"), new Uint8Array([0])), 16);
  const nonce = hkdfIndependant(sel, ikm, cat(utf8("Content-Encoding: nonce"), new Uint8Array([0])), 12);

  const tag = chiffre.subarray(chiffre.length - 16);
  const d = createDecipheriv("aes-128-gcm", Buffer.from(cek), Buffer.from(nonce));
  d.setAuthTag(Buffer.from(tag));
  const clair = Buffer.concat([d.update(Buffer.from(chiffre.subarray(0, chiffre.length - 16))), d.final()]);
  return clair;
}

// ---------------------------------------------------------------------------
// 1. Un message chiffré est déchiffrable par son destinataire, et par lui seul
// ---------------------------------------------------------------------------
const navigateur = createECDH("prime256v1");
navigateur.generateKeys();
const authSecret = new Uint8Array(webcrypto.getRandomValues(new Uint8Array(16)));
const p256dh = octetsVersB64url(new Uint8Array(navigateur.getPublicKey()));
const auth = octetsVersB64url(authSecret);

const TEXTE = JSON.stringify({ titre: "Réservation payée", corps: "Sur Studio Gounghin.", lien: "#equipe" });
const corps = await chiffrer(TEXTE, p256dh, auth);

ok("le corps chiffré a la forme de la RFC 8188 (sel, taille, clé)", corps.length > 21 + 65 + 16);
ok("la longueur de clé annoncée est bien 65", corps[20] === 65);
ok("la clé éphémère est non compressée", corps[21] === 0x04);
ok("la taille d'enregistrement annoncée est 4096",
  new DataView(corps.buffer, corps.byteOffset + 16, 4).getUint32(0, false) === 4096);

let clair = null;
try { clair = dechiffrerCommeUnNavigateur(corps, navigateur, authSecret); } catch (e) { echecs.push("déchiffrement : " + e.message); }
ok("le destinataire déchiffre le message", clair !== null);
ok("et retrouve EXACTEMENT le texte envoyé", clair !== null && clair.subarray(0, clair.length - 1).toString("utf8") === TEXTE);
ok("le dernier octet est le marqueur de fin d'enregistrement (0x02)",
  clair !== null && clair[clair.length - 1] === 0x02);

// Les accents doivent survivre : une alerte française illisible ne sert à rien.
const ACCENTS = "Réservation payée — l'équipe doit préparer l'arrivée. Coût : 40 000 FCFA.";
let clairAccents = null;
try {
  clairAccents = dechiffrerCommeUnNavigateur(await chiffrer(ACCENTS, p256dh, auth), navigateur, authSecret);
} catch (e) { echecs.push("déchiffrement avec accents : " + e.message); }
ok("les accents et les espaces insécables passent intacts",
  clairAccents !== null && clairAccents.subarray(0, clairAccents.length - 1).toString("utf8") === ACCENTS);

// Un autre appareil ne doit RIEN pouvoir lire du message destiné au premier.
const autre = createECDH("prime256v1");
autre.generateKeys();
let lu = false;
try { dechiffrerCommeUnNavigateur(corps, autre, authSecret); lu = true; } catch { lu = false; }
ok("un autre appareil ne peut pas déchiffrer le message", !lu);

// Le même secret d'appareil mais une mauvaise clé : échec aussi.
let luMauvaisAuth = false;
try {
  dechiffrerCommeUnNavigateur(corps, navigateur, new Uint8Array(16));
  luMauvaisAuth = true;
} catch { luMauvaisAuth = false; }
ok("un mauvais secret d'appareil ne déchiffre rien", !luMauvaisAuth);

// Deux envois du même texte ne doivent jamais donner le même corps (sel et clé éphémère tirés
// au hasard) : sinon un observateur reconnaîtrait les messages répétés.
const corps2 = await chiffrer(TEXTE, p256dh, auth);
ok("deux envois du même texte produisent deux corps différents",
  Buffer.compare(Buffer.from(corps), Buffer.from(corps2)) !== 0);
// Le sel ET la clé éphémère doivent changer tous les deux. Un sel figé passerait inaperçu si
// l'on ne comparait que les corps entiers, puisque la clé éphémère suffit à les différencier.
ok("le sel est tiré au hasard à chaque envoi",
  Buffer.compare(Buffer.from(corps.subarray(0, 16)), Buffer.from(corps2.subarray(0, 16))) !== 0);
ok("le sel n'est pas une suite de zéros",
  !corps.subarray(0, 16).every((o) => o === 0));
ok("la clé éphémère change aussi à chaque envoi",
  Buffer.compare(Buffer.from(corps.subarray(21, 86)), Buffer.from(corps2.subarray(21, 86))) !== 0);
let clair2 = null;
try { clair2 = dechiffrerCommeUnNavigateur(corps2, navigateur, authSecret); } catch (e) { echecs.push("second déchiffrement : " + e.message); }
ok("mais les deux se déchiffrent sur le même texte",
  clair2 !== null && clair2.subarray(0, -1).toString("utf8") === TEXTE);

// Un seul octet modifié en vol doit faire échouer le déchiffrement (c'est le rôle du sceau GCM).
const abime = Uint8Array.from(corps);
abime[abime.length - 20] ^= 0x01;
let luAbime = false;
try { dechiffrerCommeUnNavigateur(abime, navigateur, authSecret); luAbime = true; } catch { luAbime = false; }
ok("un message modifié en route est rejeté", !luAbime);

// ---------------------------------------------------------------------------
// 2. Les clés mal formées sont refusées, et le disent
// ---------------------------------------------------------------------------
const refuse = async (fn) => { try { await fn(); return false; } catch { return true; } };
ok("une clé d'appareil tronquée est refusée",
  await refuse(() => chiffrer("x", octetsVersB64url(new Uint8Array(32)), auth)));
ok("une clé d'appareil compressée est refusée",
  await refuse(() => chiffrer("x", octetsVersB64url(cat(new Uint8Array([0x02]), new Uint8Array(64))), auth)));
ok("un secret d'appareil de mauvaise taille est refusé",
  await refuse(() => chiffrer("x", p256dh, octetsVersB64url(new Uint8Array(12)))));

// ---------------------------------------------------------------------------
// 3. VAPID : le jeton est signé par la clé privée et vérifiable avec la publique
// ---------------------------------------------------------------------------
const paireVapid = await webcrypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
const pubBrute = new Uint8Array(await webcrypto.subtle.exportKey("raw", paireVapid.publicKey));
const jwkPriv = await webcrypto.subtle.exportKey("jwk", paireVapid.privateKey);
const VAPID_PUB = octetsVersB64url(pubBrute);
const VAPID_PRIV = jwkPriv.d;

const cleSig = await importerCleSignature(VAPID_PUB, VAPID_PRIV);
const entete = await enteteVapid("https://fcm.googleapis.com/fcm/send/abc123", VAPID_PUB, cleSig, "https://yiri.bf", 1760000000000);

ok("l'en-tête annonce bien vapid", entete.startsWith("vapid t="));
ok("et transporte la clé publique", entete.includes(`k=${VAPID_PUB}`));

const jeton = entete.slice("vapid t=".length).split(",")[0].trim();
const [h, c, s] = jeton.split(".");
const enteteJwt = JSON.parse(Buffer.from(h.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
const corpsJwt = JSON.parse(Buffer.from(c.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
ok("l'algorithme est ES256", enteteJwt.alg === "ES256" && enteteJwt.typ === "JWT");
ok("le destinataire est l'ORIGINE du service, pas l'adresse complète",
  corpsJwt.aud === "https://fcm.googleapis.com");
ok("l'adresse complète de l'appareil n'est PAS dans le jeton", !jeton.includes("abc123"));
ok("le sujet est présent", corpsJwt.sub === "https://yiri.bf");
ok("le jeton expire dans douze heures", corpsJwt.exp === 1760000000 + 12 * 3600);

const signatureValide = await webcrypto.subtle.verify(
  { name: "ECDSA", hash: "SHA-256" }, paireVapid.publicKey,
  b64urlVersOctets(s), utf8(`${h}.${c}`),
);
ok("la signature est vérifiable avec la clé publique", signatureValide === true);

const signatureFausse = await webcrypto.subtle.verify(
  { name: "ECDSA", hash: "SHA-256" }, paireVapid.publicKey,
  b64urlVersOctets(s), utf8(`${h}.${c}x`),
);
ok("un contenu modifié invalide la signature", signatureFausse === false);

// Deux services différents reçoivent deux jetons différents : un jeton ne peut pas être rejoué
// d'un service vers un autre.
const enteteApple = await enteteVapid("https://web.push.apple.com/xyz", VAPID_PUB, cleSig, "https://yiri.bf", 1760000000000);
ok("chaque service a son propre jeton", enteteApple !== entete);

ok("une clé publique de mauvaise taille est refusée",
  await refuse(() => importerCleSignature(octetsVersB64url(new Uint8Array(33)), VAPID_PRIV)));
ok("une clé privée de mauvaise taille est refusée",
  await refuse(() => importerCleSignature(VAPID_PUB, octetsVersB64url(new Uint8Array(16)))));

// ---------------------------------------------------------------------------
// 4. Le texte des alertes
// ---------------------------------------------------------------------------
const a1 = texteAlerte("booking.confirmee.equipe", { titre: "Studio Gounghin" });
ok("une réservation payée s'annonce en français", a1.titre === "Réservation payée" && a1.corps.includes("Studio Gounghin"));
ok("et renvoie l'équipe vers son espace", a1.lien === "#equipe");
ok("la même alerte personnelle renvoie le propriétaire vers le SIEN",
  texteAlerte("booking.confirmee", { titre: "Studio" }).lien === "#espace");
ok("une charge utile vide ne casse rien",
  texteAlerte("booking.confirmee", {}).corps.length > 0);
ok("le pluriel des jours est juste",
  texteAlerte("subscription.bientot_expiree", { jours: 1 }).corps.includes("1 jour.") &&
  texteAlerte("subscription.bientot_expiree", { jours: 7 }).corps.includes("7 jours"));
ok("un type inconnu reste lisible et ne montre aucun code",
  texteAlerte("truc.jamais.vu", {}).titre === "YIRI" && !texteAlerte("truc.jamais.vu", {}).corps.includes("truc."));
ok("un type d'équipe inconnu renvoie vers l'espace équipe",
  texteAlerte("chose.nouvelle.equipe", {}).lien === "#equipe");
ok("aucun montant n'est affiché avec une espace insécable (illisible sur certains téléphones)",
  !/[  ]/.test(texteAlerte("refund.automatique", { montant: 40000 }).corps));
ok("le montant est bien là", texteAlerte("refund.automatique", { montant: 40000 }).corps.includes("40 000 FCFA"));

// Anti-dérive : tout type traité par le site doit être traité ici aussi.
const api = await import("node:fs").then((fs) => fs.readFileSync("src/lib/api.ts", "utf8"));
const typesDuSite = [...api.matchAll(/case "([a-z_]+\.[a-z_.]+)":/g)].map((m) => m[1]);
const source = await import("node:fs").then((fs) => fs.readFileSync("supabase/functions/push-envoyer/index.ts", "utf8"));
const manquants = typesDuSite.filter((t) => !source.includes(`"${t}"`));
ok(`les ${typesDuSite.length} types connus du site sont tous traités à l'envoi`,
  manquants.length === 0, manquants.join(", "));

console.log(`${reussis} / ${total} contrôles du push réussis`);
for (const e of echecs) console.log("ECHEC", e);
process.exit(echecs.length === 0 ? 0 : 1);
