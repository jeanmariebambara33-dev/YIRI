import * as React from "react";
import { useStore } from "../store";
import { submitApplication } from "../lib/api";
import { Button, Field, inputCls, Money } from "../ui";
import { buildStatement, PLANS } from "../lib/pricing";
import type { City } from "../lib/domain";
import { CityField } from "../cityfield";
import { PACKS, type Pack } from "../data/packs";
import { PriceBlock } from "./owners";

function OfferHero({ eyebrow, title, text, children }: { eyebrow: string; title: string; text: string; children?: React.ReactNode }) {
  return (
    <header className="flex flex-col gap-4 pt-6">
      <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent-ink">{eyebrow}</p>
      <h1 className="font-display text-[clamp(2rem,5vw,3.2rem)] font-extrabold leading-[1.02] tracking-tight text-ink text-balance">{title}</h1>
      <p className="max-w-[60ch] text-lg leading-relaxed text-muted">{text}</p>
      {children}
    </header>
  );
}

function Duties({ yiri, owner }: { yiri: string[]; owner: string[] }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {[["YIRI s'occupe de", yiri], ["Vous vous occupez de", owner]].map(([t, list]) => (
        <div key={t as string} className="flex flex-col gap-3 rounded-3xl border border-line bg-surface p-6">
          <h2 className="font-display text-lg font-bold text-ink">{t as string}</h2>
          <ul className="flex flex-col gap-2 text-sm text-ink">
            {(list as string[]).map((x) => <li key={x} className="flex gap-2"><span className="text-accent" aria-hidden="true">●</span>{x}</li>)}
          </ul>
        </div>
      ))}
    </div>
  );
}

function DetailSections({ pack }: { pack: Pack }) {
  return (
    <>
      <section className="grid gap-4 md:grid-cols-2">
        <div className="flex flex-col gap-2 rounded-3xl bg-sunk p-6"><h2 className="font-display text-lg font-bold text-ink">À qui s'adresse cette solution ?</h2><p className="text-sm leading-relaxed text-muted">{pack.profile} {pack.need}</p></div>
        <div className="flex flex-col gap-2 rounded-3xl bg-sunk p-6"><h2 className="font-display text-lg font-bold text-ink">Ce que vous pouvez en attendre</h2><p className="text-sm leading-relaxed text-muted">{pack.value}</p></div>
      </section>
      <Duties yiri={pack.included} owner={pack.ownerDuties} />
      <section className="flex flex-col gap-3 rounded-3xl border border-line bg-surface p-6">
        <h2 className="font-display text-lg font-bold text-ink">Ce qui n'est pas couvert</h2>
        <ul className="flex flex-col gap-2 text-sm text-ink">{pack.limits.map((x) => <li key={x} className="flex gap-2"><span className="text-accent" aria-hidden="true">•</span>{x}</li>)}</ul>
      </section>
      <ol className="flex flex-col gap-3 rounded-3xl bg-sunk p-6 text-sm text-ink">
        <li className="font-display text-lg font-bold">Comment commencer</li>
        {pack.steps.map((s, i) => <li key={s} className="flex gap-3"><span className="font-mono text-accent-ink tabular-nums">{i + 1}.</span>{s}</li>)}
      </ol>
    </>
  );
}

function PriceAndCommitment({ pack, children }: { pack: Pack; children?: React.ReactNode }) {
  return (
    <section className="grid gap-4 md:grid-cols-2" aria-label="Tarif et engagement">
      <div className="flex flex-col gap-3 rounded-3xl border border-line bg-surface p-6">
        <h2 className="font-display text-lg font-bold text-ink">Combien ça coûte ?</h2>
        <PriceBlock pack={pack} />
        {pack.id === "visibilite" && (
          <div className="grid gap-2 sm:grid-cols-2">
            {(Object.keys(PLANS) as (keyof typeof PLANS)[]).map((k) => (
              <div key={k} className="rounded-2xl border border-line p-3 text-sm"><p className="font-semibold text-ink">{PLANS[k].label}</p><p className="tabular-nums text-muted"><Money value={PLANS[k].price} /></p>{k === "annuel" && <p className="text-xs text-muted">Soit 2 500 FCFA par mois.</p>}</div>
            ))}
          </div>
        )}
      </div>
      <div className="flex flex-col gap-2 rounded-3xl border border-line bg-surface p-6">
        <h2 className="font-display text-lg font-bold text-ink">Engagement et résiliation</h2>
        <p className="text-sm leading-relaxed text-muted">{pack.commitment}</p>
        {children}
      </div>
    </section>
  );
}

export function OfferAnnonce() {
  const { go } = useStore();
  const pack = PACKS.visibilite;
  return (
    <div className="flex flex-col gap-10 py-6">
      <OfferHero eyebrow={pack.name} title="Votre logement visible partout au Burkina Faso." text={pack.benefit + " Vous gérez, YIRI vous rend visible."} />
      <DetailSections pack={pack} />
      <PriceAndCommitment pack={pack} />
      <div className="flex flex-col gap-2 rounded-3xl bg-brand p-6 text-on-brand">
        <h2 className="font-display text-xl font-bold">Prêt à publier ?</h2>
        <p className="text-sm opacity-90">Vous créez votre annonce maintenant. Elle sera vérifiée par l'équipe YIRI, puis publiée après paiement de l'abonnement.</p>
        <Button variant="secondary" className="mt-1 self-start" onClick={() => go({ name: "nouvelle-annonce" })}>Publier mon logement</Button>
      </div>
    </div>
  );
}

export function OfferGestion() {
  const { go } = useStore();
  const pack = PACKS.serenite;
  const [rlp, setRlp] = React.useState(500_000);
  const [ownerExp, setOwnerExp] = React.useState(45_000);
  const st = buildStatement({ accommodationCollected: rlp, deductPaymentFees: false, ownerExpenses: ownerExp });
  return (
    <div className="flex flex-col gap-10 py-6">
      <OfferHero eyebrow={pack.name} title="Votre logement meublé, géré de l'arrivée au départ." text={pack.value} />
      <DetailSections pack={pack} />
      <PriceAndCommitment pack={pack} />
      <section className="grid gap-6 rounded-3xl border border-line bg-surface p-6 md:grid-cols-2">
        <div className="flex flex-col gap-4">
          <h2 className="font-display text-xl font-bold text-ink">Comprendre un relevé : simulateur</h2>
          <p className="text-sm text-muted">Hypothèse de départ : 60 % des revenus locatifs partageables au propriétaire, 40 % à YIRI. Les montants sont des exemples, pas une promesse de revenus.</p>
          <Field label="Revenus locatifs partageables du mois" htmlFor="sim-rlp">
            <input id="sim-rlp" type="range" min={0} max={1_000_000} step={10_000} value={rlp} onChange={(e) => setRlp(+e.target.value)} className="accent-[var(--brand)]" />
          </Field>
          <p className="text-lg font-bold text-ink"><Money value={rlp} /></p>
          <Field label="Charges du propriétaire (eau, électricité, Wi-Fi)" htmlFor="sim-exp">
            <input id="sim-exp" type="number" step={1000} min={0} className={inputCls} value={ownerExp} onChange={(e) => setOwnerExp(Math.max(0, Math.round(+e.target.value || 0)))} />
          </Field>
        </div>
        <dl className="flex flex-col gap-3 self-center rounded-2xl bg-sunk p-5 text-sm">
          <div className="flex justify-between"><dt className="text-muted">Part propriétaire (60 %)</dt><dd><Money value={st.ownerShare} className="font-semibold text-ink" /></dd></div>
          <div className="flex justify-between"><dt className="text-muted">Commission YIRI (40 %)</dt><dd><Money value={st.yiriCommission} className="text-ink" /></dd></div>
          <div className="flex justify-between"><dt className="text-muted">Vos charges</dt><dd className="text-ink">− <Money value={st.ownerExpenses} /></dd></div>
          <div className="flex justify-between border-t border-line-strong pt-3 text-base font-bold text-ink"><dt>Vous conservez</dt><dd><Money value={st.ownerNet} /></dd></div>
          <p className="text-xs text-muted">Avant autres dépenses de propriété et fiscalité. Le contrat précise la base partageable, les délais de versement et les justificatifs.</p>
        </dl>
      </section>
      <div className="flex flex-col gap-2 rounded-3xl bg-brand p-6 text-on-brand">
        <h2 className="font-display text-xl font-bold">Envie d'en discuter ?</h2>
        <p className="text-sm opacity-90">Vous envoyez une demande à l'équipe YIRI, qui vous rappelle. Rien n'est publié ni signé à cette étape.</p>
        <Button variant="secondary" className="mt-1 self-start" onClick={() => go({ name: "demande", pack: "serenite" })}>Demander à être contacté</Button>
      </div>
    </div>
  );
}

export function OfferPartenariat() {
  const empty = { contactName: "", phone: "", city: "Ouagadougou" as City, district: "", kind: "Villa", rooms: 2, condition: "", works: "" };
  const [f, setF] = React.useState(empty);
  const [consent, setConsent] = React.useState(false);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [sent, setSent] = React.useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: k === "rooms" ? +e.target.value : e.target.value });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (f.contactName.trim().length < 2) er.contactName = "Indiquez votre nom.";
    if (!/^[+\d][\d\s]{7,}$/.test(f.phone.trim())) er.phone = "Numéro invalide. Exemple : +226 70 12 34 56.";
    if (f.district.trim().length < 2) er.district = "Indiquez le quartier.";
    if (f.condition.trim().length < 10) er.condition = "Décrivez l'état du bien en une ou deux phrases.";
    if (!consent) er.consent = "Votre accord est nécessaire pour traiter la candidature.";
    setErrors(er);
    if (Object.keys(er).length) return;
    // Vers la BASE, plus vers le magasin de démonstration : une candidature doit arriver
    // chez YIRI, pas rester dans le navigateur de celui qui l'envoie.
    setErrors({});
    void (async () => {
      try {
        await submitApplication({
          contact_name: f.contactName, contact_phone: f.phone, city: f.city,
          district: f.district, property_kind: f.kind, rooms: f.rooms,
          condition_notes: f.condition, estimated_works: f.works,
        });
        setSent(true); setF(empty); setConsent(false);
      } catch (err) {
        setErrors({ envoi: err instanceof Error ? err.message : "L'envoi a échoué. Réessayez." });
      }
    })();
  }

  return (
    <div className="flex flex-col gap-10 py-6">
      <OfferHero eyebrow="YIRI Partenariat immobilier" title="Votre bien vide, équipé et exploité par YIRI." text={PACKS.partenariat.value} />
      <DetailSections pack={PACKS.partenariat} />
      <PriceAndCommitment pack={PACKS.partenariat} />
      <div className="rounded-2xl border border-warn/40 bg-warn/10 p-4 text-sm leading-relaxed text-ink">
        Cette candidature n'engage ni vous ni YIRI. Aucun montant de loyer ni rendement n'est promis avant la visite, l'étude chiffrée et la signature d'un contrat validé juridiquement.
      </div>
      {sent ? (
        <div className="flex flex-col gap-3 rounded-3xl border border-line bg-surface p-6">
          <h2 className="font-display text-xl font-bold text-ink">Candidature reçue</h2>
          <p className="text-muted">L'équipe YIRI étudie votre dossier et vous contacte pour une présélection.</p>
          <Button variant="secondary" className="self-start" onClick={() => setSent(false)}>Envoyer une autre candidature</Button>
        </div>
      ) : (
        <form onSubmit={submit} noValidate className="grid gap-5 rounded-3xl border border-line bg-surface p-6 sm:grid-cols-2">
          <h2 className="font-display text-xl font-bold text-ink sm:col-span-2">Proposer mon bien : envoyer ma candidature</h2>
          <Field label="Nom complet" htmlFor="pa-name" error={errors.contactName}><input id="pa-name" className={inputCls} value={f.contactName} onChange={set("contactName")} autoComplete="name" /></Field>
          <Field label="Téléphone" htmlFor="pa-phone" error={errors.phone}><input id="pa-phone" className={inputCls} value={f.phone} onChange={set("phone")} inputMode="tel" placeholder="+226 70 12 34 56" /></Field>
          <CityField id="pa-city" value={f.city} onChange={(v) => setF({ ...f, city: v })} />
          <Field label="Quartier" htmlFor="pa-district" error={errors.district}><input id="pa-district" className={inputCls} value={f.district} onChange={set("district")} /></Field>
          <Field label="Type de bien" htmlFor="pa-kind"><select id="pa-kind" className={inputCls} value={f.kind} onChange={set("kind")}><option>Villa</option><option>Appartement</option><option>Studio</option><option>Chambre-salon</option></select></Field>
          <Field label="Nombre de chambres" htmlFor="pa-rooms"><input id="pa-rooms" type="number" min={0} max={10} className={inputCls} value={f.rooms} onChange={set("rooms")} /></Field>
          <div className="sm:col-span-2"><Field label="État actuel du bien" htmlFor="pa-cond" error={errors.condition}><textarea id="pa-cond" rows={3} className={inputCls} value={f.condition} onChange={set("condition")} placeholder="Ex. : construction récente, carrelage neuf, pas de climatisation." /></Field></div>
          <div className="sm:col-span-2"><Field label="Travaux ou équipements à prévoir (estimation)" htmlFor="pa-works" hint="Facultatif. Les photos seront demandées lors de la présélection."><textarea id="pa-works" rows={2} className={inputCls} value={f.works} onChange={set("works")} /></Field></div>
          <div className="flex flex-col gap-1 sm:col-span-2">
            <label className="flex items-start gap-3 text-sm text-ink" htmlFor="pa-consent">
              <input id="pa-consent" type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-1 size-4 accent-[var(--brand)]" />
              J'accepte que YIRI utilise ces informations pour étudier ma candidature et me recontacter.
            </label>
            {errors.consent && <p className="text-xs font-medium text-danger">{errors.consent}</p>}
          </div>
          {/* Un échec d'envoi doit se voir : sans ça, le visiteur croirait sa candidature partie. */}
          {errors.envoi && (
            <p role="alert" className="sm:col-span-2 rounded-xl border border-danger/40 bg-danger/10 px-3.5 py-2.5 text-sm font-medium text-danger">
              {errors.envoi}
            </p>
          )}
          <Button type="submit" className="sm:col-span-2 sm:justify-self-start">Envoyer ma candidature</Button>
        </form>
      )}
    </div>
  );
}
