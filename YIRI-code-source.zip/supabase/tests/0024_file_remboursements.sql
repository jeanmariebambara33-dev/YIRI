-- Tests de la migration 0024 : la file des remboursements transporte la raison de l'échec.
--
-- Ce qui est éprouvé : qu'un remboursement échoué arrive à l'équipe AVEC son motif. Avant la
-- 0024, la colonne n'était pas renvoyée : l'écran affichait « échoué » et rien d'autre, alors
-- que la raison était écrite en base. Un défaut invisible — une propriété absente vaut
-- « undefined » et la ligne s'effaçait sans bruit. C'est le contrôle des types qui l'a trouvé.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 6) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values (t.u(6), 'paiements', t.u(5));

insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'gestion', 'Villa Koulouba', 'd', 'Ouagadougou', 'K', 'a', 4,2,2, 20000,1, 'publiee', false);
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status)
values (t.b(1), t.p(1), t.u(1), daterange(current_date - 5, current_date - 2), 2, 20000, 60000, 60000, 'terminee');
insert into payment_attempts (reference, object, target_id, amount_xof, created_by, provider, payer_account)
values ('REF-0024', 'reservation', t.b(1), 60000, t.u(1), 'saspay', '+22600000000');
insert into payment_transactions (booking_id, purpose, amount_xof, status, provider_reference, idempotency_key)
values (t.b(1), 'booking', 60000, 'reussi', 'REF-0024', 'idem-0024');
insert into refunds (payment_transaction_id, amount_xof, status, reason, failure_reason)
select id, 30000, 'echoue', 'Annulation du voyageur', 'Compte du payeur inconnu chez le prestataire'
  from payment_transactions where provider_reference = 'REF-0024';

\o
-- ---------------------------------------------------------------- l'équipe « paiements »
reset role; select t.as(6);

select t.eq('le motif d''échec remonte jusqu''à l''équipe',
  $$select failure_reason from refunds_queue(10) limit 1$$,
  'Compte du payeur inconnu chez le prestataire');

-- Les colonnes d'origine n'ont pas bougé : ajouter une colonne ne doit rien déplacer.
select t.eq('le montant est intact',
  $$select amount_xof::text from refunds_queue(10) limit 1$$, '30000');
select t.eq('le payeur est toujours connu',
  $$select payer_known::text from refunds_queue(10) limit 1$$, 'true');
select t.eq('le statut est intact',
  $$select status from refunds_queue(10) limit 1$$, 'echoue');

-- ---------------------------------------------------------------- les autres restent dehors
-- Ajouter une colonne n'ouvre pas la porte : la permission est toujours exigée.
reset role; select t.as(1);
select t.must_fail('un voyageur n''ouvre pas la file des remboursements',
  $$select * from refunds_queue(10)$$);
reset role; select t.as(3);
select t.must_fail('un propriétaire non plus',
  $$select * from refunds_queue(10)$$);
reset role; select t.as(0);
select t.must_fail('un visiteur non connecté encore moins',
  $$select * from refunds_queue(10)$$);

reset role;
select label, case when pass then 'OK  ' else 'ECHEC' end as etat, coalesce(detail, '') from t.results order by id;
select count(*) filter (where not pass) || ' échec(s) sur ' || count(*) || ' contrôles' from t.results;
