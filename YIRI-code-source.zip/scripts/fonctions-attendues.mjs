// Fabrique supabase/preprod/fonctions_manquantes.sql à partir des migrations elles-mêmes.
//
// Pourquoi ce script existe : la migration 0008 n'a jamais été appliquée sur le projet en ligne,
// et personne ne s'en est aperçu pendant des semaines. L'écran des pièces d'identité affichait
// « Impossible de lire la file d'attente » et c'est tout. Un contrôle écrit à la main se serait
// désynchronisé au bout de deux migrations ; celui-ci se régénère depuis la source.
//
// Usage : node scripts/fonctions-attendues.mjs
import fs from "node:fs";
import path from "node:path";

const RACINE = path.resolve(new URL("..", import.meta.url).pathname);
const DOSSIER = path.join(RACINE, "supabase/migrations");

const attendues = new Map();   // "public.nom(types)" -> numéro de migration

// Les « create » et les « drop » sont lus DANS L'ORDRE DU FICHIER, pas en deux passes.
//
// Traiter d'abord tous les create puis tous les drop paraissait équivalent. Ça ne l'est pas : la
// migration 0024 supprime refunds_queue(int) puis la recrée avec une colonne de plus. En deux
// passes, le drop effaçait l'entrée APRÈS le create, et la fonction disparaissait de la liste
// attendue — donc son absence en ligne n'aurait plus jamais été signalée. Exactement le trou que
// ce fichier existe pour empêcher.
const CREATE = /create\s+(?:or\s+replace\s+)?function\s+([a-z_0-9]+)\s*\(([^)]*)\)/gi;
const DROP = /drop\s+function\s+(?:if\s+exists\s+)?([a-z_0-9]+)\s*\(([^)]*)\)/gi;

/** « p_limit int default 50 » -> « int » ; « variadic ps team_perm[] » -> « team_perm[] ». */
function types(liste) {
  return liste.split(",").map((a) => a.trim()).filter(Boolean).map((a) => {
    const sans = a.replace(/\s+default\s+[\s\S]*$/i, "").replace(/^variadic\s+/i, "").trim();
    const mots = sans.split(/\s+/);
    return mots.length >= 2 ? mots.slice(1).join(" ") : mots[0];
  }).join(",");
}

for (const fichier of fs.readdirSync(DOSSIER).filter((f) => /^\d{4}.*\.sql$/.test(f)).sort()) {
  const migration = fichier.slice(0, 4);
  const texte = fs.readFileSync(path.join(DOSSIER, fichier), "utf8");

  const evenements = [];
  for (const m of texte.matchAll(CREATE)) {
    evenements.push({ at: m.index, pose: true, signature: `public.${m[1]}(${types(m[2])})` });
  }
  for (const m of texte.matchAll(DROP)) {
    evenements.push({ at: m.index, pose: false, signature: `public.${m[1]}(${types(m[2])})` });
  }
  evenements.sort((a, b) => a.at - b.at);

  for (const e of evenements) {
    // Une migration plus récente peut RETIRER une fonction (0013 ferme la réservation sans
    // téléphone). Sans ça, le contrôle réclamerait pour toujours une fonction volontairement
    // supprimée, et on finirait par ne plus le lire.
    if (e.pose) { if (!attendues.has(e.signature)) attendues.set(e.signature, migration); }
    else attendues.delete(e.signature);
  }
}

const lignes = [...attendues.entries()]
  .sort((a, b) => (a[1] + a[0]).localeCompare(b[1] + b[0]))
  .map(([signature, migration]) => `    ('${migration}', '${signature}')`);

const sql = `-- YIRI — fonctions attendues en base. LECTURE SEULE, ne modifie rien.
-- FICHIER ENGENDRÉ par scripts/fonctions-attendues.mjs — ne pas modifier à la main.
--
-- À coller dans l'éditeur SQL après CHAQUE migration appliquée en ligne.
-- N'affiche QUE ce qui manque. Aucune ligne renvoyée = tout est en place.
--
-- Il existe parce que la migration 0008 a été sautée sans bruit sur le projet en ligne :
-- l'écran des pièces d'identité affichait une erreur générique, et rien d'autre ne le signalait.
with attendu(migration, signature) as (values
${lignes.join(",\n")}
)
select migration, signature as fonction_absente
  from attendu
 where to_regprocedure(signature) is null
 order by migration, signature;
`;

const sortie = path.join(RACINE, "supabase/preprod/fonctions_manquantes.sql");
fs.writeFileSync(sortie, sql);
console.log(`${lignes.length} fonctions attendues -> supabase/preprod/fonctions_manquantes.sql`);
