-- Tests de la migration 0017 : notifications poussées sur l'appareil.
-- Ce qui est éprouvé ici, c'est surtout ce qui NE doit PAS arriver : qu'un appareil enregistré
-- donne un droit, qu'un navigateur atteigne la file d'envoi, ou qu'une personne voie les
-- appareils d'une autre.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values
  (t.u(3), 'proprietaire'), (t.u(5), 'admin');
-- 6 : validation. 7 : paiements. 8 : demandes. 9 : AUCUNE autorisation.
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'paiements', t.u(5)), (t.u(8), 'demandes', t.u(5));

-- ============ La clé publique ============
reset role; select t.as(0);
select t.eq('sans réglage, la clé publique est absente et rien ne casse',
  $$select coalesce(push_public_key(), 'NULL')$$, 'NULL');
reset role;
insert into public_settings (key, value) values ('push_vapid_public', 'BClePubliqueDeTest');
select t.as(0);
select t.eq('un visiteur non connecté lit la clé publique (il en a besoin avant de se connecter)',
  $$select push_public_key()$$, 'BClePubliqueDeTest');
-- Le droit d'écriture est RETIRÉ, donc la tentative est refusée net : elle ne se contente pas
-- de ne toucher aucune ligne.
select t.must_fail('mais il ne peut pas écrire dans les réglages',
  $$update public_settings set value = 'force' where key = 'push_vapid_public'$$);
select t.must_fail('ni en insérer', $$insert into public_settings (key, value) values ('x', 'y')$$);

-- ============ Enregistrer son appareil ============
reset role; select t.as(0);
select t.must_fail('un visiteur n''enregistre aucun appareil',
  $$select register_push('https://push.test/1', 'cle', 'auth')$$);

reset role; select t.as(3);
select t.ok('le propriétaire enregistre son téléphone',
  $$select register_push('https://push.test/p3-a', 'cle3a', 'auth3a', 'Android')$$);
select t.eq('et le retrouve dans ses appareils', $$select count(*)::text from my_push_devices()$$, '1');
select t.eq('l''adresse complète n''est pas renvoyée à l''écran, seulement sa fin',
  $$select endpoint_court from my_push_devices()$$, 'sh.test/p3-a');

-- Idempotence : le navigateur fait tourner ses clés, le même appareil se réenregistre.
select t.ok('réenregistrer le même appareil ne crée pas de doublon',
  $$select register_push('https://push.test/p3-a', 'cle3a-neuve', 'auth3a-neuve', 'Android')$$);
select t.eq('il reste un seul appareil', $$select count(*)::text from my_push_devices()$$, '1');
reset role;
select t.eq('et ce sont les nouvelles clés qui sont gardées',
  $$select p256dh from push_subscriptions where endpoint = 'https://push.test/p3-a'$$, 'cle3a-neuve');

-- Adresses refusées
select t.as(3);
select t.must_fail('une adresse sans https est refusée',
  $$select register_push('http://push.test/clair', 'c', 'a')$$);
select t.must_fail('une adresse vide est refusée', $$select register_push(NULL, 'c', 'a')$$);
select t.must_fail('des clés manquantes sont refusées',
  $$select register_push('https://push.test/sansCles', '', '')$$);

-- ============ Cloisonnement ============
reset role; select t.as(7);
select t.ok('un membre de l''équipe enregistre le sien',
  $$select register_push('https://push.test/u7', 'cle7', 'auth7', 'iPhone')$$);
select t.eq('il ne voit QUE le sien', $$select count(*)::text from my_push_devices()$$, '1');
select t.cnt('et la table ne lui en montre pas d''autre', $$select * from push_subscriptions$$, 1);

reset role; select t.as(5);
select t.cnt('même un administrateur ne voit pas les appareils des autres',
  $$select * from push_subscriptions$$, 0);
select t.eq('un administrateur ne voit pas non plus ceux des autres par la fonction',
  $$select count(*)::text from my_push_devices()$$, '0');

-- Un appareil qui change de main suit son nouveau propriétaire : sinon l'ancien recevrait
-- les alertes du nouveau sur le même téléphone.
reset role; select t.as(9);
select t.ok('le même téléphone, un autre compte', $$select register_push('https://push.test/p3-a', 'c9', 'a9')$$);
reset role;
select t.eq('l''appareil a changé de propriétaire',
  format($$select (user_id = %L)::text from push_subscriptions where endpoint = 'https://push.test/p3-a'$$, t.u(9)), 'true');
select t.as(3);
select t.eq('l''ancien propriétaire ne l''a plus', $$select count(*)::text from my_push_devices()$$, '0');

-- ============ Ne plus recevoir ============
reset role; select t.as(7);
select t.eq('se désinscrire retire bien l''appareil',
  $$select unregister_push('https://push.test/u7')::text$$, '1');
select t.eq('et il ne reste rien', $$select count(*)::text from my_push_devices()$$, '0');
select t.eq('se désinscrire deux fois ne lève aucune erreur',
  $$select unregister_push('https://push.test/u7')::text$$, '0');
select t.eq('on ne désinscrit pas l''appareil de quelqu''un d''autre',
  $$select unregister_push('https://push.test/p3-a')::text$$, '0');
reset role;
select t.eq('qui est donc toujours là',
  $$select count(*)::text from push_subscriptions where endpoint = 'https://push.test/p3-a'$$, '1');

-- ============ La file d'envoi est fermée au navigateur ============
reset role; select t.as(5);
select t.must_fail('un administrateur ne lit pas la file d''envoi depuis le site',
  $$select * from push_pending(10)$$);
select t.must_fail('ni ne marque quoi que ce soit comme envoyé',
  $$select push_mark_sent(array[]::uuid[])$$);
select t.must_fail('ni comme échoué', $$select push_mark_failed(array[]::uuid[])$$);
select t.as(7);
select t.must_fail('l''équipe « paiements » non plus', $$select * from push_pending(10)$$);
select t.as(0);
select t.must_fail('un visiteur encore moins', $$select * from push_pending(10)$$);

-- ============ Qui reçoit quoi ============
-- On repart propre : un appareil pour chacun des utilisateurs 3, 5, 6, 7, 8 et 9.
reset role;
delete from push_subscriptions;
insert into push_subscriptions (user_id, endpoint, p256dh, auth)
select t.u(n), 'https://push.test/u' || n, 'cle' || n, 'auth' || n from unnest(array[3, 5, 6, 7, 8, 9]) n;

delete from notifications;
insert into notifications (user_id, type, payload) values
  (t.u(3), 'booking.confirmee', '{"titre": "Studio Gounghin"}'),      -- personnelle
  (t.u(7), 'booking.confirmee.equipe', '{"titre": "Studio"}'),        -- paiements : oui
  (t.u(6), 'booking.confirmee.equipe', '{"titre": "Studio"}'),        -- validation : non
  (t.u(9), 'booking.confirmee.equipe', '{"titre": "Studio"}'),        -- aucune autorisation : non
  (t.u(5), 'booking.confirmee.equipe', '{"titre": "Studio"}'),        -- admin : oui
  (t.u(6), 'subscription.expiree.equipe', '{}'),                      -- validation : oui
  (t.u(8), 'application.recue.equipe', '{}'),                         -- demandes : oui
  (t.u(8), 'refund.attente_equipe_compte_inconnu', '{}'),             -- personnelle : oui
  (t.u(9), 'type.inconnu.equipe', '{}');                              -- inconnu : refusé par défaut

select t.eq('la notification personnelle part à son destinataire',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'booking.confirmee'$$, t.u(3)), '1');
select t.eq('une alerte d''équipe « réservation » part à qui a « paiements »',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(7)), '1');
select t.eq('elle NE part PAS à qui n''a que « validation »',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(6)), '0');
select t.eq('ni à qui n''a aucune autorisation',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(9)), '0');
select t.eq('un administrateur reçoit tout',
  format($$select count(*)::text from push_pending(100) where user_id = %L$$, t.u(5)), '1');
select t.eq('une alerte d''abonnement part à « validation »',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'subscription.expiree.equipe'$$, t.u(6)), '1');
select t.eq('une candidature part à « demandes »',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'application.recue.equipe'$$, t.u(8)), '1');
select t.eq('un type d''équipe inconnu ne part à personne (refus par défaut)',
  $$select count(*)::text from push_pending(100) where type = 'type.inconnu.equipe'$$, '0');
select t.eq('une alerte personnelle de remboursement part, elle',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type like 'refund.%%'$$, t.u(8)), '1');

-- Autant de lignes que d'appareils, pour un même destinataire.
insert into push_subscriptions (user_id, endpoint, p256dh, auth)
values (t.u(3), 'https://push.test/u3-bis', 'cle3b', 'auth3b');
select t.eq('un destinataire à deux appareils donne deux lignes',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type = 'booking.confirmee'$$, t.u(3)), '2');

-- Retirer une autorisation coupe l'envoi tout de suite, sans toucher aux appareils.
delete from team_permissions where user_id = t.u(7);
select t.eq('qui perd son autorisation ne reçoit plus, dès l''envoi suivant',
  format($$select count(*)::text from push_pending(100) where user_id = %L and type like '%%.equipe'$$, t.u(7)), '0');
select t.eq('son téléphone est pourtant toujours enregistré',
  format($$select count(*)::text from push_subscriptions where user_id = %L$$, t.u(7)), '1');

-- ============ Ne pas envoyer deux fois ============
select t.eq('marquer comme envoyé sort la notification de la file',
  format($$select push_mark_sent(array(select id from notifications where user_id = %L))::text$$, t.u(3)), '1');
select t.eq('elle n''y revient pas',
  format($$select count(*)::text from push_pending(100) where user_id = %L$$, t.u(3)), '0');
select t.eq('et la date d''envoi est posée une seule fois',
  format($$select count(*)::text from notifications where user_id = %L and pushed_at is not null$$, t.u(3)), '1');
select t.eq('la remarquer envoyée une deuxième fois ne change rien',
  format($$select push_mark_sent(array(select id from notifications where user_id = %L))::text$$, t.u(3)), '0');
select t.eq('l''appareil est noté comme joignable',
  format($$select count(*)::text from push_subscriptions where user_id = %L and last_ok_at is not null$$, t.u(3)), '2');

-- ============ Un appareil disparu est retiré ============
select t.eq('un appareil dont le service répond « inconnu » est supprimé',
  format($$select push_mark_sent(array(select id from notifications where user_id = %L),
                                 array(select id from push_subscriptions where endpoint = 'https://push.test/u6'))::text$$, t.u(6)), '2');
select t.eq('il ne reste pas dans la table',
  $$select count(*)::text from push_subscriptions where endpoint = 'https://push.test/u6'$$, '0');

-- ============ Trois échecs et on arrête ============
reset role;
delete from notifications;
insert into notifications (user_id, type, payload) values (t.u(5), 'booking.confirmee', '{}');
select t.eq('un premier échec laisse la notification dans la file',
  $$select push_mark_failed(array(select id from notifications))::text$$, '1');
select t.eq('elle y est encore', $$select count(*)::text from push_pending(100)$$, '1');
select t.ok('deuxième échec', $$select push_mark_failed(array(select id from notifications))$$);
select t.ok('troisième échec', $$select push_mark_failed(array(select id from notifications))$$);
select t.eq('au bout de trois tentatives, elle sort de la file',
  $$select count(*)::text from push_pending(100)$$, '0');
select t.eq('mais reste lisible dans le site',
  format($$select count(*)::text from (select * from notifications where user_id = %L) x$$, t.u(5)), '1');

-- ============ Rien de vieux ============
reset role;
delete from notifications;
insert into notifications (user_id, type, payload, created_at) values
  (t.u(5), 'booking.confirmee', '{}', now() - interval '5 days'),
  (t.u(5), 'booking.annulee', '{}', now() - interval '1 hour');
select t.eq('une alerte de la semaine dernière n''est pas poussée maintenant',
  $$select count(*)::text from push_pending(100) where type = 'booking.confirmee'$$, '0');
select t.eq('celle d''il y a une heure, oui',
  $$select count(*)::text from push_pending(100) where type = 'booking.annulee'$$, '1');

-- ============ Aucune clé privée en base ============
reset role;
select t.eq('aucun réglage public ne ressemble à une clé privée',
  $$select count(*)::text from public_settings
     where value ~* '(private|secret|sk_|BEGIN .*PRIVATE)' or key ~* '(private|secret|priv)'$$, '0');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0017 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
