import * as React from "react";
import { Button } from "./ui";
import * as api from "./lib/api";

// Bloc « Recevoir les alertes sur cet appareil ».
//
// Il n'apparaît que si l'appareil peut vraiment recevoir : inutile de proposer une chose qui
// échouera. Et il ne demande JAMAIS l'autorisation tout seul — seulement sur un clic. Une
// demande non sollicitée est refusée par la plupart des navigateurs, et quand elle passe, elle
// est presque toujours refusée par la personne, ce qui ferme la porte pour de bon.

function jour(d: string) {
  return new Date(d).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

export function AlertesAppareil({ compact }: { compact?: boolean }) {
  const [etat, setEtat] = React.useState<api.EtatPush | null>(null);
  const [appareils, setAppareils] = React.useState<api.PushDevice[]>([]);
  const [occupe, setOccupe] = React.useState(false);
  const [erreur, setErreur] = React.useState<string | null>(null);

  const relire = React.useCallback(() => {
    void api.etatPush().then(setEtat).catch(() => setEtat({ etat: "impossible", pourquoi: "Vérification impossible." }));
    void api.myPushDevices().then(setAppareils).catch(() => setAppareils([]));
  }, []);

  React.useEffect(relire, [relire]);

  // Le navigateur peut renouveler l'abonnement sans prévenir : le service worker nous le dit,
  // et on réenregistre, sinon l'appareil cesse de recevoir en silence.
  React.useEffect(() => {
    const ecoute = (e: MessageEvent) => {
      if ((e.data as { yiri?: string } | null)?.yiri === "push-a-reenregistrer") {
        void api.activerPush().then(setEtat).catch(() => { /* la personne pourra rétablir à la main */ });
      }
    };
    try { navigator.serviceWorker?.addEventListener("message", ecoute); } catch { /* sans conséquence */ }
    return () => { try { navigator.serviceWorker?.removeEventListener("message", ecoute); } catch { /* idem */ } };
  }, []);

  if (!etat) return null;
  if (etat.etat === "impossible") return null;

  const basculer = (activer: boolean) => {
    setOccupe(true); setErreur(null);
    const p = activer ? api.activerPush() : api.desactiverPush();
    void p.then((e) => { setEtat(e); relire(); })
      .catch((err) => setErreur(err instanceof Error ? err.message : "Opération impossible."))
      .finally(() => setOccupe(false));
  };

  const cadre = compact
    ? "rounded-2xl border border-line bg-surface p-4"
    : "rounded-2xl border border-line bg-surface p-5";

  // iPhone : Safari ne sait pousser que vers une application ajoutée à l'écran d'accueil.
  // Le dire plutôt que de proposer un bouton qui ne marchera pas.
  if (etat.etat === "a_installer") {
    return (
      <div className={cadre}>
        <h3 className="font-display font-bold text-ink">Recevoir les alertes sur cet iPhone</h3>
        <p className="mt-2 text-sm text-muted">
          Sur iPhone et iPad, les notifications ne fonctionnent qu'une fois YIRI ajouté à l'écran
          d'accueil. Appuyez sur <strong>Partager</strong> en bas de Safari, puis sur
          <strong> Sur l'écran d'accueil</strong>. Ouvrez ensuite YIRI depuis l'icône : le bouton
          d'activation apparaîtra ici.
        </p>
      </div>
    );
  }

  if (etat.etat === "refuse") {
    return (
      <div className={cadre}>
        <h3 className="font-display font-bold text-ink">Alertes bloquées par le navigateur</h3>
        <p className="mt-2 text-sm text-muted">
          Vous avez refusé les notifications pour YIRI. Un site ne peut pas redemander
          l'autorisation lui-même : il faut la rétablir dans les réglages du navigateur
          (le cadenas ou l'icône à gauche de l'adresse → Notifications → Autoriser), puis
          recharger cette page.
        </p>
      </div>
    );
  }

  const actif = etat.etat === "actif";

  return (
    <div className={cadre}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-display font-bold text-ink">Alertes sur cet appareil</h3>
          <p className="mt-1 text-sm text-muted">
            {actif
              ? "Cet appareil reçoit les alertes, même quand le site est fermé."
              : "Soyez prévenu d'une réservation payée ou d'un abonnement qui expire, sans avoir à ouvrir le site."}
          </p>
        </div>
        <Button variant={actif ? "ghost" : "primary"} disabled={occupe} onClick={() => basculer(!actif)}>
          {occupe ? "…" : actif ? "Ne plus recevoir ici" : "Activer les alertes"}
        </Button>
      </div>

      {erreur && <p role="alert" className="mt-3 rounded-xl border border-danger/40 bg-danger/10 px-3 py-2 text-sm font-medium text-danger">{erreur}</p>}

      {appareils.length > 0 && (
        <details className="mt-3">
          <summary className="cursor-pointer text-sm font-semibold text-ink">
            Appareils enregistrés ({appareils.length})
          </summary>
          <ul className="mt-2 flex flex-col gap-2">
            {appareils.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-sunk px-3 py-2 text-sm">
                <span className="text-ink">{api.nomAppareil(a.user_agent)}</span>
                <span className="text-xs text-muted">
                  {a.last_ok_at ? `dernière alerte reçue le ${jour(a.last_ok_at)}` : `ajouté le ${jour(a.created_at)}`}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-muted">
            Personne d'autre que vous ne voit cette liste, pas même un administrateur. Pour retirer
            un autre appareil, activez puis désactivez les alertes depuis cet appareil-là.
          </p>
        </details>
      )}

      {!actif && (
        <p className="mt-3 text-xs text-muted">
          Vous recevrez uniquement ce qui vous concerne : la base vérifie vos autorisations à
          chaque envoi. Le contenu de l'alerte est chiffré de bout en bout — le service de
          notification de votre téléphone le transporte sans pouvoir le lire.
        </p>
      )}
    </div>
  );
}
