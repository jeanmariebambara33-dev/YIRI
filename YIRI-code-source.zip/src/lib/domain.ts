import { addDays, addMonths, parseISODate, type ISODate } from "./dates";
import { PLANS, type PlanId } from "./pricing";
import type { XOF } from "./money";

export type Offer = "annonce" | "gestion" | "partenariat";
export type City = string; // toute localité du Burkina Faso
export type Role = "voyageur" | "proprietaire" | "admin";

// Annexe A — états d'une annonce
export type ListingStatus =
  | "brouillon"
  | "soumise"
  | "a_corriger"
  | "approuvee"
  | "refusee"
  | "publiee"
  | "suspendue"
  | "expiree"
  | "archivee";

export const LISTING_STATUS_FR: Record<ListingStatus, string> = {
  brouillon: "Brouillon",
  soumise: "Soumise",
  a_corriger: "À corriger",
  approuvee: "Approuvée",
  refusee: "Refusée",
  publiee: "Publiée",
  suspendue: "Suspendue",
  expiree: "Expirée",
  archivee: "Archivée",
};

const LISTING_TRANSITIONS: Record<ListingStatus, ListingStatus[]> = {
  brouillon: ["soumise", "archivee"],
  soumise: ["a_corriger", "approuvee", "refusee"],
  a_corriger: ["soumise", "archivee"],
  approuvee: ["publiee", "suspendue", "archivee"],
  refusee: ["archivee"],
  publiee: ["suspendue", "expiree", "archivee"],
  suspendue: ["publiee", "archivee"],
  expiree: ["publiee", "archivee"],
  archivee: [],
};

export function canTransitionListing(from: ListingStatus, to: ListingStatus): boolean {
  return LISTING_TRANSITIONS[from].includes(to);
}

// Annexe A — états d'une réservation
export type BookingStatus =
  | "en_attente_confirmation"
  | "en_attente_paiement"
  | "confirmee"
  | "en_cours"
  | "terminee"
  | "refusee"
  | "annulee"
  | "expiree"
  | "litige";

export const BOOKING_STATUS_FR: Record<BookingStatus, string> = {
  en_attente_confirmation: "En attente de confirmation",
  en_attente_paiement: "En attente de paiement",
  confirmee: "Confirmée",
  en_cours: "Séjour en cours",
  terminee: "Terminée",
  refusee: "Refusée",
  annulee: "Annulée",
  expiree: "Expirée",
  litige: "Litige",
};

/** Les réservations qui occupent le calendrier. Une demande en attente sans paiement ne bloque pas indéfiniment. */
export const BLOCKING_BOOKING: BookingStatus[] = ["en_attente_paiement", "confirmee", "en_cours"];

// Partenariat immobilier — états d'un dossier
export type ApplicationStatus =
  | "recue"
  | "preselectionnee"
  | "visite_planifiee"
  | "acceptee"
  | "refusee"
  | "contrat_signe";

export const APPLICATION_STATUS_FR: Record<ApplicationStatus, string> = {
  recue: "Reçue",
  preselectionnee: "Présélectionnée",
  visite_planifiee: "Visite planifiée",
  acceptee: "Acceptée (étude)",
  refusee: "Refusée",
  contrat_signe: "Contrat signé",
};

// ---------- Abonnements ----------

export interface Subscription {
  id: string;
  propertyId: string;
  plan: PlanId;
  amount: XOF;
  status: "en_attente_paiement" | "actif" | "expire" | "annule";
  startsAt?: ISODate;
  endsAt?: ISODate;
  paymentRef?: string;
}

/** Activation unique après paiement confirmé côté serveur ET annonce approuvée (§6). */
export function activateSubscription(s: Subscription, paidAmount: XOF, activationDate: ISODate): Subscription {
  if (s.status === "actif") return s; // idempotent : un callback répété ne réactive pas
  if (s.status !== "en_attente_paiement") throw new Error("abonnement non activable dans cet état");
  if (paidAmount !== PLANS[s.plan].price) throw new Error("montant payé différent du montant attendu");
  return { ...s, status: "actif", startsAt: activationDate, endsAt: addMonths(activationDate, PLANS[s.plan].months) };
}

export function subscriptionState(s: Subscription, today: ISODate): "inactif" | "actif" | "echeance_proche" | "expire" {
  if (s.status !== "actif" || !s.endsAt) return s.status === "expire" ? "expire" : "inactif";
  if (parseISODate(today) >= parseISODate(s.endsAt)) return "expire";
  if (parseISODate(addDays(today, 7)) >= parseISODate(s.endsAt)) return "echeance_proche";
  return "actif";
}

/** Rappels J-7, J-1 et à l'expiration (§6). */
export function reminderDue(s: Subscription, today: ISODate): "J-7" | "J-1" | "expiration" | null {
  if (!s.endsAt || s.status !== "actif") return null;
  if (today === addDays(s.endsAt, -7)) return "J-7";
  if (today === addDays(s.endsAt, -1)) return "J-1";
  if (today === s.endsAt) return "expiration";
  return null;
}

// ---------- Règle de publication (§11) ----------

export interface PublishCheck {
  offer: Offer;
  status: ListingStatus;
  complete: boolean;
  subscription?: Subscription;
  agreementSigned?: boolean;
  operationalCheckDone?: boolean;
}

export function publicationBlockers(p: PublishCheck, today: ISODate): string[] {
  const reasons: string[] = [];
  if (p.status !== "publiee" && p.status !== "approuvee") reasons.push("annonce non approuvée");
  if (!p.complete) reasons.push("annonce incomplète");
  if (p.offer === "annonce") {
    const st = p.subscription ? subscriptionState(p.subscription, today) : "inactif";
    if (st === "inactif" || st === "expire") reasons.push("abonnement non payé ou expiré");
  } else {
    if (!p.agreementSigned) reasons.push("contrat non signé");
    if (!p.operationalCheckDone) reasons.push("contrôle opérationnel non réalisé");
  }
  return reasons;
}

export function isPubliclyVisible(p: PublishCheck, today: ISODate): boolean {
  return p.status === "publiee" && publicationBlockers(p, today).length === 0;
}

/** Ce qu'il faut savoir d'un logement pour dessiner sa vignette quand il n'a pas de photo.
 *
 *  Trois champs, pas davantage. Avant, ces trois champs étaient prélevés sur le type Property
 *  des données de démonstration : 250 lignes de logements fictifs restaient donc dans le
 *  programme livré, uniquement pour fournir un type. */
export interface VisuelLogement {
  id: string;
  bedrooms: number;
  /** Teinte du visuel engendré quand il n'y a pas de photo. */
  hue: number;
}
