#!/usr/bin/env bash
# YIRI — PRÉPROD — Lot 1 : tests API en visiteur NON connecté (PREPROD.md §6, tests 1 à 3).
# Ne fait que des lectures (GET) et des appels de fonctions SANS identité ni paramètres valides.
# N'utilise que la clé PUBLIQUE « anon ». Ne l'enregistre nulle part, ne l'affiche pas.
# Usage : bash api_lot1.sh
set -u
read -r -p "URL du projet (https://xxxx.supabase.co) : " URL
read -r -s -p "Clé publique anon (la saisie est masquée) : " ANON; echo
URL="${URL%/}"
case "$URL" in https://*.supabase.co) ;; *) echo "URL inattendue — arrêt."; exit 1;; esac
[ -n "$ANON" ] || { echo "Clé vide — arrêt."; exit 1; }

show() {  # $1=libellé  $2=code HTTP  $3=corps
  local body="${3:0:160}"
  printf '%-34s HTTP %s  %s\n' "$1" "$2" "$body"
}
get() {
  local out code
  out=$(curl -sS -m 20 -w '\n%{http_code}' -H "apikey: $ANON" "$URL/rest/v1/$1") || { echo "$1 : erreur réseau"; return; }
  code="${out##*$'\n'}"; show "GET $1" "$code" "${out%$'\n'*}"
}
rpc() {
  local out code
  out=$(curl -sS -m 20 -w '\n%{http_code}' -X POST -H "apikey: $ANON" -H "Content-Type: application/json" -d '{}' "$URL/rest/v1/rpc/$1") || { echo "$1 : erreur réseau"; return; }
  code="${out##*$'\n'}"; show "RPC $1" "$code" "${out%$'\n'*}"
}

echo; echo "== Tests 1 et 2 : lectures (attendu : [] ou refus, jamais de données) =="
for t in properties bookings payment_transactions profiles user_roles team_permissions property_contacts owner_leads payment_notices public_listings public_listing_photos; do get "$t?select=*&limit=3"; done
echo; echo "== Test 3 : fonctions sensibles (attendu : refus 401/403/404, jamais 200) =="
for f in create_booking declare_payment confirm_payment reject_payment reveal_contact request_owner_role grant_owner_role set_listing_status; do rpc "$f"; done
echo; echo "Fin. Copiez ce tableau tel quel (il ne contient pas la clé)."
