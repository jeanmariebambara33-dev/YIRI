// YIRI — démarrage d'un paiement en ligne.
//
// Le navigateur dit seulement CE QU'IL VEUT PAYER (une réservation, un abonnement).
// Il n'envoie jamais de montant : c'est la base qui recalcule le prix, et c'est ce prix-là
// qui part chez le prestataire. Un navigateur modifié ne peut donc pas payer 100 FCFA
// une réservation de 60 000.
//
// Fichier AUTONOME : rien à importer, pour pouvoir être collé tel quel dans le tableau de bord
// Supabase. À déployer AVEC vérification de JWT (le comportement par défaut).

const SASPAY_BASE = "https://api.saspay.me/api/v1";

/** Variable d'environnement obligatoire. On échoue bruyamment plutôt que de deviner. */
function requis(nom: string): string {
  const v = Deno.env.get(nom);
  if (!v || v.trim() === "") throw new Error(`Variable d'environnement manquante : ${nom}`);
  return v.trim();
}

/** Appel d'une fonction de la base. « jeton » décide de l'identité :
 *  le JWT de la personne connectée, ou la clé de service pour les fonctions fermées au navigateur. */
async function rpc<T>(fn: string, args: Record<string, unknown>, jeton: string, cle: string): Promise<T> {
  const r = await fetch(`${requis("SUPABASE_URL")}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { "apikey": cle, "Authorization": `Bearer ${jeton}`, "Content-Type": "application/json" },
    body: JSON.stringify(args),
  });
  const texte = await r.text();
  if (!r.ok) throw new Error(`${fn} a échoué (${r.status}) : ${texte.slice(0, 300)}`);
  return (texte ? JSON.parse(texte) : null) as T;
}

function json(donnees: unknown, status = 200): Response {
  return new Response(JSON.stringify(donnees), { status, headers: { "Content-Type": "application/json" } });
}

type Depart = { reference: string; amount_xof: number; designation: string };

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ erreur: "méthode non autorisée" }, 405);

  const entete = req.headers.get("Authorization") ?? "";
  const jeton = entete.toLowerCase().startsWith("bearer ") ? entete.slice(7).trim() : "";
  if (!jeton) return json({ erreur: "Connectez-vous pour payer en ligne." }, 401);

  let corps: { objet?: string; id?: string };
  try {
    corps = await req.json();
  } catch {
    return json({ erreur: "requête illisible" }, 400);
  }
  const objet = corps.objet ?? "";
  const id = corps.id ?? "";
  if (objet !== "reservation" && objet !== "abonnement") {
    return json({ erreur: "objet inconnu" }, 400);
  }
  if (!/^[0-9a-f-]{36}$/i.test(id)) return json({ erreur: "identifiant invalide" }, 400);

  const url = requis("SUPABASE_URL");
  const anon = requis("SUPABASE_ANON_KEY");
  const service = requis("SUPABASE_SERVICE_ROLE_KEY");

  // L'identité de la personne vient de son jeton, pas de ce qu'elle déclare.
  const rUser = await fetch(`${url}/auth/v1/user`, {
    headers: { "apikey": anon, "Authorization": `Bearer ${jeton}` },
  });
  if (!rUser.ok) return json({ erreur: "Session expirée. Reconnectez-vous." }, 401);
  const u = await rUser.json();
  const email = String(u?.email ?? "");
  const nom = String(u?.user_metadata?.full_name ?? "").trim() || "Client YIRI";

  // ---- 1. La base vérifie l'appartenance et fixe le montant ----
  let depart: Depart;
  try {
    const lignes = await rpc<Depart[]>("start_online_payment", {
      p_object: objet,
      p_id: id,
      p_provider: "saspay",
    }, jeton, anon);
    if (!Array.isArray(lignes) || lignes.length === 0) throw new Error("aucune tentative créée");
    depart = lignes[0];
  } catch (e) {
    const m = e instanceof Error ? e.message : String(e);
    console.error("démarrage refusé :", m);
    // Le message de la base est déjà en français et sans détail technique sensible.
    return json({ erreur: m.replace(/^.*?: /, "").slice(0, 300) }, 400);
  }

  // ---- 2. Création de la page de paiement chez le prestataire ----
  // Le routeur de l'application lit « #mes-sejours », sans barre oblique : « #/mes-sejours »
  // ramènerait la personne sur une page inconnue après avoir payé.
  const retour = `${requis("SITE_URL").replace(/\/+$/, "")}/#mes-sejours`;
  try {
    const r = await fetch(`${SASPAY_BASE}/checkout-sessions/`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${requis("SASPAY_SECRET_KEY")}`,
        "Content-Type": "application/json",
        // Un réseau qui bégaie ne doit pas créer deux paiements pour la même réservation.
        "Idempotency-Key": depart.reference,
      },
      body: JSON.stringify({
        amount: String(depart.amount_xof),
        currency: "XOF",
        // Notre référence est glissée dans la description : repli si le lien venait à manquer.
        description: `${depart.designation} [${depart.reference}]`,
        customer_email: email,
        customer_name: nom,
        return_url: retour,
      }),
    });
    const texte = await r.text();
    if (!r.ok) throw new Error(`${r.status} ${texte.slice(0, 300)}`);
    const d = JSON.parse(texte)?.data ?? {};
    if (!d.id || !d.checkout_url) throw new Error("réponse sans page de paiement");

    // ---- 3. Le lien entre son identifiant et le nôtre, sans lequel son message serait orphelin ----
    await rpc("link_payment_provider_id", {
      p_reference: depart.reference,
      p_provider_id: String(d.id),
    }, service, service);

    return json({
      ok: true,
      reference: depart.reference,
      montant_xof: depart.amount_xof,
      page_paiement: d.checkout_url,
    });
  } catch (e) {
    // La tentative est refermée : sans ça elle resterait « en attente » pour toujours.
    console.error("création du paiement en échec :", e instanceof Error ? e.message : String(e));
    try {
      await rpc("fail_online_payment", {
        p_reference: depart.reference,
        p_reason: "création de la page de paiement impossible",
      }, service, service);
    } catch { /* la trace a déjà été écrite dans les journaux */ }
    return json({ erreur: "Le paiement en ligne est momentanément indisponible. Réessayez dans un instant." }, 502);
  }
});
