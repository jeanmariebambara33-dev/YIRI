// Tests de bout en bout de l'espace propriétaire (brouillon → photos → contact → pièce d'identité → validation).
// Le serveur est REMPLACÉ par une imitation qui applique les MÊMES refus que la vraie base
// (migrations 0005 et 0007, déjà vérifiées par 134 tests SQL et par les tests d'API sur le vrai projet) :
//   * pas plus de 3 annonces en cours tant que le propriétaire n'est pas vérifié ;
//   * création impossible avec un statut autre que « brouillon » ;
//   * passage en « soumise » refusé sans pièce d'identité en attente ;
//   * pièce refusée sans recto ET verso, et sans annonce existante.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
window.__refus = [];
const DB = { props: [], photos: [], contacts: [], files: [], identity: null, roles: [{ role: "voyageur" }], seq: 1 };
window.__db = DB;
const UID = "u-1";
const err = (code, message) => { window.__refus.push(message); return { data: null, error: { code, message } }; };
const okRes = (data) => ({ data, error: null });

function enCours() { return DB.props.filter((p) => ["brouillon", "a_corriger", "soumise"].includes(p.status)).length; }
function estProprietaire() { return DB.roles.some((r) => r.role === "proprietaire"); }

function run(table, op, payload, filters) {
  const by = (row) => filters.every(([c, v]) => row[c] === v);
  if (table === "properties") {
    if (op === "select") return okRes(DB.props.slice());
    if (op === "insert") {
      // RLS properties_owner_insert (0007)
      if (payload.owner_id !== UID) return err("42501", "new row violates row-level security policy");
      if (!estProprietaire() && payload.status !== "brouillon") return err("42501", "new row violates row-level security policy");
      if (!estProprietaire() && enCours() >= 3) return err("42501", "new row violates row-level security policy");
      const row = Object.assign({ id: "p-" + DB.seq++, review_note: null, created_at: new Date().toISOString() }, payload);
      DB.props.push(row); return okRes([row]);
    }
    if (op === "update") {
      const rows = DB.props.filter(by);
      for (const r of rows) {
        // déclencheur properties_identity_guard (0007)
        if (payload.status === "soumise" && r.status !== "soumise" && !estProprietaire()
            && !(DB.identity && DB.identity.state === "en_attente")) {
          return err("P0001", "Pour publier, envoyez d'abord votre pièce d'identité (recto, verso et numéro).");
        }
        Object.assign(r, payload);
      }
      return okRes(rows);
    }
  }
  if (table === "property_photos") {
    if (op === "select") return okRes(DB.photos.filter(by));
    if (op === "insert") { const row = Object.assign({ id: DB.seq++ }, payload); DB.photos.push(row); return okRes([row]); }
    if (op === "delete") { const rows = DB.photos.filter(by); DB.photos = DB.photos.filter((p) => !by(p)); return okRes(rows); }
  }
  if (table === "property_contacts") {
    if (op === "select") return okRes(DB.contacts.filter(by));
    if (op === "upsert") {
      DB.contacts = DB.contacts.filter((c) => c.property_id !== payload.property_id).concat([payload]);
      return okRes([payload]);
    }
  }
  if (table === "profiles") return okRes([{ full_name: "Awa Sawadogo", phone: null }]);
  if (table === "user_roles") return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
  if (table === "team_permissions") return okRes([]);
  return okRes([]);
}

function builder(table) {
  let op = "select", payload = null; const filters = [];
  const exec = () => { const r = run(table, op, payload, filters); return Promise.resolve(r); };
  const self = {
    select() { return self; },
    insert(p) { op = "insert"; payload = p; return self; },
    upsert(p) { op = "upsert"; payload = p; return self; },
    update(p) { op = "update"; payload = p; return self; },
    delete() { op = "delete"; return self; },
    eq(c, v) { filters.push([c, v]); return self; },
    order() { return self; },
    limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); },
    then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: "jeton", user: { id: UID, email: "awa@yiri.test" } };
const listeners = [];
window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem("fs") ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, args) {
    if (fn === "my_owner_identity") {
      return Promise.resolve(okRes([DB.identity || { state: "aucune", id_type: null, id_number_masked: null, files_sent: 0, decision_note: null, files_deleted: false }]));
    }
    if (fn === "submit_owner_identity") {
      // fonction serveur submit_owner_identity (0007)
      if (estProprietaire()) return Promise.resolve(err("P0001", "Vous êtes déjà propriétaire."));
      if (!DB.props.some((p) => ["brouillon", "a_corriger", "soumise"].includes(p.status)))
        return Promise.resolve(err("P0001", "Créez d'abord une annonce : la pièce est demandée au moment de publier."));
      const rec = DB.files.some((f) => /\\/recto\\./.test(f)), ver = DB.files.some((f) => /\\/verso\\./.test(f));
      if (!rec || !ver) return Promise.resolve(err("P0001", "Envoyez d'abord le recto ET le verso de votre pièce."));
      const norm = String(args.p_number).replace(/[\\s\\-./]+/g, "").toUpperCase();
      if (!/^[A-Z0-9]{5,25}$/.test(norm)) return Promise.resolve(err("P0001", "Numéro de pièce invalide (5 à 25 lettres ou chiffres)."));
      DB.identity = { state: "en_attente", id_type: args.p_type, id_number_masked: "****" + norm.slice(-3), files_sent: 2, decision_note: null, files_deleted: false };
      return Promise.resolve(okRes(null));
    }
    return Promise.resolve(okRes(null));
  },
  storage: { from(bucket) { return {
    async upload(path, file, opts) {
      if (file.size > 5242880) return err("413", "The object exceeded the maximum allowed size");
      if (!["image/jpeg", "image/png", "image/webp"].includes(opts.contentType)) return err("415", "mime type not supported");
      if (!path.startsWith(UID + "/")) return err("42501", "new row violates row-level security policy");
      DB.files.push(bucket + ":" + path); return okRes({ path });
    },
    async remove(paths) { DB.files = DB.files.filter((f) => !paths.some((p) => f.endsWith(p))); return okRes({}); },
    async createSignedUrl(path) { return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" }); },
    async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ viewport: { width: 1280, height: 1000 } });
await ctx.route("**cdn.jsdelivr.net/**", (r) => r.abort());
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));

const file = (name, type, bytes = 2048) => ({ name, mimeType: type, buffer: Buffer.alloc(bytes, 1) });

// --- visiteur ---
await p.goto(URL + "#espace"); await p.waitForSelector("h1");
ok("espace propriétaire fermé à un visiteur", /Connectez-vous/.test(await p.locator("body").innerText()));
ok("aucune donnée d'annonce affichée avant connexion", !/Mes annonces/.test(await p.locator("h1").first().innerText()));

// --- connexion ---
await p.getByRole("button", { name: "Se connecter" }).first().click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "awa@yiri.test"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForSelector("text=Se déconnecter");
await p.goto(URL + "#espace"); await p.waitForSelector("h1");
ok("espace propriétaire ouvert après connexion", /Mes annonces/.test(await p.locator("body").innerText()));
ok("message : la pièce n'est demandée qu'au moment de publier", /pièce d'identité n'est demandée qu'au moment de publier/.test(await p.locator("body").innerText()));
ok("aucune annonce au départ", /pas encore d'annonce/.test(await p.locator("body").innerText()));

// --- création : contrôles de saisie ---
await p.getByRole("button", { name: "Créer une annonce" }).click();
await p.waitForSelector("#l-titre");
await p.fill("#l-titre", "abc");
await p.getByRole("button", { name: "Créer le brouillon" }).click();
await p.waitForSelector("[role=alert]");
ok("titre trop court refusé", /titre d'au moins 5/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("#l-titre", "Studio meublé Ouaga 2000");
await p.fill("#l-desc", "trop court");
await p.getByRole("button", { name: "Créer le brouillon" }).click();
await p.waitForTimeout(120);
ok("description trop courte refusée", /30 caractères/.test(await p.locator("[role=alert]").first().innerText()));
ok("rien n'est envoyé au serveur tant que la saisie est invalide", await p.evaluate(() => window.__db.props.length === 0));

// --- création réussie ---
await p.fill("#l-desc", "Studio calme et propre, eau et courant, à deux pas du marché. Parking dans la cour.");
await p.fill("#l-quartier", "Ouaga 2000");
await p.fill("#l-prix", "18000");
await p.getByRole("button", { name: "Créer le brouillon" }).click();
await p.waitForSelector("[role=status]");
ok("brouillon créé", /Brouillon créé/.test(await p.locator("[role=status]").first().innerText()));
const created = await p.evaluate(() => window.__db.props[0] ?? null);
ok("l'annonce est créée au nom du compte connecté", created && created.owner_id === "u-1");
ok("l'annonce est créée en brouillon, jamais publiée", created && created.status === "brouillon");
ok("le prix saisi est bien transmis", created && created.nightly_price_xof === 18000);

await p.getByRole("button", { name: "Revenir à mes annonces" }).click();
await p.waitForTimeout(200);
ok("l'annonce apparaît dans la liste avec l'état « Brouillon »", /Brouillon/.test(await p.locator("body").innerText()));
ok("le brouillon n'est pas visible publiquement (état affiché)", !/En ligne/.test(await p.locator("body").innerText()));

// --- ouvrir l'annonce, photos ---
await p.getByText("Studio meublé Ouaga 2000").first().click();
await p.waitForSelector("#l-photo");
await p.setInputFiles("#l-photo", file("faux.pdf", "application/pdf"));
await p.waitForSelector("[role=alert]");
ok("photo : fichier non image refusé", /JPEG, PNG ou WebP/.test(await p.locator("[role=alert]").first().innerText()));
await p.setInputFiles("#l-photo", file("enorme.jpg", "image/jpeg", 6 * 1024 * 1024));
await p.waitForTimeout(200);
ok("photo : fichier de plus de 5 Mo refusé", /5 Mo/.test(await p.locator("[role=alert]").first().innerText()));
ok("photo : aucun fichier refusé n'atteint le serveur", await p.evaluate(() => window.__db.files.length === 0));
await p.setInputFiles("#l-photo", file("salon.jpg", "image/jpeg"));
await p.waitForSelector("[role=status]");
ok("photo valide acceptée", /Photo ajoutée/.test(await p.locator("[role=status]").first().innerText()));
const stored = await p.evaluate(() => window.__db.files[0] ?? "");
ok("photo rangée dans le dossier du propriétaire et de l'annonce", /^property-photos:u-1\/p-1\//.test(stored));
ok("photo marquée « En attente » de vérification des droits", /En attente/.test(await p.locator("body").innerText()));

// --- contact ---
await p.fill("#l-cname", "A");
await p.getByRole("button", { name: "Enregistrer le contact" }).click();
await p.waitForTimeout(150);
ok("contact : nom trop court refusé", /nom de la personne/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("#l-cname", "Awa Sawadogo"); await p.fill("#l-tel", "12345");
await p.getByRole("button", { name: "Enregistrer le contact" }).click();
await p.waitForTimeout(150);
ok("contact : numéro invalide refusé", /Numéro invalide/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("#l-tel", "+226 70 11 22 33");
await p.getByRole("button", { name: "Enregistrer le contact" }).click();
await p.waitForSelector("[role=status]");
ok("contact enregistré", /Contact enregistré/.test(await p.locator("[role=status]").first().innerText()));

// --- publication bloquée sans pièce d'identité ---
let body = await p.locator("body").innerText();
ok("la pièce d'identité est demandée au moment de publier", /Vérifiez votre identité pour publier/.test(body));
ok("le bouton d'envoi en validation est désactivé", await p.getByRole("button", { name: "Envoyer en validation" }).isDisabled());
ok("l'annonce est toujours un brouillon côté serveur", await p.evaluate(() => window.__db.props[0].status === "brouillon"));

// --- pièce d'identité ---
await p.getByRole("button", { name: "Envoyer ma pièce d'identité" }).click();
await p.waitForTimeout(150);
ok("pièce : numéro vide refusé", /Numéro invalide/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("#id-num", "B1234567");
await p.getByRole("button", { name: "Envoyer ma pièce d'identité" }).click();
await p.waitForTimeout(150);
ok("pièce : refusée sans le recto et le verso", /recto ET le verso/.test(await p.locator("[role=alert]").first().innerText()));
await p.setInputFiles("#id-recto", file("recto.jpg", "image/jpeg"));
await p.waitForTimeout(250);
await p.setInputFiles("#id-verso", file("verso.png", "image/png"));
await p.waitForTimeout(250);
const idFiles = await p.evaluate(() => window.__db.files.filter((f) => f.startsWith("owner-identity:")));
ok("recto et verso rangés dans l'espace privé du compte", idFiles.length === 2 && idFiles.every((f) => f.startsWith("owner-identity:u-1/")));
ok("noms de fichiers imposés (recto / verso)", idFiles.some((f) => /\/recto\./.test(f)) && idFiles.some((f) => /\/verso\./.test(f)));
await p.fill("#id-num", "B1234567");
await p.getByRole("button", { name: "Envoyer ma pièce d'identité" }).click();
await p.waitForTimeout(400);
body = await p.locator("body").innerText();
ok("pièce envoyée : message de vérification en cours", /L'équipe YIRI la vérifie|cours de vérification/.test(body));
const ident = await p.evaluate(() => window.__db.identity);
ok("le numéro n'est jamais renvoyé en clair à l'application", ident && ident.id_number_masked === "****567");

// --- envoi en validation ---
await p.getByRole("button", { name: "Envoyer en validation" }).click();
await p.waitForTimeout(400);
ok("annonce envoyée en validation", await p.evaluate(() => window.__db.props[0].status === "soumise"));
body = await p.locator("body").innerText();
ok("l'état affiché passe à « En cours de validation »", /En cours de validation/.test(body));
ok("le propriétaire ne peut plus modifier une annonce soumise", await p.locator("#l-titre").isDisabled());

// --- le serveur reste le juge : sans pièce, la publication est de nouveau bloquée ---
await p.evaluate(() => { window.__db.props[0].status = "brouillon"; window.__db.identity = null; });
await p.getByRole("button", { name: "Revenir à mes annonces" }).click();
await p.waitForTimeout(400);
await p.getByText("Studio meublé Ouaga 2000").first().click();
await p.waitForTimeout(400);
ok("sans pièce, la demande de publication est à nouveau bloquée", await p.getByRole("button", { name: "Envoyer en validation" }).isDisabled());
ok("la pièce est redemandée", /Vérifiez votre identité pour publier/.test(await p.locator("body").innerText()));

// --- plafond de 3 annonces pour un compte non vérifié ---
await p.evaluate(() => {
  const base = { owner_id: "u-1", status: "brouillon", description: "x", city: "Ouagadougou", district: "A", nightly_price_xof: 1000, capacity: 1, bedrooms: 1, beds: 1, min_nights: 1, private_address: null, review_note: null, created_at: "2026-01-01" };
  window.__db.props.push(Object.assign({ id: "p-2", title: "Deux" }, base));
  window.__db.props.push(Object.assign({ id: "p-3", title: "Trois" }, base));
});
await p.getByRole("button", { name: "Revenir à mes annonces" }).click();
await p.waitForTimeout(400);
body = await p.locator("body").innerText();
ok("plafond atteint : message explicite", /déjà 3 annonces en cours/.test(body));
ok("plafond atteint : bouton de création désactivé", await p.getByRole("button", { name: "Créer une annonce" }).isDisabled());
ok("les 3 annonces sont bien listées", /Deux/.test(body) && /Trois/.test(body));

// --- un propriétaire vérifié n'est plus limité (rôle relu à la connexion, jamais depuis le navigateur) ---
await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }, { role: "proprietaire" }]; });
await p.evaluate(() => { location.hash = "compte"; });
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "awa@yiri.test"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(500);
await p.evaluate(() => { location.hash = "espace"; });
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("propriétaire vérifié : mention affichée", /identité est vérifiée/.test(body));
ok("propriétaire vérifié : création de nouveau possible", !(await p.getByRole("button", { name: "Créer une annonce" }).isDisabled()));
await p.getByText("Studio meublé Ouaga 2000").first().click();
await p.waitForTimeout(400);
ok("propriétaire vérifié : plus de demande de pièce d'identité", !/Vérifiez votre identité pour publier/.test(await p.locator("body").innerText()));
ok("propriétaire vérifié : envoi en validation possible", !(await p.getByRole("button", { name: "Envoyer en validation" }).isDisabled()));

ok("aucune erreur JavaScript pendant les tests", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 3).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DE L'ESPACE PROPRIETAIRE SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
