# Les courriels — ce que tu dois faire

Cinq étapes. Le service est **Brevo** : 300 courriels par jour en gratuit, et surtout il accepte
une simple adresse d'expéditeur vérifiée — tu n'as pas besoin de posséder `yiri.bf` pour
commencer.

---

## 1. Créer le compte Brevo

Va sur **brevo.com**, crée un compte gratuit. C'est toi qui le crées : je ne le fais pas à ta
place, et je n'ai pas accès à tes comptes.

À l'inscription, Brevo demande à quoi sert le compte : réponds **courriels transactionnels**
(et non campagnes marketing). Le compte doit être **validé par Brevo** avant de pouvoir envoyer —
c'est généralement rapide, mais tant que ce n'est pas fait, les envois sont refusés.

## 2. Vérifier l'adresse qui enverra

Dans Brevo → **Senders, Domains & Dedicated IPs** → **Senders** → **Add a sender**.

Mets une adresse que tu contrôles réellement, par exemple ton adresse Gmail. Brevo y envoie un
courriel de confirmation : clique sur le lien.

> Le jour où tu auras `yiri.bf`, remplace cette adresse par `notifications@yiri.bf` et vérifie le
> **domaine** (et non plus l'adresse seule). Les courriels arriveront beaucoup moins souvent dans
> les indésirables, et porteront ton nom de domaine plutôt qu'une adresse personnelle.

## 3. Prendre la clé d'API

Brevo → **SMTP & API** → onglet **API Keys** → **Generate a new API key**.

La clé commence par `xkeysib-`. **Elle ne s'affiche qu'une fois** : copie-la tout de suite.
Ne me l'envoie pas.

## 4. Les secrets Supabase

```
https://supabase.com/dashboard/project/kzzrowymwwxoydklnkfb/settings/functions
```

**Add new secret**, trois fois :

| Name | Value |
|---|---|
| `BREVO_API_KEY` | la clé `xkeysib-…` de l'étape 3 |
| `EMAIL_FROM` | l'adresse vérifiée à l'étape 2 |
| `EMAIL_FROM_NAME` | `YIRI` |

`PUSH_TRIGGER_SECRET` est déjà en place : les courriels réutilisent le même, tu n'as rien à
ajouter de ce côté.

> Pour passer à Resend plus tard : ajoute `RESEND_API_KEY` et `EMAIL_PROVIDER` = `resend`.
> Rien d'autre à changer, le code gère les deux.

## 5. Appliquer les migrations et déployer

Dans le **SQL Editor**, colle et exécute, dans cet ordre :

1. `0019_remboursement_equipe.sql`
2. `0020_courriels.sql`

Puis déploie la fonction, comme pour les notifications du téléphone :

```
https://supabase.com/dashboard/project/kzzrowymwwxoydklnkfb/functions
```

**Deploy a new function** → **Via Editor** → nom **exactement** `email-envoyer` → colle tout
`index.ts` → **Verify JWT désactivé** → Deploy.

Le déclencheur, lui, est déjà posé : la migration 0020 l'a étendu pour qu'il appelle les deux
fonctions, celle du téléphone et celle des courriels.

---

## Vérifier

```sql
select push_declencher_manuel();
```

La réponse doit nommer **deux** adresses. Puis envoie-toi un essai — remplace l'adresse :

```sql
insert into notifications (user_id, type, payload)
select id, 'listing.approuvee', '{"titre": "Essai des courriels"}'
  from profiles where id = (select id from auth.users where email = 'ton.adresse@exemple.com');
```

Le courriel doit arriver en moins d'une minute. Puis efface l'essai :

```sql
delete from notifications where payload->>'titre' = 'Essai des courriels';
```

Pour voir où en sont les envois :

```sql
select type,
       count(*) filter (where emailed_at is null) as en_attente,
       count(*) filter (where emailed_at is not null) as partis,
       max(email_error) as derniere_erreur
  from notifications
 where created_at > now() - interval '2 days'
 group by type order by en_attente desc;
```

La colonne `derniere_erreur` dit en clair ce que Brevo a refusé, le cas échéant.

## Si rien n'arrive

1. **Edge Functions → email-envoyer → Logs.** Le message nomme le secret manquant.
2. `Brevo 401` → la clé d'API est fausse ou a été régénérée.
3. `Brevo 400 : Invalid sender` → l'adresse de `EMAIL_FROM` n'est pas vérifiée, ou ne correspond
   pas exactement à celle validée à l'étape 2.
4. **`{"envoyes": 0}`** → la base n'a rien à envoyer. Soit la personne n'a pas d'adresse connue,
   soit le type d'événement n'est pas de ceux qui donnent lieu à un courriel (la liste est courte
   et volontaire : voir `_email_eligible` dans la migration 0020).
5. **Le courriel part mais arrive en indésirables** → normal tant que l'expéditeur est une adresse
   personnelle. C'est le domaine `yiri.bf` vérifié qui règle ça.

## Ce qui reste vrai quoi qu'il arrive

- **Un courriel n'est dit parti que si Brevo l'a confirmé** par un identifiant de message. Jamais
  sur une supposition.
- **Un échec d'envoi ne casse rien** : une réservation confirmée par le serveur le reste, même si
  aucun courriel ne part.
- **Pas deux fois le même courriel** : la trace est portée par la notification elle-même.
- **Qui reçoit quoi est décidé par la base**, à l'envoi, avec les mêmes autorisations que les
  notifications du téléphone. Un propriétaire ne reçoit que ce qui concerne ses logements.
