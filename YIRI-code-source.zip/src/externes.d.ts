// Déclarations des bibliothèques extérieures, pour que la vérification de types fonctionne
// SANS rien installer.
//
// Le projet n'a pas de node_modules : React et supabase-js arrivent par CDN et esbuild les laisse
// passer. Une vérification de types buterait donc sur « module react introuvable » et n'examinerait
// rien d'autre. React est ici déclaré juste assez pour que les appels génériques (useState<T>) et
// les types (React.ReactNode) soient compris, sans prétendre vérifier l'usage de React lui-même.
// TOUT LE RESTE est alors vérifié strictement : nos types, les accessoires passés entre nos
// composants, les signatures de src/lib.
//
// C'est ce qui manquait : src/store.tsx importait PackId depuis data/demo, où ce type n'a jamais
// existé. esbuild efface les imports de type sans les résoudre, et personne n'a rien vu.
declare module "react" {
  export type ReactNode = any;
  export type CSSProperties = Record<string, any>;
  export type DependencyList = readonly any[];
  export type ChangeEvent<T = any> = { target: T & Record<string, any> } & Record<string, any>;
  export type FormEvent<T = any> = { target: T } & Record<string, any>;
  export type ButtonHTMLAttributes<T = any> = Record<string, any>;

  export function useState<S>(initial: S | (() => S)): [S, (v: S | ((p: S) => S)) => void];
  export function useEffect(effet: () => void | (() => void), deps?: DependencyList): void;
  export function useLayoutEffect(effet: () => void | (() => void), deps?: DependencyList): void;
  // Deux formes, comme dans React. useRef<HTMLButtonElement>(null) vise un élément et vaut null
  // jusqu'au premier affichage ; useRef([]) garde une valeur qui existe dès le départ. Une seule
  // déclaration « T | null » rendait la seconde nullable et produisait de fausses erreurs partout
  // où on lit la valeur sans la tester.
  export function useRef<T>(initial: null): { current: T | null };
  export function useRef<T>(initial: T): { current: T };
  export function useCallback<T extends (...a: any[]) => any>(f: T, deps?: DependencyList): T;
  export function useMemo<T>(f: () => T, deps?: DependencyList): T;
  // Le contexte garde son type d'un bout à l'autre : createContext le pose, useContext le rend.
  // Déclaré en « any », le type se perdait et useSession() renvoyait {} — une fausse erreur.
  export interface Context<T> { Provider: any; Consumer: any; readonly __porte?: T }
  export function createContext<T>(valeur: T): Context<T>;
  export function useContext<T>(contexte: Context<T>): T;
  export const Fragment: any;
  export class Component<P = any, S = any> {
    constructor(props?: P);
    props: P & { children?: ReactNode };
    state: S;
    setState(s: Partial<S> | ((p: S) => Partial<S>)): void;
    render(): ReactNode;
  }
}

declare module "react/jsx-runtime" {
  export const jsx: any, jsxs: any, Fragment: any;
}
declare module "react-dom/client" {
  export function createRoot(e: Element | null): { render(n: any): void };
}

declare namespace JSX {
  // « key » est un accessoire que React se réserve. Sans les vrais types, il est pris pour un
  // accessoire ordinaire et chaque élément d'une liste produit une fausse erreur.
  interface IntrinsicAttributes { key?: string | number }
  interface IntrinsicElements { [nom: string]: any }
  interface Element { [k: string]: any }
  interface ElementClass { render?: any }
  interface ElementAttributesProperty { props: object }
  interface ElementChildrenAttribute { children: object }
}
