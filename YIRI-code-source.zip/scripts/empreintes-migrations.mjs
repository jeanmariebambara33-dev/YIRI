// Régénère supabase/MIGRATIONS.sha256 à partir des migrations réellement présentes.
//
// Ce fichier sert à une chose : vérifier, avant de coller une migration dans l'éditeur SQL de
// Supabase, que le texte collé est bien celui du dépôt. Il ne couvrait que 8 des 23 migrations —
// donc ni les paiements, ni les notifications, ni les relevés. Écrit à la main, il se
// désynchronisait à chaque ajout ; engendré, il ne peut plus.
//
// Usage : node scripts/empreintes-migrations.mjs
// Contrôle : node scripts/empreintes-migrations.mjs --verifier   (sortie 1 si un écart)
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const racine = path.resolve(import.meta.dirname, "..");
const dossier = path.join(racine, "supabase/migrations");
const cible = path.join(racine, "supabase/MIGRATIONS.sha256");

const lignes = fs.readdirSync(dossier)
  .filter((f) => /^\d{4}.*\.sql$/.test(f)).sort()
  .map((f) => {
    const somme = createHash("sha256").update(fs.readFileSync(path.join(dossier, f))).digest("hex");
    return `${somme}  supabase/migrations/${f}`;
  });

const contenu = lignes.join("\n") + "\n";

if (process.argv.includes("--verifier")) {
  const actuel = fs.existsSync(cible) ? fs.readFileSync(cible, "utf8") : "";
  if (actuel === contenu) {
    console.log(`OK    ${lignes.length} migrations, empreintes à jour`);
    process.exit(0);
  }
  const avant = new Set(actuel.trim().split("\n"));
  const apres = new Set(contenu.trim().split("\n"));
  for (const l of apres) if (!avant.has(l)) console.log("MANQUE OU DIFFÈRE :", l.split("  ")[1]);
  for (const l of avant) if (!apres.has(l)) console.log("EN TROP :", l.split("  ")[1]);
  console.log("\nRelancer : node scripts/empreintes-migrations.mjs");
  process.exit(1);
}

fs.writeFileSync(cible, contenu);
console.log(`${lignes.length} migrations -> supabase/MIGRATIONS.sha256`);
