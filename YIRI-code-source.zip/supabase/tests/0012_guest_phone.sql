-- Tests de la migration 0012 (téléphone du voyageur obligatoire à la réservation).
-- Base LOCALE ; auth.uid() simulé ; « reset role » = clé de service (postgres).
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 8) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values (t.u(7), 'reservations', t.u(5));

-- Un logement SOUS GESTION publié : c'est le seul cas réservable en ligne.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'gestion', 'Studio sous gestion', 'desc', 'Ouagadougou', 'Gounghin', 'adr',
        4, 1, 2, 20000, 1, 'publiee', false);
-- Et un logement « Visibilité », qui ne se réserve pas en ligne.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(2), t.u(3), 'annonce', 'Studio Visibilite', 'desc', 'Ouagadougou', 'Centre', 'adr',
        2, 1, 1, 15000, 1, 'publiee', false);

-- Un logement sous gestion n'apparaît dans la vue publique que si le mandat est signé ET que
-- la visite technique est faite (vue public_listings, 0001). Sans ça, il n'est pas réservable.
insert into management_agreements (property_id, contract_version, starts_on, signed,
                                   operational_check_done, expense_policy_version)
values (t.p(1), 'v1', current_date, true, true, 'v1');
-- L'abonnement qui rend l'annonce « Visibilité » visible publiquement.
insert into subscriptions (owner_id, property_id, plan, amount_xof, status, starts_at, ends_at)
values (t.u(3), t.p(2), 'mensuel', 5000, 'actif', current_date - 1, current_date + 30);

-- ============ La mise en forme des numéros ============
reset role;
select t.eq('les espaces disparaissent', $$select normalize_phone('70 00 00 01')$$, '70000001');
select t.eq('les tirets aussi', $$select normalize_phone('70-00-00-02')$$, '70000002');
select t.eq('les points aussi', $$select normalize_phone('70.00.00.03')$$, '70000003');
-- Les parenthèses disparaissent, mais on n'ajoute PAS un « + » que la personne n'a pas écrit :
-- deviner l'indicatif reviendrait à inventer une information.
select t.eq('les parenthèses aussi', $$select normalize_phone('(226) 70 00 00 04')$$, '22670000004');
select t.eq('l''indicatif « + » est conservé', $$select normalize_phone('+226 70 00 00 05')$$, '+22670000005');
select t.eq('le « 00 » international devient « + »', $$select normalize_phone('00226 70000006')$$, '+22670000006');
select t.eq('un numéro déjà propre reste identique', $$select normalize_phone('70000007')$$, '70000007');
select t.eq('un texte n''est pas un numéro', $$select coalesce(normalize_phone('appelle-moi'), 'NUL')$$, 'NUL');
select t.eq('un numéro trop court est refusé', $$select coalesce(normalize_phone('7000'), 'NUL')$$, 'NUL');
select t.eq('un numéro trop long est refusé', $$select coalesce(normalize_phone('1234567890123456789'), 'NUL')$$, 'NUL');
select t.eq('une chaîne vide est refusée', $$select coalesce(normalize_phone(''), 'NUL')$$, 'NUL');
select t.eq('« oui » n''est pas un numéro', $$select coalesce(normalize_phone('oui'), 'NUL')$$, 'NUL');
select t.eq('un numéro noyé dans du texte est refusé', $$select coalesce(normalize_phone('tel 70000001 svp'), 'NUL')$$, 'NUL');
select t.eq('un « + » au milieu est refusé', $$select coalesce(normalize_phone('700+00001'), 'NUL')$$, 'NUL');
select t.eq('un numéro nul reste nul', $$select coalesce(normalize_phone(null), 'NUL')$$, 'NUL');

-- ============ Réserver sans numéro : refusé ============
reset role; select t.as(1);
select t.must_fail('réservation sans numéro : refusée',
  format($$select * from create_booking(%L, current_date + 10, current_date + 12, 2, null)$$, t.p(1)));
select t.must_fail('réservation avec un numéro illisible : refusée',
  format($$select * from create_booking(%L, current_date + 10, current_date + 12, 2, 'appelle-moi')$$, t.p(1)));
select t.must_fail('réservation avec un numéro trop court : refusée',
  format($$select * from create_booking(%L, current_date + 10, current_date + 12, 2, '7000')$$, t.p(1)));
select t.eq('et rien n''a été créé au passage',
  format($$select count(*)::text from bookings where guest_id = %L$$, t.u(1)), '0');

-- Le message doit expliquer POURQUOI le numéro est demandé, sinon la personne abandonne.
select t.ok('un message explicite est préparé', $$select 1$$);
do $$
declare m text;
begin
  begin
    perform set_config('app.uid', (select t.u(1))::text, false);
    perform create_booking((select t.p(1)), current_date + 10, current_date + 12, 2, null);
  exception when others then m := sqlerrm;
  end;
  perform t.rec('le refus explique la remise des clés', m like '%remise des clés%', m);
end $$;

-- ============ Réserver avec un numéro : accepté et mis en forme ============
reset role; select t.as(1);
select t.ok('réservation avec un numéro valide : acceptée',
  format($$select * from create_booking(%L, current_date + 10, current_date + 12, 2, '70 00 00 11')$$, t.p(1)));
select t.eq('le numéro est enregistré mis en forme',
  format($$select guest_phone from bookings where guest_id = %L$$, t.u(1)), '70000011');
select t.eq('le voyageur relit son propre numéro',
  format($$select guest_phone from bookings where guest_id = %L$$, t.u(1)), '70000011');

-- Les autres règles de 0006 n'ont pas bougé : je vérifie les plus importantes.
reset role; select t.as(1);
select t.must_fail('un logement « Visibilité » ne se réserve toujours pas en ligne',
  format($$select * from create_booking(%L, current_date + 20, current_date + 22, 2, '70000011')$$, t.p(2)));
select t.must_fail('les dates passées sont toujours refusées',
  format($$select * from create_booking(%L, current_date - 2, current_date + 2, 2, '70000011')$$, t.p(1)));
select t.must_fail('trop de voyageurs : toujours refusé',
  format($$select * from create_booking(%L, current_date + 40, current_date + 42, 9, '70000011')$$, t.p(1)));
select t.must_fail('les dates qui chevauchent sont toujours refusées',
  format($$select * from create_booking(%L, current_date + 11, current_date + 13, 2, '70000011')$$, t.p(1)));
reset role; select t.as(3);
select t.must_fail('le propriétaire ne peut toujours pas réserver chez lui',
  format($$select * from create_booking(%L, current_date + 60, current_date + 62, 2, '70000033')$$, t.p(1)));
reset role; select t.as(0);
select t.must_fail('un visiteur non connecté ne peut pas réserver',
  format($$select * from create_booking(%L, current_date + 70, current_date + 72, 2, '70000099')$$, t.p(1)));

-- La contrainte de forme protège la colonne même si on écrit directement en base.
reset role;
select t.must_fail('la base refuse un numéro mal formé écrit en direct',
  format($$insert into bookings (property_id, guest_id, stay, guests, nightly_price_xof,
                                 accommodation_xof, taxes_xof, discount_xof, total_xof, status, guest_phone)
            values (%L, %L, daterange(current_date + 200, current_date + 202, '[)'), 2, 20000,
                    40000, 0, 0, 40000, 'confirmee', 'pas-un-numero')$$, t.p(1), t.u(2)));

-- ============ L'ancienne porte reste ouverte, volontairement ============
-- Le site en ligne appelle encore la version à quatre arguments. La retirer maintenant
-- casserait le bouton « Réserver » en production avant le redéploiement.
reset role; select t.as(2);
select t.ok('l''ancienne version à 4 arguments répond encore',
  format($$select * from create_booking(%L, current_date + 80, current_date + 82, 2)$$, t.p(1)));
select t.eq('mais elle laisse le numéro vide : c''est ce qu''on vient corriger',
  format($$select coalesce(guest_phone, 'VIDE') from bookings where guest_id = %L$$, t.u(2)), 'VIDE');

-- ============ Ce que les écrans affichent ============
-- La réservation du voyageur 1 porte un numéro, celle du voyageur 2 non.
reset role; select t.as(7);
select t.eq('l''équipe voit le numéro saisi au moment de réserver',
  format($$select guest_phone from bookings_queue() where guest_id = %L$$, t.u(1)), '70000011');
select t.eq('et rien d''inventé quand il n''y en a pas',
  format($$select coalesce(guest_phone, 'VIDE') from bookings_queue() where guest_id = %L$$, t.u(2)), 'VIDE');

-- Le profil sert de repli pour les réservations d'avant la migration.
reset role;
update profiles set phone = '76000002' where id = t.u(2);
reset role; select t.as(7);
select t.eq('à défaut, le numéro du profil est repris',
  format($$select guest_phone from bookings_queue() where guest_id = %L$$, t.u(2)), '76000002');

-- Côté propriétaire : toujours masqué avant paiement, visible après.
reset role; select t.as(3);
select t.eq('propriétaire : numéro masqué tant que le séjour n''est pas payé',
  format($$select coalesce(guest_phone, 'MASQUE') from owner_bookings() where id =
            (select id from bookings where guest_id = %L)$$, t.u(1)), 'MASQUE');
reset role;
update bookings set status = 'confirmee' where guest_id = t.u(1);
reset role; select t.as(3);
select t.eq('propriétaire : numéro visible une fois le séjour payé',
  format($$select guest_phone from owner_bookings() where id =
            (select id from bookings where guest_id = %L)$$, t.u(1)), '70000011');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0012 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
