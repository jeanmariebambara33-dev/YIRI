// Localités du Burkina Faso proposées dans les listes. Toute autre localité peut être saisie librement.
export const OTHER_PLACE = "Autre localité";
export const BF_PLACES = [
  "Ouagadougou", "Bobo-Dioulasso", "Koudougou", "Banfora", "Ouahigouya", "Pouytenga", "Kaya", "Dédougou",
  "Fada N'Gourma", "Tenkodogo", "Dori", "Gaoua", "Ziniaré", "Réo", "Manga", "Léo", "Houndé", "Orodara",
  "Dano", "Diébougou", "Kombissiri", "Koupéla", "Yako", "Titao", "Djibo", "Nouna", "Tougan", "Boulsa",
  "Kongoussi", "Gourcy", "Sapouy", "Pô", "Bittou", "Garango", "Zorgho", "Ouargaye", "Diapaga", "Sebba",
  "Batié", "Kaya", "Boromo", "Solenzo", "Toma", "Gayéri", "Matiacoali", "Bogandé", "Barsalogho", "Saaba",
  "Tanghin-Dassouri", "Komsilga", "Loumbila", "Koubri", "Pabré", "Bagré", "Niangoloko", "Sindou",
].filter((c, i, a) => a.indexOf(c) === i);
// Les deux premières (Ouagadougou, Bobo-Dioulasso) restent en tête ; le reste est trié par ordre alphabétique.
export const PLACES_SORTED = [BF_PLACES[0], BF_PLACES[1], ...BF_PLACES.slice(2).sort((a, b) => a.localeCompare(b, "fr"))];
