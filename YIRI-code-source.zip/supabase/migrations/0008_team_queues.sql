-- YIRI — 0008 : files d'attente de l'équipe (lecture seule, autorisées par les mêmes permissions que 0002 à 0007).
-- Pourquoi : la table owner_identity est fermée à tous les clients (0007). L'équipe « validation » a donc besoin
-- d'une fonction pour SAVOIR qu'un dossier attend, sans pour autant lire le numéro de la pièce.
-- Le numéro reste accessible uniquement par open_owner_identity(), qui journalise chaque consultation.
-- Rien des migrations 0001 à 0007 n'est modifié : ce fichier n'ajoute que des fonctions de lecture.

-- Dossiers d'identité en attente de décision. Ne renvoie JAMAIS le numéro de la pièce.
create or replace function identity_queue()
returns table (user_id uuid, full_name text, email text, id_type text, submitted_at timestamptz, files_sent int, state text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  return query
    select i.user_id, p.full_name, u.email::text, i.id_type, i.submitted_at, identity_file_count(i.user_id), i.state
      from owner_identity i
      join profiles p on p.id = i.user_id
      left join auth.users u on u.id = i.user_id
     where i.state in ('en_attente', 'a_renvoyer')
     order by i.submitted_at;
end $$;
revoke all on function identity_queue() from public, anon;
grant execute on function identity_queue() to authenticated;

-- Liens temporaires vers le recto et le verso d'un dossier : la fonction n'ouvre rien par elle-même,
-- elle sert à l'interface pour savoir quels fichiers existent. La lecture reste soumise aux règles de stockage,
-- donc à une ouverture récente du dossier par open_owner_identity().
create or replace function identity_file_paths(p_user uuid)
returns table (path text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_perm('validation') then
    raise exception 'Action réservée à l''équipe habilitée (validation).' using errcode = '42501';
  end if;
  if to_regclass('storage.objects') is null then return; end if;
  return query execute
    $q$ select name::text from storage.objects
         where bucket_id = 'owner-identity' and (storage.foldername(name))[1] = $1::text order by name $q$
    using p_user;
end $$;
revoke all on function identity_file_paths(uuid) from public, anon;
grant execute on function identity_file_paths(uuid) to authenticated;
