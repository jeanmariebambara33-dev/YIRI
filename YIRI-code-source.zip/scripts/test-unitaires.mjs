// Lance les tests unitaires de src/lib.
//
// Pourquoi ce script existe : les fichiers .test.ts importent leurs modules sans extension
// (« ./money »), ce que Node refuse en ESM. Ils étaient donc présents dans le dépôt mais
// INEXÉCUTABLES — ils donnaient une fausse impression de couverture, ce que l'audit a relevé.
// Plutôt que d'ajouter une extension à chaque import de l'application, on compile chaque
// fichier de test avec le MÊME esbuild que le site, puis on le passe à Node.
//
// Usage : node scripts/test-unitaires.mjs
import * as esbuild from "/opt/npm-tools/node_modules/esbuild/lib/main.js";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";

const racine = path.resolve(import.meta.dirname, "..");
const dossier = path.join(racine, "src/lib");
const tests = fs.readdirSync(dossier).filter((f) => f.endsWith(".test.ts")).sort();

if (tests.length === 0) {
  console.log("Aucun fichier de test unitaire.");
  process.exit(0);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "yiri-tests-"));
let echecs = 0;

for (const t of tests) {
  const sortie = path.join(tmp, t.replace(/\.ts$/, ".mjs"));
  await esbuild.build({
    entryPoints: [path.join(dossier, t)],
    outfile: sortie,
    bundle: true, format: "esm", platform: "node", jsx: "automatic",
    // React n'est pas installé localement : les tests ne doivent pas en dépendre.
    // Si l'un d'eux tire un composant, on veut le savoir plutôt que de le masquer.
    external: ["node:*"],
    // React n'est pas installé localement (le site le charge depuis un CDN). payments.test.ts
    // n'exerce que la logique pure du magasin, jamais un rendu : un substitut minimal suffit
    // à compiler, et on reste honnête sur ce qui est testé — des règles, pas des composants.
    plugins: [{
      name: "react-substitut",
      setup(build) {
        build.onResolve({ filter: /^react(\/jsx-runtime|\/jsx-dev-runtime)?$/ },
                        (a) => ({ path: a.path, namespace: "react-substitut" }));
        build.onLoad({ filter: /.*/, namespace: "react-substitut" }, () => ({
          contents: `const noop = () => {}; const identite = (x) => x;
            export const createContext = () => ({ Provider: identite, Consumer: identite });
            export const useState = (v) => [v, noop]; export const useEffect = noop;
            export const useMemo = (fn) => fn(); export const useCallback = identite;
            export const useRef = () => ({ current: null }); export const useContext = () => null;
            export const jsx = noop, jsxs = noop, Fragment = noop;
            export default { createContext, useState, useEffect, useMemo, useCallback, useRef, useContext };`,
          loader: "js",
        }));
      },
    }],
    logLevel: "silent",
  }).catch((e) => {
    console.log(`ECHEC  ${t} : compilation impossible`);
    console.log(String(e.message || e).split("\n").slice(0, 4).map((l) => "   " + l).join("\n"));
    echecs++;
    return null;
  });

  if (!fs.existsSync(sortie)) continue;

  try {
    const out = execFileSync(process.execPath, ["--test", sortie], { encoding: "utf8", stdio: "pipe" });
    const pass = (out.match(/^# pass (\d+)/m) || [])[1] ?? "?";
    const fail = (out.match(/^# fail (\d+)/m) || [])[1] ?? "?";
    console.log(`OK     ${t} : ${pass} réussis, ${fail} échoués`);
    if (fail !== "0") { echecs++; console.log(out.split("\n").filter((l) => l.includes("not ok")).slice(0, 5).map((l) => "   " + l).join("\n")); }
  } catch (e) {
    echecs++;
    const out = String(e.stdout || "") + String(e.stderr || "");
    console.log(`ECHEC  ${t}`);
    console.log(out.split("\n").filter((l) => l.includes("not ok") || l.includes("Error")).slice(0, 6).map((l) => "   " + l).join("\n"));
  }
}

fs.rmSync(tmp, { recursive: true, force: true });
console.log(echecs === 0 ? "\nTOUS LES TESTS UNITAIRES PASSENT" : `\n${echecs} fichier(s) en échec`);
process.exit(echecs === 0 ? 0 : 1);
