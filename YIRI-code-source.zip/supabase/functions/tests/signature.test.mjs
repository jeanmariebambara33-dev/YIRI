// Tests de la vérification de signature des messages du prestataire.
//
// La fonction serveur tourne sous Deno ; ces tests tournent sous Node, qui expose les MÊMES
// API (crypto.subtle, TextEncoder). Seul « Deno.env » est simulé. Ce qui est testé ici est donc
// bien le code qui sera déployé, et non une reproduction.
//
// Usage : node --experimental-strip-types supabase/functions/tests/signature.test.mjs
//
// Le vecteur de référence est calculé indépendamment (hmac/hashlib en Python) : si les deux
// implémentations tombent sur la même signature, la formule est la bonne.

import { createHmac } from "node:crypto";

// Deno.serve est appelé à la fin du fichier testé : on le neutralise pour pouvoir l'importer ici.
globalThis.Deno = { env: { get: (k) => process.env[k] }, serve: () => {} };

// On teste le fichier RÉELLEMENT déployé, celui qui sera collé dans Supabase, et non une copie.
const { hmacHex, egalConstant, signatureValide } = await import("../paiement-webhook/index.ts");

let reussis = 0, total = 0;
const echecs = [];
function verifier(label, condition, detail = "") {
  total++;
  if (condition) reussis++;
  else echecs.push(`${label}${detail ? " — " + detail : ""}`);
}

const SECRET = "whsec_test_0123456789";
const CORPS = '{"event":"transaction.success","data":{"id":"sp_abc","amount":60000}}';
const TS_FIXE = "1760000000";
const REFERENCE_PYTHON = "b0021e24230a5562c46fac868f88438848ba02e17b4c11d3180379f713e696cf";

// ---------- La formule ----------
const calculee = await hmacHex(SECRET, `${TS_FIXE}.${CORPS}`);
verifier("le HMAC correspond au vecteur calculé en Python", calculee === REFERENCE_PYTHON, calculee);
verifier("il correspond aussi à node:crypto",
  calculee === createHmac("sha256", SECRET).update(`${TS_FIXE}.${CORPS}`).digest("hex"));
verifier("sortie hexadécimale de 64 caractères minuscules", /^[0-9a-f]{64}$/.test(calculee), calculee);
verifier("l'horodatage fait partie du texte signé",
  calculee !== await hmacHex(SECRET, CORPS));
verifier("un secret différent donne une signature différente",
  calculee !== await hmacHex(SECRET + "x", `${TS_FIXE}.${CORPS}`));

// ---------- La comparaison ----------
verifier("comparaison : deux chaînes identiques", egalConstant("abc", "abc"));
verifier("comparaison : un octet de différence", !egalConstant("abc", "abd"));
verifier("comparaison : longueurs différentes", !egalConstant("abc", "abcd"));
verifier("comparaison : chaîne vide contre chaîne vide", egalConstant("", ""));

// ---------- La vérification complète ----------
const maintenant = () => String(Math.floor(Date.now() / 1000));
const signer = (corps, ts) => hmacHex(SECRET, `${ts}.${corps}`);

{
  const ts = maintenant();
  const v = await signatureValide(CORPS, await signer(CORPS, ts), ts, SECRET);
  verifier("message authentique accepté", v.ok, v.ok ? "" : v.raison);
}
{
  const ts = maintenant();
  const sig = (await signer(CORPS, ts)).toUpperCase();
  const v = await signatureValide(CORPS, sig, ts, SECRET);
  verifier("signature en majuscules acceptée", v.ok, v.ok ? "" : v.raison);
}
{
  const ts = maintenant();
  const v = await signatureValide(CORPS, " " + await signer(CORPS, ts) + " ", ts, SECRET);
  verifier("espaces autour de la signature tolérés", v.ok, v.ok ? "" : v.raison);
}
{
  // Le scénario qui compte : quelqu'un modifie le montant d'un message par ailleurs valide.
  const ts = maintenant();
  const sig = await signer(CORPS, ts);
  const falsifie = CORPS.replace("60000", "1");
  const v = await signatureValide(falsifie, sig, ts, SECRET);
  verifier("corps modifié refusé", !v.ok && v.raison === "signature invalide");
}
{
  const ts = maintenant();
  const v = await signatureValide(CORPS, await signer(CORPS, ts), ts, "mauvais_secret");
  verifier("mauvais secret refusé", !v.ok && v.raison === "signature invalide");
}
{
  // Rejeu : un message authentique capté il y a une heure.
  const vieux = String(Math.floor(Date.now() / 1000) - 3600);
  const v = await signatureValide(CORPS, await signer(CORPS, vieux), vieux, SECRET);
  verifier("message rejoué une heure plus tard refusé", !v.ok && v.raison.startsWith("horodatage trop ancien"), v.ok ? "accepté" : v.raison);
}
{
  const futur = String(Math.floor(Date.now() / 1000) + 3600);
  const v = await signatureValide(CORPS, await signer(CORPS, futur), futur, SECRET);
  verifier("horodatage dans le futur refusé", !v.ok && v.raison.startsWith("horodatage trop ancien"));
}
{
  // Juste à la limite : 299 s passent, 301 s ne passent pas.
  const limite = String(Math.floor(Date.now() / 1000) - 299);
  const v1 = await signatureValide(CORPS, await signer(CORPS, limite), limite, SECRET);
  verifier("299 secondes : accepté", v1.ok, v1.ok ? "" : v1.raison);
  const trop = String(Math.floor(Date.now() / 1000) - 301);
  const v2 = await signatureValide(CORPS, await signer(CORPS, trop), trop, SECRET);
  verifier("301 secondes : refusé", !v2.ok);
}
{
  const ts = maintenant();
  const v = await signatureValide(CORPS, null, ts, SECRET);
  verifier("signature absente refusée", !v.ok && v.raison === "signature absente");
}
{
  const v = await signatureValide(CORPS, await signer(CORPS, "1"), null, SECRET);
  verifier("horodatage absent refusé", !v.ok && v.raison === "horodatage absent");
}
{
  const v = await signatureValide(CORPS, "abc", "pas-un-nombre", SECRET);
  verifier("horodatage illisible refusé", !v.ok && v.raison === "horodatage illisible");
}
{
  // Un JSON re-sérialisé n'a pas la même signature : c'est pourquoi le code lit le corps brut.
  const ts = maintenant();
  const sig = await signer(CORPS, ts);
  const reserialise = JSON.stringify(JSON.parse(CORPS), null, 2);
  const v = await signatureValide(reserialise, sig, ts, SECRET);
  verifier("corps re-sérialisé refusé (d'où la lecture du corps brut)", !v.ok);
}
{
  const ts = maintenant();
  const v = await signatureValide(CORPS, "0".repeat(64), ts, SECRET);
  verifier("signature inventée de bonne longueur refusée", !v.ok && v.raison === "signature invalide");
}

console.log(`${reussis} / ${total} tests de signature réussis`);
for (const e of echecs) console.log("  ÉCHEC :", e);
process.exit(echecs.length === 0 ? 0 : 1);
