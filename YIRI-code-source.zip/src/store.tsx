// Navigation du site : rien d'autre.
//
// Ce fichier contenait auparavant tout un faux serveur — logements, réservations, paiements,
// candidatures — recopié dans localStorage. Plus aucun écran ne s'en servait : les données
// viennent de la base (src/lib/api.ts) et les droits sont vérifiés par la base, pas ici.
// Ce code mort partait pourtant dans le site livré, et ses « ops » de paiement pouvaient
// laisser croire qu'un paiement était géré côté navigateur. Il ne reste que le routeur.
import * as React from "react";
// PackId vient de packs.ts. Il était importé de data/demo, où ce type n'a jamais existé :
// esbuild efface les imports de type sans les résoudre, donc rien ne le signalait.
import type { PackId } from "./data/packs";

interface Ctx {
  route: Route;
  go: (r: Route) => void;
  back: () => void;
  canBack: boolean;
}

const StoreCtx = React.createContext<Ctx | null>(null);

export type Route =
  | { name: "accueil" }
  | { name: "catalogue"; city?: string }
  | { name: "logement"; id: string }
  | { name: "offre-annonce" }
  | { name: "offre-gestion" }
  | { name: "offre-partenariat" }
  | { name: "proprietaires"; need?: string; at?: string }
  | { name: "demande"; pack?: PackId | "indecis" }
  | { name: "mes-reservations" }
  | { name: "paiement"; id: string }
  | { name: "merci" }
  | { name: "proprietaire" }
  | { name: "nouvelle-annonce" }
  | { name: "connexion" }
  | { name: "compte"; mode?: "connexion" | "inscription" | "oubli" | "nouveau" }
  | { name: "espace" }
  | { name: "equipe" }
  | { name: "sejours" }
  | { name: "offre"; id: string }
  | { name: "mes-sejours" }
  | { name: "legal"; page: "mentions" | "cgu" | "confidentialite" | "cookies" }
  | { name: "admin"; tab?: string };


// Navigation par ancre (#logements, #annonce…) : le bouton « retour » du navigateur fonctionne.
const HASH_TO_ROUTE: Record<string, Route> = {
  logements: { name: "catalogue" },
  visibilite: { name: "offre-annonce" },
  serenite: { name: "offre-gestion" },
  partenariat: { name: "offre-partenariat" },
  proprietaires: { name: "proprietaires" },
  solutions: { name: "proprietaires", at: "solutions" },
  demande: { name: "demande" },
  reservations: { name: "mes-reservations" },
  merci: { name: "merci" },
  proprietaire: { name: "proprietaire" },
  "nouvelle-annonce": { name: "nouvelle-annonce" },
  admin: { name: "admin" },
  connexion: { name: "connexion" },
  compte: { name: "compte" },
  espace: { name: "espace" },
  equipe: { name: "equipe" },
  sejours: { name: "sejours" },
  "mes-sejours": { name: "mes-sejours" },
  mentions: { name: "legal", page: "mentions" },
  cgu: { name: "legal", page: "cgu" },
  confidentialite: { name: "legal", page: "confidentialite" },
  cookies: { name: "legal", page: "cookies" },
};

function routeToHash(r: Route): string {
  switch (r.name) {
    case "accueil": return "";
    case "catalogue": return "logements";
    case "logement": return `logement-${r.id}`;
    case "offre-annonce": return "visibilite";
    case "offre-gestion": return "serenite";
    case "offre-partenariat": return "partenariat";
    case "proprietaires": return r.at ? r.at : r.need ? `proprietaires-${r.need}` : "proprietaires";
    case "demande": return r.pack ? `demande-${r.pack}` : "demande";
    case "mes-reservations": return "reservations";
    case "paiement": return `paiement-${r.id}`;
    case "merci": return "merci";
    case "proprietaire": return "proprietaire";
    case "nouvelle-annonce": return "nouvelle-annonce";
    case "connexion": return "connexion";
    case "compte": return r.mode && r.mode !== "connexion" ? `compte-${r.mode}` : "compte";
    case "espace": return "espace";
    case "equipe": return "equipe";
    case "sejours": return "sejours";
    case "offre": return `offre-${r.id}`;
    case "mes-sejours": return "mes-sejours";
    case "legal": return r.page;
    case "admin": return r.tab ? `admin-${r.tab}` : "admin";
  }
}

function hashToRoute(raw: string): Route {
  const h = raw.replace(/^#/, "");
  if (h.startsWith("paiement-")) return { name: "paiement", id: h.slice(9) };
  if (h.startsWith("logement-")) return { name: "logement", id: h.slice("logement-".length) };
  if (h.startsWith("proprietaires-")) return { name: "proprietaires", need: h.slice(14) };
  if (h.startsWith("demande-")) return { name: "demande", pack: h.slice(8) as PackId | "indecis" };
  if (h.startsWith("admin-")) return { name: "admin", tab: h.slice("admin-".length) };
  if (h.startsWith("offre-") && !["offre-annonce", "offre-gestion", "offre-partenariat"].includes(h)) {
    return { name: "offre", id: h.slice("offre-".length) };
  }
  if (h.startsWith("compte-")) {
    const m = h.slice("compte-".length);
    if (m === "inscription" || m === "oubli" || m === "nouveau") return { name: "compte", mode: m };
    return { name: "compte" };
  }
  return HASH_TO_ROUTE[h] ?? { name: "accueil" };
}

function initialRoute(): Route {
  try { return hashToRoute(window.location.hash); } catch { return { name: "accueil" }; }
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [route, setRoute] = React.useState<Route>(initialRoute);

  const stack = React.useRef<Route[]>([]);
  const routeRef = React.useRef(route);
  routeRef.current = route;
  const [depth, setDepth] = React.useState(0);

  // Le bouton « retour » du navigateur doit marcher comme sur n'importe quel site.
  React.useEffect(() => {
    const onHash = () => {
      const r = hashToRoute(window.location.hash);
      if (routeToHash(r) === routeToHash(routeRef.current)) return;
      const top = stack.current[stack.current.length - 1];
      if (top && routeToHash(top) === routeToHash(r)) stack.current.pop(); else stack.current.push(routeRef.current);
      setDepth(stack.current.length);
      setRoute(r); try { window.scrollTo({ top: 0 }); } catch {}
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const go = React.useCallback((r: Route) => {
    if (routeToHash(r) !== routeToHash(routeRef.current)) { stack.current.push(routeRef.current); setDepth(stack.current.length); }
    routeRef.current = r;
    setRoute(r);
    try { window.location.hash = routeToHash(r); } catch {}
    try { window.scrollTo({ top: 0 }); } catch {}
  }, []);

  const back = React.useCallback(() => {
    const prev = stack.current.pop() ?? { name: "accueil" } as Route;
    setDepth(stack.current.length);
    routeRef.current = prev;
    setRoute(prev);
    try { window.location.hash = routeToHash(prev); } catch {}
    try { window.scrollTo({ top: 0 }); } catch {}
  }, []);

  return <StoreCtx.Provider value={{ route, go, back, canBack: depth > 0 }}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = React.useContext(StoreCtx);
  if (!c) throw new Error("StoreProvider manquant");
  return c;
}
