import * as React from "react";
import { Button } from "./ui";

// Installation sur l'écran d'accueil.
//  * Android et Chrome : le navigateur propose « beforeinstallprompt », on l'affiche au bon moment.
//  * iPhone et iPad : Safari ne propose rien, il faut expliquer le geste (Partager → Sur l'écran d'accueil).
// Le bandeau ne revient pas si la personne l'a écarté, et disparaît dès que l'application est installée.

const ECARTE = "yiri-install-ecarte";

type Invite = { prompt(): Promise<void>; userChoice: Promise<{ outcome: string }> };

function estInstallee(): boolean {
  try {
    if (window.matchMedia?.("(display-mode: standalone)").matches) return true;
    return (navigator as unknown as { standalone?: boolean }).standalone === true;
  } catch { return false; }
}

function estIOS(): boolean {
  try {
    const ua = navigator.userAgent;
    const ios = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    return ios && /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS/.test(ua);
  } catch { return false; }
}

function lu(cle: string): boolean {
  try { return localStorage.getItem(cle) === "1"; } catch { return false; }
}
function ecrire(cle: string) {
  try { localStorage.setItem(cle, "1"); } catch { /* stockage refusé : le bandeau reviendra, sans gravité */ }
}

export function InstallBanner() {
  const [invite, setInvite] = React.useState<Invite | null>(null);
  const [iosVisible, setIosVisible] = React.useState(false);
  const [cache, setCache] = React.useState(() => lu(ECARTE) || estInstallee());

  React.useEffect(() => {
    if (cache) return;
    const surInvite = (e: Event) => { e.preventDefault(); setInvite(e as unknown as Invite); };
    const surInstall = () => { setInvite(null); setIosVisible(false); setCache(true); };
    window.addEventListener("beforeinstallprompt", surInvite);
    window.addEventListener("appinstalled", surInstall);
    // iOS n'émet aucun événement : on propose après un court délai, le temps que la page soit lue.
    const t = estIOS() ? window.setTimeout(() => setIosVisible(true), 4000) : 0;
    return () => {
      window.removeEventListener("beforeinstallprompt", surInvite);
      window.removeEventListener("appinstalled", surInstall);
      if (t) clearTimeout(t);
    };
  }, [cache]);

  const fermer = () => { ecrire(ECARTE); setCache(true); setInvite(null); setIosVisible(false); };

  const installer = async () => {
    if (!invite) return;
    try {
      await invite.prompt();
      await invite.userChoice;
    } catch { /* l'invitation a expiré : on laisse le bandeau */ }
    finally { setInvite(null); ecrire(ECARTE); setCache(true); }
  };

  if (cache || (!invite && !iosVisible)) return null;

  return (
    <div role="region" aria-label="Installer l'application"
         className="fixed inset-x-3 bottom-3 z-40 mx-auto max-w-md rounded-2xl border border-line-strong bg-surface p-4 shadow-lg">
      <div className="flex items-start gap-3">
        <img src="/icone-192.png" alt="" width="44" height="44" className="rounded-xl" />
        <div className="min-w-0 flex-1">
          <p className="font-semibold text-ink">Installer YIRI sur votre téléphone</p>
          {invite ? (
            <p className="mt-0.5 text-sm text-muted">Un accès direct, sans passer par le navigateur.</p>
          ) : (
            <p className="mt-0.5 text-sm text-muted">
              Touchez <span className="font-semibold text-ink">Partager</span>, puis
              <span className="font-semibold text-ink"> Sur l'écran d'accueil</span>.
            </p>
          )}
        </div>
        <button onClick={fermer} aria-label="Fermer"
                className="-mr-1 -mt-1 rounded-full p-1.5 text-muted cursor-pointer hover:bg-sunk hover:text-ink">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" aria-hidden="true">
            <path d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </div>
      {invite && (
        <div className="mt-3 flex gap-2">
          <Button size="sm" onClick={() => void installer()}>Installer</Button>
          <Button size="sm" variant="ghost" onClick={fermer}>Plus tard</Button>
        </div>
      )}
    </div>
  );
}

/** Enregistre le service worker. Sans lui, l'application reste utilisable : elle perd seulement le hors-connexion. */
export function enregistrerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  // Un service worker n'est autorisé qu'en contexte sécurisé : https, localhost ou 127.0.0.1.
  // Ouvert comme simple fichier, il n'y en a pas, et l'application fonctionne quand même.
  if (!window.isSecureContext) return;
  const lancer = () => {
    navigator.serviceWorker.register("/sw.js").catch(() => { /* échec sans conséquence pour l'utilisateur */ });
  };
  if (document.readyState === "complete") lancer();
  else window.addEventListener("load", lancer, { once: true });
}
