import * as React from "react";
import { Button, Field, inputCls, Pill, Money } from "../ui";
import * as api from "../lib/api";

// Relevés de revenus et signalements.
//
// Côté propriétaire, le détail du calcul est montré en entier : ce qui a été encaissé, sa part,
// la commission YIRI, les dépenses retenues. Un propriétaire doit pouvoir refaire l'addition
// lui-même — c'est son argent, et un chiffre qu'on ne peut pas vérifier n'inspire pas confiance.

function mois(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}

const STATUT: Record<string, [string, "neutral" | "warn" | "good"]> = {
  a_valider: ["À régler", "warn"],
  approuve: ["À régler", "warn"],
  en_cours: ["Partiellement réglé", "warn"],
  verse: ["Réglé", "good"],
  echoue: ["Échec du virement", "neutral"],
  suspendu: ["Suspendu", "neutral"],
};

/** Ce que YIRI doit au propriétaire, période par période. */
export function MesRevenus() {
  const [data, setData] = React.useState<api.Statement[] | null>(null);
  const [erreur, setErreur] = React.useState<string | null>(null);

  React.useEffect(() => {
    let vivant = true;
    api.myStatements().then((r) => { if (vivant) setData(r); })
      .catch((e) => { if (vivant) { setErreur(e instanceof Error ? e.message : "Lecture impossible."); setData([]); } });
    return () => { vivant = false; };
  }, []);

  if (erreur) return <div className="rounded-2xl border border-danger/40 bg-danger/10 p-4 text-sm font-medium text-danger">{erreur}</div>;
  if (!data || data.length === 0) return null;

  const du = data.reduce((s, r) => s + Math.max(0, r.amount_due_xof - r.amount_paid_xof), 0);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="font-display text-lg font-bold text-ink">Mes revenus</h2>
        {du > 0 && <p className="text-sm text-muted">Reste à vous verser : <strong className="text-ink"><Money value={du} /></strong></p>}
      </div>

      {data.map((r) => {
        const [lab, tone] = STATUT[r.status] ?? [r.status, "neutral" as const];
        const reste = Math.max(0, r.amount_due_xof - r.amount_paid_xof);
        return (
          <div key={r.id} className="rounded-2xl border border-line bg-surface p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold text-ink">{mois(r.period_start)} → {mois(r.period_end)}</p>
                {r.verse_le && (
                  <p className="text-sm text-muted">
                    Versé le {new Date(r.verse_le).toLocaleDateString("fr-FR")}
                    {r.reference ? ` · référence ${r.reference}` : ""}
                  </p>
                )}
              </div>
              <Pill tone={tone}>{lab}</Pill>
            </div>

            {/* Le calcul en entier : le propriétaire doit pouvoir refaire l'addition. */}
            <dl className="mt-3 rounded-xl bg-sunk p-3 text-sm">
              <div className="flex justify-between py-0.5">
                <dt className="text-muted">Revenus des séjours payés</dt>
                <dd className="font-medium text-ink"><Money value={r.rlp_xof} /></dd>
              </div>
              <div className="flex justify-between py-0.5">
                <dt className="text-muted">Commission YIRI</dt>
                <dd className="font-medium text-ink">− <Money value={r.yiri_commission_xof} /></dd>
              </div>
              <div className="flex justify-between border-t border-line py-1 pt-1.5">
                <dt className="font-semibold text-ink">Votre part</dt>
                <dd className="font-semibold text-ink"><Money value={r.owner_share_xof} /></dd>
              </div>
              {r.owner_expenses_xof > 0 && (
                <div className="flex justify-between py-0.5">
                  <dt className="text-muted">Dépenses avancées par YIRI</dt>
                  <dd className="font-medium text-ink">− <Money value={r.owner_expenses_xof} /></dd>
                </div>
              )}
              <div className="mt-1 flex justify-between border-t border-line pt-1.5">
                <dt className="font-semibold text-ink">{r.amount_due_xof < 0 ? "À régulariser" : "Montant qui vous revient"}</dt>
                <dd className="font-semibold text-ink"><Money value={Math.abs(r.amount_due_xof)} /></dd>
              </div>
              {r.amount_paid_xof > 0 && reste > 0 && (
                <div className="flex justify-between py-0.5">
                  <dt className="text-muted">Déjà versé</dt>
                  <dd className="font-medium text-ink"><Money value={r.amount_paid_xof} /></dd>
                </div>
              )}
            </dl>

            {r.amount_due_xof < 0 && (
              <p className="mt-2 text-sm text-muted">
                Les dépenses avancées dépassent votre part sur cette période. Le solde se régularise
                sur le relevé suivant — l'équipe YIRI vous l'explique si vous le demandez.
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}

/** Signaler un problème, et suivre ce qu'on a signalé. */
export function MesSignalements({ logements }: { logements?: { id: string; title: string }[] }) {
  const [data, setData] = React.useState<api.SupportRequest[] | null>(null);
  const [ouvert, setOuvert] = React.useState(false);
  const [cat, setCat] = React.useState("acces_logement");
  const [msg, setMsg] = React.useState("");
  const [bien, setBien] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [erreur, setErreur] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    let vivant = true;
    api.mySupportRequests().then((r) => { if (vivant) setData(r); })
      .catch(() => { if (vivant) setData([]); });
    return () => { vivant = false; };
  }, [tick]);

  const envoyer = () => void (async () => {
    setBusy(true); setErreur(null);
    try {
      await api.openSupportRequest(cat, msg, bien || undefined);
      setMsg(""); setBien(""); setOuvert(false); setTick((t) => t + 1);
    } catch (e) { setErreur(e instanceof Error ? e.message : "Envoi impossible."); }
    finally { setBusy(false); }
  })();

  const enCours = (data ?? []).filter((s) => ["ouvert", "en_cours"].includes(s.status));
  const closes = (data ?? []).filter((s) => !["ouvert", "en_cours"].includes(s.status));

  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display font-bold text-ink">Un problème ?</h3>
          <p className="mt-1 text-sm text-muted">
            Signalez-le à l'équipe YIRI. Nous vous répondons, et vous suivez le traitement ici.
          </p>
        </div>
        {!ouvert && <Button size="sm" variant="secondary" onClick={() => setOuvert(true)}>Signaler un problème</Button>}
      </div>

      {ouvert && (
        <div className="mt-3 flex flex-col gap-3 border-t border-line pt-3">
          {erreur && <p role="alert" className="rounded-xl border border-danger/40 bg-danger/10 px-3 py-2 text-sm font-medium text-danger">{erreur}</p>}
          <Field label="De quoi s'agit-il ?" htmlFor="s-cat">
            <select id="s-cat" className={inputCls} value={cat} onChange={(e) => setCat(e.target.value)}>
              {api.SUPPORT_CATEGORIES.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
            </select>
          </Field>
          {logements && logements.length > 0 && (
            <Field label="Logement concerné" htmlFor="s-bien" hint="Facultatif.">
              <select id="s-bien" className={inputCls} value={bien} onChange={(e) => setBien(e.target.value)}>
                <option value="">Aucun en particulier</option>
                {logements.map((l) => <option key={l.id} value={l.id}>{l.title}</option>)}
              </select>
            </Field>
          )}
          <Field label="Décrivez le problème" htmlFor="s-msg" hint="Soyez précis : cela nous fait gagner du temps.">
            <textarea id="s-msg" rows={4} className={inputCls} value={msg} onChange={(e) => setMsg(e.target.value)}
                      placeholder="La serrure du portail ne s'ouvre pas avec le code donné." />
          </Field>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" disabled={busy || msg.trim().length < 10} onClick={envoyer}>
              {busy ? "Envoi…" : "Envoyer"}
            </Button>
            <Button size="sm" variant="ghost" disabled={busy} onClick={() => { setOuvert(false); setErreur(null); }}>Annuler</Button>
          </div>
        </div>
      )}

      {enCours.length > 0 && (
        <ul className="mt-3 flex flex-col gap-2">
          {enCours.map((s) => <SignalementLigne key={s.id} s={s} />)}
        </ul>
      )}
      {closes.length > 0 && (
        <details className="mt-3">
          <summary className="cursor-pointer text-sm font-semibold text-ink">Signalements traités ({closes.length})</summary>
          <ul className="mt-2 flex flex-col gap-2">
            {closes.map((s) => <SignalementLigne key={s.id} s={s} />)}
          </ul>
        </details>
      )}
    </div>
  );
}

function SignalementLigne({ s }: { s: api.SupportRequest }) {
  const [lab, tone] = api.SUPPORT_STATUS_FR[s.status] ?? [s.status, "neutral" as const];
  return (
    <li className="rounded-xl bg-sunk p-3 text-sm">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="font-semibold text-ink">{api.supportCategoryLabel(s.category)}</p>
        <Pill tone={tone}>{lab}</Pill>
      </div>
      {s.titre && <p className="text-xs text-muted">{s.titre}</p>}
      <p className="mt-1 text-ink">{s.message}</p>
      {s.resolution && (
        <p className="mt-2 border-t border-line pt-2 text-ink">
          <span className="text-muted">Réponse de YIRI : </span>{s.resolution}
        </p>
      )}
    </li>
  );
}
