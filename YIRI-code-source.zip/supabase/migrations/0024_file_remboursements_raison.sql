-- =====================================================================
-- 0024 — La file des remboursements transporte la raison de l'échec
-- =====================================================================
--
-- CE QUE ÇA CORRIGE. L'écran d'équipe affiche la raison d'un remboursement échoué :
--
--     {r.failure_reason ? ` · ${r.failure_reason}` : ""}
--
-- Mais refunds_queue() ne renvoyait pas cette colonne. L'équipe voyait donc « échoué », sans
-- jamais savoir pourquoi — alors que la raison est bel et bien écrite en base, par fail_refund()
-- quand le versement n'aboutit pas, et par confirm_refund_paid() quand le montant versé diffère
-- du montant approuvé. L'information existait, l'écran la demandait, le tuyau manquait.
--
-- Rien n'était visible : une propriété absente vaut « undefined » en JavaScript, et la ligne
-- s'effaçait silencieusement. C'est une vérification de types qui l'a trouvé, pas un test.
--
-- CE QUE ÇA NE FAIT PAS. Aucune donnée n'est touchée, aucune table modifiée, aucune permission
-- changée. On remplace une fonction de lecture par la même, avec une colonne de plus.
--
-- POURQUOI UN « drop » D'ABORD. PostgreSQL refuse « create or replace » quand le type de retour
-- change. Supprimer puis recréer une fonction de lecture ne touche à aucune donnée.

drop function if exists refunds_queue(int);

create or replace function refunds_queue(p_limit int default 50)
returns table (id uuid, booking_id uuid, guest_id uuid, amount_xof int, status text,
               reason text, created_at timestamptz, settled_at timestamptz,
               provider_reference text, payer_known boolean, failure_reason text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  perform require_user();
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return query
    select f.id, t.booking_id, b.guest_id, f.amount_xof, f.status, f.reason, f.created_at, f.settled_at,
           f.provider_reference,
           (a.payer_account is not null and btrim(a.payer_account) <> ''),
           f.failure_reason
      from refunds f
      join payment_transactions t on t.id = f.payment_transaction_id
      join bookings b on b.id = t.booking_id
      left join payment_attempts a on a.reference = t.provider_reference
     order by (f.status = 'demande') desc, f.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200));
end $$;
revoke all on function refunds_queue(int) from public, anon;
grant execute on function refunds_queue(int) to authenticated;

comment on function refunds_queue(int) is
  'File des remboursements pour l''équipe « paiements ». Renvoie failure_reason depuis la 0024 : '
  'sans elle, un remboursement échoué s''affichait sans motif.';
