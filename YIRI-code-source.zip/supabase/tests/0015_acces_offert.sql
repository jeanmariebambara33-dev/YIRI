-- Tests de la migration 0015 (accès offert à un propriétaire, publication de ses propres logements).
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values
  (t.u(3), 'proprietaire'), (t.u(4), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(9), 'demandes', t.u(5));
-- L'utilisateur 6 est un propriétaire VÉRIFIÉ en plus d'être validateur : sans ce rôle, sa
-- publication échouerait sur le contrôle d'identité et le test ne prouverait rien sur la
-- séparation des rôles, qui est ce qu'on veut vérifier.
insert into user_roles (user_id, role) values (t.u(6), 'proprietaire');

-- p1, p2, p3 : trois annonces Visibilité du MÊME partenaire (utilisateur 4) — le cas qui compte.
-- p5 : un logement sous gestion appartenant à l'ADMINISTRATEUR lui-même.
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(4), 'annonce', 'Partenaire 1', 'd', 'Ouagadougou', 'Zogona',  'a', 2,1,1, 15000,1, 'approuvee', false),
       (t.p(2), t.u(4), 'annonce', 'Partenaire 2', 'd', 'Ouagadougou', 'Gounghin','a', 2,1,1, 16000,1, 'approuvee', false),
       (t.p(3), t.u(4), 'annonce', 'Partenaire 3', 'd', 'Bobo-Dioulasso', 'Accart','a', 2,1,1, 17000,1, 'brouillon', false),
       (t.p(5), t.u(5), 'gestion', 'Logement YIRI','d', 'Ouagadougou', 'Koulouba','a', 4,2,2, 30000,1, 'approuvee', false);

insert into property_photos (property_id, storage_path, position, rights_checked) values
  (t.p(1), 'a/1.jpg', 0, true), (t.p(2), 'b/1.jpg', 0, true),
  (t.p(3), 'c/1.jpg', 0, true), (t.p(5), 'e/1.jpg', 0, true);
insert into property_contacts (property_id, contact_name, phone, whatsapp) values
  (t.p(1), 'Partenaire', '70000004', true),
  (t.p(2), 'Partenaire', '70000004', true),
  (t.p(3), 'Partenaire', '70000004', true);

-- ============ Qui peut offrir un accès ============
reset role; select t.as(0);
select t.must_fail('visiteur : accès offert refusé', format($$select * from grant_owner_pass(%L, 90, 'x')$$, t.u(4)));
reset role; select t.as(4);
select t.must_fail('un propriétaire ne s''offre pas un accès', format($$select * from grant_owner_pass(%L, 90, 'x')$$, t.u(4)));
reset role; select t.as(6);
select t.must_fail('l''équipe « validation » non plus', format($$select * from grant_owner_pass(%L, 90, 'x')$$, t.u(4)));
reset role; select t.as(5);
select t.must_fail('un motif est obligatoire', format($$select * from grant_owner_pass(%L, 90, '   ')$$, t.u(4)));
select t.must_fail('une durée absurde est refusée', format($$select * from grant_owner_pass(%L, 9999, 'x')$$, t.u(4)));
select t.must_fail('un compte inexistant est refusé', $$select * from grant_owner_pass('11111111-1111-1111-1111-111111111111', 90, 'x')$$);

-- ============ Avant l'accès : rien n'est publiable ni visible ============
reset role; select t.as(6);
select t.must_fail('sans abonnement ni accès, la publication est refusée',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(1)));

-- ============ L'accès offert couvre TOUS les logements du propriétaire ============
reset role; select t.as(5);
select t.ok('l''administrateur offre 90 jours au partenaire',
  format($$select * from grant_owner_pass(%L, 90, 'Partenariat de lancement')$$, t.u(4)));
reset role; select t.as(6);
select t.ok('la première annonce se publie', format($$select set_listing_status(%L, 'publiee')$$, t.p(1)));
select t.ok('la deuxième aussi, sans nouveau geste', format($$select set_listing_status(%L, 'publiee')$$, t.p(2)));
reset role;
select t.eq('les deux sont dans la vitrine publique',
  format($$select count(*)::text from public_listings where id in (%L, %L)$$, t.p(1), t.p(2)), '2');

-- Le logement publié APRÈS l'octroi est couvert lui aussi : c'est tout l'intérêt.
reset role; select t.as(4);
select t.ok('le partenaire soumet un troisième logement',
  format($$update properties set status = 'soumise' where id = %L$$, t.p(3)));
reset role; select t.as(6);
select t.ok('l''équipe l''approuve', format($$select set_listing_status(%L, 'approuvee')$$, t.p(3)));
select t.ok('et le publie : le nouveau logement est couvert sans rien redemander',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(3)));
reset role;
select t.eq('les trois logements du partenaire sont visibles',
  format($$select count(*)::text from public_listings where id in (%L, %L, %L)$$, t.p(1), t.p(2), t.p(3)), '3');
select t.eq('et aucun abonnement n''a été créé pour autant', $$select count(*)::text from subscriptions$$, '0');

-- ============ Ce que le propriétaire voit ============
reset role; select t.as(4);
select t.eq('le partenaire voit son accès et sa date de fin',
  $$select (jours_restants > 80)::text from my_free_pass()$$, 'true');
select t.eq('et le motif qu''on lui a donné', $$select reason from my_free_pass()$$, 'Partenariat de lancement');
reset role; select t.as(3);
select t.cnt('un propriétaire sans accès ne voit rien', $$select * from my_free_pass()$$, 0);

-- ============ La tâche de nuit ne retire pas ce qui est couvert ============
reset role;
select t.eq('la tâche ne retire aucune annonce du partenaire',
  $$select annonces_retirees::text from expire_subscriptions()$$, '0');
select t.eq('elles restent publiées',
  format($$select count(*)::text from properties where id in (%L, %L, %L) and status = 'publiee'$$, t.p(1), t.p(2), t.p(3)), '3');

-- ============ Fin de l'accès ============
reset role;
update owner_free_pass set starts_on = current_date - 100, ends_on = current_date where owner_id = t.u(4);
select t.eq('dès la date de fin, les annonces sortent de la vitrine',
  format($$select count(*)::text from public_listings where id in (%L, %L, %L)$$, t.p(1), t.p(2), t.p(3)), '0');
select t.eq('la tâche de nuit les passe en « expirée »',
  $$select annonces_retirees::text from expire_subscriptions()$$, '3');
reset role; select t.as(4);
select t.cnt('le propriétaire ne voit plus d''accès en cours', $$select * from my_free_pass()$$, 0);

-- ============ Retrait manuel d'un accès ============
reset role;
update owner_free_pass set starts_on = current_date - 1, ends_on = current_date + 60, revoked_at = null where owner_id = t.u(4);
update properties set status = 'publiee' where id = t.p(1);
reset role; select t.as(4);
select t.must_fail('un propriétaire ne retire pas son propre accès', format($$select revoke_owner_pass(%L, 'non')$$, t.u(4)));
reset role; select t.as(5);
select t.must_fail('un motif est obligatoire pour retirer', format($$select revoke_owner_pass(%L, ' ')$$, t.u(4)));
select t.eq('l''administrateur retire l''accès', format($$select revoke_owner_pass(%L, 'Fin du partenariat')::text$$, t.u(4)), '1');
reset role;
select t.eq('l''annonce sort de la vitrine immédiatement',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(1)), '0');
select t.eq('le propriétaire est prévenu du retrait',
  format($$select count(*)::text from notifications where user_id = %L and type = 'free_pass.retire'$$, t.u(4)), '1');
select t.eq('la ligne est conservée, pas effacée',
  format($$select count(*)::text from owner_free_pass where owner_id = %L$$, t.u(4)), '1');

-- ============ L'administrateur publie ses PROPRES logements ============
reset role; select t.as(6);
select t.must_fail('sans contrat de gestion, le logement YIRI ne se publie pas',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(5)));
reset role; select t.as(5);
select t.ok('l''administrateur enregistre le contrat de son propre logement',
  format($$select * from set_management_agreement(%L, true, true)$$, t.p(5)));
select t.ok('et le publie lui-même',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(5)));
reset role;
select t.eq('le logement de YIRI est en ligne',
  format($$select count(*)::text from public_listings where id = %L$$, t.p(5)), '1');
select t.eq('l''auto-publication est écrite au journal, distincte d''une validation ordinaire',
  $$select count(*)::text from audit_logs where action = 'listing.status.self'$$, '1');
select t.eq('et aucune notification ne s''envoie à soi-même',
  format($$select count(*)::text from notifications where user_id = %L and type like 'listing.%%'$$, t.u(5)), '0');

select t.eq('aucune pièce d''identité n''a été demandée à l''administrateur',
  format($$select count(*)::text from owner_identity where user_id = %L$$, t.u(5)), '0');

-- La règle tient toujours pour qui n'est PAS administrateur.
reset role;
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(6), t.u(6), 'gestion', 'Logement du validateur', 'd', 'Ouagadougou', 'Dassasgho', 'a', 2,1,1, 20000,1, 'approuvee', false);
insert into property_photos (property_id, storage_path, position, rights_checked) values (t.p(6), 'f/1.jpg', 0, true);
reset role; select t.as(6);
select t.ok('le validateur enregistre le contrat', format($$select * from set_management_agreement(%L, true, true)$$, t.p(6)));
select t.must_fail('mais il ne peut TOUJOURS PAS publier sa propre annonce',
  format($$select set_listing_status(%L, 'publiee')$$, t.p(6)));

-- Et la vérification d'identité reste exigée pour un propriétaire ordinaire.
reset role;
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(7), t.u(8), 'gestion', 'Logement non verifie', 'd', 'Ouagadougou', 'Tanghin', 'a', 2,1,1, 20000,1, 'soumise', false);
insert into property_photos (property_id, storage_path, position, rights_checked) values (t.p(7), 'g/1.jpg', 0, true);
reset role; select t.as(6);
select t.ok('le contrat du logement d''un propriétaire non vérifié s''enregistre',
  format($$select * from set_management_agreement(%L, true, true)$$, t.p(7)));
select t.must_fail('mais son annonce ne s''approuve pas sans pièce d''identité validée',
  format($$select set_listing_status(%L, 'approuvee')$$, t.p(7)));

-- ============ La file de l'équipe ============
reset role; select t.as(9);
select t.must_fail('l''équipe « demandes » n''ouvre pas la file des accès', $$select * from free_passes_queue()$$);
reset role; select t.as(4);
select t.must_fail('un propriétaire non plus', $$select * from free_passes_queue()$$);
reset role; select t.as(6);
select t.ok('l''équipe « validation » oui', $$select * from free_passes_queue()$$);
select t.eq('elle voit le nombre d''annonces couvertes',
  format($$select annonces::text from free_passes_queue() where owner_id = %L$$, t.u(4)), '3');
select t.eq('et que l''accès a été retiré',
  format($$select (revoke_at is not null)::text from free_passes_queue() where owner_id = %L$$, t.u(4)), 'true');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0015 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
