// Tests de bout en bout du tableau de bord d'équipe (pièces d'identité, annonces, paiements, nettoyage).
// Le serveur est REMPLACÉ par une imitation qui applique les mêmes refus que la base (0002, 0005, 0006, 0007, 0008) :
//   * chaque fonction exige la bonne autorisation (validation / paiements) ;
//   * la file d'attente ne contient jamais le numéro de la pièce ;
//   * les images ne sont lisibles qu'après ouverture du dossier, et l'ouverture est journalisée ;
//   * un montant qui ne correspond pas au prix recalculé par le serveur est refusé ;
//   * aucune suppression d'image avant décision.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };

const FAKE = `
const DB = {
  perms: [{ perm: "validation" }, { perm: "paiements" }],
  roles: [{ role: "voyageur" }],
  equipe: [
    { user_id: "m-1", perm: "validation" },
    { user_id: "m-2", perm: "paiements" },
  ],
  profils: [
    { id: "t-1", full_name: "Chef Equipe", email: "chef@test.local" },
    { id: "m-1", full_name: "Awa Valideuse", email: "awa.v@test.local" },
    { id: "m-2", full_name: "Moussa Caissier", email: "moussa.c@test.local" },
    { id: "m-3", full_name: "Nouveau Membre", email: "neuf@test.local" },
  ],
  rolesParUtilisateur: [{ user_id: "t-1", role: "admin" }],
  journal: [],
  identities: [
    { user_id: "c-1", full_name: "Awa Sawadogo", email: "awa@test.local", id_type: "cnib", id_number: "B1234567", submitted_at: "2026-10-01T08:00:00Z", state: "en_attente", files: ["c-1/recto.jpg", "c-1/verso.jpg"], decided_at: null },
    { user_id: "c-2", full_name: "Moussa Ouedraogo", email: "moussa@test.local", id_type: "passeport", id_number: "P9876543", submitted_at: "2026-10-02T08:00:00Z", state: "en_attente", files: ["c-2/recto.png", "c-2/verso.png"], decided_at: null },
  ],
  props: [
    { id: "p-1", owner_id: "c-1", title: "Studio Ouaga 2000", description: "Studio calme", city: "Ouagadougou", district: "Ouaga 2000", private_address: "Rue 1", capacity: 2, bedrooms: 1, beds: 1, nightly_price_xof: 18000, min_nights: 1, status: "soumise", review_note: null, created_at: "2026-10-01" },
    { id: "p-2", owner_id: "c-2", title: "Villa Bobo", description: "Villa spacieuse", city: "Bobo-Dioulasso", district: "Accart-Ville", private_address: null, capacity: 6, bedrooms: 3, beds: 4, nightly_price_xof: 45000, min_nights: 2, status: "approuvee", review_note: null, created_at: "2026-09-20" },
  ],
  notices: [
    { id: "n-1", user_id: "c-1", object: "abonnement", subscription_id: "s-1", booking_id: null, declared_amount_xof: 5000, reference: "CH-77", message: "Payé par Orange Money", status: "nouveau", created_at: "2026-10-05T10:00:00Z" },
  ],
  prixReel: { "s-1": 5000 },
  roles_accordes: [],
};
window.__db = DB;
const UID = "t-1";
const err = (code, message) => ({ data: null, error: { code, message } });
const okRes = (data) => ({ data, error: null });
const peut = (p) => DB.roles.some((r) => r.role === "admin") || DB.perms.some((x) => x.perm === p);
const estAdmin = () => DB.roles.some((r) => r.role === "admin");
const refusPerm = (p) => err("42501", "Action réservée à l'équipe habilitée (" + p + ").");

function run(table, op, payload, filters) {
  const by = (r) => filters.every(([c, v]) => r[c] === v);
  if (table === "properties") {
    if (op === "select") return okRes(peut("validation") ? DB.props.slice() : []);
  }
  if (table === "payment_notices") {
    if (op === "select") return okRes(peut("paiements") ? DB.notices.slice() : []);
    if (op === "update") {
      if (!peut("paiements")) return refusPerm("paiements");
      const rows = DB.notices.filter(by); rows.forEach((r) => Object.assign(r, payload)); return okRes(rows);
    }
  }
  if (table === "profiles") {
    if (!estAdmin()) return okRes([{ id: UID, full_name: "Chef Equipe", email: "chef@test.local", phone: null }]);
    const parId = filters.find(([c]) => c === "id");
    const parMail = filters.find(([c]) => c === "email");
    let out = DB.profils.slice();
    if (parMail) out = out.filter((p) => p.email === parMail[1]);
    if (parId) out = out.filter((p) => p.id === parId[1]);
    const dansListe = filters.find(([c]) => c === "__in");
    if (dansListe) out = out.filter((p) => dansListe[1].includes(p.id));
    return okRes(out.map((p) => Object.assign({ phone: null }, p)));
  }
  if (table === "user_roles") {
    if (!estAdmin()) return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    const f = filters.find(([c]) => c === "user_id");
    const tous = DB.rolesParUtilisateur.concat(DB.roles.filter((r) => r.role !== "admin").map((r) => ({ user_id: UID, role: r.role })));
    return okRes(f ? tous.filter((r) => r.user_id === f[1]) : tous);
  }
  if (table === "team_permissions") {
    const propres = DB.perms.map((p) => ({ user_id: UID, perm: p.perm }));
    if (op === "select") {
      if (!estAdmin()) return okRes(propres);
      const f = filters.find(([c]) => c === "user_id");
      const tous = DB.equipe.concat(propres);
      return okRes(f ? tous.filter((r) => r.user_id === f[1]) : tous);
    }
    if (op === "insert") {
      if (!estAdmin()) return err("42501", "new row violates row-level security policy");
      if (payload.user_id === UID) return err("42501", "new row violates row-level security policy");
      if (payload.granted_by !== UID) return err("42501", "new row violates row-level security policy");
      DB.equipe.push({ user_id: payload.user_id, perm: payload.perm });
      DB.journalEquipe = (DB.journalEquipe || []).concat([{ action: "team.perm_granted", entity_id: payload.user_id, after: { perm: payload.perm }, created_at: new Date().toISOString(), actor_id: UID }]);
      return okRes([payload]);
    }
    if (op === "delete") {
      if (!estAdmin()) return err("42501", "new row violates row-level security policy");
      const u = (filters.find(([c]) => c === "user_id") || [])[1];
      const pm = (filters.find(([c]) => c === "perm") || [])[1];
      if (u === UID) return err("42501", "new row violates row-level security policy");
      DB.equipe = DB.equipe.filter((x) => !(x.user_id === u && x.perm === pm));
      DB.journalEquipe = (DB.journalEquipe || []).concat([{ action: "team.perm_revoked", entity_id: u, after: { perm: pm }, created_at: new Date().toISOString(), actor_id: UID }]);
      return okRes([{ perm: pm }]);
    }
  }
  if (table === "audit_logs") return okRes((DB.journalEquipe || []).slice().reverse());
  return okRes([]);
}
function builder(table) {
  let op = "select", payload = null; const filters = [];
  const exec = () => Promise.resolve(run(table, op, payload, filters));
  const self = {
    select() { return self; }, insert(p) { op = "insert"; payload = p; return self; },
    upsert(p) { op = "upsert"; payload = p; return self; }, update(p) { op = "update"; payload = p; return self; },
    delete() { op = "delete"; return self; }, eq(c, v) { filters.push([c, v]); return self; },
    in(c, v) { filters.push(["__in", v]); return self; },
    order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: "jeton", user: { id: UID, email: "chef@test.local" } };
const listeners = [];
window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem("fs") ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    const trouve = (id) => DB.identities.find((i) => i.user_id === id);
    if (fn === "identity_queue") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      return Promise.resolve(okRes(DB.identities.filter((i) => ["en_attente", "a_renvoyer"].includes(i.state))
        .map((i) => ({ user_id: i.user_id, full_name: i.full_name, email: i.email, id_type: i.id_type, submitted_at: i.submitted_at, files_sent: i.files.length, state: i.state }))));
    }
    if (fn === "open_owner_identity") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      const i = trouve(a.p_user); if (!i) return Promise.resolve(err("P0001", "Aucune pièce envoyée par cet utilisateur."));
      DB.journal.push({ action: "identity.viewed", cible: i.user_id, at: Date.now() });
      return Promise.resolve(okRes([{ user_id: i.user_id, id_type: i.id_type, id_number: i.id_number, state: i.state, submitted_at: i.submitted_at, files_sent: i.files.length, files_left: i.files.length }]));
    }
    if (fn === "identity_file_paths") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      const i = trouve(a.p_user); return Promise.resolve(okRes((i ? i.files : []).map((p) => ({ path: p }))));
    }
    if (fn === "grant_owner_role") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      const i = trouve(a.p_user);
      if (!i || i.state !== "en_attente") return Promise.resolve(err("P0001", "Aucune pièce d'identité en attente de décision pour cet utilisateur."));
      if (i.files.length < 2) return Promise.resolve(err("P0001", "Le recto et le verso de la pièce sont requis."));
      i.state = "verifie"; i.decided_at = new Date().toISOString(); DB.roles_accordes.push(i.user_id);
      DB.journal.push({ action: "role.owner_granted", cible: i.user_id });
      return Promise.resolve(okRes(null));
    }
    if (fn === "reject_owner_identity") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      const i = trouve(a.p_user);
      if (!i || i.state !== "en_attente") return Promise.resolve(err("P0001", "Aucune pièce d'identité en attente de décision pour cet utilisateur."));
      i.state = a.p_resend ? "a_renvoyer" : "refuse"; i.decided_at = new Date().toISOString(); i.note = a.p_note;
      return Promise.resolve(okRes(null));
    }
    if (fn === "identity_files_pending") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      return Promise.resolve(okRes(DB.identities.filter((i) => ["verifie", "refuse"].includes(i.state) && i.files.length > 0)
        .map((i) => ({ user_id: i.user_id, state: i.state, decided_at: i.decided_at, files_left: i.files.length }))));
    }
    if (fn === "confirm_identity_files_deleted") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      const i = trouve(a.p_user);
      if (!i || !["verifie", "refuse"].includes(i.state)) return Promise.resolve(err("P0001", "Dossier introuvable ou décision non prise."));
      if (i.files.length > 0) return Promise.resolve(err("P0001", "Des images existent encore dans le stockage : supprimez-les d'abord."));
      i.files_deleted = true; return Promise.resolve(okRes(null));
    }
    if (fn === "set_listing_status") {
      if (!peut("validation")) return Promise.resolve(refusPerm("validation"));
      const p = DB.props.find((x) => x.id === a.p_property);
      if (!p) return Promise.resolve(err("P0001", "Annonce introuvable."));
      if (["a_corriger", "refusee", "suspendue"].includes(a.p_status) && (!a.p_note || a.p_note.trim().length < 5))
        return Promise.resolve(err("P0001", "Indiquez un motif clair pour le propriétaire (5 caractères minimum)."));
      if (a.p_status === "publiee") return Promise.resolve(err("P0001", "Publication refusée : Un abonnement actif (paiement confirmé) est requis."));
      p.status = a.p_status; p.review_note = a.p_note || null;
      return Promise.resolve(okRes([p]));
    }
    if (fn === "listing_publish_problem") {
      return Promise.resolve(okRes("Un abonnement actif (paiement confirmé) est requis."));
    }
    if (fn === "confirm_payment") {
      if (!peut("paiements")) return Promise.resolve(refusPerm("paiements"));
      const attendu = DB.prixReel[a.p_id];
      if (attendu === undefined) return Promise.resolve(err("P0001", "Objet introuvable."));
      if (a.p_received_amount_xof !== attendu)
        return Promise.resolve(err("P0001", "Montant reçu différent du montant attendu (" + attendu + " FCFA)."));
      DB.paiementConfirme = { id: a.p_id, montant: a.p_received_amount_xof };
      return Promise.resolve(okRes({}));
    }
    if (fn === "reject_payment") {
      if (!peut("paiements")) return Promise.resolve(refusPerm("paiements"));
      DB.paiementRefuse = { id: a.p_id, note: a.p_note };
      return Promise.resolve(okRes(null));
    }
    return Promise.resolve(okRes(null));
  },
  storage: { from(bucket) { return {
    async createSignedUrl(path) {
      // les règles de stockage n'ouvrent la lecture qu'après une ouverture récente du dossier
      const dossier = path.split("/")[0];
      const vu = DB.journal.some((j) => j.action === "identity.viewed" && j.cible === dossier);
      if (bucket === "owner-identity" && !vu) return err("42501", "new row violates row-level security policy");
      return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" });
    },
    async remove(paths) {
      const dossier = String(paths[0] || "").split("/")[0];
      const i = DB.identities.find((x) => x.user_id === dossier);
      if (i && !["verifie", "refuse"].includes(i.state)) return err("42501", "new row violates row-level security policy");
      if (i) i.files = i.files.filter((f) => !paths.includes(f));
      return okRes({});
    },
    async upload() { return okRes({}); },
    async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
const ctx = await b.newContext({ viewport: { width: 1280, height: 1100 } });
await ctx.route("**cdn.jsdelivr.net/**", (r) => r.abort());
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
let body;

// --- visiteur ---
await p.goto(URL + "#equipe"); await p.waitForSelector("h1");
ok("espace équipe fermé à un visiteur", /Connectez-vous/.test(await p.locator("body").innerText()));

// --- connexion d'un membre de l'équipe ---
await p.getByRole("button", { name: "Se connecter" }).first().click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "chef@test.local"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(600);
await p.evaluate(() => { location.hash = "equipe"; });
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("espace équipe ouvert pour un membre autorisé", /Espace équipe YIRI/.test(body));
ok("les autorisations réelles sont affichées", /validation, paiements/.test(body));

// --- file d'attente des pièces ---
ok("les deux dossiers en attente sont listés", /Awa Sawadogo/.test(body) && /Moussa Ouedraogo/.test(body));
ok("le plus ancien d'abord", body.indexOf("Awa Sawadogo") < body.indexOf("Moussa Ouedraogo"));
ok("la file d'attente n'affiche AUCUN numéro de pièce", !/B1234567|P9876543/.test(body));
ok("aucune image n'est chargée avant ouverture du dossier", await p.evaluate(() => window.__db.journal.length === 0));

// --- ouverture journalisée ---
await p.getByRole("button", { name: "Ouvrir le dossier" }).first().click();
await p.waitForTimeout(500);
body = await p.locator("body").innerText();
ok("ouverture : le numéro de la pièce apparaît", /B1234567/.test(body));
ok("ouverture : le second dossier reste fermé", !/P9876543/.test(body));
const j = await p.evaluate(() => window.__db.journal);
ok("ouverture enregistrée au journal avec la cible", j.length === 1 && j[0].action === "identity.viewed" && j[0].cible === "c-1");
ok("les deux documents sont proposés à la lecture", await p.locator("img").count() >= 2);

// --- décision : accorder le rôle ---
await p.getByRole("button", { name: "Valider et accorder le rôle propriétaire" }).click();
await p.waitForTimeout(700);
ok("rôle propriétaire accordé", await p.evaluate(() => window.__db.roles_accordes.includes("c-1")));
body = await p.locator("body").innerText();
ok("le dossier traité disparaît de la file", !/Awa Sawadogo/.test(body));
ok("le dossier suivant reste à traiter", /Moussa Ouedraogo/.test(body));

// --- décision : refus sans motif puis avec motif ---
await p.getByRole("button", { name: "Ouvrir le dossier" }).first().click();
await p.waitForTimeout(500);
await p.getByRole("button", { name: "Demander un nouveau document" }).click();
await p.waitForTimeout(600);
ok("demande de renvoi enregistrée", await p.evaluate(() => window.__db.identities[1].state === "a_renvoyer"));
body = await p.locator("body").innerText();
ok("un dossier « à renvoyer » reste visible", /Moussa Ouedraogo/.test(body) && /À renvoyer/.test(body));

// --- annonces ---
await p.getByRole("button", { name: "Annonces", exact: true }).click();
await p.waitForTimeout(500);
body = await p.locator("body").innerText();
ok("onglet annonces : l'annonce soumise est listée", /Studio Ouaga 2000/.test(body));
ok("onglet annonces : compteurs par état", /À examiner \(1\)/.test(body));
await p.getByText("Studio Ouaga 2000").first().click();
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Demander une correction" }).click();
await p.waitForTimeout(300);
ok("correction sans motif refusée", /motif d'au moins 5/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("input[id^='ln-']", "Photos floues, merci de les reprendre");
await p.getByRole("button", { name: "Demander une correction" }).click();
await p.waitForTimeout(600);
ok("correction demandée avec motif", await p.evaluate(() => window.__db.props[0].status === "a_corriger"));
ok("le motif est transmis au propriétaire", await p.evaluate(() => /Photos floues/.test(window.__db.props[0].review_note || "")));

// --- mise en ligne refusée tant que l'abonnement n'est pas payé ---
await p.getByRole("button", { name: /^Approuvée/ }).click();
await p.waitForTimeout(400);
await p.getByText("Villa Bobo").first().click();
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Que manque-t-il pour publier ?" }).click();
await p.waitForTimeout(400);
ok("le serveur dit ce qui manque pour publier", /abonnement actif/.test(await p.locator("body").innerText()));
await p.getByRole("button", { name: "Mettre en ligne" }).click();
await p.waitForTimeout(500);
ok("mise en ligne refusée sans abonnement payé", /Publication refusée/.test(await p.locator("[role=alert]").first().innerText()));
ok("l'annonce reste « approuvée »", await p.evaluate(() => window.__db.props[1].status === "approuvee"));

// --- paiements ---
await p.getByRole("button", { name: "Paiements", exact: true }).click();
await p.waitForTimeout(500);
body = await p.locator("body").innerText();
ok("onglet paiements : l'avis « J'ai payé » est listé", /Abonnement/.test(body) && /CH-77/.test(body));
ok("rappel : le montant déclaré n'est qu'une déclaration", /n'est qu'une déclaration/.test(body));
await p.getByRole("button", { name: "Confirmer la réception" }).click();
await p.waitForTimeout(300);
ok("confirmation sans montant refusée", /montant réellement reçu/.test(await p.locator("[role=alert]").first().innerText()));
await p.fill("input[id^='a-']", "4000");
await p.getByRole("button", { name: "Confirmer la réception" }).click();
await p.waitForTimeout(600);
ok("montant erroné refusé par le serveur", /Montant reçu différent/.test(await p.locator("[role=alert]").first().innerText()));
ok("aucun paiement confirmé avec un montant erroné", await p.evaluate(() => !window.__db.paiementConfirme));
ok("l'avis reste à traiter", await p.evaluate(() => window.__db.notices[0].status === "nouveau"));
await p.fill("input[id^='a-']", "5000");
await p.getByRole("button", { name: "Confirmer la réception" }).click();
await p.waitForTimeout(700);
ok("montant exact : paiement confirmé", await p.evaluate(() => window.__db.paiementConfirme && window.__db.paiementConfirme.montant === 5000));
ok("l'avis est marqué traité", await p.evaluate(() => window.__db.notices[0].status === "traite"));

// --- nettoyage des pièces ---
await p.getByRole("button", { name: "Nettoyage", exact: true }).click();
await p.waitForTimeout(500);
body = await p.locator("body").innerText();
ok("onglet nettoyage : le dossier validé attend la suppression", /Dossier validé/.test(body));
ok("rappel : une pièce d'identité ne se garde pas", /ne se garde pas/.test(body));
await p.getByRole("button", { name: "Supprimer les images" }).click();
await p.waitForTimeout(800);
ok("images supprimées du stockage", await p.evaluate(() => window.__db.identities[0].files.length === 0));
ok("suppression confirmée auprès du serveur", await p.evaluate(() => window.__db.identities[0].files_deleted === true));
ok("plus rien à nettoyer", /Tout est propre/.test(await p.locator("body").innerText()));

// --- autorisations : un membre sans « paiements » ne voit pas cet onglet ---
await p.evaluate(() => { window.__db.perms = [{ perm: "validation" }]; });
await p.evaluate(() => { location.hash = "compte"; });
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "chef@test.local"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(500);
await p.evaluate(() => { location.hash = "equipe"; });
await p.waitForTimeout(600);
ok("sans l'autorisation « paiements », l'onglet disparaît", await p.getByRole("button", { name: "Paiements", exact: true }).count() === 0);
ok("l'onglet « Pièces d'identité » reste accessible", await p.getByRole("button", { name: "Pièces d'identité", exact: true }).count() === 1);


// --- onglet Équipe : réservé aux administrateurs ---
ok("l'onglet « Équipe et accès » est invisible sans être administrateur", await p.getByRole("button", { name: "Équipe et accès", exact: true }).count() === 0);
await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }, { role: "admin" }]; });
await p.evaluate(() => { location.hash = "compte"; });
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "chef@test.local"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(500);
await p.evaluate(() => { location.hash = "equipe"; });
await p.waitForTimeout(600);
ok("administrateur : l'onglet « Équipe et accès » apparaît", await p.getByRole("button", { name: "Équipe et accès", exact: true }).count() === 1);
await p.getByRole("button", { name: "Équipe et accès", exact: true }).click();
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("équipe : les membres existants sont listés", /Awa Valideuse/.test(body) && /Moussa Caissier/.test(body));
ok("équipe : l'administrateur est signalé", /Administrateur/.test(body));
ok("équipe : rappel de donner le minimum", /le minimum dont il a besoin/.test(body));
ok("équipe : les six autorisations sont proposées", await p.locator("input[type=checkbox]").count() >= 6);

// recherche d'une personne inconnue puis connue
await p.fill("#t-mail", "inexistant@test.local");
await p.getByRole("button", { name: "Chercher" }).click();
await p.waitForTimeout(500);
ok("équipe : adresse inconnue, message clair", /Aucun compte avec cette adresse/.test(await p.locator("body").innerText()));
await p.fill("#t-mail", "neuf@test.local");
await p.getByRole("button", { name: "Chercher" }).click();
await p.waitForTimeout(600);
ok("équipe : la personne est trouvée", /Nouveau Membre/.test(await p.locator("body").innerText()));

// accorder une autorisation
const avant = await p.evaluate(() => window.__db.equipe.length);
const carteNeuf = p.locator("div.rounded-2xl").filter({ hasText: "Nouveau Membre" }).last();
await carteNeuf.locator("label").filter({ hasText: "Validation" }).locator("input").click();
await p.waitForTimeout(700);
ok("équipe : l'autorisation est accordée", await p.evaluate(() => window.__db.equipe.length) === avant + 1);
ok("équipe : c'est bien « validation » qui a été donnée", await p.evaluate(() => window.__db.equipe.some((e) => e.user_id === "m-3" && e.perm === "validation")));
ok("équipe : l'octroi est inscrit au journal", await p.evaluate(() => (window.__db.journalEquipe || []).some((j) => j.action === "team.perm_granted")));
await p.waitForTimeout(400);
ok("équipe : le journal des changements s'affiche", /Derniers changements/.test(await p.locator("body").innerText()));

// retirer une autorisation
const carteAwa = p.locator("div.rounded-2xl").filter({ hasText: "Awa Valideuse" }).last();
await carteAwa.locator("label").filter({ hasText: "Validation" }).locator("input").click();
await p.waitForTimeout(800);
await p.waitForTimeout(700);
ok("équipe : l'autorisation est retirée", await p.evaluate(() => !window.__db.equipe.some((e) => e.user_id === "m-1" && e.perm === "validation")));
ok("équipe : le retrait est inscrit au journal", await p.evaluate(() => (window.__db.journalEquipe || []).some((j) => j.action === "team.perm_revoked")));

// on ne modifie pas ses propres droits
const carteMoi = p.locator("div.rounded-2xl").filter({ hasText: "(vous)" }).last();
const nbCases = await carteMoi.locator("input[type=checkbox]").count();
let propresVerrouillees = nbCases === 0;   // un administrateur n'a aucune case : il a déjà tout
if (nbCases > 0) {
  propresVerrouillees = true;
  for (let i = 0; i < nbCases; i++) if (!(await carteMoi.locator("input[type=checkbox]").nth(i).isDisabled())) propresVerrouillees = false;
}
ok("équipe : ses propres droits ne sont pas modifiables", propresVerrouillees);
ok("équipe : le rôle administrateur ne se donne pas depuis l'application", /uniquement en base de données/.test(await p.locator("body").innerText()));

// --- un compte sans aucune autorisation est refusé ---
await p.evaluate(() => { window.__db.perms = []; window.__db.roles = [{ role: "voyageur" }]; });
await p.evaluate(() => { location.hash = "compte"; });
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Se déconnecter" }).click();
await p.waitForSelector("#c-mail");
await p.fill("#c-mail", "chef@test.local"); await p.fill("#c-mdp", "motdepasse1");
await p.getByRole("button", { name: "Se connecter" }).click();
await p.waitForTimeout(500);
await p.evaluate(() => { location.hash = "equipe"; });
await p.waitForTimeout(600);
body = await p.locator("body").innerText();
ok("compte sans autorisation : accès refusé", /Accès refusé/.test(body));
ok("compte sans autorisation : aucune donnée d'équipe affichée", !/Awa Sawadogo|Studio Ouaga|CH-77/.test(body));
ok("le bouton « Équipe » disparaît de l'en-tête", await p.getByRole("button", { name: "Équipe", exact: true }).count() === 0);

ok("aucune erreur JavaScript pendant les tests", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 3).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS DE L'ESPACE EQUIPE SONT PASSES" : `\n${fails} ECHEC(S)`);
process.exit(fails ? 1 : 0);
