import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
for (const [n, w, h] of [["desk", 1280, 900], ["mob", 390, 844]]) {
  const p = await (await b.newContext({ viewport: { width: w, height: h } })).newPage();
  const errs = []; p.on("pageerror", (e) => errs.push(e.message));
  await p.goto("file:///home/claude/yiri/dist/yiri-demo.html"); await p.waitForSelector("h1");
  // L'introduction couvre l'écran pendant quelques secondes : on la passe, sinon la capture
  // montre l'animation et non la page.
  if (await p.locator(".yi-intro").count()) {
    await p.evaluate(() => document.querySelector(".yi-passer")?.click());
    await p.waitForSelector(".yi-intro", { state: "detached", timeout: 3000 });
  }
  await p.screenshot({ path: `dist/home-${n}.png` });
  console.log(n, "overflow-x:", await p.evaluate(() => document.documentElement.scrollWidth > innerWidth), errs);
}
await b.close();
