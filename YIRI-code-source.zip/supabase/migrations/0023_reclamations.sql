-- YIRI — 0023 : les réclamations, enfin reliées à quelque chose.
--
-- Constat de l'audit : la table support_requests existe depuis la migration 0001. Elle n'a
-- jamais reçu une ligne, et aucun écran ne la lit. Un voyageur dont la serrure est cassée à
-- 22 heures n'avait aucun moyen de le signaler autrement qu'en téléphonant.
--
-- Ce fichier ouvre les deux bouts : voyageurs et propriétaires peuvent signaler un problème
-- depuis leur espace, et l'équipe les traite. Les catégories sont fixées en base — une liste
-- libre deviendrait vite illisible, et on ne peut pas trier ce qui n'est pas nommé.
--
-- Qui voit quoi : chacun ne voit QUE ses propres signalements. L'équipe habilitée les voit
-- tous. Un propriétaire ne voit pas les réclamations déposées sur son logement par un voyageur
-- tant que l'équipe n'a pas tranché — c'est volontaire : une réclamation est d'abord adressée à
-- YIRI, qui arbitre, et non une mise en cause directe entre deux personnes.

do $$
begin
  if to_regclass('public.support_requests') is null then
    raise exception 'La migration 0001 n''est pas appliquée. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Ce que la table garantit
-- =====================================================================
alter table support_requests add column if not exists booking_id uuid references bookings(id);
alter table support_requests add column if not exists resolution text;
alter table support_requests add column if not exists closed_at timestamptz;
alter table support_requests add column if not exists updated_at timestamptz not null default now();

-- Les catégories et les statuts, nommés une fois pour toutes.
alter table support_requests drop constraint if exists support_categorie_chk;
alter table support_requests add constraint support_categorie_chk
  check (category in ('acces_logement', 'proprete', 'equipement', 'securite',
                      'paiement', 'annonce_inexacte', 'comportement', 'autre'));
alter table support_requests drop constraint if exists support_statut_chk;
alter table support_requests add constraint support_statut_chk
  check (status in ('ouvert', 'en_cours', 'resolu', 'clos'));
alter table support_requests drop constraint if exists support_message_chk;
alter table support_requests add constraint support_message_chk
  check (char_length(btrim(message)) between 10 and 2000);

create index if not exists support_requests_user_idx on support_requests (user_id, created_at desc);
create index if not exists support_requests_ouvert_idx on support_requests (created_at) where status in ('ouvert', 'en_cours');

alter table support_requests enable row level security;

-- Chacun lit SES signalements, et rien d'autre. L'équipe passe par ses fonctions.
drop policy if exists support_self_read on support_requests;
create policy support_self_read on support_requests for select using (user_id = auth.uid());

-- Aucune écriture directe : tout passe par les fonctions, qui imposent les règles.
revoke insert, update, delete on support_requests from anon, authenticated;
grant select on support_requests to authenticated;

-- =====================================================================
-- 2. Signaler un problème
-- =====================================================================
create or replace function open_support_request(
  p_category text, p_message text,
  p_property uuid default null, p_booking uuid default null
)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  rid uuid;
  ouverts int;
  titre text;
begin
  if char_length(btrim(coalesce(p_message, ''))) < 10 then
    raise exception 'Décrivez le problème en quelques mots (10 caractères minimum).' using errcode = 'P0001';
  end if;

  -- Un garde-fou, pas une limite de confort : sans lui, un script ouvrirait mille signalements
  -- et noierait la file de l'équipe, qui ne verrait plus les vrais.
  select count(*) into ouverts from support_requests
   where user_id = uid and status in ('ouvert', 'en_cours');
  if ouverts >= 10 then
    raise exception 'Vous avez déjà 10 signalements en cours. L''équipe YIRI les traite ; écrivez-nous si c''est urgent.' using errcode = 'P0001';
  end if;

  -- Un signalement ne peut viser qu'un séjour ou un logement QUI VOUS CONCERNE : sinon il
  -- suffirait d'inventer un identifiant pour salir l'annonce de quelqu'un d'autre.
  if p_booking is not null then
    if not exists (
      select 1 from bookings b
       where b.id = p_booking
         and (b.guest_id = uid
              or exists (select 1 from properties p where p.id = b.property_id and p.owner_id = uid))
    ) then
      raise exception 'Cette réservation ne vous concerne pas.' using errcode = '42501';
    end if;
  end if;
  if p_property is not null and p_booking is null then
    if not exists (
      select 1 from properties p
       where p.id = p_property
         and (p.owner_id = uid
              or exists (select 1 from bookings b where b.property_id = p.id and b.guest_id = uid))
    ) then
      raise exception 'Ce logement ne vous concerne pas.' using errcode = '42501';
    end if;
  end if;

  insert into support_requests (user_id, property_id, booking_id, category, message, status)
  values (uid,
          coalesce(p_property, (select b.property_id from bookings b where b.id = p_booking)),
          p_booking, p_category, btrim(p_message), 'ouvert')
  returning id into rid;

  select p.title into titre from properties p
   where p.id = coalesce(p_property, (select b.property_id from bookings b where b.id = p_booking));

  insert into audit_logs (actor_id, action, entity_type, entity_id, after)
  values (uid, 'support.opened', 'support_request', rid::text,
          jsonb_build_object('categorie', p_category, 'logement', titre));

  -- L'équipe habilitée aux demandes, plus les administrateurs.
  insert into notifications (user_id, type, payload)
  select distinct x.user_id, 'support.ouvert.equipe',
         jsonb_build_object('signalement', rid, 'categorie', p_category, 'titre', titre)
    from (
      select tp.user_id from team_permissions tp where tp.perm in ('demandes', 'reservations')
      union
      select ur.user_id from user_roles ur where ur.role = 'admin'
    ) x
   where x.user_id <> uid;

  return rid;
end $$;
revoke all on function open_support_request(text, text, uuid, uuid) from public, anon;
grant execute on function open_support_request(text, text, uuid, uuid) to authenticated;

-- =====================================================================
-- 3. Ce que chacun voit
-- =====================================================================
create or replace function my_support_requests()
returns table (id uuid, category text, message text, status text, resolution text,
               titre text, created_at timestamptz, closed_at timestamptz)
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare uid uuid := require_user();
begin
  return query
    select s.id, s.category, s.message, s.status, s.resolution,
           p.title, s.created_at, s.closed_at
      from support_requests s
      left join properties p on p.id = s.property_id
     where s.user_id = uid
     order by s.created_at desc;
end $$;
revoke all on function my_support_requests() from public, anon;
grant execute on function my_support_requests() to authenticated;

create or replace function support_queue(p_limit int default 100)
returns table (id uuid, user_id uuid, demandeur text, telephone text, role_demandeur text,
               category text, message text, status text, resolution text,
               titre text, ville text, booking_id uuid, created_at timestamptz)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not has_any_perm('demandes', 'reservations') then
    raise exception 'Action réservée à l''équipe habilitée (demandes ou réservations).' using errcode = '42501';
  end if;
  return query
    select s.id, s.user_id, pr.full_name, pr.phone,
           case when exists (select 1 from properties p2 where p2.id = s.property_id and p2.owner_id = s.user_id)
                then 'proprietaire' else 'voyageur' end,
           s.category, s.message, s.status, s.resolution,
           p.title, p.city, s.booking_id, s.created_at
      from support_requests s
      join profiles pr on pr.id = s.user_id
      left join properties p on p.id = s.property_id
     order by (s.status in ('resolu', 'clos')), s.created_at
     limit greatest(1, least(coalesce(p_limit, 100), 300));
end $$;
revoke all on function support_queue(int) from public, anon;
grant execute on function support_queue(int) to authenticated;

-- =====================================================================
-- 4. Traiter
-- =====================================================================
create or replace function set_support_status(p_id uuid, p_status text, p_resolution text default null)
returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  sr support_requests%rowtype;
begin
  if not has_any_perm('demandes', 'reservations') then
    raise exception 'Action réservée à l''équipe habilitée (demandes ou réservations).' using errcode = '42501';
  end if;
  if p_status not in ('ouvert', 'en_cours', 'resolu', 'clos') then
    raise exception 'Statut inconnu : %', p_status using errcode = 'P0001';
  end if;

  select * into sr from support_requests where id = p_id for update;
  if not found then
    raise exception 'Signalement introuvable.' using errcode = 'P0001';
  end if;

  -- Fermer un signalement sans dire ce qui a été fait ne rend service à personne, et laisse la
  -- personne sans réponse.
  if p_status in ('resolu', 'clos') and char_length(btrim(coalesce(p_resolution, ''))) < 5 then
    raise exception 'Indiquez ce qui a été fait : la personne le lira.' using errcode = 'P0001';
  end if;

  update support_requests
     set status = p_status,
         resolution = coalesce(nullif(btrim(coalesce(p_resolution, '')), ''), resolution),
         assigned_to = uid,
         closed_at = case when p_status in ('resolu', 'clos') then now() else null end,
         updated_at = now()
   where id = p_id;

  insert into audit_logs (actor_id, action, entity_type, entity_id, before, after, reason)
  values (uid, 'support.status', 'support_request', p_id::text,
          jsonb_build_object('statut', sr.status), jsonb_build_object('statut', p_status),
          left(btrim(coalesce(p_resolution, '')), 200));

  if p_status in ('resolu', 'clos') then
    insert into notifications (user_id, type, payload)
    values (sr.user_id, 'support.traite',
            jsonb_build_object('signalement', p_id, 'statut', p_status));
  end if;
end $$;
revoke all on function set_support_status(uuid, text, text) from public, anon;
grant execute on function set_support_status(uuid, text, text) to authenticated;

-- =====================================================================
-- 5. Les réclamations par courriel
-- =====================================================================
-- Le demandeur apprend que son signalement est traité ; l'équipe apprend qu'il en arrive un.
-- Un problème de serrure à 22 heures ne doit pas attendre que quelqu'un ouvre le site.
-- Liste redéfinie en entier, pour la même raison qu'en 0022.
create or replace function _email_eligible(p_type text)
returns boolean
language sql immutable set search_path = public, pg_temp as $$
  select p_type in (
    'booking.confirmee.voyageur', 'booking.annulee.voyageur', 'refund.enregistre',
    'booking.confirmee', 'booking.annulee',
    'listing.approuvee', 'listing.publiee', 'listing.a_corriger', 'listing.refusee', 'listing.suspendue',
    'subscription.bientot_expiree', 'subscription.expire_demain', 'subscription.expiree',
    'subscription.offerte', 'free_pass.offert', 'free_pass.retire',
    'booking.confirmee.equipe', 'refund.a_examiner.equipe',
    'statement.disponible', 'payout.verse',
    -- 0023
    'support.traite', 'support.ouvert.equipe'
  );
$$;
revoke all on function _email_eligible(text) from public, anon, authenticated;

-- Le destinataire d'une alerte d'équipe « support » doit avoir l'autorisation voulue.
-- _push_destinataire_legitime ne connaît pas encore ce préfixe : sans cette ligne, un type
-- d'équipe inconnu est refusé par défaut, donc PERSONNE ne recevrait ces alertes.
create or replace function _push_destinataire_legitime(p_user uuid, p_type text)
returns boolean
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare
  est_admin boolean;
  perms text[];
begin
  select exists (select 1 from user_roles where user_id = p_user and role = 'admin') into est_admin;
  if est_admin then
    return true;
  end if;

  if p_type like '%.equipe' then
    select coalesce(array_agg(perm::text), '{}') into perms
      from team_permissions where user_id = p_user;
    if p_type like 'booking.%' then
      return perms && array['reservations', 'paiements'];
    elsif p_type like 'subscription.%' or p_type like 'listing.%' then
      return perms && array['validation', 'paiements'];
    elsif p_type like 'refund.%' or p_type like 'payment.%' or p_type like 'statement.%' or p_type like 'payout.%' then
      return perms && array['paiements'];
    elsif p_type like 'identity.%' then
      return perms && array['validation'];
    elsif p_type like 'application.%' or p_type like 'lead.%' then
      return perms && array['demandes', 'partenariat'];
    elsif p_type like 'support.%' then
      return perms && array['demandes', 'reservations'];
    end if;
    return false;  -- un type d'équipe inconnu ne part pas : refuser par défaut, jamais l'inverse
  end if;

  return true;
end $$;
revoke all on function _push_destinataire_legitime(uuid, text) from public, anon, authenticated;
