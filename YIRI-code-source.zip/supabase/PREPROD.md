# YIRI — Installation et test sur un projet Supabase de PRÉPRODUCTION

> Pour l'application des migrations pas à pas, voir **`APPLY_PREPROD.md`** (ce document-ci couvre les réglages et les tests).

> **Statut : procédure préparée, jamais exécutée.** Aucun projet Supabase n'existe, aucune clé n'a été demandée ni utilisée,
> rien n'est déployé. Les 256 tests + 26 contrôles de concurrence du dossier `supabase/tests/` tournent sur un **PostgreSQL 16 local
> avec des simulations** de Supabase (rôles `anon`/`authenticated`, `auth.uid()`, schéma `storage`). Ils **ne valident pas** l'API
> Supabase (PostgREST, GoTrue, Storage, pg_cron réels) : c'est le but de cette procédure.
> Les pages de la documentation Supabase n'ont pas pu être lues depuis l'environnement de travail ; tout ce qui est marqué
> « à confirmer » doit être revérifié dans la documentation officielle au moment de l'exécution.

## 1. Prérequis exacts (déduits des migrations)

| Élément | Pourquoi | Statut |
|---|---|---|
| Projet Supabase **dédié à la préproduction**, jetable, jamais le futur projet de production | les migrations ne sont pas rejouables (`create type`/`create table` sans `if not exists`) : en cas d'échec, on supprime le projet et on recommence | à créer par toi |
| PostgreSQL 15 ou plus récent | `gen_random_uuid()`, `hashtextextended()`, `to_regnamespace()` ; testé en local sur 16.15 | à confirmer (version affichée dans le tableau de bord) |
| Extension **btree_gist** | contraintes d'exclusion des dates (`0001`) ; la migration fait `create extension if not exists btree_gist` | automatique ; contrôle n°1 de `checks.sql` |
| Rôles `anon`, `authenticated`, `postgres` | policies `to anon/authenticated`, exécution en `postgres` | fournis par Supabase |
| Objets Supabase utilisés : `auth.uid()`, `auth.users` (déclencheur de profil), `storage.buckets`, `storage.objects`, `storage.foldername()` | `0001`, `0005` | fournis par Supabase ; contrôles n°7 à 9 |
| Extension **pg_cron** (`cron.schedule`) | expiration des blocages toutes les minutes (`0006`) | à activer par toi **avant** `0006` ; sinon `enable_cron.sql` après |
| Les migrations s'exécutent avec le rôle **postgres** (éditeur SQL du tableau de bord ou connexion directe) | création de déclencheur sur `auth.users`, de règles sur `storage.objects`, de fonctions `SECURITY DEFINER` | à confirmer au premier essai (contrôles 7 et 9) |
| API de données activée, schéma exposé `public` (réglage par défaut) | les appels `rpc/...` et `rest/v1/...` | à confirmer dans Settings → API |
| **Connexions anonymes désactivées** (Auth → Sign In / Providers) | une connexion anonyme reçoit le rôle PostgreSQL `authenticated` : les fonctions `create_booking`, `reveal_contact`, etc. la traiteraient comme un compte | à vérifier ; à confirmer dans la doc |
| Fuseau de la base en UTC (valeur par défaut) | les dates de fin d'abonnement se comparent à `current_date` ; le Burkina Faso est en UTC+0, donc aucun décalage | à confirmer |
| **Aucune clé `service_role`** hors du serveur ; l'application n'en utilise jamais | elle contourne la sécurité par ligne | règle générale |
| Ne **jamais** exécuter `supabase/tests/*` sur ce projet | ils créent un schéma `t`, de faux comptes `@test.local` et des annonces de test | contrôle n°11 |

Particularité Supabase prise en compte : les nouvelles fonctions du schéma `public` sont, par défaut, exécutables par `anon` et
`authenticated` (à confirmer). Chaque fonction sensible de `0005`/`0006` est donc retirée explicitement ; la base de test locale
reproduit ce comportement (`tests/stub.sql`) et le contrôle n°3/4 de `checks.sql` le vérifie sur le vrai projet.

## 2. Appliquer les migrations (une seule fois, dans l'ordre)

1. Créer le projet de préproduction (toi). Activer **pg_cron** (Database → Extensions).
2. Éditeur SQL → nouvelle requête → coller **`0001_init.sql`**, exécuter ; puis `0002`, `0003`, `0004`, `0005`, `0006`, **un fichier à la fois**,
   en vérifiant l'absence d'erreur avant de passer au suivant. Les messages `NOTICE` sont normaux.
3. En cas d'erreur : ne pas corriger à la main. Me transmettre le message ; supprimer le projet et recommencer proprement.
4. (Alternative avancée : Supabase CLI `supabase link` + `supabase db push`. Elle demande un jeton d'accès et le mot de passe de la base,
   que tu saisis **toi-même sur ta machine** ; ils ne me sont jamais transmis.)

## 3. Réglages Auth (tableau de bord, toi)

- E-mail + mot de passe **activé**, **confirmation de l'e-mail obligatoire**, pas de SMS, pas de connexion anonyme, pas de fournisseur tiers.
- Longueur minimale du mot de passe : 8 ou plus. Protection contre les mots de passe divulgués si le plan l'offre (à confirmer).
- **Site URL** et **Redirect URLs** : l'adresse de la préproduction (pas encore connue) — nécessaires à la récupération de mot de passe.
- **SMTP** : le service d'e-mail par défaut est limité (restrictions de destinataires et de débit, à confirmer) ; pour tester avec
  plusieurs adresses, configurer un SMTP personnalisé.
- Limites de débit d'authentification : conserver les valeurs par défaut.

## 4. Premier administrateur (aucune fonction de l'application ne peut le faire)

Après les migrations : Authentication → Users → *Add user* (e-mail confirmé d'office), puis dans l'éditeur SQL :

```sql
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'ADRESSE_ADMIN_A_REMPLACER';
```
(Le profil est créé par le déclencheur de `0005` : l'utilisateur doit donc être créé **après** les migrations.)

## 5. Contrôles SQL en lecture seule (à coller dans l'éditeur SQL)

1. `supabase/preprod/checks.sql` → 13 lignes. Attendu : tout **OK** ; trois lignes **MANUEL** légitimes avant la mise en place complète
   (pg_cron si non activé, administrateur absent, réglages Auth).
2. `supabase/preprod/checks_access.sql` → simule un visiteur puis un utilisateur inconnu et compte les lignes visibles ; attendu : **OK**
   (aucune annonce publiée donc aucune ligne, y compris dans les vues publiques).
Ces deux scripts ont été exécutés **en local** sur une base rejouée propre (résultats cohérents), pas encore sur Supabase.

## 6. Tests via l'API réelle (à exécuter ensemble, après ton accord)

Ils utilisent la clé **publique** `anon` du projet de préproduction et les jetons de comptes de test ; jamais la clé `service_role`.
Remplacer `$URL` et `$ANON` ; `$JWT_A` est le jeton d'un voyageur de test connecté.

| # | Test | Résultat attendu |
|---|---|---|
| 1 | visiteur : `GET $URL/rest/v1/properties`, `/bookings`, `/payment_transactions`, `/profiles`, `/user_roles` (en-tête `apikey: $ANON`) | `[]` ou refus ; jamais de données |
| 2 | visiteur : `GET /rest/v1/public_listings` | `[]` (aucune annonce publiée) |
| 3 | visiteur : `POST /rest/v1/rpc/create_booking`, `confirm_payment`, `reveal_contact`, `set_listing_status` | refus (droits / « Connexion requise ») |
| 4 | inscription d'un voyageur A (e-mail + mot de passe) | e-mail de confirmation reçu ; **connexion impossible avant confirmation** ; profil créé avec le seul rôle `voyageur` |
| 5 | inscription avec `{"role":"admin"}` dans les métadonnées | rôle `voyageur` uniquement |
| 6 | A : `POST /rest/v1/user_roles` `{"role":"admin"}` ; `POST /rest/v1/team_permissions` à son nom | refusés |
| 7 | A : `POST /rest/v1/bookings`, `/payment_transactions` ; `PATCH /rest/v1/bookings` | refusés / 0 ligne |
| 8 | A : `rpc/confirm_payment`, `rpc/grant_owner_role`, `rpc/set_listing_status` | « Action réservée à l'équipe habilitée » |
| 9 | A : `rpc/request_owner_role` puis tentative de créer une annonce | demande enregistrée ; création refusée tant que le rôle n'est pas attribué |
| 10 | récupération de mot de passe | e-mail reçu, lien valide, redirection correcte |
| 11 | parcours complet **sur un jeu de test unique** (1 propriétaire de test, 1 annonce Sérénité de test, 2 voyageurs de test) : réservation, deux réservations simultanées sur les mêmes dates, déclaration « J'ai payé » avec bon puis mauvais montant, confirmation manuelle par un membre « paiements », double confirmation | conforme aux tests locaux ; **jeu de test supprimé ensuite** |
| 12 | Storage : propriétaire envoie une photo dans `<son id>/<id annonce>/x.jpg` ; dans le dossier d'un autre ; fichier > 5 Mo ; fichier non image ; lecture anonyme du bucket ; lien signé d'une photo d'annonce non publiée | seul le 1er cas réussit ; tout le reste refusé |
| 13 | Expiration : créer une réservation de test, la laisser 16 min (ou, plus vite, `update bookings set hold_expires_at = now() - interval '1 minute' where id = '…'` dans l'éditeur SQL) ; surveiller `cron.job_run_details` | statut `expiree` en moins de 2 minutes ; exécutions `succeeded` |
| 14 | Concurrence réelle : deux appels simultanés `rpc/create_booking` (deux terminaux) sur les mêmes dates | un seul succès, l'autre « Ces dates ne sont plus disponibles » |

Rien de ce tableau n'a été exécuté. Les tests 11 et 14 créent des données de test **uniquement dans la préproduction** ; je ne les
préparerai qu'avec ton accord, et aucune donnée de démonstration n'est publiée.

## 7. Après les essais
- Noter les écarts avec les tests locaux ; corriger par une **nouvelle migration** (jamais en modifiant 0001–0006 déjà appliquées).
- Supprimer les comptes et données de test ; relancer `checks.sql` (contrôle n°11 doit repasser à OK).
- Le projet de préproduction reste jetable. La production sera un autre projet, appliqué seulement après validation écrite.

## Annexe A — Abonnement expiré : fermeture immédiate
La règle d'affichage public est **calculée à la lecture** (vue `public_listings` : abonnement
`actif` ET `starts_at <= aujourd'hui < ends_at`). Aucune tâche planifiée n'est nécessaire ; le statut `publiee` de l'annonce
n'est volontairement pas modifié à l'expiration, afin qu'un renouvellement la rende visible aussitôt. Prouvé par les tests de la section J de `tests/0006_functions.sql`.
