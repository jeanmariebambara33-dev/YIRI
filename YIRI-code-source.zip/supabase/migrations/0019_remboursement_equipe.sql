-- YIRI — 0019 : le voyageur n'enclenche plus de remboursement, l'équipe décide.
--
-- Pourquoi. Jusqu'ici, annuler une réservation CRÉAIT un remboursement tout seul, et le site
-- annonçait au voyageur « votre remboursement part vers le compte qui a servi au paiement ».
-- Or YIRI ne peut pas verser automatiquement : le prestataire ne documente aucune opération de
-- remboursement, et son API de versement exige une IP fixe que les fonctions serveur n'ont pas.
-- Le site promettait donc un virement que personne ne pouvait déclencher. Une promesse qu'on ne
-- tient pas vaut moins que pas de promesse du tout.
--
-- Ce qui change : le voyageur peut TOUJOURS annuler — les dates se libèrent immédiatement, ce qui
-- protège le propriétaire — mais plus aucun remboursement n'est créé de son fait, et le site ne
-- lui en promet aucun. Il est renvoyé vers YIRI.
--
-- Ce qui ne change PAS : les barèmes, les tarifs, les règles de réservation, les remboursements
-- DÉJÀ enregistrés, l'historique des paiements, le suivi côté voyageur. Aucune donnée n'est
-- supprimée, aucune ligne de la table refunds n'est touchée.
--
-- Ce que cette migration AJOUTE, et pourquoi c'est indispensable : jusqu'à aujourd'hui,
-- cancel_my_booking était le SEUL endroit de toute la base qui créait un remboursement. Retirer
-- cette création sans rien mettre à la place laisserait l'équipe sans aucun moyen d'en
-- enregistrer un. create_refund() comble exactement ce trou, réservée à l'autorisation
-- « paiements ».
--
-- Ce que cette migration ne prétend PAS faire : elle ne retire aucun droit au voyageur. Elle
-- déplace la décision de l'automate vers une personne. Le voyageur garde l'accès au support YIRI,
-- et les textes du site le disent.

-- =====================================================================
-- 0. Garde : 0010 et 0017 d'abord
-- =====================================================================
do $$
begin
  if to_regprocedure('public.cancel_my_booking(uuid,text)') is null then
    raise exception 'La migration 0010 n''est pas appliquée. Rien n''a été modifié.';
  end if;
  if to_regclass('public.push_subscriptions') is null then
    raise exception 'La migration 0017 n''est pas appliquée. Rien n''a été modifié.';
  end if;
end $$;

-- =====================================================================
-- 1. Annuler, oui. Déclencher un remboursement, non.
-- =====================================================================
-- La signature de retour est conservée à l'identique : le site existant continue de lire les
-- mêmes colonnes, et « mode » vaut désormais toujours « sans_remboursement_auto ».
create or replace function cancel_my_booking(p_booking_id uuid, p_reason text default null)
returns table (booking_status text, refund_id uuid, net_xof int, mode text)
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  q record;
begin
  select * into bk from bookings where id = p_booking_id for update;
  if not found then
    raise exception 'Réservation introuvable.' using errcode = 'P0001';
  end if;

  -- Inchangé : seul le voyageur de cette réservation peut l'annuler.
  if bk.guest_id <> uid then
    raise exception 'Seul le voyageur de cette réservation peut l''annuler.' using errcode = '42501';
  end if;

  -- Inchangé : le barème dit toujours si l'annulation est possible, et à quel palier. On garde
  -- ce calcul pour le JOURNAL — l'équipe doit pouvoir retrouver ce que le barème prévoyait au
  -- moment de l'annulation, sinon elle décide à l'aveugle plus tard.
  select * into q from refund_quote(p_booking_id);
  if not q.cancellable then
    raise exception '%', q.reason using errcode = 'P0001';
  end if;

  update bookings set status = 'annulee', hold_expires_at = null where id = bk.id;

  insert into audit_logs (actor_id, action, entity_type, entity_id, before, after, reason)
  values (uid, 'booking.cancelled_by_guest', 'booking', bk.id::text,
          jsonb_build_object('statut', bk.status),
          jsonb_build_object('statut', 'annulee', 'palier', q.tier, 'taux', q.rate_pct,
                             'encaisse', q.gross_xof, 'frais', q.fees_xof,
                             'net_que_le_bareme_prevoyait', q.net_xof,
                             'remboursement_cree', false),
          left(coalesce(p_reason, 'Annulation par le voyageur'), 200));

  -- Une annulation sur un séjour PAYÉ demande une décision humaine : l'équipe doit la voir.
  -- Rien n'est créé dans refunds ; c'est un signalement, pas un remboursement.
  if q.gross_xof > 0 then
    insert into notifications (user_id, type, payload)
    select distinct x.user_id, 'refund.a_examiner.equipe',
           jsonb_build_object('reservation', bk.id, 'encaisse', q.gross_xof,
                              'net_que_le_bareme_prevoyait', q.net_xof,
                              'palier', q.tier, 'taux', q.rate_pct)
      from (
        select tp.user_id from team_permissions tp where tp.perm = 'paiements'
        union
        select ur.user_id from user_roles ur where ur.role = 'admin'
      ) x;
  end if;

  return query select 'annulee'::text, null::uuid, 0, 'sans_remboursement_auto'::text;
end $$;
revoke all on function cancel_my_booking(uuid, text) from public, anon;
grant execute on function cancel_my_booking(uuid, text) to authenticated;

-- =====================================================================
-- 2. Le devis de remboursement n'est plus montré au voyageur
-- =====================================================================
-- Il annonçait un montant qui ne sera plus versé automatiquement. L'afficher reviendrait à
-- promettre. La fonction reste — l'équipe s'en sert pour décider, et cancel_my_booking l'appelle
-- encore pour le journal — mais elle n'est plus appelable depuis un navigateur par n'importe qui.
--
-- Note technique : cancel_my_booking et create_refund sont SECURITY DEFINER, donc elles
-- continuent d'appeler refund_quote sans que l'appelant ait le moindre droit dessus.
revoke execute on function refund_quote(uuid) from authenticated;

-- =====================================================================
-- 3. L'équipe enregistre un remboursement
-- =====================================================================
-- Remplace, côté équipe, la création automatique qui vient d'être retirée. Sans cette fonction,
-- plus personne au monde ne pourrait créer un remboursement : la table refunds n'accepte aucune
-- écriture directe (0010 a tout révoqué).
create or replace function create_refund(p_booking_id uuid, p_amount_xof int, p_reason text)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  uid uuid := require_user();
  bk bookings%rowtype;
  tx payment_transactions%rowtype;
  q record;
  r refund_rules%rowtype;
  deja int;
  compte text;
  rid uuid;
  statut text;
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  if char_length(coalesce(btrim(p_reason), '')) < 5 then
    raise exception 'Indiquez un motif : il restera au journal et justifie le versement.' using errcode = 'P0001';
  end if;

  select * into bk from bookings where id = p_booking_id for update;
  if not found then
    raise exception 'Réservation introuvable.' using errcode = 'P0001';
  end if;

  select * into tx from payment_transactions
   where booking_id = bk.id and status = 'reussi' order by updated_at desc limit 1;
  if not found then
    raise exception 'Aucun paiement encaissé sur cette réservation : il n''y a rien à rembourser.' using errcode = 'P0001';
  end if;

  select * into q from refund_quote(p_booking_id);
  if p_amount_xof is null or p_amount_xof <= 0 then
    raise exception 'Montant invalide.' using errcode = 'P0001';
  end if;
  -- On ne rend jamais plus que ce qui a été encaissé. Le barème, lui, n'est qu'un avis : l'équipe
  -- peut décider de rendre plus que le palier par geste commercial, mais jamais plus que reçu.
  if p_amount_xof > q.gross_xof then
    raise exception 'Montant supérieur à ce qui a été encaissé (% FCFA).', q.gross_xof using errcode = 'P0001';
  end if;

  -- Un remboursement en cours sur la même réservation : on ne double pas.
  if exists (select 1 from refunds f
              where f.payment_transaction_id = tx.id
                and f.status in ('demande', 'approuve', 'en_cours', 'reussi')) then
    raise exception 'Un remboursement est déjà enregistré sur cette réservation.' using errcode = 'P0001';
  end if;

  -- Les deux garde-fous de 0010 sont conservés tels quels : compte de destination connu, et
  -- plafond journalier. Ils protègent contre une erreur de saisie autant que contre une fraude.
  select * into r from refund_rules where id;
  select a.payer_account into compte from payment_attempts a where a.reference = tx.provider_reference;
  select coalesce(sum(amount_xof), 0) into deja from refunds
   where status in ('approuve', 'en_cours', 'reussi') and created_at >= current_date;

  if compte is null or btrim(compte) = '' or deja + p_amount_xof > r.daily_cap_xof then
    statut := 'demande';     -- reste à débloquer par approve_refund()
  else
    statut := 'approuve';
  end if;

  insert into refunds (payment_transaction_id, amount_xof, reason, status)
  values (tx.id, p_amount_xof, left(btrim(p_reason), 200), statut)
  returning id into rid;

  insert into audit_logs (actor_id, action, entity_type, entity_id, after, reason)
  values (uid, 'refund.created_by_team', 'refund', rid::text,
          jsonb_build_object('montant', p_amount_xof, 'statut', statut, 'reservation', bk.id,
                             'bareme_prevoyait', q.net_xof),
          left(btrim(p_reason), 200));

  insert into notifications (user_id, type, payload)
  values (bk.guest_id, 'refund.enregistre',
          jsonb_build_object('reservation', bk.id, 'montant', p_amount_xof));

  return rid;
end $$;
revoke all on function create_refund(uuid, int, text) from public, anon;
grant execute on function create_refund(uuid, int, text) to authenticated;

-- =====================================================================
-- 4. Ce que l'équipe doit voir pour décider
-- =====================================================================
-- Les annulations sur séjour payé qui n'ont encore donné lieu à aucun remboursement. C'est la
-- liste de travail qui remplace l'automatisme.
create or replace function cancellations_to_review(p_limit int default 50)
returns table (booking_id uuid, guest_id uuid, guest_name text, guest_phone text,
               titre text, ville text, arrivee date, depart date,
               encaisse_xof int, bareme_net_xof int, palier text, taux_pct int,
               annulee_le timestamptz, motif text)
language plpgsql stable security definer set search_path = public, pg_temp as $$
begin
  if not has_perm('paiements') then
    raise exception 'Action réservée à l''équipe habilitée (paiements).' using errcode = '42501';
  end if;
  return query
    select b.id, b.guest_id, pr.full_name, coalesce(b.guest_phone, pr.phone),
           p.title, p.city, lower(b.stay), upper(b.stay),
           coalesce((a.after->>'encaisse')::int, 0),
           coalesce((a.after->>'net_que_le_bareme_prevoyait')::int, 0),
           a.after->>'palier', coalesce((a.after->>'taux')::int, 0),
           a.created_at, a.reason
      from audit_logs a
      join bookings b on b.id::text = a.entity_id
      join properties p on p.id = b.property_id
      join profiles pr on pr.id = b.guest_id
     where a.action = 'booking.cancelled_by_guest'
       and coalesce((a.after->>'encaisse')::int, 0) > 0
       and not exists (
         select 1 from refunds f
           join payment_transactions t on t.id = f.payment_transaction_id
          where t.booking_id = b.id and f.status <> 'echoue')
     order by a.created_at desc
     limit greatest(1, least(coalesce(p_limit, 50), 200));
end $$;
revoke all on function cancellations_to_review(int) from public, anon;
grant execute on function cancellations_to_review(int) to authenticated;
