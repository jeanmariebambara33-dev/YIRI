// Tests de bout en bout de l'annulation par le voyageur et du remboursement (migration 0010).
// Le serveur est REMPLACÉ par une imitation qui applique les MÊMES règles que la base :
//   * seul le voyageur de la réservation peut annuler ;
//   * le montant affiché vient du serveur et c'est celui qui sera versé ;
//   * barème dégressif, frais retenus sur le remboursement ;
//   * deux garde-fous : destination inconnue, plafond journalier ;
//   * le barème n'est modifiable que par un administrateur, et un barème incohérent est refusé.
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";

const URL = "file:///home/claude/yiri/dist/yiri-demo.html";
let fails = 0;
const ok = (l, v) => { if (!v) fails++; console.log(v ? "OK   " : "ECHEC", l); };
const jour = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);

const FAKE = `
const J = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
const DB = {
  regles: { far_days: 7, far_pct: 100, mid_days: 2, mid_pct: 50, near_pct: 0, started_pct: 0, daily_cap_xof: 500000 },
  // b-1 : dans 30 jours, payée 60000, frais 1200, payeur connu   -> remboursement automatique
  // b-2 : demain, payée 40000                                     -> barème « proche », rien à rembourser
  // b-3 : dans 20 jours, payée 50000, payeur INCONNU              -> garde-fou destination
  // b-4 : dans 20 jours, payée 90000, payeur connu                -> garde-fou plafond (abaissé pendant le test)
  bookings: [
    { id: "b-1", property_id: "p-1", guest_id: "v-1", stay: "[" + J(30) + "," + J(33) + ")", guests: 2, nightly_price_xof: 20000, accommodation_xof: 60000, total_xof: 60000, status: "confirmee", hold_expires_at: null, created_at: new Date().toISOString(), paye: 60000, frais: 1200, payeur: "70000001" },
    { id: "b-2", property_id: "p-1", guest_id: "v-1", stay: "[" + J(1) + "," + J(3) + ")", guests: 2, nightly_price_xof: 20000, accommodation_xof: 40000, total_xof: 40000, status: "confirmee", hold_expires_at: null, created_at: new Date().toISOString(), paye: 40000, frais: 800, payeur: "70000002" },
    { id: "b-3", property_id: "p-1", guest_id: "v-1", stay: "[" + J(20) + "," + J(22) + ")", guests: 2, nightly_price_xof: 25000, accommodation_xof: 50000, total_xof: 50000, status: "confirmee", hold_expires_at: null, created_at: new Date().toISOString(), paye: 50000, frais: 0, payeur: null },
    { id: "b-4", property_id: "p-1", guest_id: "v-1", stay: "[" + J(25) + "," + J(28) + ")", guests: 2, nightly_price_xof: 30000, accommodation_xof: 90000, total_xof: 90000, status: "confirmee", hold_expires_at: null, created_at: new Date().toISOString(), paye: 90000, frais: 0, payeur: "70000004" },
  ],
  refunds: [],
  listings: [{ id: "p-1", offer: "gestion", title: "Villa Koulouba", description: "Villa avec jardin", city: "Ouagadougou", district: "Koulouba", capacity: 4, bedrooms: 2, beds: 3, nightly_price_xof: 20000, min_nights: 2, house_rules: null, cancellation_policy: null }],
  roles: [{ role: "voyageur" }],
  perms: [],
  seq: 1,
  signalements: [],
  motifs: [],
};
window.__db = DB;
const UID = "v-1";
const err = (code, message) => ({ data: null, error: { code, message } });
const okRes = (data) => ({ data, error: null });
const estAdmin = () => DB.roles.some((r) => r.role === "admin");
const peut = (p) => estAdmin() || DB.perms.some((x) => x.perm === p);

// La MÊME formule que refund_quote() en base.
function devis(b) {
  const d = Math.round((Date.parse(b.stay.slice(1, 11)) - Date.parse(J(0))) / 86400000);
  const r = DB.regles;
  let tier, pct;
  if (d <= 0) { tier = "commence"; pct = r.started_pct; }
  else if (d > r.far_days) { tier = "loin"; pct = r.far_pct; }
  else if (d >= r.mid_days) { tier = "moyen"; pct = r.mid_pct; }
  else { tier = "proche"; pct = r.near_pct; }
  const g = b.paye || 0, f = b.frais || 0;
  let n = Math.max(0, Math.floor(g * pct / 100) - f);
  n = Math.min(n, g);
  let cancellable = true, reason = null;
  if (["annulee", "terminee", "refusee", "expiree"].includes(b.status)) { cancellable = false; reason = "Cette réservation est déjà close."; }
  else if (b.status === "en_cours") { cancellable = false; reason = "Le séjour est en cours : contactez-nous, l'annulation ne se fait plus en ligne."; }
  return { gross_xof: g, rate_pct: pct, fees_xof: f, net_xof: n, tier, days_before: d, cancellable, reason };
}

function builder(table) {
  const filters = [];
  const run = () => {
    if (table === "public_listings") return okRes(DB.listings.slice());
    if (table === "public_listing_photos") return okRes([]);
    if (table === "bookings") return okRes(DB.bookings.filter((b) => b.guest_id === UID));
    if (table === "profiles") return okRes([{ full_name: "Issa Traore", phone: null }]);
    if (table === "user_roles") return okRes(DB.roles.map((r) => ({ user_id: UID, role: r.role })));
    if (table === "team_permissions") return okRes(DB.perms.map((x) => ({ user_id: UID, perm: x.perm })));
    return okRes([]);
  };
  const exec = () => Promise.resolve(run());
  const self = {
    select() { return self; }, insert() { return self; }, upsert() { return self; }, update() { return self; },
    delete() { return self; }, eq(c, v) { filters.push([c, v]); return self; }, in() { return self; },
    order() { return self; }, limit() { return self; },
    single() { return exec().then((r) => r.error ? r : { data: (r.data || [])[0] ?? null, error: null }); },
    maybeSingle() { return self.single(); }, then(res) { return exec().then(res); },
  };
  return self;
}

const SESSION = { access_token: "jeton", user: { id: UID, email: "issa@test.local" } };
const listeners = [];

window.supabase = { createClient() { return {
  auth: {
    async getSession() { return okRes({ session: localStorage.getItem("fs") ? SESSION : null }); },
    async signInWithPassword() { localStorage.setItem("fs", "1"); listeners.forEach((f) => f("SIGNED_IN", SESSION)); return okRes({ user: SESSION.user, session: SESSION }); },
    async signUp() { return okRes({ user: null, session: null }); },
    async signOut() { localStorage.removeItem("fs"); listeners.forEach((f) => f("SIGNED_OUT", null)); return { error: null }; },
    async resetPasswordForEmail() { return okRes({}); },
    async updateUser() { return okRes({ user: null }); },
    onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
  },
  from: builder,
  rpc(fn, a) {
    a = a || {};
    if (fn === "public_booked_ranges") return Promise.resolve(okRes([]));

    if (fn === "refund_rules_public") {
      const { far_days, far_pct, mid_days, mid_pct, near_pct, started_pct } = DB.regles;
      return Promise.resolve(okRes([{ far_days, far_pct, mid_days, mid_pct, near_pct, started_pct }]));
    }

    // Depuis la migration 0019, la base ne laisse plus un navigateur appeler refund_quote :
    // afficher une estimation reviendrait à promettre un versement que le site ne déclenche plus.
    if (fn === "refund_quote") {
      if (!peut("paiements")) return Promise.resolve(err("42501", "permission denied for function refund_quote"));
      const b = DB.bookings.find((x) => x.id === a.p_booking_id);
      if (!b) return Promise.resolve(err("P0001", "Réservation introuvable."));
      return Promise.resolve(okRes([devis(b)]));
    }

    if (fn === "cancel_my_booking") {
      const b = DB.bookings.find((x) => x.id === a.p_booking_id);
      if (!b) return Promise.resolve(err("P0001", "Réservation introuvable."));
      if (b.guest_id !== UID) return Promise.resolve(err("42501", "Seul le voyageur de cette réservation peut l'annuler."));
      const q = devis(b);
      if (!q.cancellable) return Promise.resolve(err("P0001", q.reason));
      b.status = "annulee";
      // AUCUN remboursement n'est créé : c'est tout l'objet de la migration 0019. Un séjour payé
      // donne lieu à un signalement pour l'équipe, qui décidera.
      if (q.gross_xof > 0) DB.signalements.push({ reservation: b.id, encaisse: q.gross_xof });
      DB.motifs.push(a.p_reason || null);
      return Promise.resolve(okRes([{ booking_status: "annulee", refund_id: null, net_xof: 0,
                                      mode: "sans_remboursement_auto" }]));
    }

    if (fn === "my_refunds") {
      return Promise.resolve(okRes(DB.refunds.filter((r) => r.guest_id === UID).map((r) => ({
        id: r.id, booking_id: r.booking_id, amount_xof: r.amount_xof, status: r.status,
        created_at: r.created_at, settled_at: r.settled_at, failure_reason: r.failure_reason,
      }))));
    }

    if (fn === "refunds_queue") {
      if (!peut("paiements")) return Promise.resolve(err("42501", "Action réservée à l'équipe habilitée (paiements)."));
      const tri = DB.refunds.slice().sort((x, y) => (y.status === "demande") - (x.status === "demande"));
      return Promise.resolve(okRes(tri));
    }

    if (fn === "approve_refund") {
      if (!peut("paiements")) return Promise.resolve(err("42501", "Action réservée à l'équipe habilitée (paiements)."));
      const r = DB.refunds.find((x) => x.id === a.p_refund_id);
      if (!r) return Promise.resolve(err("P0001", "Remboursement introuvable."));
      if (r.status !== "demande") return Promise.resolve(err("P0001", "Ce remboursement n'est plus en attente (statut : " + r.status + ")."));
      r.status = "approuve";
      return Promise.resolve(okRes(r));
    }

    if (fn === "set_refund_rules") {
      if (!estAdmin()) return Promise.resolve(err("42501", "Seul un administrateur peut modifier le barème d'annulation."));
      if (!(a.p_near_pct <= a.p_mid_pct && a.p_mid_pct <= a.p_far_pct) || !(a.p_mid_days <= a.p_far_days)) {
        return Promise.resolve(err("23514", "Barème incohérent : les taux doivent décroître."));
      }
      DB.regles = { far_days: a.p_far_days, far_pct: a.p_far_pct, mid_days: a.p_mid_days, mid_pct: a.p_mid_pct,
                    near_pct: a.p_near_pct, started_pct: a.p_started_pct, daily_cap_xof: a.p_daily_cap_xof };
      return Promise.resolve(okRes(DB.regles));
    }

    return Promise.resolve(okRes(null));
  },
  storage: { from() { return {
    async createSignedUrl() { return okRes({ signedUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E" }); },
    async upload() { return okRes({}); }, async remove() { return okRes({}); }, async list() { return okRes([]); },
  }; } },
}; } };
`;

const b = await chromium.launch({
  executablePath: "/opt/pw-browsers/chromium",
  args: ["--no-sandbox", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--no-first-run"],
});
const ctx = await b.newContext({ viewport: { width: 1280, height: 1200 } });
await ctx.route("**", (r) => (r.request().url().startsWith("file://") ? r.continue() : r.abort()));
await ctx.addInitScript(FAKE);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
const texte = () => p.locator("body").innerText();
// Un rechargement rejouerait addInitScript et remettrait la fausse base à zéro :
// après le premier chargement, on navigue uniquement par le routeur de l'application.
const aller = async (h) => {
  await p.evaluate((x) => { location.hash = x; }, h);
  await p.waitForTimeout(700);
};
// Revenir sur la même adresse ne déclenche rien : on sort puis on rentre pour forcer la relecture.
const rafraichir = async (h) => { await aller("#accueil"); await aller(h); };
// Les rôles et autorisations sont lus à la connexion : les changer exige de se reconnecter.
const reconnexion = async () => {
  await aller("#compte");
  await p.getByRole("button", { name: "Se déconnecter" }).click();
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "issa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(700);
};
const nb = (s) => s.replace(/ | /g, " ");

// =====================================================================
// 1. Les conditions d'annulation sont connues AVANT de réserver
// =====================================================================
await p.goto(URL + "#sejours");
await p.waitForSelector("h1");
await p.waitForTimeout(600);
await p.getByText("Villa Koulouba").first().click();
await p.waitForTimeout(600);
let t = await texte();
ok("la fiche affiche les conditions d'annulation", /Conditions d'annulation/.test(t));
ok("le barème réel y figure, pas un texte inventé", /Plus de 7 jours avant l'arrivée : remboursement intégral/.test(t));
ok("le palier intermédiaire est annoncé", /Entre 2 et 7 jours avant l'arrivée : 50 % rembours/.test(t));
ok("le palier proche est annoncé", /Moins de 2 jours avant l'arrivée : aucun remboursement/.test(t));
ok("les frais à la charge du voyageur sont annoncés", /frais du prestataire de paiement restent à votre charge/.test(t));

// =====================================================================
// 2. Annulation « loin » : remboursement automatique
// =====================================================================
// Connexion par l'interface, comme le ferait une vraie personne.
async function connexion() {
  await aller("#compte");
  await p.waitForSelector("#c-mail");
  await p.fill("#c-mail", "issa@test.local");
  await p.fill("#c-mdp", "motdepasse1");
  await p.getByRole("button", { name: "Se connecter" }).click();
  await p.waitForTimeout(700);
}
await connexion();
ok("la connexion aboutit", !/Se connecter pour/.test(await texte()));
await aller("#mes-sejours");
await p.waitForSelector("h1");
t = await texte();
ok("les réservations du voyageur sont listées", /Mes réservations/.test(t) && /60 000/.test(nb(t)));
ok("le rappel du barème figure aussi dans « Mes réservations »", /Conditions d'annulation/.test(t));

const cartes = p.locator("main div.rounded-2xl").filter({ hasText: jour(30) });
await cartes.first().getByRole("button", { name: "Annuler ma réservation" }).click();
await p.waitForTimeout(500);
t = await texte();

// Ce qui ne doit PLUS apparaître : toute promesse chiffrée de remboursement. Le site ne
// déclenche plus aucun versement, donc annoncer un montant serait un mensonge.
ok("aucun montant de remboursement n'est promis avant d'annuler",
  !/Ce que vous récupérez/.test(t) && !/58 800/.test(nb(t)));
ok("aucun taux de barème n'est présenté comme un dû", !/Barème appliqué/.test(t));
ok("mais le voyageur est averti, noir sur blanc, qu'il n'y a pas de remboursement automatique",
  /aucun\s+remboursement automatique/.test(t.replace(/\s+/g, " ")));
ok("et il sait vers qui se tourner", /équipe YIRI examine chaque cas/i.test(t.replace(/\s+/g, " ")));
ok("on lui rappelle que les dates se libèrent tout de suite", /libère immédiatement les dates/.test(t));

ok("on peut renoncer à annuler", await p.getByRole("button", { name: "Garder ma réservation" }).isVisible());
await p.getByRole("button", { name: "Garder ma réservation" }).click();
await p.waitForTimeout(300);
ok("renoncer referme le bloc sans rien annuler",
  await p.evaluate(() => window.__db.bookings.find((b) => b.id === "b-1").status === "confirmee"));

await cartes.first().getByRole("button", { name: "Annuler ma réservation" }).click();
await p.waitForTimeout(400);
await p.fill(`#c-m-b-1`, "changement de programme");
await p.getByRole("button", { name: "Confirmer l'annulation" }).click();
await p.waitForTimeout(700);
t = await texte();
ok("l'annulation est confirmée à l'écran", /Réservation annulée/.test(t));
ok("la réservation est bien annulée côté serveur",
  await p.evaluate(() => window.__db.bookings.find((b) => b.id === "b-1").status === "annulee"));
ok("AUCUN remboursement n'est créé côté serveur",
  await p.evaluate(() => !window.__db.refunds.some((r) => r.booking_id === "b-1")));
ok("aucun montant n'est annoncé après coup non plus", !/58 800/.test(nb(t)));
ok("le voyageur est renvoyé vers l'équipe YIRI", /écrivez à l'équipe YIRI/.test(t.replace(/\s+/g, " ")));
ok("le motif saisi est tout de même transmis au serveur",
  await p.evaluate(() => window.__db.motifs.some((m) => m === "changement de programme")));
ok("l'équipe est prévenue qu'une annulation payée attend une décision",
  await p.evaluate(() => window.__db.signalements.some((x) => x.reservation === "b-1" && x.encaisse === 60000)));

// =====================================================================
// 3. Le voyageur ne peut pas contourner l'interface
// =====================================================================
// L'écran ne propose plus de devis ; la base, elle, le REFUSE. C'est elle qui décide.
ok("appeler refund_quote depuis la page est refusé par le serveur",
  await p.evaluate(async () => {
    const c = window.supabase.createClient();
    const r = await c.rpc("refund_quote", { p_booking_id: "b-2" });
    return !!r.error;
  }));
ok("le site n'embarque plus aucun appel à refund_quote",
  await p.evaluate(() => !document.documentElement.innerHTML.includes("refund_quote")));

// =====================================================================
// 3 bis. Un séjour impayé n'alerte personne
// =====================================================================
await aller("#mes-sejours");
const proche = p.locator("main div.rounded-2xl").filter({ hasText: jour(1) });
await proche.first().getByRole("button", { name: "Annuler ma réservation" }).click();
await p.waitForTimeout(400);
await p.getByRole("button", { name: "Confirmer l'annulation" }).click();
await p.waitForTimeout(600);
ok("un séjour sans paiement s'annule aussi",
  await p.evaluate(() => window.__db.bookings.find((b) => b.id === "b-2").status === "annulee"));
ok("et ne crée toujours aucun remboursement",
  await p.evaluate(() => !window.__db.refunds.some((r) => r.booking_id === "b-2")));

// =====================================================================
// 4. Les garde-fous de versement ne sont plus l'affaire du voyageur
// =====================================================================
// Compte de destination inconnu, plafond journalier : ces règles existent toujours, mais elles
// s'appliquent maintenant au moment où l'ÉQUIPE enregistre un remboursement (create_refund, testé
// en SQL dans supabase/tests/0019_remboursement.sql). Le voyageur, lui, n'en voit plus rien :
// il ne déclenche plus de versement, donc il n'y a plus de garde-fou à lui expliquer.
await aller("#mes-sejours");
const inconnu = p.locator("main div.rounded-2xl").filter({ hasText: jour(20) });
await inconnu.first().getByRole("button", { name: "Annuler ma réservation" }).click();
await p.waitForTimeout(500);
await p.getByRole("button", { name: "Confirmer l'annulation" }).click();
await p.waitForTimeout(600);
t = await texte();
ok("un séjour payé sans compte de destination connu s'annule quand même",
  await p.evaluate(() => window.__db.bookings.find((b) => b.id === "b-3").status === "annulee"));
ok("sans créer de remboursement",
  await p.evaluate(() => !window.__db.refunds.some((r) => r.booking_id === "b-3")));
ok("et sans parler au voyageur de compte de destination ni de plafond",
  !/compte de destination/.test(t) && !/plafond/i.test(t));
ok("l'équipe reçoit là aussi le signalement",
  await p.evaluate(() => window.__db.signalements.some((x) => x.reservation === "b-3")));

// =====================================================================
// 6. Le refus du serveur remonte à l'écran
// =====================================================================
await p.evaluate(() => { window.__db.bookings.push({
  id: "b-9", property_id: "p-1", guest_id: "v-1", stay: "[" + new Date(Date.now() + 40 * 86400000).toISOString().slice(0, 10) + "," + new Date(Date.now() + 42 * 86400000).toISOString().slice(0, 10) + ")",
  guests: 2, nightly_price_xof: 10000, accommodation_xof: 20000, total_xof: 20000, status: "confirmee",
  hold_expires_at: null, created_at: new Date().toISOString(), paye: 20000, frais: 0, payeur: "70000009" }); });
await rafraichir("#mes-sejours");
const autre = p.locator("main div.rounded-2xl").filter({ hasText: jour(40) });
await autre.first().getByRole("button", { name: "Annuler ma réservation" }).click();
await p.waitForTimeout(400);
// La réservation change de propriétaire juste avant la confirmation : le serveur doit refuser.
await p.evaluate(() => { window.__db.bookings.find((b) => b.id === "b-9").guest_id = "autre"; });
await p.getByRole("button", { name: "Confirmer l'annulation" }).click();
await p.waitForTimeout(600);
t = await texte();
ok("le refus du serveur est affiché tel quel", /Seul le voyageur de cette réservation peut l'annuler/.test(t));
ok("et rien n'a été annulé",
  await p.evaluate(() => window.__db.bookings.find((b) => b.id === "b-9").status === "confirmee"));
await p.evaluate(() => { window.__db.bookings = window.__db.bookings.filter((b) => b.id !== "b-9"); });

// =====================================================================
// 7. L'équipe : la file des remboursements retenus
// =====================================================================
await aller("#equipe");
t = await texte();
ok("un voyageur seul n'accède pas à l'espace équipe", /Accès refusé/.test(t));

// Les remboursements ne naissent plus d'une annulation : c'est l'équipe qui les enregistre
// (create_refund, éprouvée en SQL). On en pose donc deux à la main pour éprouver SON écran, qui
// lui n'a pas changé — et dont la raison d'être est justement devenue centrale.
await p.evaluate(() => {
  window.__db.perms = [{ perm: "paiements" }];
  window.__db.refunds = [
    { id: "r-1", booking_id: "b-1", guest_id: "v-1", amount_xof: 58800, status: "demande",
      reason: "Annulation plus de 30 jours avant", created_at: new Date().toISOString(),
      settled_at: null, provider_reference: null, failure_reason: null, payer_known: true },
    { id: "r-2", booking_id: "b-3", guest_id: "v-1", amount_xof: 20000, status: "demande",
      reason: "Compte du payeur inconnu", created_at: new Date().toISOString(),
      settled_at: null, provider_reference: null, failure_reason: null, payer_known: false },
    { id: "r-3", booking_id: "b-4", guest_id: "v-1", amount_xof: 30000, status: "approuve",
      reason: "Geste commercial decide par l'equipe", created_at: new Date().toISOString(),
      settled_at: null, provider_reference: null, failure_reason: null, payer_known: true },
  ];
});
await reconnexion();
await aller("#equipe");
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Remboursements", exact: true }).click();
await p.waitForTimeout(600);
t = await texte();
ok("l'onglet Remboursements est accessible à l'habilitation « paiements »", /À vérifier/.test(t));
ok("il explique que c'est l'équipe qui enregistre, pas l'annulation du voyageur",
  /n'est plus créé par l'annulation du voyageur/.test(t.replace(/\s+/g, " ")));
ok("les deux remboursements retenus sont listés", /À vérifier \(2\)/.test(t));
ok("la destination inconnue est signalée en clair", /Destination INCONNUE/.test(t));
ok("et l'équipe est avertie que débloquer ne suffira pas", /Débloquer ne suffira pas à envoyer l'argent/.test(t));
ok("un remboursement déjà approuvé figure au suivi", /Suivi/.test(t) && /Prêt à partir/.test(t));

await p.getByRole("button", { name: "Débloquer ce remboursement" }).first().click();
await p.waitForTimeout(700);
ok("le déblocage fait passer le remboursement à « approuve »",
  await p.evaluate(() => window.__db.refunds.filter((r) => r.status === "approuve").length === 2));
t = await texte();
ok("il ne reste qu'un remboursement à vérifier", /À vérifier \(1\)/.test(t));

// =====================================================================
// 8. Le barème : administrateur seulement, et cohérence imposée
// =====================================================================
ok("l'habilitation « paiements » seule ne donne pas accès au barème",
  !/Modifier le barème d'annulation/.test(t));

await p.evaluate(() => { window.__db.roles = [{ role: "voyageur" }, { role: "admin" }]; });
await reconnexion();
await aller("#equipe");
await p.waitForTimeout(300);
await p.getByRole("button", { name: "Remboursements", exact: true }).click();
await p.waitForTimeout(600);
await p.getByRole("button", { name: "Modifier le barème d'annulation" }).click();
await p.waitForTimeout(600);
t = await texte();
ok("l'administrateur accède au barème", /Barème d'annulation/.test(t));
ok("le plafond journalier y est réglable", await p.locator("#b-daily_cap_xof").isVisible());

await p.fill("#b-far_pct", "50");
await p.fill("#b-mid_pct", "100");
await p.getByRole("button", { name: "Enregistrer le barème" }).click();
await p.waitForTimeout(600);
t = await texte();
ok("un barème incohérent est refusé par le serveur", /incohérent/i.test(t));
ok("et rien n'a été enregistré",
  await p.evaluate(() => window.__db.regles.far_pct === 100 && window.__db.regles.mid_pct === 50));

await p.fill("#b-far_pct", "90");
await p.fill("#b-mid_pct", "40");
await p.fill("#b-far_days", "10");
await p.getByRole("button", { name: "Enregistrer le barème" }).click();
await p.waitForTimeout(600);
t = await texte();
ok("un barème cohérent est enregistré", /Barème enregistré/.test(t));
ok("les nouvelles valeurs sont bien celles reçues par le serveur",
  await p.evaluate(() => { const r = window.__db.regles; return r.far_pct === 90 && r.mid_pct === 40 && r.far_days === 10; }));

await aller("#sejours");
await p.getByText("Villa Koulouba").first().click();
await p.waitForTimeout(700);
t = await texte();
ok("le barème affiché au public suit la modification", /Plus de 10 jours avant l'arrivée : 90 % rembours/.test(t));

ok("aucune erreur JavaScript pendant tout le parcours", errs.length === 0);
if (errs.length) console.log("   erreurs :", errs.slice(0, 5).join(" | "));

await b.close();
console.log(fails === 0 ? "\nTOUS LES TESTS D'ANNULATION PASSENT" : `\n${fails} ECHEC(S)`);
process.exit(fails === 0 ? 0 : 1);
