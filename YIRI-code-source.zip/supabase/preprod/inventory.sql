-- YIRI — inventaire LECTURE SEULE du schéma « public » : à lancer après CHAQUE migration et à comparer au tableau attendu
-- (APPLY_PREPROD.md). Ne modifie rien. Les objets installés par des extensions (btree_gist…) sont exclus du décompte.
select
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind = 'r')                      as tables,
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind = 'v')                      as vues,
  (select count(*) from pg_policies where schemaname = 'public')                                                                                     as politiques,
  (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f' and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e'))              as fonctions,
  (select count(*) from pg_trigger t join pg_class c on c.oid = t.tgrelid join pg_namespace n on n.oid = c.relnamespace
     where n.nspname = 'public' and not t.tgisinternal)                                                                                              as declencheurs,
  (select count(*) from pg_type t join pg_namespace n on n.oid = t.typnamespace
     where n.nspname = 'public' and t.typtype = 'e')                                                                                                 as types_enum,
  (select count(*) from pg_indexes where schemaname = 'public')                                                                                      as index;
