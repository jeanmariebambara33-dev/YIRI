// Contraste réel du texte du héros sur le paysage.
//
// On ne devine pas la couleur du fond : on masque le texte, on photographie, et on relève les
// pixels exactement sous chaque bloc. Le seuil retenu est celui du référentiel d'accessibilité :
// 4,5 pour le texte courant, 3 pour le grand texte (24 px, ou 19 px en gras).
import { chromium } from "/opt/npm-tools/node_modules/playwright/index.mjs";
import fs from "node:fs";

const PAGE = "file:///home/claude/yiri/dist/yiri-demo.html";
const BLOCS = [
  { nom: "nom YIRI",          sel: 'main [aria-label="YIRI"]',               couleur: "#f7ecd8", seuil: 3.0 },
  { nom: "accroche",          sel: "main [data-yiri-hero] p:nth-of-type(2)", couleur: "#f7ecd8", seuil: 3.0 },
  { nom: "description",       sel: "main [data-yiri-hero] p:nth-of-type(3)", couleur: "#eadcc4", seuil: 4.5 },
  { nom: "sur-titre",         sel: "main [data-yiri-hero] p:nth-of-type(1)", couleur: "#f7e3c6", seuil: 4.5 },
];

const canal = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
const lum = ([r, g, b]) => 0.2126 * canal(r) + 0.7152 * canal(g) + 0.0722 * canal(b);
const contraste = (a, b) => { const [h, l] = [lum(a), lum(b)].sort((x, y) => y - x); return (h + 0.05) / (l + 0.05); };
const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));

const b = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium", args: ["--no-sandbox"] });
let echecs = 0;

for (const [nom, w, h] of [["bureau", 1280, 800], ["telephone", 390, 844]]) {
  const p = await (await b.newContext({ viewport: { width: w, height: h } })).newPage();
  await p.goto(PAGE);
  await p.waitForSelector("h1");
  if (await p.locator(".yi-intro").count()) {
    await p.evaluate(() => document.querySelector(".yi-passer")?.click());
    await p.waitForSelector(".yi-intro", { state: "detached", timeout: 3000 });
  }
  const boites = {};
  for (const bl of BLOCS) boites[bl.nom] = await p.locator(bl.sel).first().boundingBox();

  // Deux clichés : avec le texte, puis sans. Les pixels qui diffèrent sont EXACTEMENT ceux que
  // les lettres recouvrent. Mesurer toute la boîte du bloc reviendrait à juger la lisibilité sur
  // des endroits où il n'y a aucune lettre — les bords, les interlignes — et à durcir ou relâcher
  // le voile pour de mauvaises raisons.
  const avec = `dist/texte-${nom}.png`;
  const sans = `dist/fond-${nom}.png`;
  await p.screenshot({ path: avec });
  await p.evaluate(() => {
    const e = document.querySelector("main [data-yiri-hero]");
    if (e) e.style.visibility = "hidden";
  });
  await p.screenshot({ path: sans });
  await p.context().close();

  const p2 = await (await b.newContext()).newPage();
  const b64 = (f) => "data:image/png;base64," + fs.readFileSync(f).toString("base64");
  console.log(`\n--- ${nom} ---`);
  for (const bl of BLOCS) {
    const bo = boites[bl.nom];
    if (!bo) { console.log(`  ${bl.nom} : introuvable`); echecs++; continue; }
    const fonds = await p2.evaluate(async ([a, s, box]) => {
      const lire = async (src) => {
        const img = new Image(); img.src = src; await img.decode();
        const c = document.createElement("canvas"); c.width = img.width; c.height = img.height;
        const x = c.getContext("2d"); x.drawImage(img, 0, 0);
        return x.getImageData(Math.max(0, box.x | 0), Math.max(0, box.y | 0),
                              Math.max(1, box.width | 0), Math.max(1, box.height | 0)).data;
      };
      const [A, S] = [await lire(a), await lire(s)];
      const out = [];
      for (let i = 0; i < A.length; i += 4) {
        // un pixel couvert par une lettre : celui qui a changé quand on a masqué le texte
        const d = Math.abs(A[i] - S[i]) + Math.abs(A[i + 1] - S[i + 1]) + Math.abs(A[i + 2] - S[i + 2]);
        if (d > 60) out.push([S[i], S[i + 1], S[i + 2]]);
      }
      return out;
    }, [b64(avec), b64(sans), bo]);

    if (!fonds.length) { console.log(`  ${bl.nom.padEnd(12)} aucun pixel de texte détecté`); echecs++; continue; }
    // Critère : 98 % des pixels de lettres doivent tenir le seuil.
    //
    // Pas le pire pixel : le ciel porte des étoiles de deux pixels, et l'une d'elles derrière une
    // lettre suffisait à faire chuter la note sans gêner la lecture de qui que ce soit. Un seuil
    // qu'on ne peut atteindre qu'en effaçant les étoiles n'est pas un seuil de lisibilité, c'est
    // un artefact de mesure. 2 % laisse passer les éclats isolés et rien d'autre.
    const notes = fonds.map((px) => contraste(px, hex(bl.couleur))).sort((x, y) => x - y);
    const p02 = notes[Math.floor(notes.length * 0.02)];
    const moy = notes.reduce((a, c) => a + c, 0) / notes.length;
    const vu = p02 >= bl.seuil;
    if (!vu) echecs++;
    console.log(`  ${bl.nom.padEnd(12)} ${String(fonds.length).padStart(6)} px   moyen ${moy.toFixed(2)}:1   98e centile ${p02.toFixed(2)}:1   pire ${notes[0].toFixed(2)}:1   minimum ${bl.seuil}   ${vu ? "OK" : "INSUFFISANT"}`);
  }
  await p2.context().close();
}
await b.close();
console.log(echecs === 0 ? "\nLe texte du héros est lisible partout." : `\n${echecs} bloc(s) sous le seuil.`);
process.exit(echecs ? 1 : 0);
