-- Tests de la migration 0020 : notifications manquantes et file d'envoi des courriels.
--
-- Deux choses sont éprouvées ici. D'abord que les trous sont bouchés : le voyageur est prévenu,
-- le propriétaire apprend le sort de son annonce. Ensuite, et surtout, que rien de ce qui
-- marchait n'a été cassé — la 0020 redéfinit un déclencheur validé en 0011, c'est le vrai risque.
\o /dev/null
\ir helpers.sql

insert into auth.users (id, email, raw_user_meta_data)
select t.u(n), 'u' || n || '@test.local', jsonb_build_object('full_name', 'Utilisateur ' || n) from generate_series(1, 9) n;
insert into user_roles (user_id, role) values (t.u(3), 'proprietaire'), (t.u(5), 'admin');
insert into team_permissions (user_id, perm, granted_by) values
  (t.u(6), 'validation', t.u(5)), (t.u(7), 'paiements', t.u(5)), (t.u(8), 'demandes', t.u(5));

insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(1), t.u(3), 'gestion', 'Villa Koulouba', 'd', 'Ouagadougou', 'Koulouba', 'a', 4,2,2, 20000,1, 'soumise', false);
insert into property_photos (property_id, storage_path, position, rights_checked) values (t.p(1), 'x/1.jpg', 0, true);
insert into management_agreements (property_id, contract_version, starts_on, signed, operational_check_done, expense_policy_version)
values (t.p(1), 'v1', current_date, true, true, 'v1');

-- ============ 1. Le voyageur est enfin prévenu ============
reset role;
delete from notifications;
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, guest_phone)
values (t.b(1), t.p(1), t.u(1), daterange(current_date + 10, current_date + 13), 2, 20000, 60000, 60000, 'confirmee', '70000001');

select t.eq('le VOYAGEUR est prévenu que son séjour est payé (il ne l''était pas avant)',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee.voyageur'$$, t.u(1)), '1');
select t.eq('avec le nom du logement',
  format($$select payload->>'logement' from notifications where user_id = %L$$, t.u(1)), 'Villa Koulouba');
select t.eq('le PROPRIÉTAIRE l''est toujours (rien n''a été cassé)',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee'$$, t.u(3)), '1');
select t.eq('l''ÉQUIPE « réservations » aussi',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(7)), '1');
select t.eq('l''administrateur aussi',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.confirmee.equipe'$$, t.u(5)), '1');
select t.eq('l''équipe « demandes » n''a rien à voir ici',
  format($$select count(*)::text from notifications where user_id = %L$$, t.u(8)), '0');
select t.eq('personne ne reçoit deux fois la même chose',
  $$select count(*)::text from (select user_id, type from notifications group by 1,2 having count(*) > 1) x$$, '0');

-- Annulation : même chaîne.
delete from notifications;
update bookings set status = 'annulee' where id = t.b(1);
select t.eq('le voyageur est prévenu de l''annulation',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.annulee.voyageur'$$, t.u(1)), '1');
select t.eq('le propriétaire aussi',
  format($$select count(*)::text from notifications where user_id = %L and type = 'booking.annulee'$$, t.u(3)), '1');

-- Un propriétaire qui réserve chez lui ne doit pas recevoir deux messages pour un seul fait.
delete from notifications;
insert into bookings (id, property_id, guest_id, stay, guests, nightly_price_xof, accommodation_xof, total_xof, status, guest_phone)
values (t.b(2), t.p(1), t.u(3), daterange(current_date + 20, current_date + 23), 2, 20000, 60000, 60000, 'confirmee', '70000003');
select t.eq('le propriétaire qui réserve chez lui n''est prévenu qu''une fois',
  format($$select count(*)::text from notifications where user_id = %L$$, t.u(3)), '1');
select t.eq('et c''est en tant que voyageur',
  format($$select type from notifications where user_id = %L$$, t.u(3)), 'booking.confirmee.voyageur');

-- ============ 2. L'annonce validée : une seule notification, pas deux ============
-- set_listing_status prévient déjà le propriétaire depuis la 0015. Ce test existe pour qu'on ne
-- rajoute jamais un second canal par-dessus, ce qui enverrait deux courriels pour un seul fait.
reset role; delete from notifications;
select t.as(6);
select t.ok('l''équipe valide l''annonce', format($$select set_listing_status(%L, 'approuvee')$$, t.p(1)));
reset role;
select t.eq('le propriétaire apprend que son annonce est validée, UNE seule fois',
  format($$select count(*)::text from notifications where user_id = %L and type = 'listing.approuvee'$$, t.u(3)), '1');
select t.eq('le message porte le nom du logement, pas un identifiant',
  format($$select payload->>'titre' from notifications where user_id = %L and type = 'listing.approuvee'$$, t.u(3)), 'Villa Koulouba');
select t.eq('et l''identifiant de l''annonce, pour faire un lien vers sa fiche',
  format($$select (payload->>'annonce' = %L)::text from notifications where user_id = %L and type = 'listing.approuvee'$$, t.p(1), t.u(3)), 'true');
select t.eq('personne d''autre n''est prévenu', $$select count(*)::text from notifications$$, '1');
select t.eq('aucun déclencheur en double n''a été laissé sur les annonces',
  $$select count(*)::text from pg_trigger where tgrelid = 'properties'::regclass and tgname = 'properties_notify_status'$$, '0');

-- Le refus, avec son motif.
reset role; delete from notifications;
insert into properties (id, owner_id, offer, title, description, city, district, private_address,
                        capacity, bedrooms, beds, nightly_price_xof, min_nights, status, is_demo)
values (t.p(2), t.u(3), 'annonce', 'Studio Zogona', 'd', 'Ouagadougou', 'Zogona', 'a', 2,1,1, 12000,1, 'soumise', false);
select t.as(6);
select t.ok('l''équipe renvoie une annonce en correction',
  format($$select set_listing_status(%L, 'a_corriger', 'Les photos sont floues, merci de les reprendre.')$$, t.p(2)));
reset role;
select t.eq('le propriétaire apprend qu''il doit corriger',
  format($$select count(*)::text from notifications where user_id = %L and type = 'listing.a_corriger'$$, t.u(3)), '1');
select t.eq('et le motif voyage avec le message',
  format($$select payload->>'note' from notifications where user_id = %L and type = 'listing.a_corriger'$$, t.u(3)),
  'Les photos sont floues, merci de les reprendre.');

-- ============ 3. La file des courriels ============
reset role;
delete from notifications;
insert into notifications (user_id, type, payload) values
  (t.u(1), 'booking.confirmee.voyageur', '{"logement": "Villa"}'),   -- éligible
  (t.u(3), 'listing.approuvee', '{"logement": "Villa"}'),            -- éligible
  (t.u(7), 'booking.confirmee.equipe', '{}'),                        -- éligible (paiements)
  (t.u(6), 'booking.confirmee.equipe', '{}'),                        -- PAS son autorisation
  (t.u(7), 'refund.a_examiner.equipe', '{}'),                        -- éligible
  (t.u(6), 'subscription.expiree.equipe', '{}'),                     -- autorisé mais NON éligible au courriel
  (t.u(1), 'identity.verifiee', '{}');                               -- non éligible au courriel

select t.eq('la file ne retient que les événements choisis',
  $$select count(*)::text from email_pending(100)$$, '4');
select t.eq('le voyageur y est', format($$select count(*)::text from email_pending(100) where user_id = %L$$, t.u(1)), '1');
select t.eq('le propriétaire aussi', format($$select count(*)::text from email_pending(100) where user_id = %L$$, t.u(3)), '1');
select t.eq('l''équipe « paiements » reçoit ses deux alertes',
  format($$select count(*)::text from email_pending(100) where user_id = %L$$, t.u(7)), '2');
select t.eq('qui n''a pas l''autorisation ne reçoit pas de courriel non plus',
  format($$select count(*)::text from email_pending(100) where user_id = %L$$, t.u(6)), '0');
select t.eq('une alerte sans intérêt par courriel reste sur le téléphone seulement',
  $$select count(*)::text from email_pending(100) where type = 'subscription.expiree.equipe'$$, '0');
select t.eq('l''adresse du destinataire est fournie',
  format($$select destinataire from email_pending(100) where user_id = %L$$, t.u(1)), 'u1@test.local');
select t.eq('et son nom, pour écrire « Bonjour X »',
  format($$select nom from email_pending(100) where user_id = %L$$, t.u(1)), 'Utilisateur 1');

-- Sans adresse, pas de courriel : on ne met pas une ligne vide dans la file.
update profiles set email = null where id = t.u(1);
update auth.users set email = null where id = t.u(1);
select t.eq('sans adresse connue, la notification n''entre pas dans la file',
  format($$select count(*)::text from email_pending(100) where user_id = %L$$, t.u(1)), '0');
update auth.users set email = 'u1@test.local' where id = t.u(1);

-- ============ 4. Pas deux fois le même courriel ============
select t.eq('marquer envoyé sort de la file',
  $$select email_mark_sent(array(select notification_id from email_pending(100)))::text$$, '4');
select t.eq('la file est vide', $$select count(*)::text from email_pending(100)$$, '0');
-- On remarque envoyées EXACTEMENT les mêmes : aucune ne doit repartir.
select t.eq('et remarquer envoyées les mêmes ne change rien',
  $$select email_mark_sent(array(select id from notifications where emailed_at is not null))::text$$, '0');

-- Trois échecs et on arrête : une adresse morte ne doit pas être réessayée indéfiniment.
delete from notifications;
insert into notifications (user_id, type, payload) values (t.u(3), 'listing.approuvee', '{}');
select t.eq('un échec laisse la notification dans la file',
  $$select email_mark_failed(array(select id from notifications), 'adresse rejetee par le service')::text$$, '1');
select t.eq('elle y est encore', $$select count(*)::text from email_pending(100)$$, '1');
select t.eq('et la raison est gardée, pour comprendre',
  $$select email_error from notifications$$, 'adresse rejetee par le service');
select t.ok('deuxième échec', $$select email_mark_failed(array(select id from notifications))$$);
select t.ok('troisième échec', $$select email_mark_failed(array(select id from notifications))$$);
select t.eq('au bout de trois, on cesse d''insister', $$select count(*)::text from email_pending(100)$$, '0');
select t.eq('mais la notification reste lisible dans le site',
  $$select count(*)::text from notifications$$, '1');

-- Rien de vieux.
delete from notifications;
insert into notifications (user_id, type, payload, created_at)
values (t.u(3), 'listing.approuvee', '{}', now() - interval '5 days');
select t.eq('une alerte de la semaine dernière n''est pas envoyée maintenant',
  $$select count(*)::text from email_pending(100)$$, '0');

-- ============ 5. Fermé au navigateur ============
reset role; select t.as(5);
select t.must_fail('un administrateur ne lit pas la file des courriels', $$select * from email_pending(10)$$);
select t.must_fail('ni ne marque un courriel comme envoyé', $$select email_mark_sent(array[]::uuid[])$$);
select t.must_fail('ni comme échoué', $$select email_mark_failed(array[]::uuid[])$$);
select t.as(7);
select t.must_fail('l''équipe « paiements » non plus', $$select * from email_pending(10)$$);
select t.as(0);
select t.must_fail('un visiteur encore moins', $$select * from email_pending(10)$$);
select t.as(1);
select t.must_fail('un voyageur ne lit pas l''adresse des autres', $$select * from email_pending(10)$$);

-- ============ 6. Le réglage d'adresse n'est pas un secret ============
reset role;
select t.eq('l''adresse de la fonction d''envoi de courriels est posée',
  $$select count(*)::text from public_settings where key = 'email_function_url'$$, '1');
select t.eq('et ne contient aucune clé',
  $$select count(*)::text from public_settings where value ~* '(^sk_|^xkeysib|BEGIN [A-Z ]*PRIVATE)'$$, '0');

-- ============ Résultat ============
reset role;
\o
select count(*) filter (where pass) || ' / ' || count(*) || ' tests 0020 réussis' as resultat from t.results;
select label, coalesce(detail, '') as detail from t.results where not pass order by id;
