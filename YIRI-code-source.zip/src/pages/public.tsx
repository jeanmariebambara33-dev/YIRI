// Page d'accueil.
//
// Ce fichier contenait aussi un catalogue, une fiche de logement, une page de paiement et un
// « J'ai effectué le paiement » qui ne faisaient que modifier le navigateur : un décor, hérité
// de la maquette. Aucune route n'y menait plus — le vrai parcours est dans voyage.tsx, branché
// à la base — mais le code partait quand même dans le site livré. Un faux écran de paiement
// qui dort dans la page livrée est un faux écran de paiement : supprimé.
import { Icon, NEEDS } from "./owners";
import { useStore } from "../store";
import { HeroScene, HeroContenu, OwnerScene } from "../hero";

export function Home() {
  const { go } = useStore();
  return (
    <div className="flex flex-col gap-16 pb-10">
      <section data-yiri-scene className="relative isolate flex min-h-[720px] items-center justify-center overflow-hidden">
        <HeroScene />
        <HeroContenu onDecouvrir={() => go({ name: "catalogue" })} />
      </section>

      <div className="mx-auto flex w-full max-w-6xl flex-col gap-16 px-4 sm:px-6">
      <section aria-labelledby="owners-h" className="flex flex-col overflow-hidden rounded-3xl bg-[#1a0f12] text-[#f7ecd8]">
        <div className="relative isolate flex min-h-[560px] flex-col justify-center gap-4 px-6 pb-16 pt-14 sm:px-12">
          <OwnerScene />
          <p className="text-xs font-bold uppercase tracking-[0.2em] opacity-80">Pour les propriétaires</p>
          <h2 id="owners-h" className="whitespace-nowrap font-display text-[clamp(1.4rem,6vw,4rem)] font-extrabold leading-[1.05] tracking-tight">Votre logement mérite plus.</h2>
          <p className="max-w-[54ch] text-lg leading-relaxed opacity-95">Vous possédez un appartement, une maison ou un logement meublé ? YIRI vous aide à le présenter aux voyageurs et vous permet de choisir comment vous souhaitez gérer sa location.</p>
          <p className="max-w-[54ch] leading-relaxed opacity-90">Vous gardez la main sur votre activité, ou vous choisissez un accompagnement adapté à vos besoins.</p>
          <p className="max-w-[54ch] font-semibold leading-relaxed">Aujourd'hui, vous voyagez avec YIRI. Demain, c'est peut-être votre logement qui accueille.</p>
        </div>

        <div className="flex flex-col gap-10 px-6 pb-12 sm:px-12">
          <div className="flex flex-col gap-4">
            <h3 className="font-display text-xl font-bold">Comment souhaitez-vous louer votre logement ?</h3>
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {NEEDS.map((n) => (
                <li key={n.id}>
                  <button onClick={() => go({ name: "proprietaires", need: n.id })} className="flex h-full w-full flex-col gap-3 rounded-2xl border border-white/15 bg-white/10 p-5 text-left transition-colors hover:bg-white/20 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f2b27a]">
                    <Icon name={n.icon} />
                    <span className="font-display text-lg font-bold leading-snug">{n.title}</span>
                    <span className="text-sm opacity-85">{n.text}</span>
                    <span className="mt-auto pt-1 text-sm font-semibold">Voir la solution <span aria-hidden="true">→</span></span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div className="flex flex-col items-center gap-5 border-t border-white/25 pt-10 text-center">
            <h3 className="max-w-[24ch] font-display text-[clamp(1.7rem,4.2vw,2.8rem)] font-extrabold leading-[1.08] tracking-tight text-balance">Votre logement peut être la prochaine belle découverte sur YIRI.</h3>
            <p className="max-w-[54ch] text-lg leading-relaxed opacity-90">Présentez votre bien, choisissez la façon dont vous souhaitez le gérer et découvrez la solution adaptée à votre situation.</p>
            <div className="flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
              <button onClick={() => go({ name: "proprietaires", at: "solutions" })} className="inline-flex items-center justify-center gap-2 rounded-full bg-[#f2b27a] px-9 py-4 text-lg font-extrabold text-[#2a1a12] shadow-[0_12px_40px_-10px_rgb(242_178_122/0.55)] transition-colors hover:bg-[#f8c595] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]">
                Commencer avec YIRI <span aria-hidden="true">→</span>
              </button>
              <button onClick={() => go({ name: "demande", pack: "indecis" })} className="inline-flex items-center justify-center rounded-full border border-[#f7ecd8]/60 px-9 py-4 text-lg font-bold transition-colors hover:bg-white/10 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#f8c595]">
                Poser une question
              </button>
            </div>
          </div>
        </div>
      </section>
      </div>
    </div>
  );
}
