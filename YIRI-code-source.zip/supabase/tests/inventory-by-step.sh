#!/usr/bin/env bash
# Rejoue 0001→0006 sur une base locale vide et affiche l'inventaire (preprod/inventory.sql) après CHAQUE migration.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; MIG="$HERE/../migrations"
BIN="${PG_BIN:-/usr/lib/postgresql/16/bin}"; D=/var/tmp/yiri-db-inv; PORT=5547
rm -rf "$D"; mkdir -p "$D"; chown postgres "$D"
su postgres -c "$BIN/initdb -D $D/data -U postgres -A trust >/dev/null && $BIN/pg_ctl -D $D/data -o '-p $PORT -k /tmp' -l $D/log -w start >/dev/null"
trap 'su postgres -c "$BIN/pg_ctl -D $D/data stop >/dev/null 2>&1" || true; rm -rf "$D"' EXIT
P="psql -h /tmp -p $PORT -U postgres -v ON_ERROR_STOP=1 -q"
$P -c "create database inv" && $P -d inv -f "$HERE/stub.sql" -f "$HERE/stub_storage.sql" >/dev/null
echo "migration | tables | vues | politiques | fonctions | declencheurs | types_enum | index"
for f in "$MIG"/0*.sql; do
  $P -d inv -f "$f" >/dev/null 2>&1
  r=$($P -d inv -t -A -F ' | ' -f "$HERE/../preprod/inventory.sql")
  echo "$(basename "$f" .sql | cut -c1-4) | $r"
done
